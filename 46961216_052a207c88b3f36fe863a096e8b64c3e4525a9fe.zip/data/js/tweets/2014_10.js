Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528393739501199360",
  "text" : "I am giving trick or treat n kids LEDs \n\nWITH WARNINGS NOT TO CONSUME",
  "id" : 528393739501199360,
  "created_at" : "2014-11-01 03:50:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528305249736736768",
  "text" : "halloween costume a giant negative-value greenback, with me in the center as figurehead, wearing ronald reagan mask.",
  "id" : 528305249736736768,
  "created_at" : "2014-10-31 21:59:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/NYffnDBojO",
      "expanded_url" : "http:\/\/nautil.us\/issue\/6\/secret-codes\/teaching-me-softly",
      "display_url" : "nautil.us\/issue\/6\/secret\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528297909243371520",
  "text" : "good articles on AI and ML at nautilus like http:\/\/t.co\/NYffnDBojO",
  "id" : 528297909243371520,
  "created_at" : "2014-10-31 21:30:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528281308167143424",
  "geo" : { },
  "id_str" : "528297822102507520",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr :yawn:",
  "id" : 528297822102507520,
  "in_reply_to_status_id" : 528281308167143424,
  "created_at" : "2014-10-31 21:29:50 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chorizo",
      "screen_name" : "tupactopus",
      "indices" : [ 0, 11 ],
      "id_str" : "1317798079",
      "id" : 1317798079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528283323635101696",
  "geo" : { },
  "id_str" : "528297570544922624",
  "in_reply_to_user_id" : 1317798079,
  "text" : "@tupactopus  mesothelioma is one of the highest paid keywords in all of internet advertising, so take pics and make a website 4 $$$",
  "id" : 528297570544922624,
  "in_reply_to_status_id" : 528283323635101696,
  "created_at" : "2014-10-31 21:28:50 +0000",
  "in_reply_to_screen_name" : "tupactopus",
  "in_reply_to_user_id_str" : "1317798079",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528257593349640193",
  "text" : "YES PLEASE SHARE ME I LUV IT",
  "id" : 528257593349640193,
  "created_at" : "2014-10-31 18:49:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528257506804379648",
  "text" : "I REPRESENT GRAPHICAL DESIGN AND ALSO *REAL* UX DESIGN TOO HOLLAR",
  "id" : 528257506804379648,
  "created_at" : "2014-10-31 18:49:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528256812181880832",
  "text" : "I HAVE A GENIUS WRITER LIVING WITH ME EARNING BEANS WRITING SEO BLOGS\n\nHOLLAR FOR SOME PRIMO ENGLISH \/ SPANISH \/ CHINESE TEXTS AND DOCS BABY",
  "id" : 528256812181880832,
  "created_at" : "2014-10-31 18:46:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528255552791797760",
  "text" : "my financial style is that of the cobra",
  "id" : 528255552791797760,
  "created_at" : "2014-10-31 18:41:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528253488401092611",
  "text" : "PS GREP THANKS",
  "id" : 528253488401092611,
  "created_at" : "2014-10-31 18:33:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528253304740921344",
  "text" : "HAY HACKERS\n\nTELL YOUR FRIENDS THEY CAN PUT THIS BAD MOTHER SON OF A ON CODING RETAINER FOR ALL MYRIAD OF WIZARDRY CONSULTATION &amp; CODA.",
  "id" : 528253304740921344,
  "created_at" : "2014-10-31 18:32:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527582733003141121",
  "text" : "abody use jabs n feints to move into what a want",
  "id" : 527582733003141121,
  "created_at" : "2014-10-29 22:08:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527582632469884928",
  "text" : "Johnny \"Dog Fighter\" Lincoln",
  "id" : 527582632469884928,
  "created_at" : "2014-10-29 22:07:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 3, 11 ],
      "id_str" : "33519541",
      "id" : 33519541
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 13, 26 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527530526370836480",
  "text" : "RT @pfrazee: @johnnyscript teach it your kung fu ways",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "527527869275074560",
    "geo" : { },
    "id_str" : "527528851312615424",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript teach it your kung fu ways",
    "id" : 527528851312615424,
    "in_reply_to_status_id" : 527527869275074560,
    "created_at" : "2014-10-29 18:34:13 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "protected" : false,
      "id_str" : "33519541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672088610703740929\/zJPdcWbU_normal.jpg",
      "id" : 33519541,
      "verified" : false
    }
  },
  "id" : 527530526370836480,
  "created_at" : "2014-10-29 18:40:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527524567602847744",
  "geo" : { },
  "id_str" : "527527869275074560",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript   what does i do?",
  "id" : 527527869275074560,
  "in_reply_to_status_id" : 527524567602847744,
  "created_at" : "2014-10-29 18:30:19 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527524567602847744",
  "text" : "I sheltered a young and gentle but large and rambunctious pit bull.  I was out doing muh kung fu and he was on the run scaring everyone.",
  "id" : 527524567602847744,
  "created_at" : "2014-10-29 18:17:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian A. Sinclair",
      "screen_name" : "brianarn",
      "indices" : [ 0, 9 ],
      "id_str" : "118963",
      "id" : 118963
    }, {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 10, 24 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527138210724343808",
  "geo" : { },
  "id_str" : "527323794264694785",
  "in_reply_to_user_id" : 118963,
  "text" : "@brianarn @jesusabdullah \n\nAND SO CAN YOU!!!",
  "id" : 527323794264694785,
  "in_reply_to_status_id" : 527138210724343808,
  "created_at" : "2014-10-29 04:59:24 +0000",
  "in_reply_to_screen_name" : "brianarn",
  "in_reply_to_user_id_str" : "118963",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527321427985170432",
  "text" : "a packed stadium audience generator for canvas and webGL, with and without cellphone camera flashes.  the DIY filmmaking world needs this.",
  "id" : 527321427985170432,
  "created_at" : "2014-10-29 04:50:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527241715275419648",
  "geo" : { },
  "id_str" : "527244378843402242",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove it's good to plan ahead",
  "id" : 527244378843402242,
  "in_reply_to_status_id" : 527241715275419648,
  "created_at" : "2014-10-28 23:43:50 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527241341995339776",
  "text" : "is forgot present or past?",
  "id" : 527241341995339776,
  "created_at" : "2014-10-28 23:31:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/qPhRAMsW28",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/xx_factor\/2014\/10\/28\/street_harassment_video_a_hidden_camera_records_what_women_go_through_on.html?wpsrc=sh_all_dt_tw_bot",
      "display_url" : "slate.com\/blogs\/xx_facto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527240504019525632",
  "text" : "RT @marinakukso: walking while female: http:\/\/t.co\/qPhRAMsW28 if you don't get why it blows, watch the vid &amp; try to imagine that being your\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/qPhRAMsW28",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/xx_factor\/2014\/10\/28\/street_harassment_video_a_hidden_camera_records_what_women_go_through_on.html?wpsrc=sh_all_dt_tw_bot",
        "display_url" : "slate.com\/blogs\/xx_facto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527190974876114944",
    "text" : "walking while female: http:\/\/t.co\/qPhRAMsW28 if you don't get why it blows, watch the vid &amp; try to imagine that being your everyday.",
    "id" : 527190974876114944,
    "created_at" : "2014-10-28 20:11:37 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 527240504019525632,
  "created_at" : "2014-10-28 23:28:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527110348755591169",
  "text" : "my positive ape index",
  "id" : 527110348755591169,
  "created_at" : "2014-10-28 14:51:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 0, 8 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526854335389777920",
  "geo" : { },
  "id_str" : "526864957900865536",
  "in_reply_to_user_id" : 433715578,
  "text" : "@Gyselie  smh",
  "id" : 526864957900865536,
  "in_reply_to_status_id" : 526854335389777920,
  "created_at" : "2014-10-27 22:36:09 +0000",
  "in_reply_to_screen_name" : "Gyselie",
  "in_reply_to_user_id_str" : "433715578",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Matonis",
      "screen_name" : "jonmatonis",
      "indices" : [ 3, 14 ],
      "id_str" : "101580574",
      "id" : 101580574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526864902531866624",
  "text" : "RT @jonmatonis: The concept of financial privacy is very simple. It's just like email privacy, but for your money.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526773874734923776",
    "text" : "The concept of financial privacy is very simple. It's just like email privacy, but for your money.",
    "id" : 526773874734923776,
    "created_at" : "2014-10-27 16:34:13 +0000",
    "user" : {
      "name" : "Jon Matonis",
      "screen_name" : "jonmatonis",
      "protected" : false,
      "id_str" : "101580574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518421962649915392\/2TCu0_B4_normal.png",
      "id" : 101580574,
      "verified" : false
    }
  },
  "id" : 526864902531866624,
  "created_at" : "2014-10-27 22:35:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526819061091401728",
  "text" : "neo, u have a choice, u gonna take the serious pill, or the goofy pill?",
  "id" : 526819061091401728,
  "created_at" : "2014-10-27 19:33:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK LOVE",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 0, 12 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526460563904163840",
  "geo" : { },
  "id_str" : "526486325667856384",
  "in_reply_to_user_id" : 15819295,
  "text" : "@JUNGLEPUSSY   &gt;_________&lt;",
  "id" : 526486325667856384,
  "in_reply_to_status_id" : 526460563904163840,
  "created_at" : "2014-10-26 21:31:36 +0000",
  "in_reply_to_screen_name" : "JUNGLEPUSSY",
  "in_reply_to_user_id_str" : "15819295",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chorizo",
      "screen_name" : "tupactopus",
      "indices" : [ 0, 11 ],
      "id_str" : "1317798079",
      "id" : 1317798079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526477865773465600",
  "geo" : { },
  "id_str" : "526485568017170435",
  "in_reply_to_user_id" : 1317798079,
  "text" : "@tupactopus THE STREETS IS ABOUT WHAT U AINT GOT",
  "id" : 526485568017170435,
  "in_reply_to_status_id" : 526477865773465600,
  "created_at" : "2014-10-26 21:28:35 +0000",
  "in_reply_to_screen_name" : "tupactopus",
  "in_reply_to_user_id_str" : "1317798079",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526485212453425152",
  "text" : "throw that in the dumbass mufffuckin piece o shit bin",
  "id" : 526485212453425152,
  "created_at" : "2014-10-26 21:27:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526255848054472704",
  "text" : "Visual timbre",
  "id" : 526255848054472704,
  "created_at" : "2014-10-26 06:15:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526242105643909124",
  "text" : "Guess I ll be here getting the party ending started",
  "id" : 526242105643909124,
  "created_at" : "2014-10-26 05:21:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0E3FtcDrak",
      "screen_name" : "btcdrak",
      "indices" : [ 0, 8 ],
      "id_str" : "1387081490",
      "id" : 1387081490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526234128539484160",
  "geo" : { },
  "id_str" : "526240367041974272",
  "in_reply_to_user_id" : 1387081490,
  "text" : "@btcdrak not true.  Clearly a bot.  Makes many odd tx --17K+",
  "id" : 526240367041974272,
  "in_reply_to_status_id" : 526234128539484160,
  "created_at" : "2014-10-26 05:14:15 +0000",
  "in_reply_to_screen_name" : "btcdrak",
  "in_reply_to_user_id_str" : "1387081490",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 0, 14 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526131752805212160",
  "geo" : { },
  "id_str" : "526136778348978176",
  "in_reply_to_user_id" : 379919160,
  "text" : "@MikolaLysenko  U CAUGHT THEM NOW UNMASK THE TRUE SHADOW DOM",
  "id" : 526136778348978176,
  "in_reply_to_status_id" : 526131752805212160,
  "created_at" : "2014-10-25 22:22:37 +0000",
  "in_reply_to_screen_name" : "MikolaLysenko",
  "in_reply_to_user_id_str" : "379919160",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/IuWeQELgnH",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/webworkify",
      "display_url" : "npmjs.org\/package\/webwor\u2026"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/t8fG5y5r0O",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/iframarfi",
      "display_url" : "npmjs.org\/package\/iframa\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/1GzWjZ0RMS",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/abre",
      "display_url" : "npmjs.org\/package\/abre"
    } ]
  },
  "geo" : { },
  "id_str" : "526135942726180867",
  "text" : "the browserify trifecta is complete: web workers, iframes, popups\n\nhttps:\/\/t.co\/IuWeQELgnH\n\nhttps:\/\/t.co\/t8fG5y5r0O\n\nhttps:\/\/t.co\/1GzWjZ0RMS",
  "id" : 526135942726180867,
  "created_at" : "2014-10-25 22:19:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526135473626836992",
  "text" : "I published a fork of a module from the node_modules directory of a published module in a branch of a published module, its easier this way.",
  "id" : 526135473626836992,
  "created_at" : "2014-10-25 22:17:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526075928539959296",
  "text" : "12:21 &lt; domanic&gt; hey I figured out the problem\n\n12:36 -!- domanic has quit",
  "id" : 526075928539959296,
  "created_at" : "2014-10-25 18:20:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/o496eYxb7n",
      "expanded_url" : "http:\/\/www.vis.uni-stuttgart.de\/~grave\/diss\/Diss_Grave_2010.pdf",
      "display_url" : "vis.uni-stuttgart.de\/~grave\/diss\/Di\u2026"
    }, {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/6G2pi1ET8x",
      "expanded_url" : "http:\/\/www.vis.uni-stuttgart.de\/~grave\/diss\/Grave_Dissertation_Goedel_2010.html",
      "display_url" : "vis.uni-stuttgart.de\/~grave\/diss\/Gr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526050669178789889",
  "text" : "neat\nhttp:\/\/t.co\/o496eYxb7n\n\ngoto bottom for star trek opening sequence in a godel universe\nhttp:\/\/t.co\/6G2pi1ET8x",
  "id" : 526050669178789889,
  "created_at" : "2014-10-25 16:40:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hold My Beer",
      "screen_name" : "HoldThisBeer",
      "indices" : [ 3, 16 ],
      "id_str" : "2325445944",
      "id" : 2325445944
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HoldThisBeer\/status\/511222054725484544\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/uI51pyaR2i",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Bxg5vyXIMAAer8f.png",
      "id_str" : "511222050841964544",
      "id" : 511222050841964544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Bxg5vyXIMAAer8f.png",
      "sizes" : [ {
        "h" : 218,
        "resize" : "fit",
        "w" : 298
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 298
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 298
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 298
      } ],
      "display_url" : "pic.twitter.com\/uI51pyaR2i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525687193369448448",
  "text" : "RT @HoldThisBeer: Hold my beer while I launch this TV to the third floor http:\/\/t.co\/uI51pyaR2i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HoldThisBeer\/status\/511222054725484544\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/uI51pyaR2i",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Bxg5vyXIMAAer8f.png",
        "id_str" : "511222050841964544",
        "id" : 511222050841964544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Bxg5vyXIMAAer8f.png",
        "sizes" : [ {
          "h" : 218,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 298
        } ],
        "display_url" : "pic.twitter.com\/uI51pyaR2i"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511222054725484544",
    "text" : "Hold my beer while I launch this TV to the third floor http:\/\/t.co\/uI51pyaR2i",
    "id" : 511222054725484544,
    "created_at" : "2014-09-14 18:36:50 +0000",
    "user" : {
      "name" : "Hold My Beer",
      "screen_name" : "HoldThisBeer",
      "protected" : false,
      "id_str" : "2325445944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511107589631782912\/9MHR-95h_normal.jpeg",
      "id" : 2325445944,
      "verified" : false
    }
  },
  "id" : 525687193369448448,
  "created_at" : "2014-10-24 16:36:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hold My Beer",
      "screen_name" : "HoldThisBeer",
      "indices" : [ 3, 16 ],
      "id_str" : "2325445944",
      "id" : 2325445944
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HoldThisBeer\/status\/518603703243128832\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/iNFmOgcIaw",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BzJzUS-CIAA0wkx.png",
      "id_str" : "518603699627630592",
      "id" : 518603699627630592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BzJzUS-CIAA0wkx.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 210
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 210
      } ],
      "display_url" : "pic.twitter.com\/iNFmOgcIaw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525685041511141376",
  "text" : "RT @HoldThisBeer: Hold my beer while I look over this railing http:\/\/t.co\/iNFmOgcIaw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HoldThisBeer\/status\/518603703243128832\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/iNFmOgcIaw",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BzJzUS-CIAA0wkx.png",
        "id_str" : "518603699627630592",
        "id" : 518603699627630592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BzJzUS-CIAA0wkx.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 210
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 210
        } ],
        "display_url" : "pic.twitter.com\/iNFmOgcIaw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518603703243128832",
    "text" : "Hold my beer while I look over this railing http:\/\/t.co\/iNFmOgcIaw",
    "id" : 518603703243128832,
    "created_at" : "2014-10-05 03:28:52 +0000",
    "user" : {
      "name" : "Hold My Beer",
      "screen_name" : "HoldThisBeer",
      "protected" : false,
      "id_str" : "2325445944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511107589631782912\/9MHR-95h_normal.jpeg",
      "id" : 2325445944,
      "verified" : false
    }
  },
  "id" : 525685041511141376,
  "created_at" : "2014-10-24 16:27:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525676676487708672",
  "text" : "the nodej.s website has been getting worsified more.  now the docs are ugly af.  They are off by several with that green.",
  "id" : 525676676487708672,
  "created_at" : "2014-10-24 15:54:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525508494855012352",
  "text" : "rewriting the wheel",
  "id" : 525508494855012352,
  "created_at" : "2014-10-24 04:46:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525419225696206854",
  "text" : "Capitalism wants me to feel like a sucker for being nice.",
  "id" : 525419225696206854,
  "created_at" : "2014-10-23 22:51:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525318094084792320",
  "text" : "something like a phenomnom",
  "id" : 525318094084792320,
  "created_at" : "2014-10-23 16:09:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 0, 8 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525090482117152769",
  "geo" : { },
  "id_str" : "525315177378357248",
  "in_reply_to_user_id" : 433715578,
  "text" : "@Gyselie ys",
  "id" : 525315177378357248,
  "in_reply_to_status_id" : 525090482117152769,
  "created_at" : "2014-10-23 15:57:52 +0000",
  "in_reply_to_screen_name" : "Gyselie",
  "in_reply_to_user_id_str" : "433715578",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oli Evans",
      "screen_name" : "olizilla",
      "indices" : [ 0, 9 ],
      "id_str" : "37922652",
      "id" : 37922652
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 10, 22 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525288025237233664",
  "geo" : { },
  "id_str" : "525306295482458112",
  "in_reply_to_user_id" : 37922652,
  "text" : "@olizilla @dominictarr  function()\u007Breturn this\u007D.call(this, null)",
  "id" : 525306295482458112,
  "in_reply_to_status_id" : 525288025237233664,
  "created_at" : "2014-10-23 15:22:35 +0000",
  "in_reply_to_screen_name" : "olizilla",
  "in_reply_to_user_id_str" : "37922652",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524972216069283840",
  "text" : "johnny and the plangent penises",
  "id" : 524972216069283840,
  "created_at" : "2014-10-22 17:15:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Hopper",
      "screen_name" : "khopper",
      "indices" : [ 0, 8 ],
      "id_str" : "10287452",
      "id" : 10287452
    }, {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 9, 20 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 21, 29 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524942407230816256",
  "geo" : { },
  "id_str" : "524944685370834944",
  "in_reply_to_user_id" : 10287452,
  "text" : "@khopper @whichlight @Spotify   IDK... I would rather have that two headed horse of the sea than the clown car.",
  "id" : 524944685370834944,
  "in_reply_to_status_id" : 524942407230816256,
  "created_at" : "2014-10-22 15:25:40 +0000",
  "in_reply_to_screen_name" : "khopper",
  "in_reply_to_user_id_str" : "10287452",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524943575226662912",
  "text" : "the steady crashing of applications",
  "id" : 524943575226662912,
  "created_at" : "2014-10-22 15:21:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/49smnsLWn4",
      "expanded_url" : "https:\/\/archive.org\/details\/gdelsproof00nage",
      "display_url" : "archive.org\/details\/gdelsp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524804304230572033",
  "text" : "this what im nomnom https:\/\/t.co\/49smnsLWn4",
  "id" : 524804304230572033,
  "created_at" : "2014-10-22 06:07:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 3, 15 ],
      "id_str" : "557228721",
      "id" : 557228721
    }, {
      "name" : "cta",
      "screen_name" : "cta",
      "indices" : [ 27, 31 ],
      "id_str" : "342782636",
      "id" : 342782636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blueline",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524721868826107904",
  "text" : "RT @vrroanhorse: #blueline @cta love troubles - having 2 tell someone new about ur passions w\/o sounding like a after school special. Tip: \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "cta",
        "screen_name" : "cta",
        "indices" : [ 10, 14 ],
        "id_str" : "342782636",
        "id" : 342782636
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blueline",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524714705806688256",
    "text" : "#blueline @cta love troubles - having 2 tell someone new about ur passions w\/o sounding like a after school special. Tip: say F*ck a lot",
    "id" : 524714705806688256,
    "created_at" : "2014-10-22 00:11:49 +0000",
    "user" : {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "protected" : false,
      "id_str" : "557228721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652515840194056193\/vt9WrUY__normal.jpg",
      "id" : 557228721,
      "verified" : false
    }
  },
  "id" : 524721868826107904,
  "created_at" : "2014-10-22 00:40:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 3, 14 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/gAS1X1wJMf",
      "expanded_url" : "https:\/\/vine.co\/v\/ObYmz9PH5zW",
      "display_url" : "vine.co\/v\/ObYmz9PH5zW"
    } ]
  },
  "geo" : { },
  "id_str" : "524721723229212672",
  "text" : "RT @whichlight: Prototyping the face \uD83D\uDE04\uD83D\uDE04\uD83D\uDE02\uD83D\uDE02\uD83D\uDE02 mouth sounds https:\/\/t.co\/gAS1X1wJMf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/gAS1X1wJMf",
        "expanded_url" : "https:\/\/vine.co\/v\/ObYmz9PH5zW",
        "display_url" : "vine.co\/v\/ObYmz9PH5zW"
      } ]
    },
    "geo" : { },
    "id_str" : "524720242476724225",
    "text" : "Prototyping the face \uD83D\uDE04\uD83D\uDE04\uD83D\uDE02\uD83D\uDE02\uD83D\uDE02 mouth sounds https:\/\/t.co\/gAS1X1wJMf",
    "id" : 524720242476724225,
    "created_at" : "2014-10-22 00:33:49 +0000",
    "user" : {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "protected" : false,
      "id_str" : "17092251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582894470452133888\/uBlV4V8-_normal.jpg",
      "id" : 17092251,
      "verified" : false
    }
  },
  "id" : 524721723229212672,
  "created_at" : "2014-10-22 00:39:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524594764528644098",
  "geo" : { },
  "id_str" : "524594913661288448",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  IFF you can prove its unprovable, natch",
  "id" : 524594913661288448,
  "in_reply_to_status_id" : 524594764528644098,
  "created_at" : "2014-10-21 16:15:48 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524594764528644098",
  "text" : "I think a true but unprovable theorem within a consistent system (ie. Goldbach's theorem) should become an axiom of that system.",
  "id" : 524594764528644098,
  "created_at" : "2014-10-21 16:15:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norwood Orrick",
      "screen_name" : "BlogWood",
      "indices" : [ 3, 12 ],
      "id_str" : "17356855",
      "id" : 17356855
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BlogWood\/status\/524223246070476800\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/pWNfWQUAg6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ZqQ7PIUAE-iFJ.jpg",
      "id_str" : "524223245646843905",
      "id" : 524223245646843905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ZqQ7PIUAE-iFJ.jpg",
      "sizes" : [ {
        "h" : 615,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 635,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 635,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pWNfWQUAg6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/SxLAszyVaw",
      "expanded_url" : "http:\/\/blgwd.us\/1tF1Wjd",
      "display_url" : "blgwd.us\/1tF1Wjd"
    } ]
  },
  "geo" : { },
  "id_str" : "524231711555465218",
  "text" : "RT @BlogWood: Mapping Where Jimmy John's Ex-Employees Are Forbidden to Make Sandwiches  \nhttp:\/\/t.co\/SxLAszyVaw http:\/\/t.co\/pWNfWQUAg6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BlogWood\/status\/524223246070476800\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/pWNfWQUAg6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ZqQ7PIUAE-iFJ.jpg",
        "id_str" : "524223245646843905",
        "id" : 524223245646843905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ZqQ7PIUAE-iFJ.jpg",
        "sizes" : [ {
          "h" : 615,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 635,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 635,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pWNfWQUAg6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/SxLAszyVaw",
        "expanded_url" : "http:\/\/blgwd.us\/1tF1Wjd",
        "display_url" : "blgwd.us\/1tF1Wjd"
      } ]
    },
    "geo" : { },
    "id_str" : "524223246070476800",
    "text" : "Mapping Where Jimmy John's Ex-Employees Are Forbidden to Make Sandwiches  \nhttp:\/\/t.co\/SxLAszyVaw http:\/\/t.co\/pWNfWQUAg6",
    "id" : 524223246070476800,
    "created_at" : "2014-10-20 15:38:56 +0000",
    "user" : {
      "name" : "Norwood Orrick",
      "screen_name" : "BlogWood",
      "protected" : false,
      "id_str" : "17356855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1701608243\/manhole_normal.jpg",
      "id" : 17356855,
      "verified" : false
    }
  },
  "id" : 524231711555465218,
  "created_at" : "2014-10-20 16:12:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524218915916754944",
  "text" : "G\u00F6del was mostmeta",
  "id" : 524218915916754944,
  "created_at" : "2014-10-20 15:21:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524007818337087489",
  "text" : "IS THE GITHUB OFFICE BAND CALLED DEPECHE CODE???",
  "id" : 524007818337087489,
  "created_at" : "2014-10-20 01:22:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523920319048712193",
  "text" : "i invented an improv game called SIT, STAND, ACT AWKWARDLY",
  "id" : 523920319048712193,
  "created_at" : "2014-10-19 19:35:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 0, 9 ],
      "id_str" : "2729061",
      "id" : 2729061
    }, {
      "name" : "no",
      "screen_name" : "the_N0",
      "indices" : [ 10, 17 ],
      "id_str" : "42699163",
      "id" : 42699163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523904186367623168",
  "geo" : { },
  "id_str" : "523910881302675458",
  "in_reply_to_user_id" : 2729061,
  "text" : "@doctorow @the_N0 the worst part is apologizing for doing something nice",
  "id" : 523910881302675458,
  "in_reply_to_status_id" : 523904186367623168,
  "created_at" : "2014-10-19 18:57:42 +0000",
  "in_reply_to_screen_name" : "doctorow",
  "in_reply_to_user_id_str" : "2729061",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 13, 22 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 23, 29 ],
      "id_str" : "15453",
      "id" : 15453
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 30, 39 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523867644303126528",
  "geo" : { },
  "id_str" : "523910052122333185",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso @substack @seldo @maxogden  browser virtualization of bash to a docker backend?  Later, the CLI is recognizable...",
  "id" : 523910052122333185,
  "in_reply_to_status_id" : 523867644303126528,
  "created_at" : "2014-10-19 18:54:24 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523866993410052097",
  "text" : "lazy man's sofrito",
  "id" : 523866993410052097,
  "created_at" : "2014-10-19 16:03:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/aNgFwUrwbo",
      "expanded_url" : "https:\/\/github.com\/audiocogs\/aurora.js",
      "display_url" : "github.com\/audiocogs\/auro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523560984242184192",
  "text" : "aurora.js got with browserify  https:\/\/t.co\/aNgFwUrwbo",
  "id" : 523560984242184192,
  "created_at" : "2014-10-18 19:47:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523356285614317569",
  "text" : "HOLY FUCKIN PHOSPHOROUS PHATMAN",
  "id" : 523356285614317569,
  "created_at" : "2014-10-18 06:13:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/c1R55Ky92J",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PwXai-sgM-s",
      "display_url" : "youtube.com\/watch?v=PwXai-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523350901004578817",
  "text" : "one day the bottom will fall out!\n\ni repeat one day the bottom will drop out!\n\nlook out!\n\nlook out for the FBI!\n\nhttp:\/\/t.co\/c1R55Ky92J",
  "id" : 523350901004578817,
  "created_at" : "2014-10-18 05:52:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523348304369688576",
  "text" : "me n screamin jay both had got a wild n eye",
  "id" : 523348304369688576,
  "created_at" : "2014-10-18 05:42:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523347026595954689",
  "geo" : { },
  "id_str" : "523347976215724033",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript   there will always be a better version, the ones performed and not recorded; and that exist but weren't performed, and can't.",
  "id" : 523347976215724033,
  "in_reply_to_status_id" : 523347026595954689,
  "created_at" : "2014-10-18 05:40:55 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/c1R55Ky92J",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PwXai-sgM-s",
      "display_url" : "youtube.com\/watch?v=PwXai-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523347026595954689",
  "text" : "there will never be a better version, but dont let that stop you from trying\n\ni aint lying\n\nhttp:\/\/t.co\/c1R55Ky92J",
  "id" : 523347026595954689,
  "created_at" : "2014-10-18 05:37:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523340653267148800",
  "text" : "to whom shall i entrust my grammatic estate?\n\ni am not so vain to ask u burn my disks, npm &amp; github\n\ni wish 4 publish &amp; distribute as a zine",
  "id" : 523340653267148800,
  "created_at" : "2014-10-18 05:11:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ErykahBadoula",
      "screen_name" : "fatbellybella",
      "indices" : [ 0, 14 ],
      "id_str" : "18278629",
      "id" : 18278629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523267314675109888",
  "geo" : { },
  "id_str" : "523275694780841984",
  "in_reply_to_user_id" : 18278629,
  "text" : "@fatbellybella  so ready for this.  what time u send n the uber?",
  "id" : 523275694780841984,
  "in_reply_to_status_id" : 523267314675109888,
  "created_at" : "2014-10-18 00:53:42 +0000",
  "in_reply_to_screen_name" : "fatbellybella",
  "in_reply_to_user_id_str" : "18278629",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523270714393395200",
  "geo" : { },
  "id_str" : "523275068227338240",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt  u will not be spending this winter's night alone",
  "id" : 523275068227338240,
  "in_reply_to_status_id" : 523270714393395200,
  "created_at" : "2014-10-18 00:51:12 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523273485305393152",
  "text" : "RT @node_modulhaus: WE NOW OFFERS META RETAINERS FOR CONSULT ANDS DEVELOPMENT\n\nRETAIN THE RIGHT TO RETAIN AN IMMEDIATE NUMBER OF HOURS AT A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523273403982032896",
    "text" : "WE NOW OFFERS META RETAINERS FOR CONSULT ANDS DEVELOPMENT\n\nRETAIN THE RIGHT TO RETAIN AN IMMEDIATE NUMBER OF HOURS AT A GIVEN RATE PER HOUR",
    "id" : 523273403982032896,
    "created_at" : "2014-10-18 00:44:36 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 523273485305393152,
  "created_at" : "2014-10-18 00:44:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrikeDebt",
      "screen_name" : "StrikeDebt",
      "indices" : [ 3, 14 ],
      "id_str" : "598921658",
      "id" : 598921658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/IQc0mMlBcI",
      "expanded_url" : "http:\/\/strikedebt.org\/how-far-to-free\/",
      "display_url" : "strikedebt.org\/how-far-to-fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522944285097070592",
  "text" : "RT @StrikeDebt: How much would it cost to make all public 2- and 4-yr colleges tuition free? The answer might surprise you. \nhttp:\/\/t.co\/IQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/IQc0mMlBcI",
        "expanded_url" : "http:\/\/strikedebt.org\/how-far-to-free\/",
        "display_url" : "strikedebt.org\/how-far-to-fre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "522522190885822464",
    "text" : "How much would it cost to make all public 2- and 4-yr colleges tuition free? The answer might surprise you. \nhttp:\/\/t.co\/IQc0mMlBcI",
    "id" : 522522190885822464,
    "created_at" : "2014-10-15 22:59:32 +0000",
    "user" : {
      "name" : "StrikeDebt",
      "screen_name" : "StrikeDebt",
      "protected" : false,
      "id_str" : "598921658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2487186800\/wcgxuqgrfjcvuv3e755f_normal.jpeg",
      "id" : 598921658,
      "verified" : false
    }
  },
  "id" : 522944285097070592,
  "created_at" : "2014-10-17 02:56:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "no",
      "screen_name" : "the_N0",
      "indices" : [ 0, 7 ],
      "id_str" : "42699163",
      "id" : 42699163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522936511340507136",
  "geo" : { },
  "id_str" : "522937056830717952",
  "in_reply_to_user_id" : 42699163,
  "text" : "@the_N0  i agree.  i like to go to the lowest level and do the scream void thing.",
  "id" : 522937056830717952,
  "in_reply_to_status_id" : 522936511340507136,
  "created_at" : "2014-10-17 02:28:04 +0000",
  "in_reply_to_screen_name" : "the_N0",
  "in_reply_to_user_id_str" : "42699163",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522935859575001090",
  "text" : "is there anything more outmoded than a record label?  recordings?  labels?  these are commodities now.",
  "id" : 522935859575001090,
  "created_at" : "2014-10-17 02:23:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522933513704972291",
  "text" : "revolutionary therapy",
  "id" : 522933513704972291,
  "created_at" : "2014-10-17 02:13:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522703684044460035",
  "text" : "javascript is the best meta language cuz you can use quotes inside quotes",
  "id" : 522703684044460035,
  "created_at" : "2014-10-16 11:00:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522551083617751040",
  "text" : "im listening to the story of visiting the shaman to get my shasum checked.",
  "id" : 522551083617751040,
  "created_at" : "2014-10-16 00:54:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522473311478226944",
  "geo" : { },
  "id_str" : "522480960240369665",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords thank you miss manners",
  "id" : 522480960240369665,
  "in_reply_to_status_id" : 522473311478226944,
  "created_at" : "2014-10-15 20:15:42 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522417824518520832",
  "text" : "i do not typically read an email until it has sat in my inbox a couple days",
  "id" : 522417824518520832,
  "created_at" : "2014-10-15 16:04:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522240583511715840",
  "text" : "which turtle is divinci in the teenage renegade psycho renaissance boy band that goes around painting murals?",
  "id" : 522240583511715840,
  "created_at" : "2014-10-15 04:20:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522221390494064640",
  "text" : "KIRKLANDIA - a send-up of big box morality in the style of \"Portlandia\", a send-up of etsy morality.",
  "id" : 522221390494064640,
  "created_at" : "2014-10-15 03:04:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522170433286574081",
  "text" : "i can tell by the way my drum has been tightening and loosening daily that the weather pattern is rising in decibels.  seasonal distortion",
  "id" : 522170433286574081,
  "created_at" : "2014-10-14 23:41:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522091209636864000",
  "text" : "fight club except the main dude is always wearing a wireless cellphone headset and everybody ignores him",
  "id" : 522091209636864000,
  "created_at" : "2014-10-14 18:26:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521853527929262080",
  "text" : "hire me today",
  "id" : 521853527929262080,
  "created_at" : "2014-10-14 02:42:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521853470094024705",
  "text" : "we're taking music\nthat u listen to,\nwhile taking drugs,\nto get to the next level,\nto the next level",
  "id" : 521853470094024705,
  "created_at" : "2014-10-14 02:42:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521344761060286464",
  "text" : "confessions of a newbody",
  "id" : 521344761060286464,
  "created_at" : "2014-10-12 17:00:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521011195394789376",
  "text" : "The hardest job in any project is the one you need to do next.  The easiest job is the one I am doing now, sorry pick another job.",
  "id" : 521011195394789376,
  "created_at" : "2014-10-11 18:55:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/VT2grhueYD",
      "expanded_url" : "http:\/\/www.jessamyn.com\/barth\/dolt.html",
      "display_url" : "jessamyn.com\/barth\/dolt.html"
    } ]
  },
  "in_reply_to_status_id_str" : "520656174711320577",
  "geo" : { },
  "id_str" : "520656935226322944",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  i love a good short story http:\/\/t.co\/VT2grhueYD",
  "id" : 520656935226322944,
  "in_reply_to_status_id" : 520656174711320577,
  "created_at" : "2014-10-10 19:27:41 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520653416356274177",
  "text" : "this is a twitter interlude\nhave u some o dis lard\nmy brain got fat asses",
  "id" : 520653416356274177,
  "created_at" : "2014-10-10 19:13:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520652546226917376",
  "text" : "it will be noted that i only talk to myself here.  and to you.  freak.",
  "id" : 520652546226917376,
  "created_at" : "2014-10-10 19:10:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520652429251997696",
  "text" : "twitter is for your avatar, not your true emotional selfie, stupid",
  "id" : 520652429251997696,
  "created_at" : "2014-10-10 19:09:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520040439135875072",
  "text" : "the \"george of the jungle\" beat is my rocksteady",
  "id" : 520040439135875072,
  "created_at" : "2014-10-09 02:37:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519557253041360896",
  "text" : "if u haven't noticed, my name is a bitcoin prediction.",
  "id" : 519557253041360896,
  "created_at" : "2014-10-07 18:37:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519556979358826496",
  "text" : "can i experience confirmation bais from another person?  what is this stuff?  this feels good!",
  "id" : 519556979358826496,
  "created_at" : "2014-10-07 18:36:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518419719255101441",
  "text" : "the only proof of anything I would accept in a shitcoin is proof of community.  all other motives end in profit taking and dumps.",
  "id" : 518419719255101441,
  "created_at" : "2014-10-04 15:17:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crypto Asian",
      "screen_name" : "CryptoAsian",
      "indices" : [ 0, 12 ],
      "id_str" : "2315539361",
      "id" : 2315539361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518419454766497794",
  "in_reply_to_user_id" : 2315539361,
  "text" : "@CryptoAsian your POD is pretty weak. 5\/5 for 2 years experience, and some a driver's license?",
  "id" : 518419454766497794,
  "created_at" : "2014-10-04 15:16:44 +0000",
  "in_reply_to_screen_name" : "CryptoAsian",
  "in_reply_to_user_id_str" : "2315539361",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518418297562202112",
  "text" : "proof of stake and proof of work are the shit in shitcoins",
  "id" : 518418297562202112,
  "created_at" : "2014-10-04 15:12:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518415629364113408",
  "text" : "GO BITCOIN GOOOOO",
  "id" : 518415629364113408,
  "created_at" : "2014-10-04 15:01:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518264152331403265",
  "text" : "so reddit goes with dogecoin \nheh they clearly ought \nsuch dogepartying days \nwow\nvery pay off",
  "id" : 518264152331403265,
  "created_at" : "2014-10-04 04:59:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518262353235038209",
  "text" : "RT @nexxylove: Hashtag. Only instead of Twitter, it's smoking hashish and playing tag outside with your friends.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518260953100468226",
    "text" : "Hashtag. Only instead of Twitter, it's smoking hashish and playing tag outside with your friends.",
    "id" : 518260953100468226,
    "created_at" : "2014-10-04 04:46:54 +0000",
    "user" : {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719047162793828353\/ilHIszOy_normal.jpg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 518262353235038209,
  "created_at" : "2014-10-04 04:52:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518160557606567938",
  "text" : "\"classification is an advantage if u ask me. affords more time out of mind. that's the aisle you'll find me in. The time out of mind aisle?\"",
  "id" : 518160557606567938,
  "created_at" : "2014-10-03 22:07:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "That Chip Person",
      "screen_name" : "Chiparoo",
      "indices" : [ 0, 9 ],
      "id_str" : "2034551",
      "id" : 2034551
    }, {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 10, 26 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gg",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517778629825413120",
  "geo" : { },
  "id_str" : "518160187643813889",
  "in_reply_to_user_id" : 2034551,
  "text" : "@Chiparoo @brianloveswords   classes are fundamental to social inequity tho.  So... bonus point for the irony!  #gg",
  "id" : 518160187643813889,
  "in_reply_to_status_id" : 517778629825413120,
  "created_at" : "2014-10-03 22:06:30 +0000",
  "in_reply_to_screen_name" : "Chiparoo",
  "in_reply_to_user_id_str" : "2034551",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/nfOliTPqYw",
      "expanded_url" : "http:\/\/ww2.kqed.org\/news\/2014\/09\/30\/half-of-those-killed-by-san-francisco-police-are-mentally-ill\/",
      "display_url" : "ww2.kqed.org\/news\/2014\/09\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518157339044491264",
  "text" : "half of all deadly police incidents in SF result in the murder of mentally ill person.  pretty much why I stay home. http:\/\/t.co\/nfOliTPqYw",
  "id" : 518157339044491264,
  "created_at" : "2014-10-03 21:55:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/LHe5UBxUlq",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=vphmJEpLXU0",
      "display_url" : "youtube.com\/watch?v=vphmJE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518138803156824064",
  "text" : "gonna make a fake one of these https:\/\/t.co\/LHe5UBxUlq",
  "id" : 518138803156824064,
  "created_at" : "2014-10-03 20:41:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518137601241669632",
  "text" : "i was a dedicated troll of the purest form in the early days of internet.  kicking people off aol for being dicks and pretend cybersexing.",
  "id" : 518137601241669632,
  "created_at" : "2014-10-03 20:36:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518093195859595264",
  "text" : "after I sponsor a couple issues of cryptocurrency weekly, i'll have made internet transactions with 10 different shitcoins.  sponsored?  :^D",
  "id" : 518093195859595264,
  "created_at" : "2014-10-03 17:40:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/FX3a9304as",
      "expanded_url" : "http:\/\/cryptocurrencyweekly.com\/",
      "display_url" : "cryptocurrencyweekly.com"
    } ]
  },
  "geo" : { },
  "id_str" : "518089034665443328",
  "text" : "the only periodical i read periodically is http:\/\/t.co\/FX3a9304as",
  "id" : 518089034665443328,
  "created_at" : "2014-10-03 17:23:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/SvnDzu91AY",
      "expanded_url" : "https:\/\/www.circle.com\/en",
      "display_url" : "circle.com\/en"
    } ]
  },
  "geo" : { },
  "id_str" : "518087516482985984",
  "text" : "incursory, i didnt read a word, but I like the visual affect   https:\/\/t.co\/SvnDzu91AY",
  "id" : 518087516482985984,
  "created_at" : "2014-10-03 17:17:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518071724949393408",
  "text" : "i'll have the forking content-addressable append-only historical key\/value blob store, over leveldb, and a side of gui",
  "id" : 518071724949393408,
  "created_at" : "2014-10-03 16:14:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517927277997211649",
  "text" : "oh god imma hobgoblin",
  "id" : 517927277997211649,
  "created_at" : "2014-10-03 06:41:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/517824405095710720\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/bMtdn8nA7F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By-ujPYCIAA0wGY.jpg",
      "id_str" : "517824402616885248",
      "id" : 517824402616885248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By-ujPYCIAA0wGY.jpg",
      "sizes" : [ {
        "h" : 822,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/bMtdn8nA7F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517824405095710720",
  "text" : "I play the zeros n ones with my feet. http:\/\/t.co\/bMtdn8nA7F",
  "id" : 517824405095710720,
  "created_at" : "2014-10-02 23:52:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517762941043892224",
  "geo" : { },
  "id_str" : "517765101529870337",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain  HUMNA HUMNA HUMMMMNA",
  "id" : 517765101529870337,
  "in_reply_to_status_id" : 517762941043892224,
  "created_at" : "2014-10-02 19:56:34 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipartisan Report",
      "screen_name" : "Bipartisanism",
      "indices" : [ 3, 17 ],
      "id_str" : "487600344",
      "id" : 487600344
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Bipartisanism\/status\/510221796067401729\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/WvEESA8PES",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxSsBRcCIAAA-e3.jpg",
      "id_str" : "510221795660537856",
      "id" : 510221795660537856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxSsBRcCIAAA-e3.jpg",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/WvEESA8PES"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517759983996248064",
  "text" : "RT @Bipartisanism: If roads were like bike lanes. http:\/\/t.co\/WvEESA8PES",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Bipartisanism\/status\/510221796067401729\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/WvEESA8PES",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxSsBRcCIAAA-e3.jpg",
        "id_str" : "510221795660537856",
        "id" : 510221795660537856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxSsBRcCIAAA-e3.jpg",
        "sizes" : [ {
          "h" : 326,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/WvEESA8PES"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510221796067401729",
    "text" : "If roads were like bike lanes. http:\/\/t.co\/WvEESA8PES",
    "id" : 510221796067401729,
    "created_at" : "2014-09-12 00:22:10 +0000",
    "user" : {
      "name" : "Bipartisan Report",
      "screen_name" : "Bipartisanism",
      "protected" : false,
      "id_str" : "487600344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815330356\/sampson_normal.png",
      "id" : 487600344,
      "verified" : false
    }
  },
  "id" : 517759983996248064,
  "created_at" : "2014-10-02 19:36:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/y1rxGHlwpy",
      "expanded_url" : "http:\/\/webaudio.github.io\/web-audio-api\/#the-audioworker",
      "display_url" : "webaudio.github.io\/web-audio-api\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517741211604353024",
  "text" : "COME YOU BLOATED DEVS GET THESE SPECS UP\n\nhttp:\/\/t.co\/y1rxGHlwpy",
  "id" : 517741211604353024,
  "created_at" : "2014-10-02 18:21:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517711757515575296",
  "text" : "the NSA wormholed ubuntu",
  "id" : 517711757515575296,
  "created_at" : "2014-10-02 16:24:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517711488140574722",
  "text" : "wherever the fuck it is it aint",
  "id" : 517711488140574722,
  "created_at" : "2014-10-02 16:23:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/E8Y0EPYerD",
      "expanded_url" : "http:\/\/arhive.ubuntu.com",
      "display_url" : "arhive.ubuntu.com"
    } ]
  },
  "geo" : { },
  "id_str" : "517711390190997504",
  "text" : "getting a bunch of 404 trynna update ubuntu from http:\/\/t.co\/E8Y0EPYerD",
  "id" : 517711390190997504,
  "created_at" : "2014-10-02 16:23:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517528746400575488",
  "text" : "better than naught recordings",
  "id" : 517528746400575488,
  "created_at" : "2014-10-02 04:17:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517390140424351744",
  "text" : "which is to say that browser vendors have not made high performing application cuz they busy making mozilla and android and ios",
  "id" : 517390140424351744,
  "created_at" : "2014-10-01 19:06:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517385596172791808",
  "text" : "browser has latency but ableton live doesn't.  why?  cuz these browser vendors are clowning on development.",
  "id" : 517385596172791808,
  "created_at" : "2014-10-01 18:48:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517384811011665920",
  "text" : "console.me(web audio is all latent for live audio input  :```(",
  "id" : 517384811011665920,
  "created_at" : "2014-10-01 18:45:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]