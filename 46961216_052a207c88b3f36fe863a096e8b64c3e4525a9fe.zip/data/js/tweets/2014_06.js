Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483781157469696000",
  "text" : "culture is sharing tho",
  "id" : 483781157469696000,
  "created_at" : "2014-07-01 01:16:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483718122781048833",
  "geo" : { },
  "id_str" : "483758089145819137",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords   The Onion could republish that article.",
  "id" : 483758089145819137,
  "in_reply_to_status_id" : 483718122781048833,
  "created_at" : "2014-06-30 23:44:50 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483050179893809152",
  "text" : "i could place every penalty kick wtf dumabasses aint got no clown in em except that one brazillian",
  "id" : 483050179893809152,
  "created_at" : "2014-06-29 00:51:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483049438898704384",
  "text" : "growth expand from the inside\ndestruction expands on the outside",
  "id" : 483049438898704384,
  "created_at" : "2014-06-29 00:48:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 0, 10 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483048340838305794",
  "geo" : { },
  "id_str" : "483048820788310016",
  "in_reply_to_user_id" : 14529356,
  "text" : "@postcrunk  the prescription for which may be the work of Samuel Beckett",
  "id" : 483048820788310016,
  "in_reply_to_status_id" : 483048340838305794,
  "created_at" : "2014-06-29 00:46:28 +0000",
  "in_reply_to_screen_name" : "postcrunk",
  "in_reply_to_user_id_str" : "14529356",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK LOVE",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 0, 12 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483046832772104192",
  "geo" : { },
  "id_str" : "483047980862160896",
  "in_reply_to_user_id" : 15819295,
  "text" : "@JUNGLEPUSSY   HI CAN WE GET AN OAKLAND DATE????",
  "id" : 483047980862160896,
  "in_reply_to_status_id" : 483046832772104192,
  "created_at" : "2014-06-29 00:43:07 +0000",
  "in_reply_to_screen_name" : "JUNGLEPUSSY",
  "in_reply_to_user_id_str" : "15819295",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483046115139272704",
  "text" : "BITCH!\nthat's some goood points you made\n!BITCH",
  "id" : 483046115139272704,
  "created_at" : "2014-06-29 00:35:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483045918627725313",
  "text" : "here is the major misconception about words.  They don't always mean something.  They may just be an exclamation.  BITCH!",
  "id" : 483045918627725313,
  "created_at" : "2014-06-29 00:34:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483045700893032449",
  "text" : "BITCH!\nWHEN I LIE\nYOU WILL KNOW I AM \n!BITCH",
  "id" : 483045700893032449,
  "created_at" : "2014-06-29 00:34:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483044861369520130",
  "text" : "make that a pychodonut",
  "id" : 483044861369520130,
  "created_at" : "2014-06-29 00:30:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483044800535334912",
  "text" : "chasing this one nigga all over the psychosphere",
  "id" : 483044800535334912,
  "created_at" : "2014-06-29 00:30:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Node.js\u2122 Reactions \u00A9",
      "screen_name" : "NodejsReactions",
      "indices" : [ 3, 19 ],
      "id_str" : "1464249528",
      "id" : 1464249528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/HDLp4bLdVJ",
      "expanded_url" : "http:\/\/tmblr.co\/ZM62_r1J_Jwvo",
      "display_url" : "tmblr.co\/ZM62_r1J_Jwvo"
    } ]
  },
  "geo" : { },
  "id_str" : "482942458376892417",
  "text" : "RT @NodejsReactions: When they let me near the CSS http:\/\/t.co\/HDLp4bLdVJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/HDLp4bLdVJ",
        "expanded_url" : "http:\/\/tmblr.co\/ZM62_r1J_Jwvo",
        "display_url" : "tmblr.co\/ZM62_r1J_Jwvo"
      } ]
    },
    "geo" : { },
    "id_str" : "482924167881588736",
    "text" : "When they let me near the CSS http:\/\/t.co\/HDLp4bLdVJ",
    "id" : 482924167881588736,
    "created_at" : "2014-06-28 16:31:08 +0000",
    "user" : {
      "name" : "Node.js\u2122 Reactions \u00A9",
      "screen_name" : "NodejsReactions",
      "protected" : false,
      "id_str" : "1464249528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000702184184\/ede2937d8b45bd813042863f5f2ace5d_normal.png",
      "id" : 1464249528,
      "verified" : false
    }
  },
  "id" : 482942458376892417,
  "created_at" : "2014-06-28 17:43:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 12, 21 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    }, {
      "name" : "Alex Wiltschko",
      "screen_name" : "awiltsch",
      "indices" : [ 22, 31 ],
      "id_str" : "35546323",
      "id" : 35546323
    }, {
      "name" : "Robert M Ochshorn",
      "screen_name" : "rmozone",
      "indices" : [ 32, 40 ],
      "id_str" : "18620306",
      "id" : 18620306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482884466093064192",
  "geo" : { },
  "id_str" : "482891254888275968",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight @maxogden @awiltsch @rmozone it's jus another visualization of the same data used by substacks module, focused on a range of hz",
  "id" : 482891254888275968,
  "in_reply_to_status_id" : 482884466093064192,
  "created_at" : "2014-06-28 14:20:21 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482888778692829184",
  "text" : "LOUDBOT: FUCK ME WITH A 8\" DIAMETER DILDO \njjjohnny: SAID THE BARRIER TO THE SOLUTION TO THE SEEKER \nLOUDBOT: I'M DELIRIOUS. TIME TO GO HOME",
  "id" : 482888778692829184,
  "created_at" : "2014-06-28 14:10:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482701927482793984",
  "text" : "there are two ways to say how could I forget",
  "id" : 482701927482793984,
  "created_at" : "2014-06-28 01:48:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482607037520441345",
  "text" : "one morning, on an walk, a bum in my hood asked to borrow 15 grand.  lol! Later, downtown, one asked us to direct a kickstarter for a cut.",
  "id" : 482607037520441345,
  "created_at" : "2014-06-27 19:30:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482606335351984130",
  "text" : "oh, you seek the true revolution\nthere's no hoping for it\nit's the one for the true",
  "id" : 482606335351984130,
  "created_at" : "2014-06-27 19:28:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482605736631885824",
  "text" : "all these revolutions got a nigga dizzy",
  "id" : 482605736631885824,
  "created_at" : "2014-06-27 19:25:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482605534890061824",
  "text" : "the revolution will be staged",
  "id" : 482605534890061824,
  "created_at" : "2014-06-27 19:25:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482594110470385665",
  "geo" : { },
  "id_str" : "482596461268332544",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords  don't try to eat sharp things and they won't fall out of your mouth",
  "id" : 482596461268332544,
  "in_reply_to_status_id" : 482594110470385665,
  "created_at" : "2014-06-27 18:48:57 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elizabeth stark",
      "screen_name" : "starkness",
      "indices" : [ 3, 13 ],
      "id_str" : "2189541",
      "id" : 2189541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Z2LuyvoRIK",
      "expanded_url" : "http:\/\/phrack.org\/issues\/7\/3.html",
      "display_url" : "phrack.org\/issues\/7\/3.html"
    } ]
  },
  "geo" : { },
  "id_str" : "482096960128573442",
  "text" : "RT @starkness: \"This is our world now... the world of the electron and the switch, the beauty of the baud.\" \u2014Hacker Manifesto, 1986 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Z2LuyvoRIK",
        "expanded_url" : "http:\/\/phrack.org\/issues\/7\/3.html",
        "display_url" : "phrack.org\/issues\/7\/3.html"
      } ]
    },
    "geo" : { },
    "id_str" : "481987612299632641",
    "text" : "\"This is our world now... the world of the electron and the switch, the beauty of the baud.\" \u2014Hacker Manifesto, 1986 http:\/\/t.co\/Z2LuyvoRIK",
    "id" : 481987612299632641,
    "created_at" : "2014-06-26 02:29:36 +0000",
    "user" : {
      "name" : "elizabeth stark",
      "screen_name" : "starkness",
      "protected" : false,
      "id_str" : "2189541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1974819036\/stark.4_normal.jpg",
      "id" : 2189541,
      "verified" : false
    }
  },
  "id" : 482096960128573442,
  "created_at" : "2014-06-26 09:44:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481747587402199040",
  "text" : "self.on('hug', function(hug)\u007B return hug \u007D)",
  "id" : 481747587402199040,
  "created_at" : "2014-06-25 10:35:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481741056145231873",
  "text" : "there is a mania sweeping through the bay area.  Modern psychology and the CDC dont know shit about epidemic mentality.  Whatchathinkbouthat",
  "id" : 481741056145231873,
  "created_at" : "2014-06-25 10:09:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481620556316282882",
  "text" : "E PLURIBUS AMORES UNUM",
  "id" : 481620556316282882,
  "created_at" : "2014-06-25 02:11:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland Wiki",
      "screen_name" : "oaklandwiki",
      "indices" : [ 108, 120 ],
      "id_str" : "702364508",
      "id" : 702364508
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Qk7ryQWmt6",
      "expanded_url" : "http:\/\/oaklandwiki.org\/2014_Mayoral_Election?&redirected_from=2014%20election",
      "display_url" : "oaklandwiki.org\/2014_Mayoral_E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481610810431512576",
  "text" : "many thankus to the peeps posting information about the Oakland mayoral race  @  http:\/\/t.co\/Qk7ryQWmt6  cc\/@oaklandwiki  #Oakland",
  "id" : 481610810431512576,
  "created_at" : "2014-06-25 01:32:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dogemayor",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/wI65755Oxn",
      "expanded_url" : "http:\/\/einsteinforoakland.org\/",
      "display_url" : "einsteinforoakland.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481607044923785217",
  "text" : "Einstein 4 Oakland!  http:\/\/t.co\/wI65755Oxn  #dogemayor",
  "id" : 481607044923785217,
  "created_at" : "2014-06-25 01:17:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481282818920566784",
  "text" : "i shaved\ngame over",
  "id" : 481282818920566784,
  "created_at" : "2014-06-24 03:49:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481217064552497153",
  "text" : "what do you call the diffs between code and the text of the code?",
  "id" : 481217064552497153,
  "created_at" : "2014-06-23 23:27:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481060428038930432",
  "text" : "luckily my subconscience weighs a ton, cuz its humungulous",
  "id" : 481060428038930432,
  "created_at" : "2014-06-23 13:05:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481060353262891008",
  "text" : "ram a lam a ding dong",
  "id" : 481060353262891008,
  "created_at" : "2014-06-23 13:05:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481059689048727552",
  "text" : "Ida prefferred the other one",
  "id" : 481059689048727552,
  "created_at" : "2014-06-23 13:02:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481059581397712896",
  "text" : "a read \/ write error made me trade one good idea for another",
  "id" : 481059581397712896,
  "created_at" : "2014-06-23 13:01:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480878849514024961",
  "geo" : { },
  "id_str" : "480880076792152064",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti  true and but i guess its about tricking the referee and really that is what we should all strive for in our times, fuck the ref.",
  "id" : 480880076792152064,
  "in_reply_to_status_id" : 480878849514024961,
  "created_at" : "2014-06-23 01:08:39 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480878798003388416",
  "text" : "where is the live streaming soccer on the internet?",
  "id" : 480878798003388416,
  "created_at" : "2014-06-23 01:03:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480877092369088512",
  "geo" : { },
  "id_str" : "480878615878316033",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti a good game discourages or bans fouls.  ergo, NBA basketball doesn't qualify as a game. something fundamental has to change.",
  "id" : 480878615878316033,
  "in_reply_to_status_id" : 480877092369088512,
  "created_at" : "2014-06-23 01:02:50 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480877092369088512",
  "geo" : { },
  "id_str" : "480878100809388032",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti im talkin bout how the foul is basically a tactical move you have to use at the end of most games. that's bitch drama built in.",
  "id" : 480878100809388032,
  "in_reply_to_status_id" : 480877092369088512,
  "created_at" : "2014-06-23 01:00:48 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480836005101338624",
  "geo" : { },
  "id_str" : "480876033428557824",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti \nNBA is a bitch for the foul, and that is why I don't like the NBA",
  "id" : 480876033428557824,
  "in_reply_to_status_id" : 480836005101338624,
  "created_at" : "2014-06-23 00:52:35 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nappy Harlot",
      "screen_name" : "iamenuff",
      "indices" : [ 0, 9 ],
      "id_str" : "74345578",
      "id" : 74345578
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 10, 22 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480789910547206146",
  "geo" : { },
  "id_str" : "480873008991440896",
  "in_reply_to_user_id" : 74345578,
  "text" : "@iamenuff @marinakukso \ncriminalize cold advancements\nthis is a good thing\nlet women breathe and just be\nopen an app\nbrowse\nand click on me",
  "id" : 480873008991440896,
  "in_reply_to_status_id" : 480789910547206146,
  "created_at" : "2014-06-23 00:40:34 +0000",
  "in_reply_to_screen_name" : "iamenuff",
  "in_reply_to_user_id_str" : "74345578",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480475960630726656",
  "text" : "this is why I napped all day\ni napped all day for this",
  "id" : 480475960630726656,
  "created_at" : "2014-06-21 22:22:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480410061995393024",
  "text" : "Its fun to alter time, Dipsy",
  "id" : 480410061995393024,
  "created_at" : "2014-06-21 18:00:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480409954189201409",
  "text" : "wow such meow",
  "id" : 480409954189201409,
  "created_at" : "2014-06-21 18:00:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 3, 13 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480400081359626240",
  "text" : "RT @LouMinoti: You gonna bring thirsty horses to the spring they bound to take a sip",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480399605570355200",
    "text" : "You gonna bring thirsty horses to the spring they bound to take a sip",
    "id" : 480399605570355200,
    "created_at" : "2014-06-21 17:19:26 +0000",
    "user" : {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "protected" : false,
      "id_str" : "262151877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725638787720712192\/IT5u9RUF_normal.jpg",
      "id" : 262151877,
      "verified" : false
    }
  },
  "id" : 480400081359626240,
  "created_at" : "2014-06-21 17:21:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480397960451084289",
  "geo" : { },
  "id_str" : "480398736170819584",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti be happy for your friend, and be happy for me, for me and your friend gave each other happies",
  "id" : 480398736170819584,
  "in_reply_to_status_id" : 480397960451084289,
  "created_at" : "2014-06-21 17:15:58 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480397298589904896",
  "text" : "okay!\nokay! do thing yes\nsry what oopsy\nokay! \nwhat oopsy\nbetter yay\nwow",
  "id" : 480397298589904896,
  "created_at" : "2014-06-21 17:10:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480379708744298497",
  "text" : "RT @TheHatGhost: Yes you America wake up! Your pancakes are ready.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480306267882143747",
    "text" : "Yes you America wake up! Your pancakes are ready.",
    "id" : 480306267882143747,
    "created_at" : "2014-06-21 11:08:32 +0000",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606927351168036864\/lzGOA4HX_normal.jpg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 480379708744298497,
  "created_at" : "2014-06-21 16:00:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480194607993483264",
  "text" : "now in doge",
  "id" : 480194607993483264,
  "created_at" : "2014-06-21 03:44:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480194557955436544",
  "text" : "try \ntry eat throw \ntry if throw \nelse yay \nthrow \nthrow",
  "id" : 480194557955436544,
  "created_at" : "2014-06-21 03:44:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480193909843169281",
  "text" : "immabout to rip out the only try catch I ever used in my code.\nit goes\ntry\u007B\n try\u007B\n  eat()\n catch\u007B\n try\u007B\n   if\u007B throw\n   else\u007B\n catch\u007B\ncatch\u007B",
  "id" : 480193909843169281,
  "created_at" : "2014-06-21 03:42:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480108544205660160",
  "text" : "A CRAFTED PHRASE THAT CRUXES ON \"SOMETIMES\" \n\nWHERE \"SOMETIMES\" IS THE DOORWAY TO ALL THAT IS POSSIBLY POSSIBLE. \n\nWOW SWEET SUCH BUTT SMELL",
  "id" : 480108544205660160,
  "created_at" : "2014-06-20 22:02:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480107278947741696",
  "text" : "I GUARANTEE THESE BITCHES WONT RESPOND",
  "id" : 480107278947741696,
  "created_at" : "2014-06-20 21:57:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modern Kierkegaard",
      "screen_name" : "KierkegaardNow",
      "indices" : [ 16, 31 ],
      "id_str" : "15232253",
      "id" : 15232253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480022145800491009",
  "geo" : { },
  "id_str" : "480106941336006656",
  "in_reply_to_user_id" : 349143448,
  "text" : "@NietzscheQuots @KierkegaardNow \nNEVER HAVE I FELT THAT\n\"I DON'T WANT MY ILLUSIONS DESTROYED\"\nBUT SAY SOMETIMES AND ANYTHING BE TRUE",
  "id" : 480106941336006656,
  "in_reply_to_status_id" : 480022145800491009,
  "created_at" : "2014-06-20 21:56:29 +0000",
  "in_reply_to_screen_name" : "PureNietzsche",
  "in_reply_to_user_id_str" : "349143448",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modern Kierkegaard",
      "screen_name" : "KierkegaardNow",
      "indices" : [ 16, 31 ],
      "id_str" : "15232253",
      "id" : 15232253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480022145800491009",
  "geo" : { },
  "id_str" : "480106190609735680",
  "in_reply_to_user_id" : 349143448,
  "text" : "@NietzscheQuots @KierkegaardNow \nYEAH YEAH AND WELL WELL\nSOMETIMES ANYTHING, ALWAYS\nBUT I DUNNO BOUT THAT",
  "id" : 480106190609735680,
  "in_reply_to_status_id" : 480022145800491009,
  "created_at" : "2014-06-20 21:53:30 +0000",
  "in_reply_to_screen_name" : "PureNietzsche",
  "in_reply_to_user_id_str" : "349143448",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480105557693452288",
  "text" : "the goatsy page on wikipedia doesn't know about the textual representation of fucking with dolphins content.  you can look it up yrself.",
  "id" : 480105557693452288,
  "created_at" : "2014-06-20 21:50:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480104535411548161",
  "text" : "observation:  the immortal goatsecx image was the fashion precursor to all those american apparel advertisements",
  "id" : 480104535411548161,
  "created_at" : "2014-06-20 21:46:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479917450478497792",
  "text" : "i know psychic judo\nand you don't know \nwhat psychic judo is",
  "id" : 479917450478497792,
  "created_at" : "2014-06-20 09:23:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike R",
      "screen_name" : "mrotondo",
      "indices" : [ 3, 12 ],
      "id_str" : "11868",
      "id" : 11868
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mrotondo\/status\/479891263697604608\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/W4oiHjbObf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqjqj4OCMAAIxE1.png",
      "id_str" : "479891262422528000",
      "id" : 479891262422528000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqjqj4OCMAAIxE1.png",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/W4oiHjbObf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479916684338155520",
  "text" : "RT @mrotondo: COMMENTARY.png http:\/\/t.co\/W4oiHjbObf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mrotondo\/status\/479891263697604608\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/W4oiHjbObf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqjqj4OCMAAIxE1.png",
        "id_str" : "479891262422528000",
        "id" : 479891262422528000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqjqj4OCMAAIxE1.png",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1065,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/W4oiHjbObf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479891263697604608",
    "text" : "COMMENTARY.png http:\/\/t.co\/W4oiHjbObf",
    "id" : 479891263697604608,
    "created_at" : "2014-06-20 07:39:27 +0000",
    "user" : {
      "name" : "Mike R",
      "screen_name" : "mrotondo",
      "protected" : false,
      "id_str" : "11868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/125319601\/me_head_normal.jpg",
      "id" : 11868,
      "verified" : false
    }
  },
  "id" : 479916684338155520,
  "created_at" : "2014-06-20 09:20:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479916549969420288",
  "text" : "what will sympathy with a computer get you?",
  "id" : 479916549969420288,
  "created_at" : "2014-06-20 09:19:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wouter van Cleef",
      "screen_name" : "WvanCleef",
      "indices" : [ 3, 13 ],
      "id_str" : "98413229",
      "id" : 98413229
    }, {
      "name" : "M. James Kondo",
      "screen_name" : "jameskondo",
      "indices" : [ 37, 48 ],
      "id_str" : "232850782",
      "id" : 232850782
    }, {
      "name" : "Luay \u0644\u0624\u064A \u0627\u0644\u062E\u0637\u064A\u0628",
      "screen_name" : "AL_Khatteeb",
      "indices" : [ 117, 129 ],
      "id_str" : "255888435",
      "id" : 255888435
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AL_Khatteeb\/status\/479568233901871104\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bELGjm62Nj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqfEw5cIUAEB8my.jpg",
      "id_str" : "479568229669818369",
      "id" : 479568229669818369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqfEw5cIUAEB8my.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bELGjm62Nj"
    } ],
    "hashtags" : [ {
      "text" : "isis",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479838783467057152",
  "text" : "RT @WvanCleef: LOL! Sushi?! #isis MT @jameskondo \"Sushi\" is a word of unity of mankind. \u30B7\u30FC\u30A2\u6D3E \u3068\u30B9\u30F3\u30CB\u6D3E \u306E\u4E21\u89AA\u306E\u5B50\u4F9B\u304C Sushi)via @AL_Khatteeb http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "M. James Kondo",
        "screen_name" : "jameskondo",
        "indices" : [ 22, 33 ],
        "id_str" : "232850782",
        "id" : 232850782
      }, {
        "name" : "Luay \u0644\u0624\u064A \u0627\u0644\u062E\u0637\u064A\u0628",
        "screen_name" : "AL_Khatteeb",
        "indices" : [ 102, 114 ],
        "id_str" : "255888435",
        "id" : 255888435
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AL_Khatteeb\/status\/479568233901871104\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/bELGjm62Nj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqfEw5cIUAEB8my.jpg",
        "id_str" : "479568229669818369",
        "id" : 479568229669818369,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqfEw5cIUAEB8my.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bELGjm62Nj"
      } ],
      "hashtags" : [ {
        "text" : "isis",
        "indices" : [ 13, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479600330951254016",
    "text" : "LOL! Sushi?! #isis MT @jameskondo \"Sushi\" is a word of unity of mankind. \u30B7\u30FC\u30A2\u6D3E \u3068\u30B9\u30F3\u30CB\u6D3E \u306E\u4E21\u89AA\u306E\u5B50\u4F9B\u304C Sushi)via @AL_Khatteeb http:\/\/t.co\/bELGjm62Nj",
    "id" : 479600330951254016,
    "created_at" : "2014-06-19 12:23:24 +0000",
    "user" : {
      "name" : "Wouter van Cleef",
      "screen_name" : "WvanCleef",
      "protected" : false,
      "id_str" : "98413229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2796320974\/1e0a898ecafa41086212347ce9297695_normal.jpeg",
      "id" : 98413229,
      "verified" : false
    }
  },
  "id" : 479838783467057152,
  "created_at" : "2014-06-20 04:10:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479726611843907584",
  "text" : "accept debugging",
  "id" : 479726611843907584,
  "created_at" : "2014-06-19 20:45:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479708019786137601",
  "geo" : { },
  "id_str" : "479709619070062592",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  O_o  but it has full size HDMI port",
  "id" : 479709619070062592,
  "in_reply_to_status_id" : 479708019786137601,
  "created_at" : "2014-06-19 19:37:40 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479663650295541761",
  "geo" : { },
  "id_str" : "479688292448108544",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah they",
  "id" : 479688292448108544,
  "in_reply_to_status_id" : 479663650295541761,
  "created_at" : "2014-06-19 18:12:55 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479431686271156224",
  "text" : "BRING FORTH THE AUTODOPPLEGANGER",
  "id" : 479431686271156224,
  "created_at" : "2014-06-19 01:13:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479420441484738561",
  "text" : "give me a scholarship to teach robots at the robot college",
  "id" : 479420441484738561,
  "created_at" : "2014-06-19 00:28:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479396135518236672",
  "text" : "me foder, the hooly goost",
  "id" : 479396135518236672,
  "created_at" : "2014-06-18 22:52:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479395942085312512",
  "text" : "okay so i finally learned who my father.\nmy father whom i never met.\nthe wood nymph spirit of Abraham Lincoln \nthat almost preliterate L",
  "id" : 479395942085312512,
  "created_at" : "2014-06-18 22:51:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Goodman",
      "screen_name" : "chromakode",
      "indices" : [ 0, 11 ],
      "id_str" : "14457445",
      "id" : 14457445
    }, {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 12, 23 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "stagas",
      "screen_name" : "stagas",
      "indices" : [ 30, 37 ],
      "id_str" : "50715651",
      "id" : 50715651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479342449949560832",
  "geo" : { },
  "id_str" : "479387143974838272",
  "in_reply_to_user_id" : 14457445,
  "text" : "@chromakode @whichlight  yeuh @stagas is writing awesome javascript audio code.  +1 for the crypto crowd source.  I got 5 on it.",
  "id" : 479387143974838272,
  "in_reply_to_status_id" : 479342449949560832,
  "created_at" : "2014-06-18 22:16:16 +0000",
  "in_reply_to_screen_name" : "chromakode",
  "in_reply_to_user_id_str" : "14457445",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479382984148013057",
  "text" : "the fact that a retweet bot was the only one that RTd my greatest tweet ever.  that fact, and its relationship to my relationship w technolo",
  "id" : 479382984148013057,
  "created_at" : "2014-06-18 21:59:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479070072434991104",
  "text" : "there be an infinite of maybe \nergo most maybe be not worth mentioning\nbut mine are no doubt \nand no doubt are the rarest of all maybe",
  "id" : 479070072434991104,
  "created_at" : "2014-06-18 01:16:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLT HULK",
      "screen_name" : "PLT_Hulk",
      "indices" : [ 3, 12 ],
      "id_str" : "484936561",
      "id" : 484936561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478618407189770241",
  "text" : "RT @PLT_Hulk: THERE AM FEW THINGS WHAT ANGER PEOPLE MORE THAN HAVING TO USE THEM BRAINS!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478512870033199104",
    "text" : "THERE AM FEW THINGS WHAT ANGER PEOPLE MORE THAN HAVING TO USE THEM BRAINS!!",
    "id" : 478512870033199104,
    "created_at" : "2014-06-16 12:22:13 +0000",
    "user" : {
      "name" : "PLT HULK",
      "screen_name" : "PLT_Hulk",
      "protected" : false,
      "id_str" : "484936561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2104335318\/roflbot_normal.jpeg",
      "id" : 484936561,
      "verified" : false
    }
  },
  "id" : 478618407189770241,
  "created_at" : "2014-06-16 19:21:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "indices" : [ 3, 18 ],
      "id_str" : "620142261",
      "id" : 620142261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478616394083205121",
  "text" : "RT @KimKierkegaard: Those who speak to the crowd, coveting its approval, must be regarded as being worse than prostitutes. Oh, hey 100,000 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478605432953778176",
    "text" : "Those who speak to the crowd, coveting its approval, must be regarded as being worse than prostitutes. Oh, hey 100,000 people!",
    "id" : 478605432953778176,
    "created_at" : "2014-06-16 18:30:01 +0000",
    "user" : {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "protected" : false,
      "id_str" : "620142261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2346161730\/images-2_normal.jpg",
      "id" : 620142261,
      "verified" : false
    }
  },
  "id" : 478616394083205121,
  "created_at" : "2014-06-16 19:13:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Women Art Dealers",
      "screen_name" : "womenartdealers",
      "indices" : [ 0, 16 ],
      "id_str" : "168616860",
      "id" : 168616860
    }, {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 17, 31 ],
      "id_str" : "429007315",
      "id" : 429007315
    }, {
      "name" : "Marie-Andr\u00E9e Paquet",
      "screen_name" : "mapaquet",
      "indices" : [ 32, 41 ],
      "id_str" : "129316450",
      "id" : 129316450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478545759357255681",
  "geo" : { },
  "id_str" : "478616274570723329",
  "in_reply_to_user_id" : 168616860,
  "text" : "@womenartdealers @jesusabdullah @mapaquet  dudes got setup lol",
  "id" : 478616274570723329,
  "in_reply_to_status_id" : 478545759357255681,
  "created_at" : "2014-06-16 19:13:06 +0000",
  "in_reply_to_screen_name" : "womenartdealers",
  "in_reply_to_user_id_str" : "168616860",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLT HULK",
      "screen_name" : "PLT_Hulk",
      "indices" : [ 3, 12 ],
      "id_str" : "484936561",
      "id" : 484936561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478463287747559424",
  "text" : "RT @PLT_Hulk: WHERE AM THE DON DRAPER OF FUNCTIONALS PROGRAMMING!!?!??!?!?!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478307476274966528",
    "text" : "WHERE AM THE DON DRAPER OF FUNCTIONALS PROGRAMMING!!?!??!?!?!!",
    "id" : 478307476274966528,
    "created_at" : "2014-06-15 22:46:03 +0000",
    "user" : {
      "name" : "PLT HULK",
      "screen_name" : "PLT_Hulk",
      "protected" : false,
      "id_str" : "484936561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2104335318\/roflbot_normal.jpeg",
      "id" : 484936561,
      "verified" : false
    }
  },
  "id" : 478463287747559424,
  "created_at" : "2014-06-16 09:05:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 8, 20 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "rvagg",
      "indices" : [ 21, 27 ],
      "id_str" : "158704969",
      "id" : 158704969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478322758393135104",
  "geo" : { },
  "id_str" : "478462730173566977",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar @dominictarr @rvagg \n\nle boosh?",
  "id" : 478462730173566977,
  "in_reply_to_status_id" : 478322758393135104,
  "created_at" : "2014-06-16 09:02:58 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477519542600466432",
  "text" : "u know ur raygay when u no know to spell it &amp;&amp; u yes yes nuh kere",
  "id" : 477519542600466432,
  "created_at" : "2014-06-13 18:35:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/SqXELHRKsX",
      "expanded_url" : "http:\/\/cjohnson.io\/2014\/tesla",
      "display_url" : "cjohnson.io\/2014\/tesla"
    } ]
  },
  "geo" : { },
  "id_str" : "477499061939871744",
  "text" : "this describes it pretty well http:\/\/t.co\/SqXELHRKsX",
  "id" : 477499061939871744,
  "created_at" : "2014-06-13 17:13:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477027301314404352",
  "text" : "i love my lifes",
  "id" : 477027301314404352,
  "created_at" : "2014-06-12 09:59:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/a4kDjs1LKl",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=6TAAx01TMi8&index=3&list=RD9W9jkzbqcdM",
      "display_url" : "youtube.com\/watch?v=6TAAx0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476464909543170048",
  "text" : "\"give me 15 seconds, i'll go into a zone\"\n\nhttps:\/\/t.co\/a4kDjs1LKl\n\nthis is wicked",
  "id" : 476464909543170048,
  "created_at" : "2014-06-10 20:44:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476079231378526209",
  "text" : "my baby ego encouraged that no significant advancement was made in itses absence.",
  "id" : 476079231378526209,
  "created_at" : "2014-06-09 19:11:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475680704601546752",
  "text" : "Why must I wrestle my life from a bear every time I enter the woods???  It's like lightning...",
  "id" : 475680704601546752,
  "created_at" : "2014-06-08 16:48:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474973705861214209",
  "text" : "Im going to Mono Lake with the ghost of Mark Twain",
  "id" : 474973705861214209,
  "created_at" : "2014-06-06 17:58:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474799429896003584",
  "text" : "GROW YOUR DICK",
  "id" : 474799429896003584,
  "created_at" : "2014-06-06 06:26:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 3, 11 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474795919506800640",
  "text" : "RT @LOUDBOT: THINK LIKE A BEAR OF ACTION, ACT LIKE A BEAR OF THOUGHT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/example.com\" rel=\"nofollow\"\u003EBITCHES DON'T KNOW 'BOUT MY INTENSIVE AERIAL BOMBARDMENT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442559383327617026",
    "text" : "THINK LIKE A BEAR OF ACTION, ACT LIKE A BEAR OF THOUGHT",
    "id" : 442559383327617026,
    "created_at" : "2014-03-09 07:15:54 +0000",
    "user" : {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "protected" : false,
      "id_str" : "41296337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/404999194\/speaker_normal.png",
      "id" : 41296337,
      "verified" : false
    }
  },
  "id" : 474795919506800640,
  "created_at" : "2014-06-06 06:12:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 3, 11 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474795889299423232",
  "text" : "RT @LOUDBOT: ALL I AM SAYING IS THAT IF YOU SHARPEN YOUR TEETH NOW YOU WILL NOT HAVE TO WORRY ABOUT DOING IT AFTER THE APOCALYPSE STARTS.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/example.com\" rel=\"nofollow\"\u003EBITCHES DON'T KNOW 'BOUT MY INTENSIVE AERIAL BOMBARDMENT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442767123685707776",
    "text" : "ALL I AM SAYING IS THAT IF YOU SHARPEN YOUR TEETH NOW YOU WILL NOT HAVE TO WORRY ABOUT DOING IT AFTER THE APOCALYPSE STARTS.",
    "id" : 442767123685707776,
    "created_at" : "2014-03-09 21:01:23 +0000",
    "user" : {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "protected" : false,
      "id_str" : "41296337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/404999194\/speaker_normal.png",
      "id" : 41296337,
      "verified" : false
    }
  },
  "id" : 474795889299423232,
  "created_at" : "2014-06-06 06:12:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 3, 11 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474794637551357952",
  "text" : "RT @LOUDBOT: A HOVERCAR IN EVERY GARAGE, AN IPV6 ADDRESS FOR EVERY PLASTIC GROCERY BAG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/example.com\" rel=\"nofollow\"\u003EBITCHES DON'T KNOW 'BOUT MY INTENSIVE AERIAL BOMBARDMENT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "447147869586223104",
    "text" : "A HOVERCAR IN EVERY GARAGE, AN IPV6 ADDRESS FOR EVERY PLASTIC GROCERY BAG",
    "id" : 447147869586223104,
    "created_at" : "2014-03-21 23:08:54 +0000",
    "user" : {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "protected" : false,
      "id_str" : "41296337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/404999194\/speaker_normal.png",
      "id" : 41296337,
      "verified" : false
    }
  },
  "id" : 474794637551357952,
  "created_at" : "2014-06-06 06:07:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 3, 11 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474793675545788416",
  "text" : "RT @LOUDBOT: THERE'S A BIGGER SOURCE OF EVIL THAN PREMATURE OPTIMIZATION: FUCKTARDEDNESS THAT CAN'T EVER BE OPTIMIZED.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/example.com\" rel=\"nofollow\"\u003EBITCHES DON'T KNOW 'BOUT MY INTENSIVE AERIAL BOMBARDMENT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459507056139972608",
    "text" : "THERE'S A BIGGER SOURCE OF EVIL THAN PREMATURE OPTIMIZATION: FUCKTARDEDNESS THAT CAN'T EVER BE OPTIMIZED.",
    "id" : 459507056139972608,
    "created_at" : "2014-04-25 01:39:54 +0000",
    "user" : {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "protected" : false,
      "id_str" : "41296337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/404999194\/speaker_normal.png",
      "id" : 41296337,
      "verified" : false
    }
  },
  "id" : 474793675545788416,
  "created_at" : "2014-06-06 06:03:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 3, 11 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474790261126479872",
  "text" : "RT @LOUDBOT: HAS ANYONE SEEN MY CHILDHOOD? I THINK I LEFT THE CASSETTE AROUND HERE SOMEWHERE.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/example.com\" rel=\"nofollow\"\u003EBITCHES DON'T KNOW 'BOUT MY INTENSIVE AERIAL BOMBARDMENT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454663216379858944",
    "text" : "HAS ANYONE SEEN MY CHILDHOOD? I THINK I LEFT THE CASSETTE AROUND HERE SOMEWHERE.",
    "id" : 454663216379858944,
    "created_at" : "2014-04-11 16:52:12 +0000",
    "user" : {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "protected" : false,
      "id_str" : "41296337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/404999194\/speaker_normal.png",
      "id" : 41296337,
      "verified" : false
    }
  },
  "id" : 474790261126479872,
  "created_at" : "2014-06-06 05:49:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 3, 11 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474787395728986112",
  "text" : "RT @LOUDBOT: THE FIRST RULE OF THE MAILING LIST IS PLEASE UNSUBSCRIBE ME FROM THE MAILING LIST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/example.com\" rel=\"nofollow\"\u003EBITCHES DON'T KNOW 'BOUT MY INTENSIVE AERIAL BOMBARDMENT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463511217340833793",
    "text" : "THE FIRST RULE OF THE MAILING LIST IS PLEASE UNSUBSCRIBE ME FROM THE MAILING LIST",
    "id" : 463511217340833793,
    "created_at" : "2014-05-06 02:51:00 +0000",
    "user" : {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "protected" : false,
      "id_str" : "41296337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/404999194\/speaker_normal.png",
      "id" : 41296337,
      "verified" : false
    }
  },
  "id" : 474787395728986112,
  "created_at" : "2014-06-06 05:38:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474786840881283072",
  "text" : "LAST NIGHT RECORDINGS",
  "id" : 474786840881283072,
  "created_at" : "2014-06-06 05:36:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474786268644012032",
  "text" : "LIFE IS A BONANZA",
  "id" : 474786268644012032,
  "created_at" : "2014-06-06 05:34:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474776631035564032",
  "geo" : { },
  "id_str" : "474778377266532352",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti the only excuse I'll allow, is losing on the road to secure the home closer.  Otherwise, it was the Mexicans for sure.",
  "id" : 474778377266532352,
  "in_reply_to_status_id" : 474776631035564032,
  "created_at" : "2014-06-06 05:02:40 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Tweetserve",
      "screen_name" : "TheTweetserve",
      "indices" : [ 4, 18 ],
      "id_str" : "2300627557",
      "id" : 2300627557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474776703621799937",
  "text" : "the @TheTweetserve finally retweeted a decent one of mine.",
  "id" : 474776703621799937,
  "created_at" : "2014-06-06 04:56:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474775234462371841",
  "geo" : { },
  "id_str" : "474776441972744192",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti \nbut they are the HEAT \nTHEY ARE THE AVATAR FOR HEAT ITSELF",
  "id" : 474776441972744192,
  "in_reply_to_status_id" : 474775234462371841,
  "created_at" : "2014-06-06 04:54:59 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474712046357848064",
  "text" : "OH BITCH BALLS!!!",
  "id" : 474712046357848064,
  "created_at" : "2014-06-06 00:39:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474709381485826048",
  "text" : "some times I cannot believe that words formed by mouths into language actually communicate meaning; \n\nwhere some time means often.",
  "id" : 474709381485826048,
  "created_at" : "2014-06-06 00:28:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474692427010166784",
  "text" : "feedback is creates fractals",
  "id" : 474692427010166784,
  "created_at" : "2014-06-05 23:21:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474406262151467008",
  "text" : "* the justDownloadTheOriginal Remix",
  "id" : 474406262151467008,
  "created_at" : "2014-06-05 04:24:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 15, 26 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 27, 35 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474218957751476225",
  "geo" : { },
  "id_str" : "474243890971561984",
  "in_reply_to_user_id" : 17092251,
  "text" : "... the babies @whichlight @soldair",
  "id" : 474243890971561984,
  "in_reply_to_status_id" : 474218957751476225,
  "created_at" : "2014-06-04 17:38:49 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473743911848906753",
  "text" : "the crypt keepers says\ni'll take these graves \nto my secret",
  "id" : 473743911848906753,
  "created_at" : "2014-06-03 08:32:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473657848233074688",
  "text" : "i am substack",
  "id" : 473657848233074688,
  "created_at" : "2014-06-03 02:50:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 5, 12 ],
      "id_str" : "15692193",
      "id" : 15692193
    }, {
      "name" : "juliepagano",
      "screen_name" : "juliepagano",
      "indices" : [ 13, 25 ],
      "id_str" : "2874563195",
      "id" : 2874563195
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 26, 35 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Felix Geisend\u00F6rfer",
      "screen_name" : "felixge",
      "indices" : [ 36, 44 ],
      "id_str" : "9599342",
      "id" : 9599342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473643912314109952",
  "geo" : { },
  "id_str" : "473657823365062657",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs @feross @juliepagano @substack @felixge \nI am substack",
  "id" : 473657823365062657,
  "in_reply_to_status_id" : 473643912314109952,
  "created_at" : "2014-06-03 02:49:59 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473577727279128576",
  "text" : "god monkey's patch",
  "id" : 473577727279128576,
  "created_at" : "2014-06-02 21:31:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "indices" : [ 3, 18 ],
      "id_str" : "620142261",
      "id" : 620142261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473564769664761856",
  "text" : "RT @KimKierkegaard: Should I use my sins to terrify the public?Or should I keep this terror hidden in my innermost being? Trying on a few l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473550841610518528",
    "text" : "Should I use my sins to terrify the public?Or should I keep this terror hidden in my innermost being? Trying on a few looks 2 see what works",
    "id" : 473550841610518528,
    "created_at" : "2014-06-02 19:44:53 +0000",
    "user" : {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "protected" : false,
      "id_str" : "620142261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2346161730\/images-2_normal.jpg",
      "id" : 620142261,
      "verified" : false
    }
  },
  "id" : 473564769664761856,
  "created_at" : "2014-06-02 20:40:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473560857352237056",
  "text" : "\u00BFcachetona o nalgona?",
  "id" : 473560857352237056,
  "created_at" : "2014-06-02 20:24:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472970103340797952",
  "text" : "dirty, dirty",
  "id" : 472970103340797952,
  "created_at" : "2014-06-01 05:17:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472967152639569920",
  "text" : "i reserve hope for things that don't matter all too much.",
  "id" : 472967152639569920,
  "created_at" : "2014-06-01 05:05:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]