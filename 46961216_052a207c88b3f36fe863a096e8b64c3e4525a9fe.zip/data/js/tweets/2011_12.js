Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151411501272543232",
  "text" : "kickin' apps and taking domains",
  "id" : 151411501272543232,
  "created_at" : "2011-12-26 21:18:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayson Musson",
      "screen_name" : "therealhennessy",
      "indices" : [ 3, 19 ],
      "id_str" : "137090436",
      "id" : 137090436
    }, {
      "name" : "Justin Charles",
      "screen_name" : "justincharles",
      "indices" : [ 38, 52 ],
      "id_str" : "5674602",
      "id" : 5674602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151407422454497280",
  "text" : "RT @therealhennessy: @ChelseaVPeretti @justincharles the tapestry of the internet has brought us together",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justin Charles",
        "screen_name" : "justincharles",
        "indices" : [ 17, 31 ],
        "id_str" : "5674602",
        "id" : 5674602
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "151392228458250240",
    "geo" : { },
    "id_str" : "151405439370801152",
    "in_reply_to_user_id" : 78194111,
    "text" : "@ChelseaVPeretti @justincharles the tapestry of the internet has brought us together",
    "id" : 151405439370801152,
    "in_reply_to_status_id" : 151392228458250240,
    "created_at" : "2011-12-26 20:54:04 +0000",
    "in_reply_to_screen_name" : "chelseaperetti",
    "in_reply_to_user_id_str" : "78194111",
    "user" : {
      "name" : "Jayson Musson",
      "screen_name" : "therealhennessy",
      "protected" : false,
      "id_str" : "137090436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710908032515964928\/7_bdCSc4_normal.jpg",
      "id" : 137090436,
      "verified" : false
    }
  },
  "id" : 151407422454497280,
  "created_at" : "2011-12-26 21:01:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakim El Hattab",
      "screen_name" : "hakimel",
      "indices" : [ 0, 8 ],
      "id_str" : "73339662",
      "id" : 73339662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "positive",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151397151447060480",
  "geo" : { },
  "id_str" : "151403664576217088",
  "in_reply_to_user_id" : 73339662,
  "text" : "@hakimel she passes the \"jams with reggae\" test #positive",
  "id" : 151403664576217088,
  "in_reply_to_status_id" : 151397151447060480,
  "created_at" : "2011-12-26 20:47:01 +0000",
  "in_reply_to_screen_name" : "hakimel",
  "in_reply_to_user_id_str" : "73339662",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/XX345mIp",
      "expanded_url" : "http:\/\/fullcomment.nationalpost.com\/2011\/12\/22\/peter-goodspeed-irans-currency-collapse-prompts-fear-of-oil-blockade\/",
      "display_url" : "fullcomment.nationalpost.com\/2011\/12\/22\/pet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150301296971362305",
  "text" : "\u201CMy biggest worry is they will miscalculate our resolve.\" Senior US Military fears inability to muster control of self http:\/\/t.co\/XX345mIp",
  "id" : 150301296971362305,
  "created_at" : "2011-12-23 19:46:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Israel",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "Palestine",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150290350358003712",
  "text" : "RT @FourYawkeyWay: #Israel will once again be occupying Christmas in #Palestine as it has been occupying Christmas & all of Palestine fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Israel",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Palestine",
        "indices" : [ 50, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "150288418901995521",
    "text" : "#Israel will once again be occupying Christmas in #Palestine as it has been occupying Christmas & all of Palestine for decades.",
    "id" : 150288418901995521,
    "created_at" : "2011-12-23 18:55:25 +0000",
    "user" : {
      "name" : "David Ferreira",
      "screen_name" : "Igualitarista",
      "protected" : false,
      "id_str" : "242154581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586766949268361216\/xCZ2INGI_normal.jpg",
      "id" : 242154581,
      "verified" : false
    }
  },
  "id" : 150290350358003712,
  "created_at" : "2011-12-23 19:03:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150288003397455872",
  "text" : "are you struggling, or just struffling, bug man?",
  "id" : 150288003397455872,
  "created_at" : "2011-12-23 18:53:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 114, 122 ],
      "id_str" : "19417999",
      "id" : 19417999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "consulting",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150285970942599168",
  "text" : "The Syrian didn't like any of my music stylings over the office ambient music system. Not afro psych nor Dam funk @DamFunK #consulting",
  "id" : 150285970942599168,
  "created_at" : "2011-12-23 18:45:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wheniGrowBillion",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150280367989997569",
  "text" : "#wheniGrowBillion",
  "id" : 150280367989997569,
  "created_at" : "2011-12-23 18:23:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/x3YE3vbj",
      "expanded_url" : "http:\/\/canv.as",
      "display_url" : "canv.as"
    }, {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/srxqMxB0",
      "expanded_url" : "http:\/\/gun.io\/careers\/437\/software-engineer",
      "display_url" : "gun.io\/careers\/437\/so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "149959346686660609",
  "text" : "wow I like what http:\/\/t.co\/x3YE3vbj is doing. also they are hiring http:\/\/t.co\/srxqMxB0",
  "id" : 149959346686660609,
  "created_at" : "2011-12-22 21:07:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/OjfZrhS4",
      "expanded_url" : "http:\/\/canv.as\/s\/fyjw",
      "display_url" : "canv.as\/s\/fyjw"
    }, {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/XvBJ5jyO",
      "expanded_url" : "http:\/\/canv.as\/s\/fykf",
      "display_url" : "canv.as\/s\/fykf"
    } ]
  },
  "geo" : { },
  "id_str" : "149956792959500290",
  "text" : "oh heil no! http:\/\/t.co\/OjfZrhS4 (go to top http:\/\/t.co\/XvBJ5jyO)",
  "id" : 149956792959500290,
  "created_at" : "2011-12-22 20:57:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "Node Summit",
      "screen_name" : "NodeSummit",
      "indices" : [ 139, 140 ],
      "id_str" : "293718395",
      "id" : 293718395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nodejs",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/nyI11xre",
      "expanded_url" : "http:\/\/nationalheadquarters.org",
      "display_url" : "nationalheadquarters.org"
    } ]
  },
  "geo" : { },
  "id_str" : "149698574563819520",
  "text" : "RT @AngelineGragzin: My company http:\/\/t.co\/nyI11xre builds apps w\/ #Nodejs. We applied to present Project OMEGAWD @ Node Summit SF *Loo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Node Summit",
        "screen_name" : "NodeSummit",
        "indices" : [ 118, 129 ],
        "id_str" : "293718395",
        "id" : 293718395
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nodejs",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http:\/\/t.co\/nyI11xre",
        "expanded_url" : "http:\/\/nationalheadquarters.org",
        "display_url" : "nationalheadquarters.org"
      } ]
    },
    "geo" : { },
    "id_str" : "149576685682044928",
    "text" : "My company http:\/\/t.co\/nyI11xre builds apps w\/ #Nodejs. We applied to present Project OMEGAWD @ Node Summit SF *Looks @NodeSummit* :-)",
    "id" : 149576685682044928,
    "created_at" : "2011-12-21 19:47:15 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703307803574865921\/ZpTWouST_normal.jpg",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 149698574563819520,
  "created_at" : "2011-12-22 03:51:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149596049395286017",
  "text" : "RT @LOLGOP: FYI: The original Tea Party wasn't fighting for higher taxes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149595111616020480",
    "text" : "FYI: The original Tea Party wasn't fighting for higher taxes.",
    "id" : 149595111616020480,
    "created_at" : "2011-12-21 21:00:28 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649031186845560832\/c385MSMQ_normal.jpg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 149596049395286017,
  "created_at" : "2011-12-21 21:04:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SolyndraCo",
      "screen_name" : "SolyndraCo",
      "indices" : [ 3, 14 ],
      "id_str" : "374672090",
      "id" : 374672090
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Solyndra",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149270362021040128",
  "text" : "RT @SolyndraCo: At #Solyndra all of our email was powered by clean, solar energy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Solyndra",
        "indices" : [ 3, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "142338586904231936",
    "text" : "At #Solyndra all of our email was powered by clean, solar energy.",
    "id" : 142338586904231936,
    "created_at" : "2011-12-01 20:25:38 +0000",
    "user" : {
      "name" : "SolyndraCo",
      "screen_name" : "SolyndraCo",
      "protected" : false,
      "id_str" : "374672090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1545757472\/SOL-avi-small_normal.jpg",
      "id" : 374672090,
      "verified" : false
    }
  },
  "id" : 149270362021040128,
  "created_at" : "2011-12-20 23:30:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148935198057304064",
  "text" : "That doesn't sound like a bad thing to me, baby.",
  "id" : 148935198057304064,
  "created_at" : "2011-12-20 01:18:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148934197661274112",
  "text" : "\"Beware of writing zero-length buffers, as they will induce NaNs to your buffers.\"",
  "id" : 148934197661274112,
  "created_at" : "2011-12-20 01:14:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147845806748209152",
  "text" : "ima go ahead and feel humbled by the appearance of a Costco Jobs ad targeted at me in gmail.",
  "id" : 147845806748209152,
  "created_at" : "2011-12-17 01:09:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "clowncongress",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/VOMlOGIH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0PAJNntoRgA&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=0PAJNn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147797998284439552",
  "text" : "edit: 600,000++ dislikings of Rick Perry bafoonery http:\/\/t.co\/VOMlOGIH #clowncongress",
  "id" : 147797998284439552,
  "created_at" : "2011-12-16 21:59:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/Rp62gQWA",
      "expanded_url" : "http:\/\/blogs.villagevoice.com\/runninscared\/2011\/12\/rick_perrys_ant.php",
      "display_url" : "blogs.villagevoice.com\/runninscared\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147796942531989504",
  "text" : "Surely this is the work of some cognizant mole. Rick Perry's 'anti-gay' ad is scored by outspoken gay composer. http:\/\/t.co\/Rp62gQWA",
  "id" : 147796942531989504,
  "created_at" : "2011-12-16 21:55:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Park",
      "screen_name" : "donpark",
      "indices" : [ 0, 8 ],
      "id_str" : "892821",
      "id" : 892821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146028086104834049",
  "geo" : { },
  "id_str" : "146031948844892161",
  "in_reply_to_user_id" : 892821,
  "text" : "@donpark I follow. Ya was curious what buffering happnd in socket.io before I got the data. Needa dig deeper. Still gonna push it tho!",
  "id" : 146031948844892161,
  "in_reply_to_status_id" : 146028086104834049,
  "created_at" : "2011-12-12 01:01:44 +0000",
  "in_reply_to_screen_name" : "donpark",
  "in_reply_to_user_id_str" : "892821",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Park",
      "screen_name" : "donpark",
      "indices" : [ 0, 8 ],
      "id_str" : "892821",
      "id" : 892821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146020320124469249",
  "geo" : { },
  "id_str" : "146021561592324096",
  "in_reply_to_user_id" : 892821,
  "text" : "@donpark is there some sort of restriction on packet size?",
  "id" : 146021561592324096,
  "in_reply_to_status_id" : 146020320124469249,
  "created_at" : "2011-12-12 00:20:27 +0000",
  "in_reply_to_screen_name" : "donpark",
  "in_reply_to_user_id_str" : "892821",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack",
      "screen_name" : "jack",
      "indices" : [ 0, 5 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "metrosex",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "146019477442662401",
  "geo" : { },
  "id_str" : "146020994463703040",
  "in_reply_to_user_id" : 12,
  "text" : "@jack Dorsey keeps cities for mistresses #metrosex",
  "id" : 146020994463703040,
  "in_reply_to_status_id" : 146019477442662401,
  "created_at" : "2011-12-12 00:18:12 +0000",
  "in_reply_to_screen_name" : "jack",
  "in_reply_to_user_id_str" : "12",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146016511914549248",
  "text" : "successfully streamed blobs as array buffers from client to serve over websocket. #nodejs",
  "id" : 146016511914549248,
  "created_at" : "2011-12-12 00:00:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "html5",
      "indices" : [ 37, 43 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145635735402315776",
  "text" : "Hey HTML5 Files API. Grow a gzipper! #html5 #nodejs",
  "id" : 145635735402315776,
  "created_at" : "2011-12-10 22:47:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "commonjs",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "html5",
      "indices" : [ 100, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145595091212443649",
  "text" : "Grant me this wish: that the HTML5 File System API === Node's File System module. #commonjs #nodejs #html5",
  "id" : 145595091212443649,
  "created_at" : "2011-12-10 20:05:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145224814360150016",
  "text" : "I'm pretty sure that major corporations are stifling innovation right now by choking my internet access.",
  "id" : 145224814360150016,
  "created_at" : "2011-12-09 19:34:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marak",
      "screen_name" : "marak",
      "indices" : [ 0, 6 ],
      "id_str" : "110465841",
      "id" : 110465841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144966668802732033",
  "in_reply_to_user_id" : 110465841,
  "text" : "@marak  what do i do to activate an inactive account? error:  Cannot reset password for inactive account.",
  "id" : 144966668802732033,
  "created_at" : "2011-12-09 02:28:41 +0000",
  "in_reply_to_screen_name" : "marak",
  "in_reply_to_user_id_str" : "110465841",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "indices" : [ 3, 13 ],
      "id_str" : "13696102",
      "id" : 13696102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/APR2MKwy",
      "expanded_url" : "http:\/\/www.procatinator.com\/",
      "display_url" : "procatinator.com"
    } ]
  },
  "geo" : { },
  "id_str" : "144966234931331072",
  "text" : "RT @indexzero: This is what the Internet is all about :: http:\/\/t.co\/APR2MKwy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/APR2MKwy",
        "expanded_url" : "http:\/\/www.procatinator.com\/",
        "display_url" : "procatinator.com"
      } ]
    },
    "geo" : { },
    "id_str" : "144933658208378880",
    "text" : "This is what the Internet is all about :: http:\/\/t.co\/APR2MKwy",
    "id" : 144933658208378880,
    "created_at" : "2011-12-09 00:17:31 +0000",
    "user" : {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "protected" : false,
      "id_str" : "13696102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596629051525083137\/OR9vj35E_normal.png",
      "id" : 13696102,
      "verified" : false
    }
  },
  "id" : 144966234931331072,
  "created_at" : "2011-12-09 02:26:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/tBP1jwHz",
      "expanded_url" : "http:\/\/www.popularmechanics.com\/technology\/aviation\/crashes\/what-really-happened-aboard-air-france-447-6611877",
      "display_url" : "popularmechanics.com\/technology\/avi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "144962466361774080",
  "text" : "This is a dramatic and terrifying story:  http:\/\/t.co\/tBP1jwHz",
  "id" : 144962466361774080,
  "created_at" : "2011-12-09 02:11:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/ZUnO3dR5",
      "expanded_url" : "http:\/\/pdf.textfiles.com\/zines\/TEL\/tel-01.pdf",
      "display_url" : "pdf.textfiles.com\/zines\/TEL\/tel-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "144908910627799041",
  "text" : "what about the comic at the end this phone hacking magazine from the 70s, scroll to last page: http:\/\/t.co\/ZUnO3dR5",
  "id" : 144908910627799041,
  "created_at" : "2011-12-08 22:39:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redis",
      "indices" : [ 57, 63 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144907089632968704",
  "text" : "how do i configure the host for a redis server? anybody? #redis #nodejs",
  "id" : 144907089632968704,
  "created_at" : "2011-12-08 22:31:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trill",
      "indices" : [ 46, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144664947077554176",
  "text" : "i pressed control and f and then i typed god. #trill",
  "id" : 144664947077554176,
  "created_at" : "2011-12-08 06:29:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/t1FujWmE",
      "expanded_url" : "http:\/\/wikileaks.org\/support.html",
      "display_url" : "wikileaks.org\/support.html"
    } ]
  },
  "geo" : { },
  "id_str" : "144594255543934977",
  "text" : "RT @wikileaks: Assange: 366 days detained-no charge; WikiLeaks: 369 days banking blockade-no process; Manning: 563 days jail-no trial ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/t1FujWmE",
        "expanded_url" : "http:\/\/wikileaks.org\/support.html",
        "display_url" : "wikileaks.org\/support.html"
      } ]
    },
    "geo" : { },
    "id_str" : "144573836409573376",
    "text" : "Assange: 366 days detained-no charge; WikiLeaks: 369 days banking blockade-no process; Manning: 563 days jail-no trial http:\/\/t.co\/t1FujWmE",
    "id" : 144573836409573376,
    "created_at" : "2011-12-08 00:27:43 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 144594255543934977,
  "created_at" : "2011-12-08 01:48:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144549932068651008",
  "text" : "that was my lunch break",
  "id" : 144549932068651008,
  "created_at" : "2011-12-07 22:52:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/tLOuQhjq",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Pesticides_in_the_United_States",
      "display_url" : "en.wikipedia.org\/wiki\/Pesticide\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "144548646367657984",
  "text" : "rough numbers: USA sprays abt 1-2 Valdez Oil Spills in pesticides, every year. Src: 15 min. web research starting @ http:\/\/t.co\/tLOuQhjq",
  "id" : 144548646367657984,
  "created_at" : "2011-12-07 22:47:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GONZO_CAPITALISM",
      "screen_name" : "randsevilla",
      "indices" : [ 31, 43 ],
      "id_str" : "33033995",
      "id" : 33033995
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 44, 60 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "Nestor Br\u00FBl\u00E9e",
      "screen_name" : "Nestor_tweets",
      "indices" : [ 61, 75 ],
      "id_str" : "221527591",
      "id" : 221527591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/GYkxlHa9",
      "expanded_url" : "http:\/\/copyrightedimagesofbusinessmenjumping.com\/",
      "display_url" : "\u2026rightedimagesofbusinessmenjumping.com"
    } ]
  },
  "in_reply_to_status_id_str" : "144505874122145793",
  "geo" : { },
  "id_str" : "144534120310120448",
  "in_reply_to_user_id" : 58809542,
  "text" : "videos of businessmen sparring @randsevilla @AngelineGragzin @nestor_tweets http:\/\/t.co\/GYkxlHa9",
  "id" : 144534120310120448,
  "in_reply_to_status_id" : 144505874122145793,
  "created_at" : "2011-12-07 21:49:54 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Loomis",
      "screen_name" : "ErikLoomis",
      "indices" : [ 3, 14 ],
      "id_str" : "17136680",
      "id" : 17136680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144156927591583744",
  "text" : "RT @ErikLoomis: Every time I start working on my book, I get angry at capitalists who have been dead for 90 years.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144142784406892545",
    "text" : "Every time I start working on my book, I get angry at capitalists who have been dead for 90 years.",
    "id" : 144142784406892545,
    "created_at" : "2011-12-06 19:54:52 +0000",
    "user" : {
      "name" : "Erik Loomis",
      "screen_name" : "ErikLoomis",
      "protected" : false,
      "id_str" : "17136680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227170266\/ibt_normal.jpg",
      "id" : 17136680,
      "verified" : false
    }
  },
  "id" : 144156927591583744,
  "created_at" : "2011-12-06 20:51:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "OpMonsanto",
      "indices" : [ 3, 14 ],
      "id_str" : "294447837",
      "id" : 294447837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/HFP5jJV5",
      "expanded_url" : "http:\/\/pastebin.com\/U0HZqB7e",
      "display_url" : "pastebin.com\/U0HZqB7e"
    } ]
  },
  "geo" : { },
  "id_str" : "143819975193411584",
  "text" : "RT @OpMonsanto: For those who missed it: http:\/\/t.co\/HFP5jJV5  Internal Monsanto fact sheet exposing pesticides, and how much damage the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/HFP5jJV5",
        "expanded_url" : "http:\/\/pastebin.com\/U0HZqB7e",
        "display_url" : "pastebin.com\/U0HZqB7e"
      } ]
    },
    "geo" : { },
    "id_str" : "143805110617772032",
    "text" : "For those who missed it: http:\/\/t.co\/HFP5jJV5  Internal Monsanto fact sheet exposing pesticides, and how much damage they know they cause.",
    "id" : 143805110617772032,
    "created_at" : "2011-12-05 21:33:04 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "OpMonsanto",
      "protected" : false,
      "id_str" : "294447837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1526039593\/anonymous-green-babydoll_design_normal.png",
      "id" : 294447837,
      "verified" : false
    }
  },
  "id" : 143819975193411584,
  "created_at" : "2011-12-05 22:32:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143543779427753984",
  "text" : "RT @LOLGOP: Herman Cain is endorsing Newt Gingrich as a subtle way to say to his wife, \"See, I could be a lot worse.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "143534181014700033",
    "text" : "Herman Cain is endorsing Newt Gingrich as a subtle way to say to his wife, \"See, I could be a lot worse.\"",
    "id" : 143534181014700033,
    "created_at" : "2011-12-05 03:36:30 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649031186845560832\/c385MSMQ_normal.jpg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 143543779427753984,
  "created_at" : "2011-12-05 04:14:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T-Mobile",
      "screen_name" : "TMobile",
      "indices" : [ 34, 42 ],
      "id_str" : "17338082",
      "id" : 17338082
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tmobile",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143367869676269568",
  "text" : "your \"unlimited\" data plan sucks! @tmobile #tmobile",
  "id" : 143367869676269568,
  "created_at" : "2011-12-04 16:35:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/8ASmcSol",
      "expanded_url" : "http:\/\/www.spiegel.de\/international\/world\/0,1518,800850,00.html",
      "display_url" : "spiegel.de\/international\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "143120857135456256",
  "text" : "Is the Republican Party a reality television show, the winner gets to run for President? That is so way ahead. http:\/\/t.co\/8ASmcSol",
  "id" : 143120857135456256,
  "created_at" : "2011-12-04 00:14:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143101049677414400",
  "text" : "urge to update growing",
  "id" : 143101049677414400,
  "created_at" : "2011-12-03 22:55:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 0, 7 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142802752983142400",
  "geo" : { },
  "id_str" : "143090625435271168",
  "in_reply_to_user_id" : 668423,
  "text" : "@mikeal v0.4.7. I'll be upgrading soon.",
  "id" : 143090625435271168,
  "in_reply_to_status_id" : 142802752983142400,
  "created_at" : "2011-12-03 22:13:58 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 0, 7 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142801468792123392",
  "geo" : { },
  "id_str" : "142802563404795904",
  "in_reply_to_user_id" : 668423,
  "text" : "@mikeal ?:[  r.connection has no method 'abort'",
  "id" : 142802563404795904,
  "in_reply_to_status_id" : 142801468792123392,
  "created_at" : "2011-12-03 03:09:18 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 0, 7 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142799516033232896",
  "geo" : { },
  "id_str" : "142801236037611520",
  "in_reply_to_user_id" : 668423,
  "text" : "@mikeal I found this to work... onRepsonse: function(e,r)\u007B r.connection._events.close();\u007D",
  "id" : 142801236037611520,
  "in_reply_to_status_id" : 142799516033232896,
  "created_at" : "2011-12-03 03:04:02 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/u3l5S6iR",
      "expanded_url" : "http:\/\/english.ahram.org.eg\/~\/NewsContent\/1\/64\/27956\/Egypt\/Politics-\/Suez-port-employees-reveal-ton-US-tear-gas-order-f.aspx",
      "display_url" : "english.ahram.org.eg\/~\/NewsContent\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "142793555612667904",
  "text" : "US Exports doing well. 21 tons of tear gas shipping to Egypt [reported] http:\/\/t.co\/u3l5S6iR #ows",
  "id" : 142793555612667904,
  "created_at" : "2011-12-03 02:33:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/mpL20dk4",
      "expanded_url" : "http:\/\/a4.sphotos.ak.fbcdn.net\/hphotos-ak-snc7\/380486_208171025924854_182336115175012_463207_893481402_n.jpg",
      "display_url" : "a4.sphotos.ak.fbcdn.net\/hphotos-ak-snc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "142792438757597184",
  "text" : "Here's a Federal Gov't \/ Monsanto Venn Diagram http:\/\/t.co\/mpL20dk4",
  "id" : 142792438757597184,
  "created_at" : "2011-12-03 02:29:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142780503848796161",
  "geo" : { },
  "id_str" : "142787911295836160",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia dropped yr orange in yr keyboard again :?",
  "id" : 142787911295836160,
  "in_reply_to_status_id" : 142780503848796161,
  "created_at" : "2011-12-03 02:11:05 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 0, 7 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142787655673974784",
  "in_reply_to_user_id" : 668423,
  "text" : "@mikeal Is it possible to end\/close a request, say after the first onResponse? #nodejs",
  "id" : 142787655673974784,
  "created_at" : "2011-12-03 02:10:04 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/uKv9ALhG",
      "expanded_url" : "http:\/\/www.nytimes.com\/2011\/12\/02\/us\/drilling-down-fighting-over-oil-and-gas-well-leases.html?_r=1&hp",
      "display_url" : "nytimes.com\/2011\/12\/02\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "142708742683762688",
  "text" : "private landowners sign contracts they don't read, let OIL CO's contaminate water tables; NYT article sympathetic http:\/\/t.co\/uKv9ALhG",
  "id" : 142708742683762688,
  "created_at" : "2011-12-02 20:56:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]