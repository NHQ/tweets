Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616041156946735104",
  "text" : "dont say yes or no \ngive it seven beats and then\nsay maybe, baby",
  "id" : 616041156946735104,
  "created_at" : "2015-07-01 00:30:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615998167234904064",
  "geo" : { },
  "id_str" : "616000288252518400",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair you must not be familiar with EULA's law of STFU and EAT THESE COOKIES",
  "id" : 616000288252518400,
  "in_reply_to_status_id" : 615998167234904064,
  "created_at" : "2015-06-30 21:48:08 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/fEHe7WlZ3J",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/stand-by",
      "display_url" : "soundcloud.com\/folkstack\/stan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615999597354192897",
  "text" : "you have to get past the contra to get the good\n  \nhttps:\/\/t.co\/fEHe7WlZ3J",
  "id" : 615999597354192897,
  "created_at" : "2015-06-30 21:45:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/fEHe7WlZ3J",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/stand-by",
      "display_url" : "soundcloud.com\/folkstack\/stan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615937076719042560",
  "text" : "https:\/\/t.co\/fEHe7WlZ3J",
  "id" : 615937076719042560,
  "created_at" : "2015-06-30 17:36:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615633501262446593",
  "text" : "premature ejubilation",
  "id" : 615633501262446593,
  "created_at" : "2015-06-29 21:30:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614993803984789504",
  "text" : "me priest reading scripternets",
  "id" : 614993803984789504,
  "created_at" : "2015-06-28 03:08:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614992877760811008",
  "text" : "dont say yes or no \nwait seven beats, and then\nsay maybe, baby",
  "id" : 614992877760811008,
  "created_at" : "2015-06-28 03:05:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614774846635913216",
  "text" : "I could not remember the word \"optimistic\" right now.",
  "id" : 614774846635913216,
  "created_at" : "2015-06-27 12:38:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Scott ANDERSON",
      "screen_name" : "treenopie",
      "indices" : [ 0, 10 ],
      "id_str" : "976380487",
      "id" : 976380487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614484680012750848",
  "geo" : { },
  "id_str" : "614485190878978048",
  "in_reply_to_user_id" : 976380487,
  "text" : "@treenopie  \"Hitched by the state.\"",
  "id" : 614485190878978048,
  "in_reply_to_status_id" : 614484680012750848,
  "created_at" : "2015-06-26 17:27:40 +0000",
  "in_reply_to_screen_name" : "treenopie",
  "in_reply_to_user_id_str" : "976380487",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614484143657762816",
  "text" : "Marriage is still a bad idea.",
  "id" : 614484143657762816,
  "created_at" : "2015-06-26 17:23:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/6KuUIYRvmA",
      "expanded_url" : "http:\/\/www.commondreams.org\/author\/margaret-kimberley",
      "display_url" : "commondreams.org\/author\/margare\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614323186117652480",
  "text" : "good writer, bad news  http:\/\/t.co\/6KuUIYRvmA",
  "id" : 614323186117652480,
  "created_at" : "2015-06-26 06:43:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "France World News",
      "screen_name" : "franceworldnews",
      "indices" : [ 3, 19 ],
      "id_str" : "2157067153",
      "id" : 2157067153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614301351632211969",
  "text" : "RT @franceworldnews: Baseball welcomes first gay player. France surrenders.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/franceworldnews\" rel=\"nofollow\"\u003EFrance World News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614293267446931456",
    "text" : "Baseball welcomes first gay player. France surrenders.",
    "id" : 614293267446931456,
    "created_at" : "2015-06-26 04:45:02 +0000",
    "user" : {
      "name" : "France World News",
      "screen_name" : "franceworldnews",
      "protected" : false,
      "id_str" : "2157067153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000650651370\/0e85ec9ecae0b763e059c858ce11b89a_normal.png",
      "id" : 2157067153,
      "verified" : false
    }
  },
  "id" : 614301351632211969,
  "created_at" : "2015-06-26 05:17:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614155819303632897",
  "text" : "DO YOU HAVE THE QUANTUM DATA???",
  "id" : 614155819303632897,
  "created_at" : "2015-06-25 19:38:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612850935811829760",
  "text" : "OH \"Polemics are intellectual gimmicks.\"",
  "id" : 612850935811829760,
  "created_at" : "2015-06-22 05:13:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612835732281888768",
  "text" : "Happy Father's Day, Mom.",
  "id" : 612835732281888768,
  "created_at" : "2015-06-22 04:13:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "juneteenth",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612341493144006656",
  "text" : "&lt;3 when I get love on the street in my hood.  About to go play the #juneteenth fest at the park.",
  "id" : 612341493144006656,
  "created_at" : "2015-06-20 19:29:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 0, 8 ],
      "id_str" : "19417999",
      "id" : 19417999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/vpQVil5bDu",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/i-get-excited",
      "display_url" : "soundcloud.com\/folkstack\/i-ge\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "612339190395637760",
  "geo" : { },
  "id_str" : "612340972974837760",
  "in_reply_to_user_id" : 19417999,
  "text" : "@DaMFunK I liked this song so much I had to work it a little bit:\n\nhttps:\/\/t.co\/vpQVil5bDu",
  "id" : 612340972974837760,
  "in_reply_to_status_id" : 612339190395637760,
  "created_at" : "2015-06-20 19:27:19 +0000",
  "in_reply_to_screen_name" : "DaMFunK",
  "in_reply_to_user_id_str" : "19417999",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/PdQIyicp3S",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=dQ01FGeB1vo",
      "display_url" : "youtube.com\/watch?v=dQ01FG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612090797106688000",
  "text" : "can't say I hate this album cover, or the song.  https:\/\/t.co\/PdQIyicp3S",
  "id" : 612090797106688000,
  "created_at" : "2015-06-20 02:53:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GTFO",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612056088913973248",
  "text" : "twitter ads now autoplaying like a bad newsblog website  on scroll over.  that's some jump the shark shit. #GTFO",
  "id" : 612056088913973248,
  "created_at" : "2015-06-20 00:35:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612036313877843969",
  "text" : "I need to take a serotonin dump.",
  "id" : 612036313877843969,
  "created_at" : "2015-06-19 23:16:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611828167544803328",
  "geo" : { },
  "id_str" : "611834876887633920",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  wow I did not know cockroaches could program!",
  "id" : 611834876887633920,
  "in_reply_to_status_id" : 611828167544803328,
  "created_at" : "2015-06-19 09:56:16 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611736827632824320",
  "text" : "I'm feeling left out of the rap game",
  "id" : 611736827632824320,
  "created_at" : "2015-06-19 03:26:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611623869707759616",
  "text" : "POPE ON A ROLL",
  "id" : 611623869707759616,
  "created_at" : "2015-06-18 19:57:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brendle",
      "screen_name" : "brendlewhat",
      "indices" : [ 3, 15 ],
      "id_str" : "38103536",
      "id" : 38103536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611601904104136704",
  "text" : "RT @brendlewhat: *lives in a culture of cutthroat competition, militarism and callousness led by sociopaths idolized as heroes* WHY DOES TH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279662765340229632",
    "text" : "*lives in a culture of cutthroat competition, militarism and callousness led by sociopaths idolized as heroes* WHY DOES THIS KEEP HAPPENING?",
    "id" : 279662765340229632,
    "created_at" : "2012-12-14 19:02:53 +0000",
    "user" : {
      "name" : "brendle",
      "screen_name" : "brendlewhat",
      "protected" : false,
      "id_str" : "38103536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458718748015202304\/pZ4ZTsOU_normal.png",
      "id" : 38103536,
      "verified" : false
    }
  },
  "id" : 611601904104136704,
  "created_at" : "2015-06-18 18:30:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefanie Gunning",
      "screen_name" : "stefgunning",
      "indices" : [ 3, 15 ],
      "id_str" : "17488457",
      "id" : 17488457
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stefgunning\/status\/611592531806044160\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/2maaEdQFSX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHzQKq-UcAEeUS0.png",
      "id_str" : "611592531168489473",
      "id" : 611592531168489473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHzQKq-UcAEeUS0.png",
      "sizes" : [ {
        "h" : 509,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2maaEdQFSX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611601714907447296",
  "text" : "RT @stefgunning: Originally posted on Gawker. Please share widely. http:\/\/t.co\/2maaEdQFSX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/stefgunning\/status\/611592531806044160\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/2maaEdQFSX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHzQKq-UcAEeUS0.png",
        "id_str" : "611592531168489473",
        "id" : 611592531168489473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHzQKq-UcAEeUS0.png",
        "sizes" : [ {
          "h" : 509,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/2maaEdQFSX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611592531806044160",
    "text" : "Originally posted on Gawker. Please share widely. http:\/\/t.co\/2maaEdQFSX",
    "id" : 611592531806044160,
    "created_at" : "2015-06-18 17:53:17 +0000",
    "user" : {
      "name" : "Stefanie Gunning",
      "screen_name" : "stefgunning",
      "protected" : false,
      "id_str" : "17488457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587738191668514816\/kHaKJLzD_normal.jpg",
      "id" : 17488457,
      "verified" : false
    }
  },
  "id" : 611601714907447296,
  "created_at" : "2015-06-18 18:29:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/4KpqxhDL78",
      "expanded_url" : "https:\/\/twitter.com\/DarwinBondGraha\/status\/611590911546384384",
      "display_url" : "twitter.com\/DarwinBondGrah\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611595667677429761",
  "text" : "You can hear the Oakland city council oozing slime when they talk about money. https:\/\/t.co\/4KpqxhDL78",
  "id" : 611595667677429761,
  "created_at" : "2015-06-18 18:05:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611592685128777728",
  "geo" : { },
  "id_str" : "611593948235210752",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso   I haven't seen that since it came out, how does it fare?  It's satire right?",
  "id" : 611593948235210752,
  "in_reply_to_status_id" : 611592685128777728,
  "created_at" : "2015-06-18 17:58:54 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611592168990314497",
  "text" : "That batman movie sure was a fascist fairytale, with all the artistic poverty of state sponsored propaganda.  I need a colon cleanse now.",
  "id" : 611592168990314497,
  "created_at" : "2015-06-18 17:51:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 3, 14 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611377999523393537",
  "text" : "RT @grayamelia: Sir I'm sorry, this section is for apt metaphors only",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611344194737602560",
    "text" : "Sir I'm sorry, this section is for apt metaphors only",
    "id" : 611344194737602560,
    "created_at" : "2015-06-18 01:26:28 +0000",
    "user" : {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "protected" : false,
      "id_str" : "181328570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542768392499761152\/NN148tlm_normal.png",
      "id" : 181328570,
      "verified" : false
    }
  },
  "id" : 611377999523393537,
  "created_at" : "2015-06-18 03:40:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611314603771887616",
  "text" : "idea:  transcontinental water pipelines",
  "id" : 611314603771887616,
  "created_at" : "2015-06-17 23:28:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611265314861416449",
  "text" : "I seek a touring vehicle of some kind, to beg, barter or borrow.",
  "id" : 611265314861416449,
  "created_at" : "2015-06-17 20:13:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611260006428643329",
  "text" : "How do I utilize \"acts of God\" in my application code in a meaningful way?",
  "id" : 611260006428643329,
  "created_at" : "2015-06-17 19:51:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611226383054843904",
  "text" : "ES6 is going to be hard on newbs.  \n\nWhat's that thing, you ask?  It's formal shorthand for something you haven't grokked yet.",
  "id" : 611226383054843904,
  "created_at" : "2015-06-17 17:38:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611225272621215744",
  "text" : "The Babel analogy for ES6 is apt b\/c ES6 basically splits JS into multiple languages so we can't understand each other's code.",
  "id" : 611225272621215744,
  "created_at" : "2015-06-17 17:33:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611033960676626432",
  "text" : "At long last, a legitimate reason for Oakland to riot.",
  "id" : 611033960676626432,
  "created_at" : "2015-06-17 04:53:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611010671845617664",
  "geo" : { },
  "id_str" : "611013345471131649",
  "in_reply_to_user_id" : 46961216,
  "text" : "the navy warned everybody \"they have to get thru us to get to you\"",
  "id" : 611013345471131649,
  "in_reply_to_status_id" : 611010671845617664,
  "created_at" : "2015-06-17 03:31:48 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611010671845617664",
  "text" : "if you don't watch these sports finals,  you miss out on all the absurdity and propaganda these hopeless people ingest",
  "id" : 611010671845617664,
  "created_at" : "2015-06-17 03:21:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Sl85y2IOlk",
      "expanded_url" : "https:\/\/twitter.com\/thedailybeast\/status\/610992397997223936",
      "display_url" : "twitter.com\/thedailybeast\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610999807969079297",
  "text" : "\"They can look at the video and say all the ways we use excessive force. And we can point out all the ways we didn\u2019t https:\/\/t.co\/Sl85y2IOlk",
  "id" : 610999807969079297,
  "created_at" : "2015-06-17 02:38:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 27, 36 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610989302667833345",
  "text" : "i'm just gonna claim to be @substack from now on irl",
  "id" : 610989302667833345,
  "created_at" : "2015-06-17 01:56:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "algofunk",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/mTf4QO94FV",
      "expanded_url" : "http:\/\/studio.substack.net\/stretch-beat_THEORYMIX_con_reverso",
      "display_url" : "studio.substack.net\/stretch-beat_T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610630874069995520",
  "text" : "#algofunk\nhttp:\/\/t.co\/mTf4QO94FV",
  "id" : 610630874069995520,
  "created_at" : "2015-06-16 02:12:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/gSIg1VbR1K",
      "expanded_url" : "http:\/\/studio.substack.net\/stretch-beat_THEORYMIX",
      "display_url" : "studio.substack.net\/stretch-beat_T\u2026"
    }, {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/kXxXo06eC5",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/610574362035527680",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610618197012680704",
  "text" : "ITS THEORY MIX \n\nhttp:\/\/t.co\/gSIg1VbR1K  https:\/\/t.co\/kXxXo06eC5",
  "id" : 610618197012680704,
  "created_at" : "2015-06-16 01:21:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610574362035527680",
  "geo" : { },
  "id_str" : "610617245899710465",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack \nCUE SOUND",
  "id" : 610617245899710465,
  "in_reply_to_status_id" : 610574362035527680,
  "created_at" : "2015-06-16 01:17:50 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/XGn4akq5R5",
      "expanded_url" : "https:\/\/gist.github.com\/dominictarr\/2c5b283fda065ea8f6c3",
      "display_url" : "gist.github.com\/dominictarr\/2c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610560715267698688",
  "text" : "when grammar and poetry collide https:\/\/t.co\/XGn4akq5R5",
  "id" : 610560715267698688,
  "created_at" : "2015-06-15 21:33:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610178575933681664",
  "text" : "I was born homeless and dumb.  I'm no different than the rest of you.",
  "id" : 610178575933681664,
  "created_at" : "2015-06-14 20:14:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610167272104038400",
  "text" : "It is wonderful to have some thing to punch.",
  "id" : 610167272104038400,
  "created_at" : "2015-06-14 19:29:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 3, 11 ],
      "id_str" : "433715578",
      "id" : 433715578
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 13, 26 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610128888635613184",
  "text" : "RT @Gyselie: @johnnyscript The sun will be out at noon and then you can shine too in all its glory!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "610111910088830976",
    "geo" : { },
    "id_str" : "610123457586532352",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript The sun will be out at noon and then you can shine too in all its glory!",
    "id" : 610123457586532352,
    "in_reply_to_status_id" : 610111910088830976,
    "created_at" : "2015-06-14 16:35:42 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "protected" : false,
      "id_str" : "433715578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469656620155154432\/1XOA8tYu_normal.jpeg",
      "id" : 433715578,
      "verified" : false
    }
  },
  "id" : 610128888635613184,
  "created_at" : "2015-06-14 16:57:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610119587644882944",
  "text" : "DUH GUBORNMNET COME AROUND EVERY WEEK TO MAKE US SHUFFLE THE STREET OR PAY A FEE",
  "id" : 610119587644882944,
  "created_at" : "2015-06-14 16:20:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610118541103136768",
  "text" : "how dare our society seek to have it's government clean the streets for US.  that's some infantile shit.",
  "id" : 610118541103136768,
  "created_at" : "2015-06-14 16:16:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610118350019014656",
  "text" : "how dare our society seek to have it's government clean the streets for them.  that's some infantile shit.",
  "id" : 610118350019014656,
  "created_at" : "2015-06-14 16:15:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610118181810647040",
  "text" : "we should clean our own streets",
  "id" : 610118181810647040,
  "created_at" : "2015-06-14 16:14:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610116115461619713",
  "text" : "I am very affective.",
  "id" : 610116115461619713,
  "created_at" : "2015-06-14 16:06:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610111910088830976",
  "text" : "think happy thoughts\n\nthen tweet them at me so I can think them too",
  "id" : 610111910088830976,
  "created_at" : "2015-06-14 15:49:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 14, 27 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608995087461171200",
  "text" : "RT @substack: @johnnyscript laws are the worst legacy system you've ever seen with no tests and billions of stakeholders",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "608740851938807808",
    "geo" : { },
    "id_str" : "608750742397018112",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript laws are the worst legacy system you've ever seen with no tests and billions of stakeholders",
    "id" : 608750742397018112,
    "in_reply_to_status_id" : 608740851938807808,
    "created_at" : "2015-06-10 21:41:01 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 608995087461171200,
  "created_at" : "2015-06-11 13:51:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608887918132760577",
  "text" : "\"We're all going down, and we're all taking each other with us!\"",
  "id" : 608887918132760577,
  "created_at" : "2015-06-11 06:46:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608887675932688384",
  "text" : "\"We're gonna kill off the characters you like, and force you to identify with them you would hate.\"",
  "id" : 608887675932688384,
  "created_at" : "2015-06-11 06:45:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608855328629772288",
  "text" : "Jesus was radical  #NeverForget",
  "id" : 608855328629772288,
  "created_at" : "2015-06-11 04:36:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608742295806943232",
  "text" : "TAKE THAT, OBLIVION!!!",
  "id" : 608742295806943232,
  "created_at" : "2015-06-10 21:07:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 3, 18 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608741496498470912",
  "text" : "RT @brownnoiseblog: does anyone know how the DSM-V classifies identifying very strongly with one's place of employment",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608741014438850561",
    "text" : "does anyone know how the DSM-V classifies identifying very strongly with one's place of employment",
    "id" : 608741014438850561,
    "created_at" : "2015-06-10 21:02:22 +0000",
    "user" : {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "protected" : false,
      "id_str" : "283708113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3182488049\/166dbd593d5eef02f3c21853931f3cfe_normal.jpeg",
      "id" : 283708113,
      "verified" : false
    }
  },
  "id" : 608741496498470912,
  "created_at" : "2015-06-10 21:04:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 0, 15 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608741014438850561",
  "geo" : { },
  "id_str" : "608741234652217344",
  "in_reply_to_user_id" : 283708113,
  "text" : "@brownnoiseblog  stockholm syndrome",
  "id" : 608741234652217344,
  "in_reply_to_status_id" : 608741014438850561,
  "created_at" : "2015-06-10 21:03:14 +0000",
  "in_reply_to_screen_name" : "brownnoiseblog",
  "in_reply_to_user_id_str" : "283708113",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608741005332848640",
  "text" : "comparisons between the code of law and the code of computers are weak at best.  laws are not beholden to logic.",
  "id" : 608741005332848640,
  "created_at" : "2015-06-10 21:02:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Andolfatto",
      "screen_name" : "dandolfa",
      "indices" : [ 0, 9 ],
      "id_str" : "1342956066",
      "id" : 1342956066
    }, {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 10, 21 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608738294839398400",
  "geo" : { },
  "id_str" : "608740876123185153",
  "in_reply_to_user_id" : 1342956066,
  "text" : "@dandolfa @Satoshi_N_ laws are not beholden to logic, and the interpretation of them changes from one governing entity to the next.",
  "id" : 608740876123185153,
  "in_reply_to_status_id" : 608738294839398400,
  "created_at" : "2015-06-10 21:01:49 +0000",
  "in_reply_to_screen_name" : "dandolfa",
  "in_reply_to_user_id_str" : "1342956066",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608740851938807808",
  "text" : "With computers, we write code, and when it fails, change the code.  With laws, we change the interpreter slightly and hope for the best.",
  "id" : 608740851938807808,
  "created_at" : "2015-06-10 21:01:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Andolfatto",
      "screen_name" : "dandolfa",
      "indices" : [ 0, 9 ],
      "id_str" : "1342956066",
      "id" : 1342956066
    }, {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 10, 21 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608738294839398400",
  "geo" : { },
  "id_str" : "608738660758913024",
  "in_reply_to_user_id" : 1342956066,
  "text" : "@dandolfa @Satoshi_N_ computers",
  "id" : 608738660758913024,
  "in_reply_to_status_id" : 608738294839398400,
  "created_at" : "2015-06-10 20:53:01 +0000",
  "in_reply_to_screen_name" : "dandolfa",
  "in_reply_to_user_id_str" : "1342956066",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Andolfatto",
      "screen_name" : "dandolfa",
      "indices" : [ 0, 9 ],
      "id_str" : "1342956066",
      "id" : 1342956066
    }, {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 10, 21 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608717954839019520",
  "geo" : { },
  "id_str" : "608737310771798016",
  "in_reply_to_user_id" : 1342956066,
  "text" : "@dandolfa @Satoshi_N_ in the context of the spirit of open source, the criticism stands.  Plus, codes of law don't strictly call the shots.",
  "id" : 608737310771798016,
  "in_reply_to_status_id" : 608717954839019520,
  "created_at" : "2015-06-10 20:47:39 +0000",
  "in_reply_to_screen_name" : "dandolfa",
  "in_reply_to_user_id_str" : "1342956066",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 3, 14 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    }, {
      "name" : "MasterCard",
      "screen_name" : "MasterCard",
      "indices" : [ 47, 58 ],
      "id_str" : "75014376",
      "id" : 75014376
    }, {
      "name" : "Bitcoin",
      "screen_name" : "Bitcoin",
      "indices" : [ 96, 104 ],
      "id_str" : "357312062",
      "id" : 357312062
    }, {
      "name" : "MasterCard",
      "screen_name" : "MasterCard",
      "indices" : [ 123, 134 ],
      "id_str" : "75014376",
      "id" : 75014376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608671001237323777",
  "text" : "RT @Satoshi_N_: Cost to merchant for accepting @MasterCard for coffee: 0.30 USD\n\nCost to accept @Bitcoin: 0.01 USD\n\nMaking @MasterCard eat \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MasterCard",
        "screen_name" : "MasterCard",
        "indices" : [ 31, 42 ],
        "id_str" : "75014376",
        "id" : 75014376
      }, {
        "name" : "Bitcoin",
        "screen_name" : "Bitcoin",
        "indices" : [ 80, 88 ],
        "id_str" : "357312062",
        "id" : 357312062
      }, {
        "name" : "MasterCard",
        "screen_name" : "MasterCard",
        "indices" : [ 107, 118 ],
        "id_str" : "75014376",
        "id" : 75014376
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608646376944209920",
    "text" : "Cost to merchant for accepting @MasterCard for coffee: 0.30 USD\n\nCost to accept @Bitcoin: 0.01 USD\n\nMaking @MasterCard eat crow: Priceless",
    "id" : 608646376944209920,
    "created_at" : "2015-06-10 14:46:19 +0000",
    "user" : {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "protected" : false,
      "id_str" : "2375721396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727448034024525825\/nxaF8tNf_normal.jpg",
      "id" : 2375721396,
      "verified" : false
    }
  },
  "id" : 608671001237323777,
  "created_at" : "2015-06-10 16:24:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608503679109468162",
  "geo" : { },
  "id_str" : "608504102335569922",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords  watch out boy, he'll chew you up!",
  "id" : 608504102335569922,
  "in_reply_to_status_id" : 608503679109468162,
  "created_at" : "2015-06-10 05:20:58 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608502995555348480",
  "geo" : { },
  "id_str" : "608503596859023360",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords  must be an east coast thing.  or maybe it's the hungry look in your eyes.",
  "id" : 608503596859023360,
  "in_reply_to_status_id" : 608502995555348480,
  "created_at" : "2015-06-10 05:18:57 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608451713729720320",
  "text" : "twitter's microsoft bing translations are useless.",
  "id" : 608451713729720320,
  "created_at" : "2015-06-10 01:52:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/DD8rlV8JER",
      "expanded_url" : "http:\/\/studio.substack.net\/set%20phasers%20to%20phase%20?time=1433870941675",
      "display_url" : "studio.substack.net\/set%20phasers%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608325615780024320",
  "text" : "SET PHASERS TO BOOGIE\n\nhttp:\/\/t.co\/DD8rlV8JER",
  "id" : 608325615780024320,
  "created_at" : "2015-06-09 17:31:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608068608246218752",
  "text" : "\/2\/2\/2\/2\/2\/2\/2\/2\/2\/2\/2\/2\/2\/2\/2",
  "id" : 608068608246218752,
  "created_at" : "2015-06-09 00:30:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608065465110425600",
  "text" : "I melt laptop speakers, and rip thee crotch of pants.",
  "id" : 608065465110425600,
  "created_at" : "2015-06-09 00:17:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/x2BQXJgI3e",
      "expanded_url" : "http:\/\/studio.substack.net\/toward%20a%20better%20enevelope",
      "display_url" : "studio.substack.net\/toward%20a%20b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608064501494255616",
  "text" : "trynna concoct a purely functional envelope scheme, not quite there yet, but \n\nhttp:\/\/t.co\/x2BQXJgI3e",
  "id" : 608064501494255616,
  "created_at" : "2015-06-09 00:14:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/x2BQXJgI3e",
      "expanded_url" : "http:\/\/studio.substack.net\/toward%20a%20better%20enevelope",
      "display_url" : "studio.substack.net\/toward%20a%20b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608063811241836544",
  "text" : "http:\/\/t.co\/x2BQXJgI3e",
  "id" : 608063811241836544,
  "created_at" : "2015-06-09 00:11:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/8OgKlr9IaI",
      "expanded_url" : "https:\/\/twitter.com\/modulhaus3000\/status\/607972686933811201",
      "display_url" : "twitter.com\/modulhaus3000\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607974174909341696",
  "text" : "HELLO WORLD https:\/\/t.co\/8OgKlr9IaI",
  "id" : 607974174909341696,
  "created_at" : "2015-06-08 18:15:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/i3UjHzTt7A",
      "expanded_url" : "https:\/\/twitter.com\/marinakukso\/status\/607970462380007424",
      "display_url" : "twitter.com\/marinakukso\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607974104533106688",
  "text" : "CHECK THE PRIVILEGE OF YOUR GAZE, MAN https:\/\/t.co\/i3UjHzTt7A",
  "id" : 607974104533106688,
  "created_at" : "2015-06-08 18:14:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/IxhxexcqvJ",
      "expanded_url" : "https:\/\/twitter.com\/fordm\/status\/607883435080712192",
      "display_url" : "twitter.com\/fordm\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607962900523712512",
  "text" : "judge a civilization by how they treat their poor, sick and living https:\/\/t.co\/IxhxexcqvJ",
  "id" : 607962900523712512,
  "created_at" : "2015-06-08 17:30:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Ver",
      "screen_name" : "rogerkver",
      "indices" : [ 3, 13 ],
      "id_str" : "176758255",
      "id" : 176758255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607959672226607104",
  "text" : "RT @rogerkver: If it is wrong for one person to do something, it is still wrong when 51% vote to hire someone to do it for them. Democracy \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607911715410345984",
    "text" : "If it is wrong for one person to do something, it is still wrong when 51% vote to hire someone to do it for them. Democracy is not freedom.",
    "id" : 607911715410345984,
    "created_at" : "2015-06-08 14:07:02 +0000",
    "user" : {
      "name" : "Roger Ver",
      "screen_name" : "rogerkver",
      "protected" : false,
      "id_str" : "176758255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553695831782883328\/IvKiS7WJ_normal.jpeg",
      "id" : 176758255,
      "verified" : false
    }
  },
  "id" : 607959672226607104,
  "created_at" : "2015-06-08 17:17:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/1Zq5HPVNqp",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/crack-keyboard",
      "display_url" : "soundcloud.com\/folkstack\/crac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607814109069852672",
  "text" : "\"crack keyboard\", a recorded live code session \n\nhttps:\/\/t.co\/1Zq5HPVNqp",
  "id" : 607814109069852672,
  "created_at" : "2015-06-08 07:39:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/607243884976939008\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/7fFuOYxnfQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG1dF4lUkAACsB6.png",
      "id_str" : "607243880434536448",
      "id" : 607243880434536448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG1dF4lUkAACsB6.png",
      "sizes" : [ {
        "h" : 438,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 157,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7fFuOYxnfQ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/607243884976939008\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/7fFuOYxnfQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG1dGHkU8AAwr54.png",
      "id_str" : "607243884456898560",
      "id" : 607243884456898560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG1dGHkU8AAwr54.png",
      "sizes" : [ {
        "h" : 894,
        "resize" : "fit",
        "w" : 694
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 894,
        "resize" : "fit",
        "w" : 694
      } ],
      "display_url" : "pic.twitter.com\/7fFuOYxnfQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/73q3TauIhP",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=c23b29f6a9f2482e2c81",
      "display_url" : "requirebin.com\/?gist=c23b29f6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607243884976939008",
  "text" : "color quantizer.  drop image.  edit lines 19-22.  rerun code.  drop image.  http:\/\/t.co\/73q3TauIhP http:\/\/t.co\/7fFuOYxnfQ",
  "id" : 607243884976939008,
  "created_at" : "2015-06-06 17:53:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/607235753412657152\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ix9lrldPXv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG1VszUUgAEqLcQ.png",
      "id_str" : "607235752942927873",
      "id" : 607235752942927873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG1VszUUgAEqLcQ.png",
      "sizes" : [ {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 791
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 791
      } ],
      "display_url" : "pic.twitter.com\/ix9lrldPXv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607234902279385088",
  "geo" : { },
  "id_str" : "607235753412657152",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript LOL http:\/\/t.co\/ix9lrldPXv",
  "id" : 607235753412657152,
  "in_reply_to_status_id" : 607234902279385088,
  "created_at" : "2015-06-06 17:21:00 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607234902279385088",
  "text" : "poems and song lyrics would make strong, memorable passwords",
  "id" : 607234902279385088,
  "created_at" : "2015-06-06 17:17:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/h17poTWJ2a",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=RbKr-k1PTvA",
      "display_url" : "youtube.com\/watch?v=RbKr-k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607228501020667904",
  "text" : "A random thought occurred to me:  rainbow fish.  \n\nI asked the Internet, wherefore?  \n\nErgo, said th'Internet:  https:\/\/t.co\/h17poTWJ2a",
  "id" : 607228501020667904,
  "created_at" : "2015-06-06 16:52:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607203667796631553",
  "text" : "Every morning, the same bird tries to fly through the mirror in my garden.\n\nI am that bird.",
  "id" : 607203667796631553,
  "created_at" : "2015-06-06 15:13:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607197850435321856",
  "text" : "&gt; Unsubscribe from LinkedIn\n&gt; Delete email account\n&gt; Sell house, live in woods\n&gt; Get on twitter\n&gt; See retweets about LinkedIn\n&gt; Kill yrself",
  "id" : 607197850435321856,
  "created_at" : "2015-06-06 14:50:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAinfo Chicago",
      "screen_name" : "DNAinfoCHI",
      "indices" : [ 3, 14 ],
      "id_str" : "552151606",
      "id" : 552151606
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DNAinfoCHI\/status\/606883724165156864\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/RKWoitI6EE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGwU77eUAAAhM8B.jpg",
      "id_str" : "606883069597843456",
      "id" : 606883069597843456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGwU77eUAAAhM8B.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/RKWoitI6EE"
    } ],
    "hashtags" : [ {
      "text" : "neverforget",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/21wLen8jjR",
      "expanded_url" : "http:\/\/dnain.fo\/1G09Oib",
      "display_url" : "dnain.fo\/1G09Oib"
    } ]
  },
  "geo" : { },
  "id_str" : "606911818724839424",
  "text" : "RT @DNAinfoCHI: New sign on a Downtown bridge implores Chicagoans to #neverforget http:\/\/t.co\/21wLen8jjR http:\/\/t.co\/RKWoitI6EE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DNAinfoCHI\/status\/606883724165156864\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/RKWoitI6EE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGwU77eUAAAhM8B.jpg",
        "id_str" : "606883069597843456",
        "id" : 606883069597843456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGwU77eUAAAhM8B.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/RKWoitI6EE"
      } ],
      "hashtags" : [ {
        "text" : "neverforget",
        "indices" : [ 53, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/21wLen8jjR",
        "expanded_url" : "http:\/\/dnain.fo\/1G09Oib",
        "display_url" : "dnain.fo\/1G09Oib"
      } ]
    },
    "geo" : { },
    "id_str" : "606883724165156864",
    "text" : "New sign on a Downtown bridge implores Chicagoans to #neverforget http:\/\/t.co\/21wLen8jjR http:\/\/t.co\/RKWoitI6EE",
    "id" : 606883724165156864,
    "created_at" : "2015-06-05 18:02:09 +0000",
    "user" : {
      "name" : "DNAinfo Chicago",
      "screen_name" : "DNAinfoCHI",
      "protected" : false,
      "id_str" : "552151606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725753354345938944\/Oqy9NRtv_normal.jpg",
      "id" : 552151606,
      "verified" : true
    }
  },
  "id" : 606911818724839424,
  "created_at" : "2015-06-05 19:53:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/9ouO0w4kCL",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/4ab9b059329c8ae2d778",
      "display_url" : "gist.github.com\/NHQ\/4ab9b05932\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606685332122255360",
  "text" : "some image rgb\/b&amp;w quantization filters: https:\/\/t.co\/9ouO0w4kCL",
  "id" : 606685332122255360,
  "created_at" : "2015-06-05 04:53:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Xr4VzLTaOg",
      "expanded_url" : "https:\/\/twitter.com\/NeinQuarterly\/status\/606581422585966592",
      "display_url" : "twitter.com\/NeinQuarterly\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606595571357392899",
  "text" : "YOU MEAN \"HYPOTHETICAL\" IMPLICATIONS, I'M SURE, WUTWUTWUT https:\/\/t.co\/Xr4VzLTaOg",
  "id" : 606595571357392899,
  "created_at" : "2015-06-04 22:57:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/92EFm9DRvl",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/you-me-and-an-algorithm-make-untitled-track-3",
      "display_url" : "soundcloud.com\/folkstack\/you-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606594887375450112",
  "text" : "I cut this from a recent session testing my web audio warez\n\n\"you, me, and an algorithm make untitled track 3\" \n\nhttps:\/\/t.co\/92EFm9DRvl",
  "id" : 606594887375450112,
  "created_at" : "2015-06-04 22:54:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/19ccfdlFS1",
      "expanded_url" : "https:\/\/twitter.com\/DaMFunK\/status\/606579748303609858",
      "display_url" : "twitter.com\/DaMFunK\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606586407373533184",
  "text" : "STFU! https:\/\/t.co\/19ccfdlFS1",
  "id" : 606586407373533184,
  "created_at" : "2015-06-04 22:20:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606583044451926017",
  "text" : "I'm too pretty to care about such things.",
  "id" : 606583044451926017,
  "created_at" : "2015-06-04 22:07:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606558220589531136",
  "text" : "and now back to the love above",
  "id" : 606558220589531136,
  "created_at" : "2015-06-04 20:28:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606557372606070784",
  "geo" : { },
  "id_str" : "606557911309942784",
  "in_reply_to_user_id" : 46961216,
  "text" : "pointedly, walgreens has branded one of their shit food distributions Nice!",
  "id" : 606557911309942784,
  "in_reply_to_status_id" : 606557372606070784,
  "created_at" : "2015-06-04 20:27:30 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606557372606070784",
  "text" : "i dont mean to say \"nice\" and \"take care\" are bad words from a sincere person.  but they are a transparent kiss off from most consumers.",
  "id" : 606557372606070784,
  "created_at" : "2015-06-04 20:25:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/kDI3mOSoxC",
      "expanded_url" : "https:\/\/twitter.com\/the_N0\/status\/606555249847902209",
      "display_url" : "twitter.com\/the_N0\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606556199127912448",
  "text" : "*kills papa* https:\/\/t.co\/kDI3mOSoxC",
  "id" : 606556199127912448,
  "created_at" : "2015-06-04 20:20:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "irony",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606551663864709122",
  "geo" : { },
  "id_str" : "606553023221932032",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  yet in teaching of a \"lawful\" society, it is automatic (cognitively unchecked) that aught against a law is amoral.  #irony",
  "id" : 606553023221932032,
  "in_reply_to_status_id" : 606551663864709122,
  "created_at" : "2015-06-04 20:08:04 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EINS78",
      "screen_name" : "EINS78",
      "indices" : [ 0, 7 ],
      "id_str" : "14301616",
      "id" : 14301616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606549317759819777",
  "geo" : { },
  "id_str" : "606551765849247745",
  "in_reply_to_user_id" : 14301616,
  "text" : "@EINS78  we barely have a concept of decriminalization, tho we have a million laws you can break.",
  "id" : 606551765849247745,
  "in_reply_to_status_id" : 606549317759819777,
  "created_at" : "2015-06-04 20:03:04 +0000",
  "in_reply_to_screen_name" : "EINS78",
  "in_reply_to_user_id_str" : "14301616",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606549141246722051",
  "text" : "we need to teach people that laws are neither a place to get nor put your morality.  and teach that morality is another term for judgement.",
  "id" : 606549141246722051,
  "created_at" : "2015-06-04 19:52:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EINS78",
      "screen_name" : "EINS78",
      "indices" : [ 0, 7 ],
      "id_str" : "14301616",
      "id" : 14301616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606546222942294016",
  "geo" : { },
  "id_str" : "606548714446974978",
  "in_reply_to_user_id" : 14301616,
  "text" : "@EINS78 which is why, in the case of drugs, reforms have to sidewind thru other legal constructs, in this case medicine and healthcare.",
  "id" : 606548714446974978,
  "in_reply_to_status_id" : 606546222942294016,
  "created_at" : "2015-06-04 19:50:57 +0000",
  "in_reply_to_screen_name" : "EINS78",
  "in_reply_to_user_id_str" : "14301616",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EINS78",
      "screen_name" : "EINS78",
      "indices" : [ 0, 7 ],
      "id_str" : "14301616",
      "id" : 14301616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606546222942294016",
  "geo" : { },
  "id_str" : "606548509202857987",
  "in_reply_to_user_id" : 14301616,
  "text" : "@EINS78  to say \"legalize\" is \"we accept this behavior but our moral judgement will persist\".  ppl unwittingly get their morality from laws.",
  "id" : 606548509202857987,
  "in_reply_to_status_id" : 606546222942294016,
  "created_at" : "2015-06-04 19:50:08 +0000",
  "in_reply_to_screen_name" : "EINS78",
  "in_reply_to_user_id_str" : "14301616",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606544030114017282",
  "geo" : { },
  "id_str" : "606546617861173248",
  "in_reply_to_user_id" : 46961216,
  "text" : "\"take care\" is a nice way of saying goodbye.",
  "id" : 606546617861173248,
  "in_reply_to_status_id" : 606544030114017282,
  "created_at" : "2015-06-04 19:42:37 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EINS78",
      "screen_name" : "EINS78",
      "indices" : [ 0, 7 ],
      "id_str" : "14301616",
      "id" : 14301616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606332666762432512",
  "geo" : { },
  "id_str" : "606545794322161665",
  "in_reply_to_user_id" : 14301616,
  "text" : "@EINS78  meant as a framework more than a particular. It's ironic that legalization is the necessary context in a \"free\" but lawful society.",
  "id" : 606545794322161665,
  "in_reply_to_status_id" : 606332666762432512,
  "created_at" : "2015-06-04 19:39:21 +0000",
  "in_reply_to_screen_name" : "EINS78",
  "in_reply_to_user_id_str" : "14301616",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606544030114017282",
  "text" : "\"nice\" is the least you can say, and that is exactly what your sentiment is worth: as little as positively possible.  thanks.  nice.",
  "id" : 606544030114017282,
  "created_at" : "2015-06-04 19:32:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 3, 15 ],
      "id_str" : "557228721",
      "id" : 557228721
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606239681034907648",
  "text" : "RT @vrroanhorse: @johnnyscript look like a series of horse heads and mane.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "606237752955240448",
    "geo" : { },
    "id_str" : "606238894078722049",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript look like a series of horse heads and mane.",
    "id" : 606238894078722049,
    "in_reply_to_status_id" : 606237752955240448,
    "created_at" : "2015-06-03 23:19:50 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "protected" : false,
      "id_str" : "557228721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652515840194056193\/vt9WrUY__normal.jpg",
      "id" : 557228721,
      "verified" : false
    }
  },
  "id" : 606239681034907648,
  "created_at" : "2015-06-03 23:22:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/606237752955240448\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/rsDbW86Agy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGnKBiVUQAAGGuW.png",
      "id_str" : "606237752602935296",
      "id" : 606237752602935296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGnKBiVUQAAGGuW.png",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 165,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rsDbW86Agy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606237752955240448",
  "text" : "WHATS HAPPENING YOU ASK? http:\/\/t.co\/rsDbW86Agy",
  "id" : 606237752955240448,
  "created_at" : "2015-06-03 23:15:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606225775457492992",
  "text" : "decriminalize &gt; legalize",
  "id" : 606225775457492992,
  "created_at" : "2015-06-03 22:27:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606220863206088704",
  "text" : "RT @modulhaus3000: AGREE OR DISAGREE\n\nTHE WEB WOULD BE BETTER AND EASIER TO BUILD IF WE ALL GOT PUBLIC IP ADDRESSES.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606219483959590912",
    "text" : "AGREE OR DISAGREE\n\nTHE WEB WOULD BE BETTER AND EASIER TO BUILD IF WE ALL GOT PUBLIC IP ADDRESSES.",
    "id" : 606219483959590912,
    "created_at" : "2015-06-03 22:02:42 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 606220863206088704,
  "created_at" : "2015-06-03 22:08:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605891109005295617",
  "text" : "everything is depressing",
  "id" : 605891109005295617,
  "created_at" : "2015-06-03 00:17:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/E4s6NNoRSV",
      "expanded_url" : "http:\/\/meta.florist",
      "display_url" : "meta.florist"
    } ]
  },
  "geo" : { },
  "id_str" : "605821654325862401",
  "text" : "does anybody want this domain: http:\/\/t.co\/E4s6NNoRSV",
  "id" : 605821654325862401,
  "created_at" : "2015-06-02 19:41:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/gTnNRBGRFZ",
      "expanded_url" : "https:\/\/twitter.com\/dominictarr\/status\/605760750477377537",
      "display_url" : "twitter.com\/dominictarr\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605782945442373637",
  "text" : "good PR is a psychic sybil attack https:\/\/t.co\/gTnNRBGRFZ",
  "id" : 605782945442373637,
  "created_at" : "2015-06-02 17:08:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 105, 117 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605534941636521985",
  "text" : "how does a site keep element styles from showing up in \"inspect element\", liked wired dot com seems to?  @yoshuawuyts",
  "id" : 605534941636521985,
  "created_at" : "2015-06-02 00:42:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anthropomorphic OS",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/wcogRs2tr6",
      "expanded_url" : "http:\/\/studio.substack.net\/whaleparty?time=1433103179515",
      "display_url" : "studio.substack.net\/whaleparty?tim\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "605428328909152257",
  "geo" : { },
  "id_str" : "605509793004912641",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts http:\/\/t.co\/wcogRs2tr6",
  "id" : 605509793004912641,
  "in_reply_to_status_id" : 605428328909152257,
  "created_at" : "2015-06-01 23:02:39 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605357225956245504",
  "geo" : { },
  "id_str" : "605423174306562048",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts  more boring mimesis",
  "id" : 605423174306562048,
  "in_reply_to_status_id" : 605357225956245504,
  "created_at" : "2015-06-01 17:18:27 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 0, 8 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605385458676137985",
  "geo" : { },
  "id_str" : "605422785364566016",
  "in_reply_to_user_id" : 433715578,
  "text" : "@Gyselie  probably picked yr pocket  ;^P",
  "id" : 605422785364566016,
  "in_reply_to_status_id" : 605385458676137985,
  "created_at" : "2015-06-01 17:16:54 +0000",
  "in_reply_to_screen_name" : "Gyselie",
  "in_reply_to_user_id_str" : "433715578",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605268966877970432",
  "text" : "what is the brain's sample rate?",
  "id" : 605268966877970432,
  "created_at" : "2015-06-01 07:05:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]