Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539294232175845376",
  "text" : "be lossless",
  "id" : 539294232175845376,
  "created_at" : "2014-12-01 05:45:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539294131760033793",
  "text" : "ween thyself off the .mp3\n\ngo lossless",
  "id" : 539294131760033793,
  "created_at" : "2014-12-01 05:45:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539257697195921408",
  "geo" : { },
  "id_str" : "539281067857829888",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray  lol they say Darren Wilson was \"exonerated\"",
  "id" : 539281067857829888,
  "in_reply_to_status_id" : 539257697195921408,
  "created_at" : "2014-12-01 04:53:20 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539279568746463232",
  "text" : "RT @deray: Highlight of the day: White male protestor sincerely tells officer, \"You didn't tell me individually to disperse.\" Arrest avoide\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539261112529608704",
    "text" : "Highlight of the day: White male protestor sincerely tells officer, \"You didn't tell me individually to disperse.\" Arrest avoided.",
    "id" : 539261112529608704,
    "created_at" : "2014-12-01 03:34:02 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 539279568746463232,
  "created_at" : "2014-12-01 04:47:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/DM2WTIHBvc",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=qgLh2S1yMU4",
      "display_url" : "youtube.com\/watch?v=qgLh2S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539242307908694016",
  "text" : "this was as good as a movie set piece\npolice stand here\nmedia stand over there\npolice, fire at the cameras\n#ferguson\nhttps:\/\/t.co\/DM2WTIHBvc",
  "id" : 539242307908694016,
  "created_at" : "2014-12-01 02:19:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/09i6y1dOzY",
      "expanded_url" : "http:\/\/youtu.be\/uT0uaZ5Ymeo",
      "display_url" : "youtu.be\/uT0uaZ5Ymeo"
    } ]
  },
  "geo" : { },
  "id_str" : "539237542772473857",
  "text" : "compelling evidence that paramilitary agents started most fires in #Ferguson after Grand Jury opinion!!!\n\nhttp:\/\/t.co\/09i6y1dOzY",
  "id" : 539237542772473857,
  "created_at" : "2014-12-01 02:00:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539215255633543169",
  "text" : "i love how small and effective these protests can be",
  "id" : 539215255633543169,
  "created_at" : "2014-12-01 00:31:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChuckModi",
      "screen_name" : "popsspotsports",
      "indices" : [ 3, 18 ],
      "id_str" : "3497009297",
      "id" : 3497009297
    }, {
      "name" : "Rams",
      "screen_name" : "rams",
      "indices" : [ 62, 67 ],
      "id_str" : "10528",
      "id" : 10528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539213966874906624",
  "text" : "RT @POPSspotSports: Just spoke w\/ @melritchey who had seizure @Rams game. She is Fine!!! She reports officer called her a \"stupid effin bit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rams",
        "screen_name" : "rams",
        "indices" : [ 42, 47 ],
        "id_str" : "10528",
        "id" : 10528
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539211593922670593",
    "text" : "Just spoke w\/ @melritchey who had seizure @Rams game. She is Fine!!! She reports officer called her a \"stupid effin bitch\" &amp; \"C-word\".",
    "id" : 539211593922670593,
    "created_at" : "2014-12-01 00:17:16 +0000",
    "user" : {
      "name" : "ChuckModi",
      "screen_name" : "ChuckModi1",
      "protected" : false,
      "id_str" : "728604440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663760728990605312\/u0ayKQjk_normal.jpg",
      "id" : 728604440,
      "verified" : false
    }
  },
  "id" : 539213966874906624,
  "created_at" : "2014-12-01 00:26:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539213706387660800",
  "text" : "did anybody else get a weird IFTTT email out the blue?",
  "id" : 539213706387660800,
  "created_at" : "2014-12-01 00:25:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539211840010465280",
  "text" : "I THINK YALL LOOK JUST, WONDERFUL AND GREAT\n\n#FERGUSON",
  "id" : 539211840010465280,
  "created_at" : "2014-12-01 00:18:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lnonblonde",
      "screen_name" : "Lnonblonde",
      "indices" : [ 3, 14 ],
      "id_str" : "113349253",
      "id" : 113349253
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Lnonblonde\/status\/539188173910192129\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/EyCnqLbAAa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3uUyV0CUAEro8b.jpg",
      "id_str" : "539188172970676225",
      "id" : 539188172970676225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3uUyV0CUAEro8b.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EyCnqLbAAa"
    } ],
    "hashtags" : [ {
      "text" : "TamirRice",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/xN6gQkWNhp",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2854617\/Cops-shot-12-year-old-Tamir-Rice-dead-holding-BB-gun-did-not-aid-watched-lie-agony-died-just-hours-later.html",
      "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539190821526847489",
  "text" : "RT @Lnonblonde: Cops Who Shot #TamirRice In The Stomach Watched Him Lay In Agony &amp; Gave NO First Aid via http:\/\/t.co\/xN6gQkWNhp http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Lnonblonde\/status\/539188173910192129\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/EyCnqLbAAa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3uUyV0CUAEro8b.jpg",
        "id_str" : "539188172970676225",
        "id" : 539188172970676225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3uUyV0CUAEro8b.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/EyCnqLbAAa"
      } ],
      "hashtags" : [ {
        "text" : "TamirRice",
        "indices" : [ 14, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/xN6gQkWNhp",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2854617\/Cops-shot-12-year-old-Tamir-Rice-dead-holding-BB-gun-did-not-aid-watched-lie-agony-died-just-hours-later.html",
        "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "539188173910192129",
    "text" : "Cops Who Shot #TamirRice In The Stomach Watched Him Lay In Agony &amp; Gave NO First Aid via http:\/\/t.co\/xN6gQkWNhp http:\/\/t.co\/EyCnqLbAAa",
    "id" : 539188173910192129,
    "created_at" : "2014-11-30 22:44:12 +0000",
    "user" : {
      "name" : "Lnonblonde",
      "screen_name" : "Lnonblonde",
      "protected" : false,
      "id_str" : "113349253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728116537853272064\/J4ZihlgG_normal.jpg",
      "id" : 113349253,
      "verified" : false
    }
  },
  "id" : 539190821526847489,
  "created_at" : "2014-11-30 22:54:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lnonblonde",
      "screen_name" : "Lnonblonde",
      "indices" : [ 3, 14 ],
      "id_str" : "113349253",
      "id" : 113349253
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Lnonblonde\/status\/539186237962084353\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/6fsNsOjStq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3uTBr4CQAArHnL.jpg",
      "id_str" : "539186237567811584",
      "id" : 539186237567811584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3uTBr4CQAArHnL.jpg",
      "sizes" : [ {
        "h" : 329,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6fsNsOjStq"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/WPMD5pdLVh",
      "expanded_url" : "http:\/\/crooksandliars.com\/2014\/11\/gov-deval-patrick-d-calls-indictment?utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "crooksandliars.com\/2014\/11\/gov-de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539190795295653890",
  "text" : "RT @Lnonblonde: Massachusetts Governor Deval Patrick Calls For Indictment &amp; Trial Of Darren Wilson #Ferguson http:\/\/t.co\/WPMD5pdLVh http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Lnonblonde\/status\/539186237962084353\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/6fsNsOjStq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3uTBr4CQAArHnL.jpg",
        "id_str" : "539186237567811584",
        "id" : 539186237567811584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3uTBr4CQAArHnL.jpg",
        "sizes" : [ {
          "h" : 329,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6fsNsOjStq"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/WPMD5pdLVh",
        "expanded_url" : "http:\/\/crooksandliars.com\/2014\/11\/gov-deval-patrick-d-calls-indictment?utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "crooksandliars.com\/2014\/11\/gov-de\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "539186237962084353",
    "text" : "Massachusetts Governor Deval Patrick Calls For Indictment &amp; Trial Of Darren Wilson #Ferguson http:\/\/t.co\/WPMD5pdLVh http:\/\/t.co\/6fsNsOjStq",
    "id" : 539186237962084353,
    "created_at" : "2014-11-30 22:36:31 +0000",
    "user" : {
      "name" : "Lnonblonde",
      "screen_name" : "Lnonblonde",
      "protected" : false,
      "id_str" : "113349253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728116537853272064\/J4ZihlgG_normal.jpg",
      "id" : 113349253,
      "verified" : false
    }
  },
  "id" : 539190795295653890,
  "created_at" : "2014-11-30 22:54:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/yFSTU4elrz",
      "expanded_url" : "https:\/\/vine.co\/v\/Onx3uixEWUT",
      "display_url" : "vine.co\/v\/Onx3uixEWUT"
    } ]
  },
  "geo" : { },
  "id_str" : "539178242008027136",
  "text" : "RT @deray: Wow. DOTSON ARRESTED SOMEONE. #ferguson https:\/\/t.co\/yFSTU4elrz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ferguson",
        "indices" : [ 30, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/yFSTU4elrz",
        "expanded_url" : "https:\/\/vine.co\/v\/Onx3uixEWUT",
        "display_url" : "vine.co\/v\/Onx3uixEWUT"
      } ]
    },
    "geo" : { },
    "id_str" : "539169709795840001",
    "text" : "Wow. DOTSON ARRESTED SOMEONE. #ferguson https:\/\/t.co\/yFSTU4elrz",
    "id" : 539169709795840001,
    "created_at" : "2014-11-30 21:30:50 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 539178242008027136,
  "created_at" : "2014-11-30 22:04:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539161320726093824",
  "text" : "RT @deray: You should see the Ram's fans respond to the Riot police. It's like they're watching a movie. #Ferguson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539160516753498112",
    "text" : "You should see the Ram's fans respond to the Riot police. It's like they're watching a movie. #Ferguson",
    "id" : 539160516753498112,
    "created_at" : "2014-11-30 20:54:18 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 539161320726093824,
  "created_at" : "2014-11-30 20:57:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/4wJ6b3uwWe",
      "expanded_url" : "https:\/\/vine.co\/v\/OnxDLw0Bnl1",
      "display_url" : "vine.co\/v\/OnxDLw0Bnl1"
    } ]
  },
  "geo" : { },
  "id_str" : "539160909751406592",
  "text" : "RT @deray: \"Walk on the sidewalk immediately.\" - officer #ferguson https:\/\/t.co\/4wJ6b3uwWe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ferguson",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/4wJ6b3uwWe",
        "expanded_url" : "https:\/\/vine.co\/v\/OnxDLw0Bnl1",
        "display_url" : "vine.co\/v\/OnxDLw0Bnl1"
      } ]
    },
    "geo" : { },
    "id_str" : "539159493113049088",
    "text" : "\"Walk on the sidewalk immediately.\" - officer #ferguson https:\/\/t.co\/4wJ6b3uwWe",
    "id" : 539159493113049088,
    "created_at" : "2014-11-30 20:50:14 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 539160909751406592,
  "created_at" : "2014-11-30 20:55:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/TiMh32WQyr",
      "expanded_url" : "https:\/\/vine.co\/v\/OnxIbrpUpra",
      "display_url" : "vine.co\/v\/OnxIbrpUpra"
    } ]
  },
  "geo" : { },
  "id_str" : "539160718935719936",
  "text" : "RT @deray: Riot police March. Super intense. #ferguson https:\/\/t.co\/TiMh32WQyr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ferguson",
        "indices" : [ 34, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/TiMh32WQyr",
        "expanded_url" : "https:\/\/vine.co\/v\/OnxIbrpUpra",
        "display_url" : "vine.co\/v\/OnxIbrpUpra"
      } ]
    },
    "geo" : { },
    "id_str" : "539160352676904961",
    "text" : "Riot police March. Super intense. #ferguson https:\/\/t.co\/TiMh32WQyr",
    "id" : 539160352676904961,
    "created_at" : "2014-11-30 20:53:39 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 539160718935719936,
  "created_at" : "2014-11-30 20:55:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/deray\/status\/539147740442144768\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/tJlp9mzVue",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3twAffCUAAFkof.jpg",
      "id_str" : "539147734154891264",
      "id" : 539147734154891264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3twAffCUAAFkof.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tJlp9mzVue"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539147896470265856",
  "text" : "RT @deray: This officer follows me and tapes me. I think I'll go say hello when we stop. #Ferguson http:\/\/t.co\/tJlp9mzVue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/deray\/status\/539147740442144768\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/tJlp9mzVue",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3twAffCUAAFkof.jpg",
        "id_str" : "539147734154891264",
        "id" : 539147734154891264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3twAffCUAAFkof.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tJlp9mzVue"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539147740442144768",
    "text" : "This officer follows me and tapes me. I think I'll go say hello when we stop. #Ferguson http:\/\/t.co\/tJlp9mzVue",
    "id" : 539147740442144768,
    "created_at" : "2014-11-30 20:03:32 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 539147896470265856,
  "created_at" : "2014-11-30 20:04:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.Nicole",
      "screen_name" : "urbanexpressive",
      "indices" : [ 3, 19 ],
      "id_str" : "540135325",
      "id" : 540135325
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TamirRice",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539146867594915841",
  "text" : "RT @urbanexpressive: The cops that killed #TamirRice has since had a week to get an explanation out while he barely had 2 seconds to explai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TamirRice",
        "indices" : [ 21, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539126112941768704",
    "text" : "The cops that killed #TamirRice has since had a week to get an explanation out while he barely had 2 seconds to explain himself b4 shot",
    "id" : 539126112941768704,
    "created_at" : "2014-11-30 18:37:36 +0000",
    "user" : {
      "name" : "J.Nicole",
      "screen_name" : "urbanexpressive",
      "protected" : false,
      "id_str" : "540135325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642027528287354881\/2lHSdvHn_normal.jpg",
      "id" : 540135325,
      "verified" : false
    }
  },
  "id" : 539146867594915841,
  "created_at" : "2014-11-30 20:00:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u899A\u609F\u3057\u308D\u6771\u4EAC\uFF01\u3053\u306Ejedmund\u304C\u6765\u305F!",
      "screen_name" : "jedmund",
      "indices" : [ 3, 11 ],
      "id_str" : "9700152",
      "id" : 9700152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hg5uC5RdhT",
      "expanded_url" : "http:\/\/gawker.com\/my-vassar-college-faculty-id-makes-everything-ok-1664133077",
      "display_url" : "gawker.com\/my-vassar-coll\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539113823022903297",
  "text" : "RT @jedmund: This may be from Gawker, but holy hell is it Required Reading. Pretty much how I feel every day working at Pinterest\n\nhttp:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hg5uC5RdhT",
        "expanded_url" : "http:\/\/gawker.com\/my-vassar-college-faculty-id-makes-everything-ok-1664133077",
        "display_url" : "gawker.com\/my-vassar-coll\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "538932042243657728",
    "text" : "This may be from Gawker, but holy hell is it Required Reading. Pretty much how I feel every day working at Pinterest\n\nhttp:\/\/t.co\/hg5uC5RdhT",
    "id" : 538932042243657728,
    "created_at" : "2014-11-30 05:46:26 +0000",
    "user" : {
      "name" : "\u899A\u609F\u3057\u308D\u6771\u4EAC\uFF01\u3053\u306Ejedmund\u304C\u6765\u305F!",
      "screen_name" : "jedmund",
      "protected" : false,
      "id_str" : "9700152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726182261289144321\/UVAHsZQv_normal.jpg",
      "id" : 9700152,
      "verified" : false
    }
  },
  "id" : 539113823022903297,
  "created_at" : "2014-11-30 17:48:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/538975032588779520\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/5E66SwkUwt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3rS76uCAAAMYr_.jpg",
      "id_str" : "538975032240635904",
      "id" : 538975032240635904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3rS76uCAAAMYr_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5E66SwkUwt"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "oakland",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538975032588779520",
  "text" : "wow i didn't see the yesterday\n\nu gotta be amaze\n\n#Ferguson #oakland http:\/\/t.co\/5E66SwkUwt",
  "id" : 538975032588779520,
  "created_at" : "2014-11-30 08:37:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lnonblonde",
      "screen_name" : "Lnonblonde",
      "indices" : [ 3, 14 ],
      "id_str" : "113349253",
      "id" : 113349253
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Lnonblonde\/status\/538593068350337024\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EEPMGZk0Vj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3l3iq2CcAARMW7.jpg",
      "id_str" : "538593067947683840",
      "id" : 538593067947683840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3l3iq2CcAARMW7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EEPMGZk0Vj"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538974436167147521",
  "text" : "RT @Lnonblonde: Earlier:Protestor Puts Bike Lock Around His Neck Shuts Down BART \nNo Service In Or Out Of San Francisco #Ferguson http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Lnonblonde\/status\/538593068350337024\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/EEPMGZk0Vj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3l3iq2CcAARMW7.jpg",
        "id_str" : "538593067947683840",
        "id" : 538593067947683840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3l3iq2CcAARMW7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EEPMGZk0Vj"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 104, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538593068350337024",
    "text" : "Earlier:Protestor Puts Bike Lock Around His Neck Shuts Down BART \nNo Service In Or Out Of San Francisco #Ferguson http:\/\/t.co\/EEPMGZk0Vj",
    "id" : 538593068350337024,
    "created_at" : "2014-11-29 07:19:28 +0000",
    "user" : {
      "name" : "Lnonblonde",
      "screen_name" : "Lnonblonde",
      "protected" : false,
      "id_str" : "113349253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728116537853272064\/J4ZihlgG_normal.jpg",
      "id" : 113349253,
      "verified" : false
    }
  },
  "id" : 538974436167147521,
  "created_at" : "2014-11-30 08:34:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/5pkAJgvlZR",
      "expanded_url" : "http:\/\/www.tasigh.org\/ingenium\/pics\/smtreb.gif",
      "display_url" : "tasigh.org\/ingenium\/pics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538973259899752449",
  "text" : "look at this egg tosser \n\nhttp:\/\/t.co\/5pkAJgvlZR\n\n#ferguson",
  "id" : 538973259899752449,
  "created_at" : "2014-11-30 08:30:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/ptzeBGqBfP",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/538971746607431682",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "538972129031905280",
  "geo" : { },
  "id_str" : "538972380945584128",
  "in_reply_to_user_id" : 2265133784,
  "text" : "@BushVsClinton also true. for which see https:\/\/t.co\/ptzeBGqBfP",
  "id" : 538972380945584128,
  "in_reply_to_status_id" : 538972129031905280,
  "created_at" : "2014-11-30 08:26:43 +0000",
  "in_reply_to_screen_name" : "DonaldPrezTrump",
  "in_reply_to_user_id_str" : "2265133784",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BobbyPlattz",
      "screen_name" : "MasterMind5151",
      "indices" : [ 0, 15 ],
      "id_str" : "2739149852",
      "id" : 2739149852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538971002546315264",
  "geo" : { },
  "id_str" : "538972100233420800",
  "in_reply_to_user_id" : 2739149852,
  "text" : "@MasterMind5151 STFU",
  "id" : 538972100233420800,
  "in_reply_to_status_id" : 538971002546315264,
  "created_at" : "2014-11-30 08:25:36 +0000",
  "in_reply_to_screen_name" : "MasterMind5151",
  "in_reply_to_user_id_str" : "2739149852",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538971746607431682",
  "text" : "glass is cheap\n\nlabor is expensive\n\nlabor is life\n\nown yours today\n\n#ferguson",
  "id" : 538971746607431682,
  "created_at" : "2014-11-30 08:24:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538971515639693312",
  "text" : "new bank and fast food windows mean new jobs\n\n#ferguson",
  "id" : 538971515639693312,
  "created_at" : "2014-11-30 08:23:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538970300491128832",
  "text" : "@KenCottonIII  hey dump some of your morality anywhere",
  "id" : 538970300491128832,
  "created_at" : "2014-11-30 08:18:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Goddess",
      "screen_name" : "drgoddess",
      "indices" : [ 12, 22 ],
      "id_str" : "19468168",
      "id" : 19468168
    }, {
      "name" : "Disgruntled Haradrim",
      "screen_name" : "pdjeliclark",
      "indices" : [ 23, 35 ],
      "id_str" : "562421645",
      "id" : 562421645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538970141589909504",
  "text" : "@AnonFatCat @drgoddess @pdjeliclark i was wondering if they were the same height numerically...",
  "id" : 538970141589909504,
  "created_at" : "2014-11-30 08:17:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosette Paneque",
      "screen_name" : "CosettePaneque",
      "indices" : [ 3, 18 ],
      "id_str" : "70160380",
      "id" : 70160380
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 131, 144 ],
      "url" : "http:\/\/t.co\/pQ65rbS3Yd",
      "expanded_url" : "http:\/\/ow.ly\/F5GXs",
      "display_url" : "ow.ly\/F5GXs"
    } ]
  },
  "geo" : { },
  "id_str" : "538969313307152384",
  "text" : "RT @CosettePaneque: If you read nothing else about #Ferguson, read this. How To Argue Eloquently &amp; Back Yourself Up With Facts http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/pQ65rbS3Yd",
        "expanded_url" : "http:\/\/ow.ly\/F5GXs",
        "display_url" : "ow.ly\/F5GXs"
      } ]
    },
    "geo" : { },
    "id_str" : "538965825399828480",
    "text" : "If you read nothing else about #Ferguson, read this. How To Argue Eloquently &amp; Back Yourself Up With Facts http:\/\/t.co\/pQ65rbS3Yd",
    "id" : 538965825399828480,
    "created_at" : "2014-11-30 08:00:40 +0000",
    "user" : {
      "name" : "Cosette Paneque",
      "screen_name" : "CosettePaneque",
      "protected" : false,
      "id_str" : "70160380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598387135016665088\/hRCBTpbm_normal.jpg",
      "id" : 70160380,
      "verified" : false
    }
  },
  "id" : 538969313307152384,
  "created_at" : "2014-11-30 08:14:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Patriot0987\/status\/538965918869495808\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nfZMOCDbvL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3rKpY6IUAExA9H.jpg",
      "id_str" : "538965917833908225",
      "id" : 538965917833908225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3rKpY6IUAExA9H.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nfZMOCDbvL"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/Patriot0987\/status\/538965918869495808\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nfZMOCDbvL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3rKpTwIcAAtyJQ.jpg",
      "id_str" : "538965916449796096",
      "id" : 538965916449796096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3rKpTwIcAAtyJQ.jpg",
      "sizes" : [ {
        "h" : 779,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/nfZMOCDbvL"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538969082825961472",
  "text" : "RT @Patriot0987: #Ferguson justin bieber miley cyrus darren wilson  fakes http:\/\/t.co\/nfZMOCDbvL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Patriot0987\/status\/538965918869495808\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/nfZMOCDbvL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3rKpY6IUAExA9H.jpg",
        "id_str" : "538965917833908225",
        "id" : 538965917833908225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3rKpY6IUAExA9H.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nfZMOCDbvL"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/Patriot0987\/status\/538965918869495808\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/nfZMOCDbvL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3rKpTwIcAAtyJQ.jpg",
        "id_str" : "538965916449796096",
        "id" : 538965916449796096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3rKpTwIcAAtyJQ.jpg",
        "sizes" : [ {
          "h" : 779,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 779,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 779,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/nfZMOCDbvL"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538965918869495808",
    "text" : "#Ferguson justin bieber miley cyrus darren wilson  fakes http:\/\/t.co\/nfZMOCDbvL",
    "id" : 538965918869495808,
    "created_at" : "2014-11-30 08:01:03 +0000",
    "user" : {
      "name" : "John Smith",
      "screen_name" : "NerdRoadKill",
      "protected" : false,
      "id_str" : "103703750",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1228914409\/untitledww_normal.jpg",
      "id" : 103703750,
      "verified" : false
    }
  },
  "id" : 538969082825961472,
  "created_at" : "2014-11-30 08:13:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BS Filter",
      "screen_name" : "BSfil",
      "indices" : [ 3, 9 ],
      "id_str" : "2775904743",
      "id" : 2775904743
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/OccupyRMN\/status\/538956005422690304\/photo\/1",
      "indices" : [ 131, 144 ],
      "url" : "http:\/\/t.co\/DTTa9SObiA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3rBoX9CUAAxe0n.jpg",
      "id_str" : "538956004793143296",
      "id" : 538956004793143296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3rBoX9CUAAxe0n.jpg",
      "sizes" : [ {
        "h" : 303,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DTTa9SObiA"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538967367343017984",
  "text" : "RT @BSfil: May 2012: Students in Quebec were asked to send protest march route to the cops &amp; they replied with this: #Ferguson http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/OccupyRMN\/status\/538956005422690304\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/DTTa9SObiA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3rBoX9CUAAxe0n.jpg",
        "id_str" : "538956004793143296",
        "id" : 538956004793143296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3rBoX9CUAAxe0n.jpg",
        "sizes" : [ {
          "h" : 303,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DTTa9SObiA"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538966538179846144",
    "text" : "May 2012: Students in Quebec were asked to send protest march route to the cops &amp; they replied with this: #Ferguson http:\/\/t.co\/DTTa9SObiA",
    "id" : 538966538179846144,
    "created_at" : "2014-11-30 08:03:30 +0000",
    "user" : {
      "name" : "BS Filter",
      "screen_name" : "BSfil",
      "protected" : false,
      "id_str" : "2775904743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650028978061729792\/euSvtYAM_normal.jpg",
      "id" : 2775904743,
      "verified" : false
    }
  },
  "id" : 538967367343017984,
  "created_at" : "2014-11-30 08:06:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538966567443116032",
  "geo" : { },
  "id_str" : "538967202238443520",
  "in_reply_to_user_id" : 146510281,
  "text" : "@LouieDroogs  haha this can't be real flag for twitter spambot",
  "id" : 538967202238443520,
  "in_reply_to_status_id" : 538966567443116032,
  "created_at" : "2014-11-30 08:06:09 +0000",
  "in_reply_to_screen_name" : "PuroSweetLou",
  "in_reply_to_user_id_str" : "146510281",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538963121071611904",
  "text" : "CALLING IN THE NATION GUARD IS GETTING OUT OF HAND. POLICE NOTHING BUT THUGS WITHOUT THEM. LIKE THUGS THEY OUTDONE BY THE PUBLIC  #FERGUSON",
  "id" : 538963121071611904,
  "created_at" : "2014-11-30 07:49:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538962312560771072",
  "text" : "WHY WASN'T THIS INCIDENT HANDLED FIRST IN FERGUSON, AS A LOCAL MATTER?\n\nGOVERNOR STEPPED IN QUICK, WITH A STATE OF EMERGENCY!\n\n#Ferguson",
  "id" : 538962312560771072,
  "created_at" : "2014-11-30 07:46:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538962090505945088",
  "text" : "SEE HOW QUICK THE LARGER FORCE GOT INVOLVED\n\n#FERGUSON",
  "id" : 538962090505945088,
  "created_at" : "2014-11-30 07:45:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538958653898764288",
  "text" : "it aint nice being on the business end of business' means",
  "id" : 538958653898764288,
  "created_at" : "2014-11-30 07:32:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538958107913621504",
  "text" : "a lot of this can be traced back to 9\/11 and proceedings\n\nmost obviously in the war leftovers given to police, but in policy and paranoia",
  "id" : 538958107913621504,
  "created_at" : "2014-11-30 07:30:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538957201038008320",
  "text" : "killin at home \nkillin abroad\nlawd knows they got killin\nkillin on they mind",
  "id" : 538957201038008320,
  "created_at" : "2014-11-30 07:26:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538956860548608000",
  "text" : "i am not even lying they popped two kids doing exactly same things I did when I was them\n\ni have had guns pointed on me by police too  \n\nd:(",
  "id" : 538956860548608000,
  "created_at" : "2014-11-30 07:25:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538953489041207296",
  "text" : "the strategy is to keep it heavy and ultra peaceful in ferg\/MO\n\nthey have 200 more days ahead of them, by precedent, and we know shits worse",
  "id" : 538953489041207296,
  "created_at" : "2014-11-30 07:11:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538951533740584960",
  "text" : "YA EYE AINT BIG ENOUGH FOR YA STOMACH\n\nSEE THE BIGGER BEEF\n\nTHIS METAPHOR BROUGHT YOU BY THE BEEF COUNCIL",
  "id" : 538951533740584960,
  "created_at" : "2014-11-30 07:03:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538949688326516737",
  "text" : "yet nobody is laughing",
  "id" : 538949688326516737,
  "created_at" : "2014-11-30 06:56:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538946507978706944",
  "text" : "protest slave, nows yr chance\n\nsing n act like workin\n\nbut be ready to dash\n\nif cracker catch u steppin\n\nsmile @ the fool n dance\n\n#ferguson",
  "id" : 538946507978706944,
  "created_at" : "2014-11-30 06:43:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538944844907806721",
  "text" : "why be silent? twitter is a service to be a broadcast media. only different.  but it is what you paid for, isn't it? \n\nspeak your protest!",
  "id" : 538944844907806721,
  "created_at" : "2014-11-30 06:37:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/so3fPEx47l",
      "expanded_url" : "http:\/\/vimeo.com\/113145046",
      "display_url" : "vimeo.com\/113145046"
    } ]
  },
  "in_reply_to_status_id_str" : "538933376095232000",
  "geo" : { },
  "id_str" : "538933721336791040",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha watch this thriller!  \nhttp:\/\/t.co\/so3fPEx47l",
  "id" : 538933721336791040,
  "in_reply_to_status_id" : 538933376095232000,
  "created_at" : "2014-11-30 05:53:06 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538932570323304449",
  "geo" : { },
  "id_str" : "538932997190217728",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha is it like when James Bond drops the movie's title in a witty reply?",
  "id" : 538932997190217728,
  "in_reply_to_status_id" : 538932570323304449,
  "created_at" : "2014-11-30 05:50:14 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 24, 32 ]
    }, {
      "text" : "ferguson",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "protest",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/q1wPhZ8MIH",
      "expanded_url" : "http:\/\/vimeo.com\/113011810",
      "display_url" : "vimeo.com\/113011810"
    } ]
  },
  "geo" : { },
  "id_str" : "538929344865771520",
  "text" : "http:\/\/t.co\/q1wPhZ8MIH\n\n#oakland #ferguson #protest",
  "id" : 538929344865771520,
  "created_at" : "2014-11-30 05:35:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538928458890371072",
  "text" : "watch that one",
  "id" : 538928458890371072,
  "created_at" : "2014-11-30 05:32:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "sf",
      "indices" : [ 41, 44 ]
    }, {
      "text" : "oakland",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/so3fPEx47l",
      "expanded_url" : "http:\/\/vimeo.com\/113145046",
      "display_url" : "vimeo.com\/113145046"
    } ]
  },
  "geo" : { },
  "id_str" : "538928154450997249",
  "text" : "fvck\n\nhttp:\/\/t.co\/so3fPEx47l \n\n#ferguson #sf #oakland",
  "id" : 538928154450997249,
  "created_at" : "2014-11-30 05:30:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0625\u0646\u062A\u0641\u0627\u0636\u0629 \u0627\u0644\u0628\u0627\u064A \u0622\u0631\u064A\u0627",
      "screen_name" : "BayAreaIntifada",
      "indices" : [ 3, 19 ],
      "id_str" : "399867227",
      "id" : 399867227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackoutBlackFriday",
      "indices" : [ 27, 47 ]
    }, {
      "text" : "SF",
      "indices" : [ 51, 54 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 109, 118 ]
    }, {
      "text" : "Ayotzinapa",
      "indices" : [ 119, 130 ]
    }, {
      "text" : "Oakland",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/3yaJqlnBQa",
      "expanded_url" : "http:\/\/vimeo.com\/113145046",
      "display_url" : "vimeo.com\/113145046"
    } ]
  },
  "geo" : { },
  "id_str" : "538927174594469888",
  "text" : "RT @BayAreaIntifada: (Vid) #BlackoutBlackFriday in #SF shopping district. Pigs &amp; windows get smashed on. #Ferguson #Ayotzinapa #Oakland htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackoutBlackFriday",
        "indices" : [ 6, 26 ]
      }, {
        "text" : "SF",
        "indices" : [ 30, 33 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "Ayotzinapa",
        "indices" : [ 98, 109 ]
      }, {
        "text" : "Oakland",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/3yaJqlnBQa",
        "expanded_url" : "http:\/\/vimeo.com\/113145046",
        "display_url" : "vimeo.com\/113145046"
      } ]
    },
    "geo" : { },
    "id_str" : "538842540246835201",
    "text" : "(Vid) #BlackoutBlackFriday in #SF shopping district. Pigs &amp; windows get smashed on. #Ferguson #Ayotzinapa #Oakland http:\/\/t.co\/3yaJqlnBQa",
    "id" : 538842540246835201,
    "created_at" : "2014-11-29 23:50:47 +0000",
    "user" : {
      "name" : "\u0625\u0646\u062A\u0641\u0627\u0636\u0629 \u0627\u0644\u0628\u0627\u064A \u0622\u0631\u064A\u0627",
      "screen_name" : "BayAreaIntifada",
      "protected" : false,
      "id_str" : "399867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480873371337383936\/DdhkId2o_normal.jpeg",
      "id" : 399867227,
      "verified" : false
    }
  },
  "id" : 538927174594469888,
  "created_at" : "2014-11-30 05:27:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538923523230535680",
  "geo" : { },
  "id_str" : "538923906736717824",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha ah can't i haven't had a blockbuster membership since 1998",
  "id" : 538923906736717824,
  "in_reply_to_status_id" : 538923523230535680,
  "created_at" : "2014-11-30 05:14:06 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/vq8g6R1fxg",
      "expanded_url" : "http:\/\/www.imdb.com\/title\/tt0113690\/?ref_=nm_flmg_wr_20",
      "display_url" : "imdb.com\/title\/tt011369\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "538922792066891776",
  "geo" : { },
  "id_str" : "538923328497397761",
  "in_reply_to_user_id" : 46961216,
  "text" : "@ednapiranha  oh no wonder it had scott bakula http:\/\/t.co\/vq8g6R1fxg",
  "id" : 538923328497397761,
  "in_reply_to_status_id" : 538922792066891776,
  "created_at" : "2014-11-30 05:11:48 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538921952983797760",
  "geo" : { },
  "id_str" : "538922792066891776",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha oh that director,  we had \"lord of illusions\" on VHS from the blockbuster bargain bin, and watched it at least a couple times.",
  "id" : 538922792066891776,
  "in_reply_to_status_id" : 538921952983797760,
  "created_at" : "2014-11-30 05:09:40 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538920565264773120",
  "geo" : { },
  "id_str" : "538921531737260032",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha  as long as it isn't pop-culturally significant any more we're good",
  "id" : 538921531737260032,
  "in_reply_to_status_id" : 538920565264773120,
  "created_at" : "2014-11-30 05:04:40 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skylar",
      "screen_name" : "Skylar1964",
      "indices" : [ 27, 38 ],
      "id_str" : "131535809",
      "id" : 131535809
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/538921338618929153\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/fIO0N2stzH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3qiGgkCMAANXMy.png",
      "id_str" : "538921338128183296",
      "id" : 538921338128183296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3qiGgkCMAANXMy.png",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 104,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fIO0N2stzH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538921338618929153",
  "text" : "lol look at this character @skylar1964 keeps hitting me the logic.  My ignorance could fixed by following the news! http:\/\/t.co\/fIO0N2stzH",
  "id" : 538921338618929153,
  "created_at" : "2014-11-30 05:03:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538918982443487232",
  "geo" : { },
  "id_str" : "538920303242399744",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha  I think we could be friends.  I can't hang with the references either.",
  "id" : 538920303242399744,
  "in_reply_to_status_id" : 538918982443487232,
  "created_at" : "2014-11-30 04:59:47 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538918292849975297",
  "geo" : { },
  "id_str" : "538918888876949504",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha  I've only seen \"episode one\"",
  "id" : 538918888876949504,
  "in_reply_to_status_id" : 538918292849975297,
  "created_at" : "2014-11-30 04:54:10 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538918430934454273",
  "text" : "technerds\n\ncyber monday is your day to walk out with yr hands up",
  "id" : 538918430934454273,
  "created_at" : "2014-11-30 04:52:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538916748175474689",
  "text" : "the police are collecting riot + overtime pay on top of salary\n\nso, in a way, the protest is also in their interest\n\nwe protest!\n\n#ferguson",
  "id" : 538916748175474689,
  "created_at" : "2014-11-30 04:45:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skylar",
      "screen_name" : "Skylar1964",
      "indices" : [ 0, 11 ],
      "id_str" : "131535809",
      "id" : 131535809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538915936137252865",
  "geo" : { },
  "id_str" : "538916112847499264",
  "in_reply_to_user_id" : 46961216,
  "text" : "@Skylar1964 cuz sharing your insensitive and unenlightened reasoning is a poor choice on the internet!",
  "id" : 538916112847499264,
  "in_reply_to_status_id" : 538915936137252865,
  "created_at" : "2014-11-30 04:43:08 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skylar",
      "screen_name" : "Skylar1964",
      "indices" : [ 0, 11 ],
      "id_str" : "131535809",
      "id" : 131535809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538914507322826753",
  "geo" : { },
  "id_str" : "538915936137252865",
  "in_reply_to_user_id" : 131535809,
  "text" : "@Skylar1964 if u can justify murder, and no trial(!), for shoplifting, then by yr own reasoning u should be shot for for your poor intellect",
  "id" : 538915936137252865,
  "in_reply_to_status_id" : 538914507322826753,
  "created_at" : "2014-11-30 04:42:26 +0000",
  "in_reply_to_screen_name" : "Skylar1964",
  "in_reply_to_user_id_str" : "131535809",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538914423545405440",
  "text" : "bigots are such flame bait\n\nmay the flames reach them",
  "id" : 538914423545405440,
  "created_at" : "2014-11-30 04:36:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538914043826688000",
  "text" : "billions of dollars being spent to defend pure, vile, intentional ignorance, and the wealth amassed by its perpetrators\n\n#ferguson",
  "id" : 538914043826688000,
  "created_at" : "2014-11-30 04:34:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538913445174079489",
  "geo" : { },
  "id_str" : "538913706935992320",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray looks like west point is in town for a bowl game",
  "id" : 538913706935992320,
  "in_reply_to_status_id" : 538913445174079489,
  "created_at" : "2014-11-30 04:33:34 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538913531496640512",
  "text" : "the system will accept a pyrrhic victory\n\n#ferguson",
  "id" : 538913531496640512,
  "created_at" : "2014-11-30 04:32:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538910173138395136",
  "geo" : { },
  "id_str" : "538913089664466946",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray \n\nno, the police won't protect you from cops, narcs, bigots, capitalists, real estate developers, politicians, or injustice",
  "id" : 538913089664466946,
  "in_reply_to_status_id" : 538910173138395136,
  "created_at" : "2014-11-30 04:31:07 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538912461370322945",
  "text" : "pissing off bigots on twitter like this was AOL 1997",
  "id" : 538912461370322945,
  "created_at" : "2014-11-30 04:28:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skylar",
      "screen_name" : "Skylar1964",
      "indices" : [ 0, 11 ],
      "id_str" : "131535809",
      "id" : 131535809
    }, {
      "name" : "BioTech",
      "screen_name" : "gulfstream450",
      "indices" : [ 12, 26 ],
      "id_str" : "2322858322",
      "id" : 2322858322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538907570321522688",
  "geo" : { },
  "id_str" : "538911951888207872",
  "in_reply_to_user_id" : 131535809,
  "text" : "@Skylar1964 @gulfstream450  wow imagine if your poor reasoning had equally bad results!  to die be gunned for silly shit, like yr intellect!",
  "id" : 538911951888207872,
  "in_reply_to_status_id" : 538907570321522688,
  "created_at" : "2014-11-30 04:26:36 +0000",
  "in_reply_to_screen_name" : "Skylar1964",
  "in_reply_to_user_id_str" : "131535809",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538910368962068480",
  "text" : "Michael Brown mighta had a future.  Darren Wilson was gonna be a dumbass, racist grunt cop the rest of his miserable life.  \n\n#ferguson",
  "id" : 538910368962068480,
  "created_at" : "2014-11-30 04:20:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538907885799870464",
  "text" : "Darren Wilson is all set, got a brand new life!  One he stole directly from Michael Brown.\n\n#ferguson",
  "id" : 538907885799870464,
  "created_at" : "2014-11-30 04:10:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BioTech",
      "screen_name" : "gulfstream450",
      "indices" : [ 0, 14 ],
      "id_str" : "2322858322",
      "id" : 2322858322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538906416896286721",
  "geo" : { },
  "id_str" : "538906885458370560",
  "in_reply_to_user_id" : 2322858322,
  "text" : "@gulfstream450  why it's almost like he stole that life right out of Michael Brown",
  "id" : 538906885458370560,
  "in_reply_to_status_id" : 538906416896286721,
  "created_at" : "2014-11-30 04:06:28 +0000",
  "in_reply_to_screen_name" : "gulfstream450",
  "in_reply_to_user_id_str" : "2322858322",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538904566914240512",
  "text" : "\" I'm nigga rich, bitch, so imma quit \" - darren wilson, after his racist fundraiser money and MSM payouts.  also death threats.\n\n#Ferguson",
  "id" : 538904566914240512,
  "created_at" : "2014-11-30 03:57:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Ford",
      "screen_name" : "1communitybible",
      "indices" : [ 3, 19 ],
      "id_str" : "2739624249",
      "id" : 2739624249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538901038153990144",
  "text" : "RT @1communitybible: The more I pray for Ferguson the more I get a sense God will get the glory in that community!  #Ferguson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538900282290491393",
    "text" : "The more I pray for Ferguson the more I get a sense God will get the glory in that community!  #Ferguson",
    "id" : 538900282290491393,
    "created_at" : "2014-11-30 03:40:14 +0000",
    "user" : {
      "name" : "Jason Ford",
      "screen_name" : "1communitybible",
      "protected" : false,
      "id_str" : "2739624249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521849086086246403\/mNMPjWaF_normal.jpeg",
      "id" : 2739624249,
      "verified" : false
    }
  },
  "id" : 538901038153990144,
  "created_at" : "2014-11-30 03:43:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caveman Corey",
      "screen_name" : "Corey_Peters",
      "indices" : [ 0, 13 ],
      "id_str" : "282228966",
      "id" : 282228966
    }, {
      "name" : "David Carson",
      "screen_name" : "PDPJ",
      "indices" : [ 14, 19 ],
      "id_str" : "17068692",
      "id" : 17068692
    }, {
      "name" : "Brian Stelter",
      "screen_name" : "brianstelter",
      "indices" : [ 20, 33 ],
      "id_str" : "14515799",
      "id" : 14515799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538898985390325761",
  "geo" : { },
  "id_str" : "538900420442087425",
  "in_reply_to_user_id" : 282228966,
  "text" : "@Corey_Peters @PDPJ @brianstelter stop at the cop before the real boss? your life must be nice n easy to ignore the big picture like that.",
  "id" : 538900420442087425,
  "in_reply_to_status_id" : 538898985390325761,
  "created_at" : "2014-11-30 03:40:47 +0000",
  "in_reply_to_screen_name" : "Corey_Peters",
  "in_reply_to_user_id_str" : "282228966",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538900289529458688",
  "text" : "the reason politicians will not stop cops is cuz after the police finally turn, aint nobody to protect the politician\nheads &gt; roll\n#Ferguson",
  "id" : 538900289529458688,
  "created_at" : "2014-11-30 03:40:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caveman Corey",
      "screen_name" : "Corey_Peters",
      "indices" : [ 0, 13 ],
      "id_str" : "282228966",
      "id" : 282228966
    }, {
      "name" : "David Carson",
      "screen_name" : "PDPJ",
      "indices" : [ 14, 19 ],
      "id_str" : "17068692",
      "id" : 17068692
    }, {
      "name" : "Brian Stelter",
      "screen_name" : "brianstelter",
      "indices" : [ 20, 33 ],
      "id_str" : "14515799",
      "id" : 14515799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538896975257554944",
  "geo" : { },
  "id_str" : "538898367401570304",
  "in_reply_to_user_id" : 282228966,
  "text" : "@Corey_Peters @PDPJ @brianstelter  \n\ni know!  besmirching the fine gloss put on the State of Missouri by the killing of an unarmed citizen",
  "id" : 538898367401570304,
  "in_reply_to_status_id" : 538896975257554944,
  "created_at" : "2014-11-30 03:32:37 +0000",
  "in_reply_to_screen_name" : "Corey_Peters",
  "in_reply_to_user_id_str" : "282228966",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Winslow (SAO)",
      "screen_name" : "Romonaga_",
      "indices" : [ 0, 10 ],
      "id_str" : "54309607",
      "id" : 54309607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538897011257667584",
  "geo" : { },
  "id_str" : "538897446500589568",
  "in_reply_to_user_id" : 54309607,
  "text" : "@Romonaga_  u aint inspiring nobody",
  "id" : 538897446500589568,
  "in_reply_to_status_id" : 538897011257667584,
  "created_at" : "2014-11-30 03:28:58 +0000",
  "in_reply_to_screen_name" : "Romonaga_",
  "in_reply_to_user_id_str" : "54309607",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/06xpquXn2Y",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/538895432038899713",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "538895111602442240",
  "geo" : { },
  "id_str" : "538896759724863488",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nhttps:\/\/t.co\/06xpquXn2Y",
  "id" : 538896759724863488,
  "in_reply_to_status_id" : 538895111602442240,
  "created_at" : "2014-11-30 03:26:14 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soul Watcher",
      "screen_name" : "lisecob",
      "indices" : [ 0, 8 ],
      "id_str" : "1217062580",
      "id" : 1217062580
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538893699573641216",
  "geo" : { },
  "id_str" : "538895432038899713",
  "in_reply_to_user_id" : 1217062580,
  "text" : "@lisecob  you are not worthy of the best that flag stands for, if you choose to be ignorant of the worst\n\n#ferguson",
  "id" : 538895432038899713,
  "in_reply_to_status_id" : 538893699573641216,
  "created_at" : "2014-11-30 03:20:57 +0000",
  "in_reply_to_screen_name" : "lisecob",
  "in_reply_to_user_id_str" : "1217062580",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/zabNvBnwCo",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/538894883864338433",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538895111602442240",
  "text" : "hey ma im trolling strangers on the internet like it was 1995\n\nhttps:\/\/t.co\/zabNvBnwCo",
  "id" : 538895111602442240,
  "created_at" : "2014-11-30 03:19:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Darcy",
      "screen_name" : "oliverdarcy",
      "indices" : [ 0, 12 ],
      "id_str" : "27075032",
      "id" : 27075032
    }, {
      "name" : "Marcus DiPaola",
      "screen_name" : "MJDiPaola",
      "indices" : [ 13, 23 ],
      "id_str" : "376000557",
      "id" : 376000557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538893704837070849",
  "geo" : { },
  "id_str" : "538894883864338433",
  "in_reply_to_user_id" : 27075032,
  "text" : "@oliverdarcy @MJDiPaola  actually this is anti-classicist behaviour. classy refers to actions considered moral or fashionable by upper class",
  "id" : 538894883864338433,
  "in_reply_to_status_id" : 538893704837070849,
  "created_at" : "2014-11-30 03:18:47 +0000",
  "in_reply_to_screen_name" : "oliverdarcy",
  "in_reply_to_user_id_str" : "27075032",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538894282669576192",
  "text" : "you should be trolling twitter and facebook for dumb and ignorant responses to #ferguson",
  "id" : 538894282669576192,
  "created_at" : "2014-11-30 03:16:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538890872063287299",
  "geo" : { },
  "id_str" : "538893807635271680",
  "in_reply_to_user_id" : 53446001,
  "text" : "@RobKimWill  right, because when you don't understand, its the others' fault.  Yet yr supercilious comment shows u dont care to understand.",
  "id" : 538893807635271680,
  "in_reply_to_status_id" : 538890872063287299,
  "created_at" : "2014-11-30 03:14:30 +0000",
  "in_reply_to_screen_name" : "JM_Browning",
  "in_reply_to_user_id_str" : "53446001",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538850004421464064",
  "text" : "stereo is stupid",
  "id" : 538850004421464064,
  "created_at" : "2014-11-30 00:20:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538847595691773952",
  "geo" : { },
  "id_str" : "538848874551459840",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  i did both that!  track 1 is compressed.  it's also mono tho, I need to copy channel 1 to channel 2 I guess.  CANCEL THE SHOW",
  "id" : 538848874551459840,
  "in_reply_to_status_id" : 538847595691773952,
  "created_at" : "2014-11-30 00:15:57 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538843142750208000",
  "geo" : { },
  "id_str" : "538847279868698624",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr hm thx, can you DL the bundle in a lossless format and test the other mixes? (i made it free)",
  "id" : 538847279868698624,
  "in_reply_to_status_id" : 538843142750208000,
  "created_at" : "2014-11-30 00:09:37 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 3, 16 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/o7nd7sPjmU",
      "expanded_url" : "http:\/\/gofund.me\/FrontlineAnon?pc=tw_cr_n",
      "display_url" : "gofund.me\/FrontlineAnon?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538823644453937152",
  "text" : "RT @occupythemob: Anonymous Ustream . My phone has just shut off. I need to pay the bill. Please help out. Click to Donate:  http:\/\/t.co\/o7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/o7nd7sPjmU",
        "expanded_url" : "http:\/\/gofund.me\/FrontlineAnon?pc=tw_cr_n",
        "display_url" : "gofund.me\/FrontlineAnon?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "538823343898910720",
    "text" : "Anonymous Ustream . My phone has just shut off. I need to pay the bill. Please help out. Click to Donate:  http:\/\/t.co\/o7nd7sPjmU",
    "id" : 538823343898910720,
    "created_at" : "2014-11-29 22:34:30 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "AnonyMobLife",
      "protected" : false,
      "id_str" : "341908197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627989340111654912\/Xo6hS4Ab_normal.jpg",
      "id" : 341908197,
      "verified" : false
    }
  },
  "id" : 538823644453937152,
  "created_at" : "2014-11-29 22:35:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/jEBHE6cQS3",
      "expanded_url" : "https:\/\/folkstack.bandcamp.com\/album\/intoreducing",
      "display_url" : "folkstack.bandcamp.com\/album\/intoredu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538821634958704640",
  "text" : "this may sound awesome\nbecause it sounded awesome at the time\nand cuz we used muh javascripts live on the guitar\nhttps:\/\/t.co\/jEBHE6cQS3",
  "id" : 538821634958704640,
  "created_at" : "2014-11-29 22:27:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538819230658199552",
  "geo" : { },
  "id_str" : "538820912359821312",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords dude, if it's your personal site, let it go",
  "id" : 538820912359821312,
  "in_reply_to_status_id" : 538819230658199552,
  "created_at" : "2014-11-29 22:24:50 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/jEBHE6cQS3",
      "expanded_url" : "https:\/\/folkstack.bandcamp.com\/album\/intoreducing",
      "display_url" : "folkstack.bandcamp.com\/album\/intoredu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538820658809933825",
  "text" : "we are beginning to release music recorded here in Hackistan\nhere is 1st of the waves\nhttps:\/\/t.co\/jEBHE6cQS3\nproceeds support radical shit",
  "id" : 538820658809933825,
  "created_at" : "2014-11-29 22:23:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/jEBHE6cQS3",
      "expanded_url" : "https:\/\/folkstack.bandcamp.com\/album\/intoreducing",
      "display_url" : "folkstack.bandcamp.com\/album\/intoredu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "538803828821610497",
  "geo" : { },
  "id_str" : "538814247086481408",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords something for your journey thereafter, but another who has been down that cascading path\n\nhttps:\/\/t.co\/jEBHE6cQS3",
  "id" : 538814247086481408,
  "in_reply_to_status_id" : 538803828821610497,
  "created_at" : "2014-11-29 21:58:21 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wookiehangover",
      "screen_name" : "sambreed",
      "indices" : [ 0, 9 ],
      "id_str" : "14217249",
      "id" : 14217249
    }, {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 10, 26 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538798103675928577",
  "geo" : { },
  "id_str" : "538799014154469376",
  "in_reply_to_user_id" : 14217249,
  "text" : "@sambreed @brianloveswords float r 4 newbs",
  "id" : 538799014154469376,
  "in_reply_to_status_id" : 538798103675928577,
  "created_at" : "2014-11-29 20:57:50 +0000",
  "in_reply_to_screen_name" : "sambreed",
  "in_reply_to_user_id_str" : "14217249",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538787428010426368",
  "text" : "if you aren't reading and tweeting about anything but protests and ferguson and issues\n\nyou don't know what a real justified thrill yr missn",
  "id" : 538787428010426368,
  "created_at" : "2014-11-29 20:11:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meka Ro in KC",
      "screen_name" : "Meka1180RR",
      "indices" : [ 3, 14 ],
      "id_str" : "2419668234",
      "id" : 2419668234
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 16, 22 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Meka1180RR\/status\/538784407641792513\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/P7w3khenwV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3olh35CIAAR1bk.jpg",
      "id_str" : "538784369293271040",
      "id" : 538784369293271040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3olh35CIAAR1bk.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 780,
        "resize" : "fit",
        "w" : 1040
      } ],
      "display_url" : "pic.twitter.com\/P7w3khenwV"
    } ],
    "hashtags" : [ {
      "text" : "MikeBrown",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538785818098167808",
  "text" : "RT @Meka1180RR: @deray this just in. #MikeBrown http:\/\/t.co\/P7w3khenwV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 0, 6 ],
        "id_str" : "29417304",
        "id" : 29417304
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Meka1180RR\/status\/538784407641792513\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/P7w3khenwV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3olh35CIAAR1bk.jpg",
        "id_str" : "538784369293271040",
        "id" : 538784369293271040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3olh35CIAAR1bk.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 780,
          "resize" : "fit",
          "w" : 1040
        } ],
        "display_url" : "pic.twitter.com\/P7w3khenwV"
      } ],
      "hashtags" : [ {
        "text" : "MikeBrown",
        "indices" : [ 21, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538784407641792513",
    "in_reply_to_user_id" : 29417304,
    "text" : "@deray this just in. #MikeBrown http:\/\/t.co\/P7w3khenwV",
    "id" : 538784407641792513,
    "created_at" : "2014-11-29 19:59:47 +0000",
    "in_reply_to_screen_name" : "deray",
    "in_reply_to_user_id_str" : "29417304",
    "user" : {
      "name" : "Meka Ro in KC",
      "screen_name" : "Meka1180RR",
      "protected" : false,
      "id_str" : "2419668234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719939282262069249\/-yiU75ks_normal.jpg",
      "id" : 2419668234,
      "verified" : false
    }
  },
  "id" : 538785818098167808,
  "created_at" : "2014-11-29 20:05:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538785345962127360",
  "text" : "cross reference here for the nerds\n\nwhen you see the arguments about fatherhood in black communities\n\nremember: that is asking for more patr",
  "id" : 538785345962127360,
  "created_at" : "2014-11-29 20:03:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538784672080084992",
  "text" : "blessed be protesters and many thanks!\n\nu represent thugs like myself\n\nwho be too scurred of police\n\nbut not of Michael's Brown\n\n#ferguson",
  "id" : 538784672080084992,
  "created_at" : "2014-11-29 20:00:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538783583532363776",
  "text" : "the people of hackistan salute protesters everywhere\n\n#ferguson",
  "id" : 538783583532363776,
  "created_at" : "2014-11-29 19:56:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538782241418002432",
  "text" : "nobody wants to be party to violence if they can help it\ndestruction of property is well and historically justified\nshut up and listen, dad",
  "id" : 538782241418002432,
  "created_at" : "2014-11-29 19:51:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538781392683823104",
  "text" : "police are to the corporat rich and elite \n\nwhat the whip cracker was to the slave owner\n\n#ferguson",
  "id" : 538781392683823104,
  "created_at" : "2014-11-29 19:47:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538781030585356288",
  "text" : "\"good\" &amp; \"bad\" are silly, dualistic tropes used to stretch reasoning between extremes\n\nPolice in the USA are an uninvited, misused authority",
  "id" : 538781030585356288,
  "created_at" : "2014-11-29 19:46:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 3, 16 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538779600071839745",
  "text" : "RT @occupythemob: Let's make this clear, all police are bad. No such thing as a good cops because they would tell on bad cops but they don'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538779465632198657",
    "text" : "Let's make this clear, all police are bad. No such thing as a good cops because they would tell on bad cops but they don't. Simple logic",
    "id" : 538779465632198657,
    "created_at" : "2014-11-29 19:40:09 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "AnonyMobLife",
      "protected" : false,
      "id_str" : "341908197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627989340111654912\/Xo6hS4Ab_normal.jpg",
      "id" : 341908197,
      "verified" : false
    }
  },
  "id" : 538779600071839745,
  "created_at" : "2014-11-29 19:40:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538779232411738112",
  "text" : "one word\n\nEffigies\n\nanother word\n\n#Ferguson",
  "id" : 538779232411738112,
  "created_at" : "2014-11-29 19:39:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 9, 18 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538778905063092224",
  "text" : "@jden415 @substack \n\ngreat idea \n\nbyo fuck n effigy!\n\nwe protest!",
  "id" : 538778905063092224,
  "created_at" : "2014-11-29 19:37:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "sf",
      "indices" : [ 96, 99 ]
    }, {
      "text" : "oakland",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "jiujitsu",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/wRrmxMeVfY",
      "expanded_url" : "https:\/\/vine.co\/v\/On1x6iUuwxK",
      "display_url" : "vine.co\/v\/On1x6iUuwxK"
    } ]
  },
  "geo" : { },
  "id_str" : "538766067162947586",
  "text" : "excellent awareness by the detained person, to trip the cop\n\nhttps:\/\/t.co\/wRrmxMeVfY\n\n#ferguson #sf #oakland #jiujitsu",
  "id" : 538766067162947586,
  "created_at" : "2014-11-29 18:46:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lol",
      "screen_name" : "heybrittneyyyyy",
      "indices" : [ 3, 19 ],
      "id_str" : "2443071902",
      "id" : 2443071902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/heybrittneyyyyy\/status\/538762990418268161\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/cxkg8QivW1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oSFTrCcAEM2w7.jpg",
      "id_str" : "538762987813629953",
      "id" : 538762987813629953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oSFTrCcAEM2w7.jpg",
      "sizes" : [ {
        "h" : 293,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/cxkg8QivW1"
    } ],
    "hashtags" : [ {
      "text" : "JusticeForMikeBrown",
      "indices" : [ 21, 41 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 42, 51 ]
    }, {
      "text" : "FergusonDecision",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538764651832827905",
  "text" : "RT @heybrittneyyyyy: #JusticeForMikeBrown #Ferguson #FergusonDecision http:\/\/t.co\/cxkg8QivW1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/heybrittneyyyyy\/status\/538762990418268161\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/cxkg8QivW1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oSFTrCcAEM2w7.jpg",
        "id_str" : "538762987813629953",
        "id" : 538762987813629953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oSFTrCcAEM2w7.jpg",
        "sizes" : [ {
          "h" : 293,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/cxkg8QivW1"
      } ],
      "hashtags" : [ {
        "text" : "JusticeForMikeBrown",
        "indices" : [ 0, 20 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 21, 30 ]
      }, {
        "text" : "FergusonDecision",
        "indices" : [ 31, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538762990418268161",
    "text" : "#JusticeForMikeBrown #Ferguson #FergusonDecision http:\/\/t.co\/cxkg8QivW1",
    "id" : 538762990418268161,
    "created_at" : "2014-11-29 18:34:41 +0000",
    "user" : {
      "name" : "lol",
      "screen_name" : "heybrittneyyyyy",
      "protected" : false,
      "id_str" : "2443071902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716796408997634048\/vTKWcNqj_normal.jpg",
      "id" : 2443071902,
      "verified" : false
    }
  },
  "id" : 538764651832827905,
  "created_at" : "2014-11-29 18:41:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mocahontas",
      "screen_name" : "Anon_line",
      "indices" : [ 3, 13 ],
      "id_str" : "2783912326",
      "id" : 2783912326
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/anon_line\/status\/538761108904235008\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iWmUM8kJdm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oQXIxCQAAOK14.jpg",
      "id_str" : "538761095100383232",
      "id" : 538761095100383232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oQXIxCQAAOK14.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iWmUM8kJdm"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/anon_line\/status\/538761108904235008\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iWmUM8kJdm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oQXIxCAAE_TBu.jpg",
      "id_str" : "538761095100366849",
      "id" : 538761095100366849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oQXIxCAAE_TBu.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iWmUM8kJdm"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/anon_line\/status\/538761108904235008\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iWmUM8kJdm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oQXNQCYAA0epY.jpg",
      "id_str" : "538761096304156672",
      "id" : 538761096304156672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oQXNQCYAA0epY.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iWmUM8kJdm"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/anon_line\/status\/538761108904235008\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iWmUM8kJdm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oQXU6CIAAsuYd.jpg",
      "id_str" : "538761098359349248",
      "id" : 538761098359349248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oQXU6CIAAsuYd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iWmUM8kJdm"
    } ],
    "hashtags" : [ {
      "text" : "Solidarity",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538762403308371968",
  "text" : "RT @anon_line: YESTERDAY at the Ferguson Police Department before they said \"You will be subject to injury or death.\" #Solidarity http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/anon_line\/status\/538761108904235008\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/iWmUM8kJdm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oQXIxCQAAOK14.jpg",
        "id_str" : "538761095100383232",
        "id" : 538761095100383232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oQXIxCQAAOK14.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/iWmUM8kJdm"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/anon_line\/status\/538761108904235008\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/iWmUM8kJdm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oQXIxCAAE_TBu.jpg",
        "id_str" : "538761095100366849",
        "id" : 538761095100366849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oQXIxCAAE_TBu.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iWmUM8kJdm"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/anon_line\/status\/538761108904235008\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/iWmUM8kJdm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oQXNQCYAA0epY.jpg",
        "id_str" : "538761096304156672",
        "id" : 538761096304156672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oQXNQCYAA0epY.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/iWmUM8kJdm"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/anon_line\/status\/538761108904235008\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/iWmUM8kJdm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oQXU6CIAAsuYd.jpg",
        "id_str" : "538761098359349248",
        "id" : 538761098359349248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oQXU6CIAAsuYd.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/iWmUM8kJdm"
      } ],
      "hashtags" : [ {
        "text" : "Solidarity",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538761108904235008",
    "text" : "YESTERDAY at the Ferguson Police Department before they said \"You will be subject to injury or death.\" #Solidarity http:\/\/t.co\/iWmUM8kJdm",
    "id" : 538761108904235008,
    "created_at" : "2014-11-29 18:27:12 +0000",
    "user" : {
      "name" : "Mocahontas",
      "screen_name" : "Anon_line",
      "protected" : false,
      "id_str" : "2783912326",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718586937934622720\/-Q8DiZMP_normal.jpg",
      "id" : 2783912326,
      "verified" : false
    }
  },
  "id" : 538762403308371968,
  "created_at" : "2014-11-29 18:32:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538760068083499008",
  "geo" : { },
  "id_str" : "538761943935639552",
  "in_reply_to_user_id" : 46961216,
  "text" : "@brianloveswords tl;dr  Catcher In the Rye is about desiring to do good, defining your morality by it, but then not actually doing anything.",
  "id" : 538761943935639552,
  "in_reply_to_status_id" : 538760068083499008,
  "created_at" : "2014-11-29 18:30:31 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538759392322396163",
  "geo" : { },
  "id_str" : "538760068083499008",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords me too, I made my own underwear!  I didn't read Catcher untill adulthood, and then I was like, this is some soft bullshit.",
  "id" : 538760068083499008,
  "in_reply_to_status_id" : 538759392322396163,
  "created_at" : "2014-11-29 18:23:04 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/oNzOlWYvA6",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=39mb7JCIjzU&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=39mb7J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538758514748190722",
  "text" : "\"Classification is advantage, if you ask me.\nIt afford more time out of mind.\nthat's the aisle you'll find me in.\" \nhttps:\/\/t.co\/oNzOlWYvA6",
  "id" : 538758514748190722,
  "created_at" : "2014-11-29 18:16:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538758124430434304",
  "text" : "classification is what says something is fundamentally different from another thing, and this is why it is completely wrong to use on people",
  "id" : 538758124430434304,
  "created_at" : "2014-11-29 18:15:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "S\u24D2\u24D0\u24E1 H\u24D4\u24D0\u24D3\u264A",
      "screen_name" : "head_scar",
      "indices" : [ 11, 21 ],
      "id_str" : "2169073815",
      "id" : 2169073815
    }, {
      "name" : "Israelite Wolfman!",
      "screen_name" : "IsraeliteCanaan",
      "indices" : [ 22, 38 ],
      "id_str" : "2650901760",
      "id" : 2650901760
    }, {
      "name" : "Putney Swope",
      "screen_name" : "RealPutneySwope",
      "indices" : [ 39, 55 ],
      "id_str" : "633367134",
      "id" : 633367134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538757107970232320",
  "geo" : { },
  "id_str" : "538757737480732672",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti @head_scar @IsraeliteCanaan @RealPutneySwope i dont know who is talkin to whom cuz twitter is only for yelling and jokes",
  "id" : 538757737480732672,
  "in_reply_to_status_id" : 538757107970232320,
  "created_at" : "2014-11-29 18:13:48 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538757073170092032",
  "text" : "classification is a tool of systems.  \nour system is fucked up and abusive.\nplease indicate your race, gender, sex, and religion \n#ferguson",
  "id" : 538757073170092032,
  "created_at" : "2014-11-29 18:11:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538756670999252992",
  "text" : "capitalist is the modern supremacy, under which we are all slaves.  it uses race and other classifications against us.  \n\n#ferguson",
  "id" : 538756670999252992,
  "created_at" : "2014-11-29 18:09:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538755084143067136",
  "text" : "We're all brothers and sisters.  We're practically brothers and sisters to most of the animal kingdom, by DNA.\n\n#ferguson",
  "id" : 538755084143067136,
  "created_at" : "2014-11-29 18:03:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538753101826904064",
  "text" : "watching NFL football right now is probably about the nadir of protest \n\n#ferguson",
  "id" : 538753101826904064,
  "created_at" : "2014-11-29 17:55:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "S\u24D2\u24D0\u24E1 H\u24D4\u24D0\u24D3\u264A",
      "screen_name" : "head_scar",
      "indices" : [ 11, 21 ],
      "id_str" : "2169073815",
      "id" : 2169073815
    }, {
      "name" : "Israelite Wolfman!",
      "screen_name" : "IsraeliteCanaan",
      "indices" : [ 22, 38 ],
      "id_str" : "2650901760",
      "id" : 2650901760
    }, {
      "name" : "Putney Swope",
      "screen_name" : "RealPutneySwope",
      "indices" : [ 39, 55 ],
      "id_str" : "633367134",
      "id" : 633367134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538750831169114112",
  "geo" : { },
  "id_str" : "538751175072677888",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti @head_scar @IsraeliteCanaan @RealPutneySwope can't u see my alien theory was the exact opposite of african provenance? u too high",
  "id" : 538751175072677888,
  "in_reply_to_status_id" : 538750831169114112,
  "created_at" : "2014-11-29 17:47:44 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "S\u24D2\u24D0\u24E1 H\u24D4\u24D0\u24D3\u264A",
      "screen_name" : "head_scar",
      "indices" : [ 11, 21 ],
      "id_str" : "2169073815",
      "id" : 2169073815
    }, {
      "name" : "Israelite Wolfman!",
      "screen_name" : "IsraeliteCanaan",
      "indices" : [ 22, 38 ],
      "id_str" : "2650901760",
      "id" : 2650901760
    }, {
      "name" : "Putney Swope",
      "screen_name" : "RealPutneySwope",
      "indices" : [ 39, 55 ],
      "id_str" : "633367134",
      "id" : 633367134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538750330616700928",
  "geo" : { },
  "id_str" : "538750799846076416",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti @head_scar @IsraeliteCanaan @RealPutneySwope im not the one said there were no blacks in africa! i only came up with a hypothesis",
  "id" : 538750799846076416,
  "in_reply_to_status_id" : 538750330616700928,
  "created_at" : "2014-11-29 17:46:14 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "S\u24D2\u24D0\u24E1 H\u24D4\u24D0\u24D3\u264A",
      "screen_name" : "head_scar",
      "indices" : [ 11, 21 ],
      "id_str" : "2169073815",
      "id" : 2169073815
    }, {
      "name" : "Israelite Wolfman!",
      "screen_name" : "IsraeliteCanaan",
      "indices" : [ 22, 38 ],
      "id_str" : "2650901760",
      "id" : 2650901760
    }, {
      "name" : "Putney Swope",
      "screen_name" : "RealPutneySwope",
      "indices" : [ 39, 55 ],
      "id_str" : "633367134",
      "id" : 633367134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538748920030330881",
  "geo" : { },
  "id_str" : "538749295370178560",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti @head_scar @IsraeliteCanaan @RealPutneySwope  u got a better explanation for the lack of blackness in africa?",
  "id" : 538749295370178560,
  "in_reply_to_status_id" : 538748920030330881,
  "created_at" : "2014-11-29 17:40:16 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u24D2\u24D0\u24E1 H\u24D4\u24D0\u24D3\u264A",
      "screen_name" : "head_scar",
      "indices" : [ 0, 10 ],
      "id_str" : "2169073815",
      "id" : 2169073815
    }, {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 11, 21 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Israelite Wolfman!",
      "screen_name" : "IsraeliteCanaan",
      "indices" : [ 22, 38 ],
      "id_str" : "2650901760",
      "id" : 2650901760
    }, {
      "name" : "Putney Swope",
      "screen_name" : "RealPutneySwope",
      "indices" : [ 39, 55 ],
      "id_str" : "633367134",
      "id" : 633367134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538747157344698368",
  "geo" : { },
  "id_str" : "538747832392753152",
  "in_reply_to_user_id" : 2169073815,
  "text" : "@head_scar @LouMinoti @IsraeliteCanaan @RealPutneySwope there were no blacks, translucent aliens landed on n. pole &amp; migrated toward equator",
  "id" : 538747832392753152,
  "in_reply_to_status_id" : 538747157344698368,
  "created_at" : "2014-11-29 17:34:27 +0000",
  "in_reply_to_screen_name" : "head_scar",
  "in_reply_to_user_id_str" : "2169073815",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lora Kolodny",
      "screen_name" : "lorakolodny",
      "indices" : [ 0, 12 ],
      "id_str" : "27046692",
      "id" : 27046692
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 13, 19 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538743694308810752",
  "geo" : { },
  "id_str" : "538745249934606336",
  "in_reply_to_user_id" : 27046692,
  "text" : "@lorakolodny @deray  cuz of what they will do to you in custody?  cuz you should be innocent till proven guilty?",
  "id" : 538745249934606336,
  "in_reply_to_status_id" : 538743694308810752,
  "created_at" : "2014-11-29 17:24:11 +0000",
  "in_reply_to_screen_name" : "lorakolodny",
  "in_reply_to_user_id_str" : "27046692",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538744876415086592",
  "text" : "how did apprehend become the word for capturing a suspect?  these police don't apprehend the smell of their own shit.\n\n#ferguson",
  "id" : 538744876415086592,
  "created_at" : "2014-11-29 17:22:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538744217062080513",
  "text" : "beware any who refer to theyself as enlightened",
  "id" : 538744217062080513,
  "created_at" : "2014-11-29 17:20:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Enlightment",
      "screen_name" : "BlackIntellect9",
      "indices" : [ 0, 16 ],
      "id_str" : "2370641940",
      "id" : 2370641940
    }, {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 17, 27 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538742429953060867",
  "geo" : { },
  "id_str" : "538744016092008448",
  "in_reply_to_user_id" : 2370641940,
  "text" : "@BlackIntellect9 @LouMinoti  says the \"enlightened\" one who led by calling a stranger on the internet a pedophile and white supremacist",
  "id" : 538744016092008448,
  "in_reply_to_status_id" : 538742429953060867,
  "created_at" : "2014-11-29 17:19:17 +0000",
  "in_reply_to_screen_name" : "BlackIntellect9",
  "in_reply_to_user_id_str" : "2370641940",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538741902359932928",
  "geo" : { },
  "id_str" : "538742371232780289",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  contributions will support radical propaganda, open source software, and street action",
  "id" : 538742371232780289,
  "in_reply_to_status_id" : 538741902359932928,
  "created_at" : "2014-11-29 17:12:45 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTC",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538741902359932928",
  "text" : "this my gang's address - crypto wizards and radical free agents\n\n1GKaub689wgEnw9ipcDfizShE9NpWPrhbK \n\n#BTC",
  "id" : 538741902359932928,
  "created_at" : "2014-11-29 17:10:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Enlightment",
      "screen_name" : "BlackIntellect9",
      "indices" : [ 0, 16 ],
      "id_str" : "2370641940",
      "id" : 2370641940
    }, {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 54, 64 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538738667054178304",
  "geo" : { },
  "id_str" : "538739629630189568",
  "in_reply_to_user_id" : 2370641940,
  "text" : "@BlackIntellect9 leave the fire racial instigation to @LouMinoti and focus on that enlightenment shit.  we're all niggers to the system.",
  "id" : 538739629630189568,
  "in_reply_to_status_id" : 538738667054178304,
  "created_at" : "2014-11-29 17:01:51 +0000",
  "in_reply_to_screen_name" : "BlackIntellect9",
  "in_reply_to_user_id_str" : "2370641940",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Enlightment",
      "screen_name" : "BlackIntellect9",
      "indices" : [ 0, 16 ],
      "id_str" : "2370641940",
      "id" : 2370641940
    }, {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 17, 27 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Thoros of Beer",
      "screen_name" : "MrLawson",
      "indices" : [ 28, 37 ],
      "id_str" : "18829343",
      "id" : 18829343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538736807941525504",
  "geo" : { },
  "id_str" : "538737771138277377",
  "in_reply_to_user_id" : 2370641940,
  "text" : "@BlackIntellect9 @LouMinoti @MrLawson sorry didn't mean to derail from the awesomeness of ancient north africa, before names and races",
  "id" : 538737771138277377,
  "in_reply_to_status_id" : 538736807941525504,
  "created_at" : "2014-11-29 16:54:28 +0000",
  "in_reply_to_screen_name" : "BlackIntellect9",
  "in_reply_to_user_id_str" : "2370641940",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Enlightment",
      "screen_name" : "BlackIntellect9",
      "indices" : [ 0, 16 ],
      "id_str" : "2370641940",
      "id" : 2370641940
    }, {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 17, 27 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Thoros of Beer",
      "screen_name" : "MrLawson",
      "indices" : [ 28, 37 ],
      "id_str" : "18829343",
      "id" : 18829343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538735869705093121",
  "geo" : { },
  "id_str" : "538736627016040448",
  "in_reply_to_user_id" : 2370641940,
  "text" : "@BlackIntellect9 @LouMinoti @MrLawson i agree with everything, but there is a reason why ppl brown all around the mediterranean. intersex!",
  "id" : 538736627016040448,
  "in_reply_to_status_id" : 538735869705093121,
  "created_at" : "2014-11-29 16:49:55 +0000",
  "in_reply_to_screen_name" : "BlackIntellect9",
  "in_reply_to_user_id_str" : "2370641940",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Enlightment",
      "screen_name" : "BlackIntellect9",
      "indices" : [ 0, 16 ],
      "id_str" : "2370641940",
      "id" : 2370641940
    }, {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 17, 27 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Thoros of Beer",
      "screen_name" : "MrLawson",
      "indices" : [ 28, 37 ],
      "id_str" : "18829343",
      "id" : 18829343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538734645828141056",
  "geo" : { },
  "id_str" : "538735405223669763",
  "in_reply_to_user_id" : 2370641940,
  "text" : "@BlackIntellect9 @LouMinoti @MrLawson if your mom and dad are also brother and sister, which is how those crazy fucks did it sometimes",
  "id" : 538735405223669763,
  "in_reply_to_status_id" : 538734645828141056,
  "created_at" : "2014-11-29 16:45:04 +0000",
  "in_reply_to_screen_name" : "BlackIntellect9",
  "in_reply_to_user_id_str" : "2370641940",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Black Enlightment",
      "screen_name" : "BlackIntellect9",
      "indices" : [ 0, 16 ],
      "id_str" : "2370641940",
      "id" : 2370641940
    }, {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 17, 27 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Thoros of Beer",
      "screen_name" : "MrLawson",
      "indices" : [ 28, 37 ],
      "id_str" : "18829343",
      "id" : 18829343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538732650383433728",
  "geo" : { },
  "id_str" : "538733083080814592",
  "in_reply_to_user_id" : 2370641940,
  "text" : "@BlackIntellect9 @LouMinoti @MrLawson nah they were Macedonian Royalty who had been inbreeding for generations.  she only had one set of GPs",
  "id" : 538733083080814592,
  "in_reply_to_status_id" : 538732650383433728,
  "created_at" : "2014-11-29 16:35:50 +0000",
  "in_reply_to_screen_name" : "BlackIntellect9",
  "in_reply_to_user_id_str" : "2370641940",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Thoros of Beer",
      "screen_name" : "MrLawson",
      "indices" : [ 11, 20 ],
      "id_str" : "18829343",
      "id" : 18829343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538728998881476609",
  "geo" : { },
  "id_str" : "538730196955066368",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti @MrLawson u are correct.  those thousands year old people are dead.",
  "id" : 538730196955066368,
  "in_reply_to_status_id" : 538728998881476609,
  "created_at" : "2014-11-29 16:24:22 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Thoros of Beer",
      "screen_name" : "MrLawson",
      "indices" : [ 11, 20 ],
      "id_str" : "18829343",
      "id" : 18829343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538728537562558464",
  "geo" : { },
  "id_str" : "538728958402232320",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti @MrLawson  i think u missing my point dawg, i was agreeing with the your own context of rulers calling history's shots",
  "id" : 538728958402232320,
  "in_reply_to_status_id" : 538728537562558464,
  "created_at" : "2014-11-29 16:19:27 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Thoros of Beer",
      "screen_name" : "MrLawson",
      "indices" : [ 11, 20 ],
      "id_str" : "18829343",
      "id" : 18829343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538727354517172224",
  "geo" : { },
  "id_str" : "538727981825277952",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti @MrLawson nah probably not, thats the mediterranean for you.  north africans, arabs, and europeans all mixed up around there.",
  "id" : 538727981825277952,
  "in_reply_to_status_id" : 538727354517172224,
  "created_at" : "2014-11-29 16:15:34 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "sf",
      "indices" : [ 75, 78 ]
    }, {
      "text" : "oakland",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538724104934010880",
  "text" : "san francisco finally came to the protest, with some good game.\n\n#ferguson #sf #oakland",
  "id" : 538724104934010880,
  "created_at" : "2014-11-29 16:00:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    }, {
      "name" : "Thoros of Beer",
      "screen_name" : "MrLawson",
      "indices" : [ 11, 20 ],
      "id_str" : "18829343",
      "id" : 18829343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538721333681860608",
  "geo" : { },
  "id_str" : "538723304073621504",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti @MrLawson  cuz Egypt was ruled by greeks, romans, and the west from 300 B.C. until the Spring Revolution.  Cleopatra was greek.",
  "id" : 538723304073621504,
  "in_reply_to_status_id" : 538721333681860608,
  "created_at" : "2014-11-29 15:56:59 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bipartisan Report",
      "screen_name" : "Bipartisanism",
      "indices" : [ 3, 17 ],
      "id_str" : "487600344",
      "id" : 487600344
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Bipartisanism\/status\/538554467239460864\/photo\/1",
      "indices" : [ 147, 148 ],
      "url" : "http:\/\/t.co\/PY2gV2khDh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3lUbtqCcAAsQ_x.jpg",
      "id_str" : "538554465536602112",
      "id" : 538554465536602112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3lUbtqCcAAsQ_x.jpg",
      "sizes" : [ {
        "h" : 356,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/PY2gV2khDh"
    } ],
    "hashtags" : [ {
      "text" : "Seattle",
      "indices" : [ 27, 35 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538722423601127425",
  "text" : "RT @Bipartisanism: Here in #Seattle we have legal weed &amp; our gay mayor supports &amp; marches with #Ferguson protestors. Where do you live? htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Bipartisanism\/status\/538554467239460864\/photo\/1",
        "indices" : [ 125, 147 ],
        "url" : "http:\/\/t.co\/PY2gV2khDh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3lUbtqCcAAsQ_x.jpg",
        "id_str" : "538554465536602112",
        "id" : 538554465536602112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3lUbtqCcAAsQ_x.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/PY2gV2khDh"
      } ],
      "hashtags" : [ {
        "text" : "Seattle",
        "indices" : [ 8, 16 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538554467239460864",
    "text" : "Here in #Seattle we have legal weed &amp; our gay mayor supports &amp; marches with #Ferguson protestors. Where do you live? http:\/\/t.co\/PY2gV2khDh",
    "id" : 538554467239460864,
    "created_at" : "2014-11-29 04:46:05 +0000",
    "user" : {
      "name" : "Bipartisan Report",
      "screen_name" : "Bipartisanism",
      "protected" : false,
      "id_str" : "487600344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815330356\/sampson_normal.png",
      "id" : 487600344,
      "verified" : false
    }
  },
  "id" : 538722423601127425,
  "created_at" : "2014-11-29 15:53:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kayla Reed",
      "screen_name" : "RE_invent_ED",
      "indices" : [ 3, 16 ],
      "id_str" : "210576889",
      "id" : 210576889
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538721889959833600",
  "text" : "RT @RE_invent_ED: They are so frustrated that we aren't stopping. They will be bankrupt before we go home #Ferguson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538566316613840896",
    "text" : "They are so frustrated that we aren't stopping. They will be bankrupt before we go home #Ferguson",
    "id" : 538566316613840896,
    "created_at" : "2014-11-29 05:33:10 +0000",
    "user" : {
      "name" : "Kayla Reed",
      "screen_name" : "RE_invent_ED",
      "protected" : false,
      "id_str" : "210576889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717022323354669057\/FuvDiRn2_normal.jpg",
      "id" : 210576889,
      "verified" : false
    }
  },
  "id" : 538721889959833600,
  "created_at" : "2014-11-29 15:51:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538721723689230336",
  "text" : "RT @deray: Y'all, we aren't crazy. That San Francisco video is definitely not in #Ferguson. WE WOULD ALL BE DEAD if that happened.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 70, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538587941044355075",
    "text" : "Y'all, we aren't crazy. That San Francisco video is definitely not in #Ferguson. WE WOULD ALL BE DEAD if that happened.",
    "id" : 538587941044355075,
    "created_at" : "2014-11-29 06:59:06 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 538721723689230336,
  "created_at" : "2014-11-29 15:50:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538577500297641984",
  "text" : "Protesting is a peaceful way to get arrested, and since getting arrest is inevitable in the USA, you might as well get in a word.\n\n#ferguson",
  "id" : 538577500297641984,
  "created_at" : "2014-11-29 06:17:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538575192977444866",
  "text" : "RT @deray: Hearing a cop say, \"This is my neighborhood now\" makes me understand how Darren Wilson had a law enforcement career. #Ferguson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 117, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538566599192502272",
    "text" : "Hearing a cop say, \"This is my neighborhood now\" makes me understand how Darren Wilson had a law enforcement career. #Ferguson",
    "id" : 538566599192502272,
    "created_at" : "2014-11-29 05:34:17 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 538575192977444866,
  "created_at" : "2014-11-29 06:08:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Lusk",
      "screen_name" : "th3n1nja",
      "indices" : [ 3, 12 ],
      "id_str" : "211758660",
      "id" : 211758660
    }, {
      "name" : "\u0625\u0646\u062A\u0641\u0627\u0636\u0629 \u0627\u0644\u0628\u0627\u064A \u0622\u0631\u064A\u0627",
      "screen_name" : "BayAreaIntifada",
      "indices" : [ 15, 31 ],
      "id_str" : "399867227",
      "id" : 399867227
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BayAreaIntifada\/status\/537104043089227776\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Nfbs0NNo2r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QtRyBCcAEi3QI.jpg",
      "id_str" : "537104039071084545",
      "id" : 537104039071084545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QtRyBCcAEi3QI.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Nfbs0NNo2r"
    } ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "usa",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "mikebrown",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538574357736722432",
  "text" : "RT @th3n1nja: \"@BayAreaIntifada: #oakland protesters burn #usa flag for #mikebrown #Ferguson http:\/\/t.co\/Nfbs0NNo2r\" 1\/2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0625\u0646\u062A\u0641\u0627\u0636\u0629 \u0627\u0644\u0628\u0627\u064A \u0622\u0631\u064A\u0627",
        "screen_name" : "BayAreaIntifada",
        "indices" : [ 1, 17 ],
        "id_str" : "399867227",
        "id" : 399867227
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BayAreaIntifada\/status\/537104043089227776\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Nfbs0NNo2r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QtRyBCcAEi3QI.jpg",
        "id_str" : "537104039071084545",
        "id" : 537104039071084545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QtRyBCcAEi3QI.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Nfbs0NNo2r"
      } ],
      "hashtags" : [ {
        "text" : "oakland",
        "indices" : [ 19, 27 ]
      }, {
        "text" : "usa",
        "indices" : [ 44, 48 ]
      }, {
        "text" : "mikebrown",
        "indices" : [ 58, 68 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538564631568998400",
    "text" : "\"@BayAreaIntifada: #oakland protesters burn #usa flag for #mikebrown #Ferguson http:\/\/t.co\/Nfbs0NNo2r\" 1\/2",
    "id" : 538564631568998400,
    "created_at" : "2014-11-29 05:26:28 +0000",
    "user" : {
      "name" : "Mark Lusk",
      "screen_name" : "th3n1nja",
      "protected" : false,
      "id_str" : "211758660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1188335379\/joker-poster_normal.jpg",
      "id" : 211758660,
      "verified" : false
    }
  },
  "id" : 538574357736722432,
  "created_at" : "2014-11-29 06:05:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wilken",
      "screen_name" : "kooljooez",
      "indices" : [ 0, 10 ],
      "id_str" : "38433327",
      "id" : 38433327
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unitedProtest",
      "indices" : [ 67, 81 ]
    }, {
      "text" : "ferguson",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538554034354126848",
  "geo" : { },
  "id_str" : "538554814003970048",
  "in_reply_to_user_id" : 38433327,
  "text" : "@kooljooez  that's right, everybody is getting in on the protest!  #unitedProtest #ferguson",
  "id" : 538554814003970048,
  "in_reply_to_status_id" : 538554034354126848,
  "created_at" : "2014-11-29 04:47:28 +0000",
  "in_reply_to_screen_name" : "kooljooez",
  "in_reply_to_user_id_str" : "38433327",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Elder",
      "screen_name" : "larryelder",
      "indices" : [ 0, 11 ],
      "id_str" : "195271137",
      "id" : 195271137
    }, {
      "name" : "christopher hubbard",
      "screen_name" : "SoCalCMH",
      "indices" : [ 12, 21 ],
      "id_str" : "17404680",
      "id" : 17404680
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538552870233055233",
  "geo" : { },
  "id_str" : "538553976170758145",
  "in_reply_to_user_id" : 195271137,
  "text" : "@larryelder @SoCalCMH \nwow Tom\nsuch piss\nvery analysis \n#ferguson",
  "id" : 538553976170758145,
  "in_reply_to_status_id" : 538552870233055233,
  "created_at" : "2014-11-29 04:44:08 +0000",
  "in_reply_to_screen_name" : "larryelder",
  "in_reply_to_user_id_str" : "195271137",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IAMJAYRALPH",
      "screen_name" : "iamjayralph",
      "indices" : [ 3, 15 ],
      "id_str" : "113710751",
      "id" : 113710751
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CNN",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "MikeBrown",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/oCIpfmPRxg",
      "expanded_url" : "https:\/\/vine.co\/v\/O1Izm9HaBHU",
      "display_url" : "vine.co\/v\/O1Izm9HaBHU"
    } ]
  },
  "geo" : { },
  "id_str" : "538552194858225664",
  "text" : "RT @iamjayralph: \"Sorry I just got hit with a rock Remix\"\uD83D\uDE02\uD83D\uDE02(im sorry I couldn't resist) #CNN #Ferguson #MikeBrown  https:\/\/t.co\/oCIpfmPRxg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/vine.co\" rel=\"nofollow\"\u003EVine for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CNN",
        "indices" : [ 71, 75 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 76, 85 ]
      }, {
        "text" : "MikeBrown",
        "indices" : [ 86, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/oCIpfmPRxg",
        "expanded_url" : "https:\/\/vine.co\/v\/O1Izm9HaBHU",
        "display_url" : "vine.co\/v\/O1Izm9HaBHU"
      } ]
    },
    "geo" : { },
    "id_str" : "538550475541737472",
    "text" : "\"Sorry I just got hit with a rock Remix\"\uD83D\uDE02\uD83D\uDE02(im sorry I couldn't resist) #CNN #Ferguson #MikeBrown  https:\/\/t.co\/oCIpfmPRxg",
    "id" : 538550475541737472,
    "created_at" : "2014-11-29 04:30:13 +0000",
    "user" : {
      "name" : "IAMJAYRALPH",
      "screen_name" : "iamjayralph",
      "protected" : false,
      "id_str" : "113710751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538234167788830721\/S-QpQHgZ_normal.jpeg",
      "id" : 113710751,
      "verified" : false
    }
  },
  "id" : 538552194858225664,
  "created_at" : "2014-11-29 04:37:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/v8DRgfvKHG",
      "expanded_url" : "https:\/\/vine.co\/v\/OnnmwupxmE1",
      "display_url" : "vine.co\/v\/OnnmwupxmE1"
    } ]
  },
  "geo" : { },
  "id_str" : "538551105073188864",
  "text" : "RT @Asap_Giffy: #ferguson https:\/\/t.co\/v8DRgfvKHG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ferguson",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/v8DRgfvKHG",
        "expanded_url" : "https:\/\/vine.co\/v\/OnnmwupxmE1",
        "display_url" : "vine.co\/v\/OnnmwupxmE1"
      } ]
    },
    "geo" : { },
    "id_str" : "538550564553256961",
    "text" : "#ferguson https:\/\/t.co\/v8DRgfvKHG",
    "id" : 538550564553256961,
    "created_at" : "2014-11-29 04:30:35 +0000",
    "user" : {
      "name" : "russ",
      "screen_name" : "asapGiffy",
      "protected" : false,
      "id_str" : "2301643723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723343104368058368\/GyciFynt_normal.jpg",
      "id" : 2301643723,
      "verified" : false
    }
  },
  "id" : 538551105073188864,
  "created_at" : "2014-11-29 04:32:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538550928388136960",
  "text" : "@ElmoreKara getting shot at by police",
  "id" : 538550928388136960,
  "created_at" : "2014-11-29 04:32:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538549734949265408",
  "text" : "yep, protest caroling",
  "id" : 538549734949265408,
  "created_at" : "2014-11-29 04:27:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "~AS~",
      "screen_name" : "angelsavant",
      "indices" : [ 3, 15 ],
      "id_str" : "17258834",
      "id" : 17258834
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 38, 44 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/p4DTR3stc2",
      "expanded_url" : "https:\/\/vine.co\/v\/OnnBamrtJvT",
      "display_url" : "vine.co\/v\/OnnBamrtJvT"
    } ]
  },
  "geo" : { },
  "id_str" : "538549643190484993",
  "text" : "RT @angelsavant: Brilliant tactic!!! \"@deray: We carol. The movement lives. CWE. #ferguson https:\/\/t.co\/p4DTR3stc2\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 21, 27 ],
        "id_str" : "29417304",
        "id" : 29417304
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ferguson",
        "indices" : [ 64, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/p4DTR3stc2",
        "expanded_url" : "https:\/\/vine.co\/v\/OnnBamrtJvT",
        "display_url" : "vine.co\/v\/OnnBamrtJvT"
      } ]
    },
    "geo" : { },
    "id_str" : "538549308140695552",
    "text" : "Brilliant tactic!!! \"@deray: We carol. The movement lives. CWE. #ferguson https:\/\/t.co\/p4DTR3stc2\"",
    "id" : 538549308140695552,
    "created_at" : "2014-11-29 04:25:35 +0000",
    "user" : {
      "name" : "~AS~",
      "screen_name" : "angelsavant",
      "protected" : false,
      "id_str" : "17258834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515730614364798977\/7eCoCdar_normal.jpeg",
      "id" : 17258834,
      "verified" : false
    }
  },
  "id" : 538549643190484993,
  "created_at" : "2014-11-29 04:26:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538548134423851008",
  "text" : "agaraste aire",
  "id" : 538548134423851008,
  "created_at" : "2014-11-29 04:20:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AHMAD T. CHERRY SR.",
      "screen_name" : "SHUTTLECOCK74",
      "indices" : [ 3, 17 ],
      "id_str" : "36808182",
      "id" : 36808182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/OaklandElle\/status\/538457415524438016\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/vgvrKBDtwh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3j8Km1CQAAaH1i.jpg",
      "id_str" : "538457414622658560",
      "id" : 538457414622658560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3j8Km1CQAAaH1i.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vgvrKBDtwh"
    } ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "ShutItDown",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "OAK2STL",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 62, 71 ]
    }, {
      "text" : "MikeBrown",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "BlackLivesMatter",
      "indices" : [ 83, 100 ]
    }, {
      "text" : "BARTlockdown",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538530365531381760",
  "text" : "RT @SHUTTLECOCK74: So proud of #Oakland. #ShutItDown #OAK2STL #Ferguson #MikeBrown #BlackLivesMatter #BARTlockdown http:\/\/t.co\/vgvrKBDtwh\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/OaklandElle\/status\/538457415524438016\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/vgvrKBDtwh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3j8Km1CQAAaH1i.jpg",
        "id_str" : "538457414622658560",
        "id" : 538457414622658560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3j8Km1CQAAaH1i.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vgvrKBDtwh"
      } ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "ShutItDown",
        "indices" : [ 22, 33 ]
      }, {
        "text" : "OAK2STL",
        "indices" : [ 34, 42 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 43, 52 ]
      }, {
        "text" : "MikeBrown",
        "indices" : [ 53, 63 ]
      }, {
        "text" : "BlackLivesMatter",
        "indices" : [ 64, 81 ]
      }, {
        "text" : "BARTlockdown",
        "indices" : [ 82, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538520181673566208",
    "text" : "So proud of #Oakland. #ShutItDown #OAK2STL #Ferguson #MikeBrown #BlackLivesMatter #BARTlockdown http:\/\/t.co\/vgvrKBDtwh\u201D",
    "id" : 538520181673566208,
    "created_at" : "2014-11-29 02:29:51 +0000",
    "user" : {
      "name" : "AHMAD T. CHERRY SR.",
      "screen_name" : "SHUTTLECOCK74",
      "protected" : false,
      "id_str" : "36808182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587525341\/14355_185626607557_32436082557_2813148_6653216_n_normal.jpg",
      "id" : 36808182,
      "verified" : false
    }
  },
  "id" : 538530365531381760,
  "created_at" : "2014-11-29 03:10:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/J_Sleek_21\/status\/538511606859456514\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/DNxGG6E34D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ktTJvCQAA7J15.jpg",
      "id_str" : "538511437501448192",
      "id" : 538511437501448192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ktTJvCQAA7J15.jpg",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DNxGG6E34D"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538512749068681216",
  "text" : "RT @J_Sleek_21: One thing the media won't show you about #Ferguson . Devonte Hart giving out free hugs at a rally. http:\/\/t.co\/DNxGG6E34D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/J_Sleek_21\/status\/538511606859456514\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/DNxGG6E34D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ktTJvCQAA7J15.jpg",
        "id_str" : "538511437501448192",
        "id" : 538511437501448192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ktTJvCQAA7J15.jpg",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DNxGG6E34D"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 41, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538511606859456514",
    "text" : "One thing the media won't show you about #Ferguson . Devonte Hart giving out free hugs at a rally. http:\/\/t.co\/DNxGG6E34D",
    "id" : 538511606859456514,
    "created_at" : "2014-11-29 01:55:46 +0000",
    "user" : {
      "name" : "Sleek",
      "screen_name" : "Sleek_21",
      "protected" : false,
      "id_str" : "401088758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727916882976747522\/WKrXT6xf_normal.jpg",
      "id" : 401088758,
      "verified" : false
    }
  },
  "id" : 538512749068681216,
  "created_at" : "2014-11-29 02:00:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Chris Dickinson",
      "screen_name" : "isntitvacant",
      "indices" : [ 13, 26 ],
      "id_str" : "15394440",
      "id" : 15394440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538508648147075072",
  "geo" : { },
  "id_str" : "538510525345193984",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @isntitvacant \nyeah, so node should do certs, according to the premise that node should do what can only be done poorly right?",
  "id" : 538510525345193984,
  "in_reply_to_status_id" : 538508648147075072,
  "created_at" : "2014-11-29 01:51:28 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "disasteradio",
      "screen_name" : "disasteradio",
      "indices" : [ 13, 26 ],
      "id_str" : "90604368",
      "id" : 90604368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538469904090136577",
  "geo" : { },
  "id_str" : "538509949186215936",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @disasteradio  is she vapor waving \"i'm never gonna dance again\"?",
  "id" : 538509949186215936,
  "in_reply_to_status_id" : 538469904090136577,
  "created_at" : "2014-11-29 01:49:11 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dickinson",
      "screen_name" : "isntitvacant",
      "indices" : [ 0, 13 ],
      "id_str" : "15394440",
      "id" : 15394440
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 14, 26 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538488056375181312",
  "geo" : { },
  "id_str" : "538508048981975040",
  "in_reply_to_user_id" : 15394440,
  "text" : "@isntitvacant @dominictarr  like ssl certs!",
  "id" : 538508048981975040,
  "in_reply_to_status_id" : 538488056375181312,
  "created_at" : "2014-11-29 01:41:38 +0000",
  "in_reply_to_screen_name" : "isntitvacant",
  "in_reply_to_user_id_str" : "15394440",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/lZIXJ4aaqi",
      "expanded_url" : "https:\/\/vine.co\/v\/One23XpeD6e",
      "display_url" : "vine.co\/v\/One23XpeD6e"
    } ]
  },
  "geo" : { },
  "id_str" : "538404006322655232",
  "text" : "RT @deray: Shoppers walk through the protestors. #ferguson https:\/\/t.co\/lZIXJ4aaqi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ferguson",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/lZIXJ4aaqi",
        "expanded_url" : "https:\/\/vine.co\/v\/One23XpeD6e",
        "display_url" : "vine.co\/v\/One23XpeD6e"
      } ]
    },
    "geo" : { },
    "id_str" : "538401904146255873",
    "text" : "Shoppers walk through the protestors. #ferguson https:\/\/t.co\/lZIXJ4aaqi",
    "id" : 538401904146255873,
    "created_at" : "2014-11-28 18:39:51 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 538404006322655232,
  "created_at" : "2014-11-28 18:48:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ":deactivated",
      "screen_name" : "KuKluxKlanUSA",
      "indices" : [ 3, 17 ],
      "id_str" : "463231649",
      "id" : 463231649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpKKK",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/t1lAZymDU4",
      "expanded_url" : "http:\/\/pastebin.com\/hvc3WVZd",
      "display_url" : "pastebin.com\/hvc3WVZd"
    }, {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/tSlmwmeH3T",
      "expanded_url" : "http:\/\/pastebin.com\/dpUErTV2",
      "display_url" : "pastebin.com\/dpUErTV2"
    } ]
  },
  "geo" : { },
  "id_str" : "538395212679483392",
  "text" : "RT @KuKluxKlanUSA: We'll just leave this here: http:\/\/t.co\/t1lAZymDU4 http:\/\/t.co\/tSlmwmeH3T #OpKKK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpKKK",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/t1lAZymDU4",
        "expanded_url" : "http:\/\/pastebin.com\/hvc3WVZd",
        "display_url" : "pastebin.com\/hvc3WVZd"
      }, {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/tSlmwmeH3T",
        "expanded_url" : "http:\/\/pastebin.com\/dpUErTV2",
        "display_url" : "pastebin.com\/dpUErTV2"
      } ]
    },
    "geo" : { },
    "id_str" : "537369926714269696",
    "text" : "We'll just leave this here: http:\/\/t.co\/t1lAZymDU4 http:\/\/t.co\/tSlmwmeH3T #OpKKK",
    "id" : 537369926714269696,
    "created_at" : "2014-11-25 22:19:09 +0000",
    "user" : {
      "name" : ":deactivated",
      "screen_name" : "KuKluxKlanUSA",
      "protected" : false,
      "id_str" : "463231649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542909210317836288\/IpDO3-CU_normal.jpeg",
      "id" : 463231649,
      "verified" : false
    }
  },
  "id" : 538395212679483392,
  "created_at" : "2014-11-28 18:13:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ":deactivated",
      "screen_name" : "KuKluxKlanUSA",
      "indices" : [ 3, 17 ],
      "id_str" : "463231649",
      "id" : 463231649
    }, {
      "name" : "JT",
      "screen_name" : "JohnTiessen",
      "indices" : [ 20, 32 ],
      "id_str" : "38677599",
      "id" : 38677599
    }, {
      "name" : ":deactivated",
      "screen_name" : "KuKluxKlanUSA",
      "indices" : [ 54, 68 ],
      "id_str" : "463231649",
      "id" : 463231649
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Operation_KKK\/status\/536064311836164096\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Q481mfvRnJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3B7pnoCEAENER6.jpg",
      "id_str" : "536064310598832129",
      "id" : 536064310598832129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3B7pnoCEAENER6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 519
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 519
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 519
      } ],
      "display_url" : "pic.twitter.com\/Q481mfvRnJ"
    } ],
    "hashtags" : [ {
      "text" : "operationKKK",
      "indices" : [ 34, 47 ]
    }, {
      "text" : "Lulz",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "OpKKK",
      "indices" : [ 69, 75 ]
    }, {
      "text" : "HoodsOff",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538394896533839872",
  "text" : "RT @KuKluxKlanUSA: \u201C@JohnTiessen:\n#operationKKK #Lulz @KuKluxKlanUSA #OpKKK #HoodsOff http:\/\/t.co\/Q481mfvRnJ\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JT",
        "screen_name" : "JohnTiessen",
        "indices" : [ 1, 13 ],
        "id_str" : "38677599",
        "id" : 38677599
      }, {
        "name" : ":deactivated",
        "screen_name" : "KuKluxKlanUSA",
        "indices" : [ 35, 49 ],
        "id_str" : "463231649",
        "id" : 463231649
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Operation_KKK\/status\/536064311836164096\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/Q481mfvRnJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3B7pnoCEAENER6.jpg",
        "id_str" : "536064310598832129",
        "id" : 536064310598832129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3B7pnoCEAENER6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 519
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 519
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 519
        } ],
        "display_url" : "pic.twitter.com\/Q481mfvRnJ"
      } ],
      "hashtags" : [ {
        "text" : "operationKKK",
        "indices" : [ 15, 28 ]
      }, {
        "text" : "Lulz",
        "indices" : [ 29, 34 ]
      }, {
        "text" : "OpKKK",
        "indices" : [ 50, 56 ]
      }, {
        "text" : "HoodsOff",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "536179942321438720",
    "geo" : { },
    "id_str" : "536292758148091905",
    "in_reply_to_user_id" : 38677599,
    "text" : "\u201C@JohnTiessen:\n#operationKKK #Lulz @KuKluxKlanUSA #OpKKK #HoodsOff http:\/\/t.co\/Q481mfvRnJ\u201D",
    "id" : 536292758148091905,
    "in_reply_to_status_id" : 536179942321438720,
    "created_at" : "2014-11-22 22:58:52 +0000",
    "in_reply_to_screen_name" : "JohnTiessen",
    "in_reply_to_user_id_str" : "38677599",
    "user" : {
      "name" : ":deactivated",
      "screen_name" : "KuKluxKlanUSA",
      "protected" : false,
      "id_str" : "463231649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542909210317836288\/IpDO3-CU_normal.jpeg",
      "id" : 463231649,
      "verified" : false
    }
  },
  "id" : 538394896533839872,
  "created_at" : "2014-11-28 18:12:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ":deactivated",
      "screen_name" : "KuKluxKlanUSA",
      "indices" : [ 3, 17 ],
      "id_str" : "463231649",
      "id" : 463231649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpKKK",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "HoodsOff",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538394380084981762",
  "text" : "RT @KuKluxKlanUSA: All information has been gathered. This account will be cleansed of all the racist garbage by the end of the week. #OpKK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpKKK",
        "indices" : [ 115, 121 ]
      }, {
        "text" : "HoodsOff",
        "indices" : [ 122, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538215618693316608",
    "text" : "All information has been gathered. This account will be cleansed of all the racist garbage by the end of the week. #OpKKK #HoodsOff",
    "id" : 538215618693316608,
    "created_at" : "2014-11-28 06:19:37 +0000",
    "user" : {
      "name" : ":deactivated",
      "screen_name" : "KuKluxKlanUSA",
      "protected" : false,
      "id_str" : "463231649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542909210317836288\/IpDO3-CU_normal.jpeg",
      "id" : 463231649,
      "verified" : false
    }
  },
  "id" : 538394380084981762,
  "created_at" : "2014-11-28 18:09:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "London24",
      "screen_name" : "london24",
      "indices" : [ 3, 12 ],
      "id_str" : "44364729",
      "id" : 44364729
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/london24\/status\/538020176881803265\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Ecjmfc47n8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3dugBFIIAAV_Lw.jpg",
      "id_str" : "538020176818872320",
      "id" : 538020176818872320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3dugBFIIAAV_Lw.jpg",
      "sizes" : [ {
        "h" : 490,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 490
      } ],
      "display_url" : "pic.twitter.com\/Ecjmfc47n8"
    } ],
    "hashtags" : [ {
      "text" : "OxfordStreet",
      "indices" : [ 33, 46 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/6REg0KGhhJ",
      "expanded_url" : "http:\/\/buff.ly\/11Xfsme",
      "display_url" : "buff.ly\/11Xfsme"
    } ]
  },
  "geo" : { },
  "id_str" : "538107461262004224",
  "text" : "RT @london24: 1,000 people bring #OxfordStreet to a standstil in London #Ferguson demo http:\/\/t.co\/6REg0KGhhJ http:\/\/t.co\/Ecjmfc47n8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/london24\/status\/538020176881803265\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Ecjmfc47n8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3dugBFIIAAV_Lw.jpg",
        "id_str" : "538020176818872320",
        "id" : 538020176818872320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3dugBFIIAAV_Lw.jpg",
        "sizes" : [ {
          "h" : 490,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 490
        } ],
        "display_url" : "pic.twitter.com\/Ecjmfc47n8"
      } ],
      "hashtags" : [ {
        "text" : "OxfordStreet",
        "indices" : [ 19, 32 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/6REg0KGhhJ",
        "expanded_url" : "http:\/\/buff.ly\/11Xfsme",
        "display_url" : "buff.ly\/11Xfsme"
      } ]
    },
    "geo" : { },
    "id_str" : "538020176881803265",
    "text" : "1,000 people bring #OxfordStreet to a standstil in London #Ferguson demo http:\/\/t.co\/6REg0KGhhJ http:\/\/t.co\/Ecjmfc47n8",
    "id" : 538020176881803265,
    "created_at" : "2014-11-27 17:23:00 +0000",
    "user" : {
      "name" : "London24",
      "screen_name" : "london24",
      "protected" : false,
      "id_str" : "44364729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707605309951442944\/3hwpIYdf_normal.jpg",
      "id" : 44364729,
      "verified" : true
    }
  },
  "id" : 538107461262004224,
  "created_at" : "2014-11-27 23:09:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOT stressed",
      "screen_name" : "sangfroid_san",
      "indices" : [ 3, 17 ],
      "id_str" : "18687768",
      "id" : 18687768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/9Ow5hsDPnm",
      "expanded_url" : "http:\/\/twitter.com\/landofpropagand\/status\/537993526060253184\/photo\/1",
      "display_url" : "pic.twitter.com\/9Ow5hsDPnm"
    } ]
  },
  "geo" : { },
  "id_str" : "538094830929190912",
  "text" : "RT @sangfroid_san: I'm in love with this http:\/\/t.co\/9Ow5hsDPnm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/9Ow5hsDPnm",
        "expanded_url" : "http:\/\/twitter.com\/landofpropagand\/status\/537993526060253184\/photo\/1",
        "display_url" : "pic.twitter.com\/9Ow5hsDPnm"
      } ]
    },
    "geo" : { },
    "id_str" : "537997584925982720",
    "text" : "I'm in love with this http:\/\/t.co\/9Ow5hsDPnm",
    "id" : 537997584925982720,
    "created_at" : "2014-11-27 15:53:14 +0000",
    "user" : {
      "name" : "NOT stressed",
      "screen_name" : "sangfroid_san",
      "protected" : false,
      "id_str" : "18687768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723874157742702592\/S4l4IAY__normal.jpg",
      "id" : 18687768,
      "verified" : false
    }
  },
  "id" : 538094830929190912,
  "created_at" : "2014-11-27 22:19:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/sBDY2ofHpP",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/world\/americas\/obama-the-only-people-with-the-right-to-object-to-immigration-are-native-americans-9887501.html",
      "display_url" : "independent.co.uk\/news\/world\/ame\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538067896727908352",
  "text" : "all the president need do for political expedience in the age of the internet is echo what we all know to be true.  http:\/\/t.co\/sBDY2ofHpP",
  "id" : 538067896727908352,
  "created_at" : "2014-11-27 20:32:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/IPrU7zAlNP",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/world\/americas\/president-barack-obama-lifts-threat-of-deportation-off-five-million-immigrants-9876635.html",
      "display_url" : "independent.co.uk\/news\/world\/ame\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538067860552032257",
  "text" : "did not know until now, obama issued executive order to prevent millions of deportations http:\/\/t.co\/IPrU7zAlNP",
  "id" : 538067860552032257,
  "created_at" : "2014-11-27 20:32:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shadi Rahimi",
      "screen_name" : "shadirahimi",
      "indices" : [ 3, 15 ],
      "id_str" : "16037051",
      "id" : 16037051
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/fergusonaction\/status\/538047425412624384\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/T0WMKFcRSh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3eHSCFIQAE877W.jpg",
      "id_str" : "538047424359841793",
      "id" : 538047424359841793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3eHSCFIQAE877W.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T0WMKFcRSh"
    } ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 74, 87 ]
    }, {
      "text" : "MikeBrown",
      "indices" : [ 104, 114 ]
    }, {
      "text" : "StolenLives",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538066133266358272",
  "text" : "RT @shadirahimi: Activists asking ppl to share photos of an empty seat at #Thanksgiving in solidarity w #MikeBrown et al #StolenLives http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/fergusonaction\/status\/538047425412624384\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/T0WMKFcRSh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3eHSCFIQAE877W.jpg",
        "id_str" : "538047424359841793",
        "id" : 538047424359841793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3eHSCFIQAE877W.jpg",
        "sizes" : [ {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/T0WMKFcRSh"
      } ],
      "hashtags" : [ {
        "text" : "Thanksgiving",
        "indices" : [ 57, 70 ]
      }, {
        "text" : "MikeBrown",
        "indices" : [ 87, 97 ]
      }, {
        "text" : "StolenLives",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538054624037449728",
    "text" : "Activists asking ppl to share photos of an empty seat at #Thanksgiving in solidarity w #MikeBrown et al #StolenLives http:\/\/t.co\/T0WMKFcRSh",
    "id" : 538054624037449728,
    "created_at" : "2014-11-27 19:39:53 +0000",
    "user" : {
      "name" : "Shadi Rahimi",
      "screen_name" : "shadirahimi",
      "protected" : false,
      "id_str" : "16037051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666376131734470658\/z2zILRpL_normal.jpg",
      "id" : 16037051,
      "verified" : false
    }
  },
  "id" : 538066133266358272,
  "created_at" : "2014-11-27 20:25:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 3, 10 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WalmartStrikers",
      "indices" : [ 41, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/aLOqzl28HA",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f501466c-9323-4757-a002-726ca69518f1",
      "display_url" : "amp.twimg.com\/v\/f501466c-932\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538066055965323264",
  "text" : "RT @ajplus: It's still Thanksgiving, but #WalmartStrikers have already started.\nhttps:\/\/t.co\/aLOqzl28HA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WalmartStrikers",
        "indices" : [ 29, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/aLOqzl28HA",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/f501466c-9323-4757-a002-726ca69518f1",
        "display_url" : "amp.twimg.com\/v\/f501466c-932\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "538055619018633216",
    "text" : "It's still Thanksgiving, but #WalmartStrikers have already started.\nhttps:\/\/t.co\/aLOqzl28HA",
    "id" : 538055619018633216,
    "created_at" : "2014-11-27 19:43:50 +0000",
    "user" : {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "protected" : false,
      "id_str" : "110396781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510269137071783936\/AOB0NWwG_normal.png",
      "id" : 110396781,
      "verified" : true
    }
  },
  "id" : 538066055965323264,
  "created_at" : "2014-11-27 20:25:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reptilian chat queen",
      "screen_name" : "hepkitten",
      "indices" : [ 0, 10 ],
      "id_str" : "5916482",
      "id" : 5916482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537674438763094016",
  "geo" : { },
  "id_str" : "538026249440878592",
  "in_reply_to_user_id" : 5916482,
  "text" : "@hepkitten  I saw this and asked a friend.  Friend is interested, asked me to follow up. Im at kungfoowizards@gmail.com",
  "id" : 538026249440878592,
  "in_reply_to_status_id" : 537674438763094016,
  "created_at" : "2014-11-27 17:47:08 +0000",
  "in_reply_to_screen_name" : "hepkitten",
  "in_reply_to_user_id_str" : "5916482",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/oQq84R6905",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=N1yIYHT6m1Q&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=N1yIYH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537852208076058626",
  "text" : "who profits from the drug war?  who do they profit offa?\n\nhttps:\/\/t.co\/oQq84R6905\n\n#ferguson",
  "id" : 537852208076058626,
  "created_at" : "2014-11-27 06:15:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537847700998615040",
  "text" : "RT @deray: I can't even fathom putting tents out here like Occupy did. The police here would stop us from even opening the tent box! #Fergu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 122, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537847605284175872",
    "text" : "I can't even fathom putting tents out here like Occupy did. The police here would stop us from even opening the tent box! #Ferguson",
    "id" : 537847605284175872,
    "created_at" : "2014-11-27 05:57:16 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729398399292874753\/HTjaD7fj_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 537847700998615040,
  "created_at" : "2014-11-27 05:57:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "indices" : [ 3, 11 ],
      "id_str" : "15665323",
      "id" : 15665323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537846928713998336",
  "text" : "RT @afrobot: Then  the larger problem presents itself:  What conditions make this story plausible?  The protest is of those conditions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537845271531884544",
    "text" : "Then  the larger problem presents itself:  What conditions make this story plausible?  The protest is of those conditions.",
    "id" : 537845271531884544,
    "created_at" : "2014-11-27 05:48:00 +0000",
    "user" : {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "protected" : false,
      "id_str" : "15665323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442925524835254272\/1FJx1Wzd_normal.png",
      "id" : 15665323,
      "verified" : false
    }
  },
  "id" : 537846928713998336,
  "created_at" : "2014-11-27 05:54:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537837644752101377",
  "text" : "boycott thanksgiving. toast to protests. yet it is the season to feast, to take in what has grown about you, animal, vegetable, and mineral.",
  "id" : 537837644752101377,
  "created_at" : "2014-11-27 05:17:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537836726707027968",
  "text" : "you might as well boycott thanksgiving if you are going to boycott black friday #BlackFriday",
  "id" : 537836726707027968,
  "created_at" : "2014-11-27 05:14:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537836464537894912",
  "text" : "it is too bad the internet can't attack the mainstream even better and more directly somehow, as if with tasers.",
  "id" : 537836464537894912,
  "created_at" : "2014-11-27 05:13:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537835731537100801",
  "text" : "what if the people who stand outside the stores this year all of sudden sing hymns and then leave high as fuck on enlightenment #BlackFriday",
  "id" : 537835731537100801,
  "created_at" : "2014-11-27 05:10:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joe",
      "screen_name" : "zeus654",
      "indices" : [ 3, 11 ],
      "id_str" : "448221578",
      "id" : 448221578
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 13, 26 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537832812229824512",
  "text" : "RT @zeus654: @johnnyscript Fascists rule over you no matter what!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "537798376008728577",
    "geo" : { },
    "id_str" : "537798945905573890",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript Fascists rule over you no matter what!",
    "id" : 537798945905573890,
    "in_reply_to_status_id" : 537798376008728577,
    "created_at" : "2014-11-27 02:43:55 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "joe",
      "screen_name" : "zeus654",
      "protected" : false,
      "id_str" : "448221578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619311922958233604\/Pd9a06vl_normal.jpg",
      "id" : 448221578,
      "verified" : false
    }
  },
  "id" : 537832812229824512,
  "created_at" : "2014-11-27 04:58:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537832652473397248",
  "text" : "black friday historically been a euphemism for pan-demon-ium\nthis year it will be a dysphemism for peaceful gatherings in the hood\n#ferguson",
  "id" : 537832652473397248,
  "created_at" : "2014-11-27 04:57:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joe",
      "screen_name" : "zeus654",
      "indices" : [ 135, 143 ],
      "id_str" : "448221578",
      "id" : 448221578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537797200001388546",
  "geo" : { },
  "id_str" : "537798376008728577",
  "in_reply_to_user_id" : 448221578,
  "text" : "\"I am only do my job as a patriot. My job is to sit in my lazyboy &amp; fancy myself a gun-toting hero while fascists rule over me!\" - @zeus654",
  "id" : 537798376008728577,
  "in_reply_to_status_id" : 537797200001388546,
  "created_at" : "2014-11-27 02:41:39 +0000",
  "in_reply_to_screen_name" : "zeus654",
  "in_reply_to_user_id_str" : "448221578",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537796446884749312",
  "text" : "\"I was only doing my job.  My job is to be ignorant, and fearful, and use military warzone engagement tactics.\"  - Darren Wilson \n\n#ferguson",
  "id" : 537796446884749312,
  "created_at" : "2014-11-27 02:33:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malcolm Xcellent",
      "screen_name" : "J_Nova_Kane",
      "indices" : [ 3, 15 ],
      "id_str" : "169741804",
      "id" : 169741804
    }, {
      "name" : "Urban Cusp Magazine",
      "screen_name" : "UrbanCusp",
      "indices" : [ 33, 43 ],
      "id_str" : "264222504",
      "id" : 264222504
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UrbanCusp\/status\/537721760871743489\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/ElclwRJPnx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ZfFvLCYAAQBOU.jpg",
      "id_str" : "537721757684097024",
      "id" : 537721757684097024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ZfFvLCYAAQBOU.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ElclwRJPnx"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/UrbanCusp\/status\/537721760871743489\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/ElclwRJPnx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ZfF3UCMAEwaF-.jpg",
      "id_str" : "537721759869317121",
      "id" : 537721759869317121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ZfF3UCMAEwaF-.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ElclwRJPnx"
    } ],
    "hashtags" : [ {
      "text" : "Memphis",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537795202904510465",
  "text" : "RT @J_Nova_Kane: S\/O to Memphis \"@UrbanCusp: #Memphis \"Line of people laying on the sidewalk in silent protest.\"#Ferguson http:\/\/t.co\/Elclw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Urban Cusp Magazine",
        "screen_name" : "UrbanCusp",
        "indices" : [ 16, 26 ],
        "id_str" : "264222504",
        "id" : 264222504
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UrbanCusp\/status\/537721760871743489\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ElclwRJPnx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ZfFvLCYAAQBOU.jpg",
        "id_str" : "537721757684097024",
        "id" : 537721757684097024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ZfFvLCYAAQBOU.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ElclwRJPnx"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/UrbanCusp\/status\/537721760871743489\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ElclwRJPnx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ZfF3UCMAEwaF-.jpg",
        "id_str" : "537721759869317121",
        "id" : 537721759869317121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ZfF3UCMAEwaF-.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ElclwRJPnx"
      } ],
      "hashtags" : [ {
        "text" : "Memphis",
        "indices" : [ 28, 36 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537794965699846144",
    "text" : "S\/O to Memphis \"@UrbanCusp: #Memphis \"Line of people laying on the sidewalk in silent protest.\"#Ferguson http:\/\/t.co\/ElclwRJPnx\"",
    "id" : 537794965699846144,
    "created_at" : "2014-11-27 02:28:06 +0000",
    "user" : {
      "name" : "Malcolm Xcellent",
      "screen_name" : "J_Nova_Kane",
      "protected" : false,
      "id_str" : "169741804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728335540542672898\/DeFs6jsQ_normal.jpg",
      "id" : 169741804,
      "verified" : false
    }
  },
  "id" : 537795202904510465,
  "created_at" : "2014-11-27 02:29:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 118, 127 ]
    }, {
      "text" : "Cleveland",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537788113104670720",
  "text" : "Is a police \"protecting\" anybody by firing his gun at somebody, when there is no immediate threat to any other life?\n\n#Ferguson #Cleveland",
  "id" : 537788113104670720,
  "created_at" : "2014-11-27 02:00:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537737816667459585",
  "text" : "All ppl want peace, fear violence, and deplore crime.  What makes a person think black people are different?  A dangerous lack of empathy.",
  "id" : 537737816667459585,
  "created_at" : "2014-11-26 22:41:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537726926433951744",
  "geo" : { },
  "id_str" : "537730531597635584",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti  it amazes me how many poor, uneducated ppl study \"criminal justice\".  that is total turncoat shit for poor ppl in this country.",
  "id" : 537730531597635584,
  "in_reply_to_status_id" : 537726926433951744,
  "created_at" : "2014-11-26 22:12:03 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537729570229604352",
  "text" : "its almost as if the system is asking us to bring it on\n\nmaybe the system is actually crying for help\n\n#ferguson",
  "id" : 537729570229604352,
  "created_at" : "2014-11-26 22:08:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 58, 64 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537728173853519873",
  "text" : "for real-time front-line #ferguson protest updates follow @deray \n\nthe FBI is following him right now",
  "id" : 537728173853519873,
  "created_at" : "2014-11-26 22:02:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537646395067731968",
  "text" : "not surprised to hear that boston popo (pope-hoes?) cracked on protesters\n\nboston is peopled by urban rednecks\n\n#ferguson",
  "id" : 537646395067731968,
  "created_at" : "2014-11-26 16:37:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537638329781862401",
  "text" : "can we get a fucking 2D printer in the house!",
  "id" : 537638329781862401,
  "created_at" : "2014-11-26 16:05:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 3, 13 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537611466283560960",
  "text" : "RT @LouMinoti: \"God\" is like the spokes of the wheel when it spins and the spokes disappear we are the spokes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537610498234417152",
    "text" : "\"God\" is like the spokes of the wheel when it spins and the spokes disappear we are the spokes",
    "id" : 537610498234417152,
    "created_at" : "2014-11-26 14:15:05 +0000",
    "user" : {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "protected" : false,
      "id_str" : "262151877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725638787720712192\/IT5u9RUF_normal.jpg",
      "id" : 262151877,
      "verified" : false
    }
  },
  "id" : 537611466283560960,
  "created_at" : "2014-11-26 14:18:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Coco",
      "screen_name" : "MrPooni",
      "indices" : [ 3, 11 ],
      "id_str" : "15420484",
      "id" : 15420484
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MrPooni\/status\/537543458769367040\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HDHGhl7Pz2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3W866WCIAAVWvu.jpg",
      "id_str" : "537543450820747264",
      "id" : 537543450820747264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3W866WCIAAVWvu.jpg",
      "sizes" : [ {
        "h" : 825,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 745
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 745
      } ],
      "display_url" : "pic.twitter.com\/HDHGhl7Pz2"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537610601032196097",
  "text" : "RT @MrPooni: #Ferguson prosecutors had no problem recommending charges be laid against THIS officer for slapping someone's hand: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MrPooni\/status\/537543458769367040\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/HDHGhl7Pz2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3W866WCIAAVWvu.jpg",
        "id_str" : "537543450820747264",
        "id" : 537543450820747264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3W866WCIAAVWvu.jpg",
        "sizes" : [ {
          "h" : 825,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 745
        } ],
        "display_url" : "pic.twitter.com\/HDHGhl7Pz2"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537543458769367040",
    "text" : "#Ferguson prosecutors had no problem recommending charges be laid against THIS officer for slapping someone's hand: http:\/\/t.co\/HDHGhl7Pz2",
    "id" : 537543458769367040,
    "created_at" : "2014-11-26 09:48:42 +0000",
    "user" : {
      "name" : "Glen Coco",
      "screen_name" : "MrPooni",
      "protected" : false,
      "id_str" : "15420484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563583838337507328\/RYD6sVZ3_normal.png",
      "id" : 15420484,
      "verified" : false
    }
  },
  "id" : 537610601032196097,
  "created_at" : "2014-11-26 14:15:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/s3NY39Rq2Y",
      "expanded_url" : "http:\/\/www.salon.com\/2014\/11\/25\/these_motherfers_got_me_killer_mike_delivers_a_heartbreaking_speech_about_ferguson\/?utm_source=twitter&utm_medium=socialflow",
      "display_url" : "salon.com\/2014\/11\/25\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537610445280923649",
  "text" : "killer mike on point #ferguson\n\nhttp:\/\/t.co\/s3NY39Rq2Y",
  "id" : 537610445280923649,
  "created_at" : "2014-11-26 14:14:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Ptacek",
      "screen_name" : "RussPtacek",
      "indices" : [ 3, 14 ],
      "id_str" : "196336073",
      "id" : 196336073
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RussPtacek\/status\/537492410633179136\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/y2ddICEqnW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3WOflhCcAAz0Og.jpg",
      "id_str" : "537492403838414848",
      "id" : 537492403838414848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3WOflhCcAAz0Og.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/y2ddICEqnW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537500595653853187",
  "text" : "RT @RussPtacek: National Guard unit posted outside Hooters in downtown St Louis. http:\/\/t.co\/y2ddICEqnW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RussPtacek\/status\/537492410633179136\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/y2ddICEqnW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3WOflhCcAAz0Og.jpg",
        "id_str" : "537492403838414848",
        "id" : 537492403838414848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3WOflhCcAAz0Og.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/y2ddICEqnW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537492410633179136",
    "text" : "National Guard unit posted outside Hooters in downtown St Louis. http:\/\/t.co\/y2ddICEqnW",
    "id" : 537492410633179136,
    "created_at" : "2014-11-26 06:25:51 +0000",
    "user" : {
      "name" : "Russ Ptacek",
      "screen_name" : "RussPtacek",
      "protected" : false,
      "id_str" : "196336073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727096079045414912\/6jalJG8v_normal.jpg",
      "id" : 196336073,
      "verified" : true
    }
  },
  "id" : 537500595653853187,
  "created_at" : "2014-11-26 06:58:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stank",
      "screen_name" : "Vandalyzm",
      "indices" : [ 3, 13 ],
      "id_str" : "16339169",
      "id" : 16339169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeStandTogether",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537493489441714176",
  "text" : "RT @Vandalyzm: Oakland burning shit? Good. Make sure it shines enough that Oscar Grant can see it. #WeStandTogether",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeStandTogether",
        "indices" : [ 84, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537491824265674752",
    "text" : "Oakland burning shit? Good. Make sure it shines enough that Oscar Grant can see it. #WeStandTogether",
    "id" : 537491824265674752,
    "created_at" : "2014-11-26 06:23:31 +0000",
    "user" : {
      "name" : "Tony Stank",
      "screen_name" : "Vandalyzm",
      "protected" : false,
      "id_str" : "16339169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719285011531169792\/JMmDEwlZ_normal.jpg",
      "id" : 16339169,
      "verified" : false
    }
  },
  "id" : 537493489441714176,
  "created_at" : "2014-11-26 06:30:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    }, {
      "name" : "the affable llkats",
      "screen_name" : "llkats",
      "indices" : [ 13, 20 ],
      "id_str" : "22697165",
      "id" : 22697165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/KVHmQW53TC",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=fLn6nPIb9f4",
      "display_url" : "youtube.com\/watch?v=fLn6nP\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "537469052549988352",
  "geo" : { },
  "id_str" : "537483363045494784",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha @llkats https:\/\/t.co\/KVHmQW53TC",
  "id" : 537483363045494784,
  "in_reply_to_status_id" : 537469052549988352,
  "created_at" : "2014-11-26 05:49:54 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537472645554388992",
  "geo" : { },
  "id_str" : "537482328377786369",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray stop calling them the media",
  "id" : 537482328377786369,
  "in_reply_to_status_id" : 537472645554388992,
  "created_at" : "2014-11-26 05:45:47 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammie Ablaza Wills",
      "screen_name" : "FTWSammie",
      "indices" : [ 3, 13 ],
      "id_str" : "35625256",
      "id" : 35625256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qAapxsWvRX",
      "expanded_url" : "http:\/\/instagram.com\/p\/v2ZWoBHvFc\/",
      "display_url" : "instagram.com\/p\/v2ZWoBHvFc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "537467132057903105",
  "text" : "RT @FTWSammie: We are out here for the stolen lives, taken by an oppressive and ruthless system. #Oakland #Ferguson\u2026 http:\/\/t.co\/qAapxsWvRX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/qAapxsWvRX",
        "expanded_url" : "http:\/\/instagram.com\/p\/v2ZWoBHvFc\/",
        "display_url" : "instagram.com\/p\/v2ZWoBHvFc\/"
      } ]
    },
    "geo" : { },
    "id_str" : "537466547816906752",
    "text" : "We are out here for the stolen lives, taken by an oppressive and ruthless system. #Oakland #Ferguson\u2026 http:\/\/t.co\/qAapxsWvRX",
    "id" : 537466547816906752,
    "created_at" : "2014-11-26 04:43:05 +0000",
    "user" : {
      "name" : "Sammie Ablaza Wills",
      "screen_name" : "FTWSammie",
      "protected" : false,
      "id_str" : "35625256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701317475971936256\/V3Bp3Eti_normal.jpg",
      "id" : 35625256,
      "verified" : false
    }
  },
  "id" : 537467132057903105,
  "created_at" : "2014-11-26 04:45:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Beidelman",
      "screen_name" : "maggiebeidelman",
      "indices" : [ 3, 19 ],
      "id_str" : "20946895",
      "id" : 20946895
    }, {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 74, 81 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/maggiebeidelman\/status\/537466466505744385\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/q7VuIMJ8D3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3V251GCIAAtEiJ.jpg",
      "id_str" : "537466466417647616",
      "id" : 537466466417647616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3V251GCIAAtEiJ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 551,
        "resize" : "fit",
        "w" : 734
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 551,
        "resize" : "fit",
        "w" : 734
      } ],
      "display_url" : "pic.twitter.com\/q7VuIMJ8D3"
    } ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "ferguson",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537467115175809025",
  "text" : "RT @maggiebeidelman: \"Shut it down for Michael Brown!\" #oakland #ferguson @ajplus http:\/\/t.co\/q7VuIMJ8D3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AJ+",
        "screen_name" : "ajplus",
        "indices" : [ 53, 60 ],
        "id_str" : "110396781",
        "id" : 110396781
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/maggiebeidelman\/status\/537466466505744385\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/q7VuIMJ8D3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3V251GCIAAtEiJ.jpg",
        "id_str" : "537466466417647616",
        "id" : 537466466417647616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3V251GCIAAtEiJ.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 551,
          "resize" : "fit",
          "w" : 734
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 551,
          "resize" : "fit",
          "w" : 734
        } ],
        "display_url" : "pic.twitter.com\/q7VuIMJ8D3"
      } ],
      "hashtags" : [ {
        "text" : "oakland",
        "indices" : [ 34, 42 ]
      }, {
        "text" : "ferguson",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537466466505744385",
    "text" : "\"Shut it down for Michael Brown!\" #oakland #ferguson @ajplus http:\/\/t.co\/q7VuIMJ8D3",
    "id" : 537466466505744385,
    "created_at" : "2014-11-26 04:42:45 +0000",
    "user" : {
      "name" : "Maggie Beidelman",
      "screen_name" : "maggiebeidelman",
      "protected" : false,
      "id_str" : "20946895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646461040037724160\/UeTaZlBR_normal.jpg",
      "id" : 20946895,
      "verified" : false
    }
  },
  "id" : 537467115175809025,
  "created_at" : "2014-11-26 04:45:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 3, 10 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/fHntSMc3Rw",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/7030fe07-ba94-45a5-8baa-6e927e87e029",
      "display_url" : "amp.twimg.com\/v\/7030fe07-ba9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537465466092912640",
  "text" : "RT @ajplus: \"What are you going to do? Beat me? Are you fucking kidding me sir? How dare you! How dare you!\" #Oakland #Ferguson\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fHntSMc3Rw",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/7030fe07-ba94-45a5-8baa-6e927e87e029",
        "display_url" : "amp.twimg.com\/v\/7030fe07-ba9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "537464638498033664",
    "text" : "\"What are you going to do? Beat me? Are you fucking kidding me sir? How dare you! How dare you!\" #Oakland #Ferguson\nhttps:\/\/t.co\/fHntSMc3Rw",
    "id" : 537464638498033664,
    "created_at" : "2014-11-26 04:35:30 +0000",
    "user" : {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "protected" : false,
      "id_str" : "110396781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510269137071783936\/AOB0NWwG_normal.png",
      "id" : 110396781,
      "verified" : true
    }
  },
  "id" : 537465466092912640,
  "created_at" : "2014-11-26 04:38:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Death Ship",
      "screen_name" : "Iambureaucrat",
      "indices" : [ 3, 17 ],
      "id_str" : "218756218",
      "id" : 218756218
    }, {
      "name" : "Blake",
      "screen_name" : "blambo",
      "indices" : [ 26, 33 ],
      "id_str" : "14936608",
      "id" : 14936608
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Iambureaucrat\/status\/537463162254000128\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/RTq17yURJE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Vz5JLCIAAARHt.jpg",
      "id_str" : "537463156092575744",
      "id" : 537463156092575744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Vz5JLCIAAARHt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/RTq17yURJE"
    } ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537464605417562112",
  "text" : "RT @Iambureaucrat: Repost @blambo: \n\"Cops trying to stop protesters\" near the African American Museum and Library. \n#Oakland #Ferguson http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blake",
        "screen_name" : "blambo",
        "indices" : [ 7, 14 ],
        "id_str" : "14936608",
        "id" : 14936608
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Iambureaucrat\/status\/537463162254000128\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/RTq17yURJE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Vz5JLCIAAARHt.jpg",
        "id_str" : "537463156092575744",
        "id" : 537463156092575744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Vz5JLCIAAARHt.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/RTq17yURJE"
      } ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537463162254000128",
    "text" : "Repost @blambo: \n\"Cops trying to stop protesters\" near the African American Museum and Library. \n#Oakland #Ferguson http:\/\/t.co\/RTq17yURJE",
    "id" : 537463162254000128,
    "created_at" : "2014-11-26 04:29:38 +0000",
    "user" : {
      "name" : "The Death Ship",
      "screen_name" : "Iambureaucrat",
      "protected" : false,
      "id_str" : "218756218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656322003108933632\/_ys7zIHM_normal.jpg",
      "id" : 218756218,
      "verified" : false
    }
  },
  "id" : 537464605417562112,
  "created_at" : "2014-11-26 04:35:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 121, 130 ]
    }, {
      "text" : "OAKLAND",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537460955420950528",
  "text" : "A COMMON ANTI-PROTEST TACTIC IS TO SURROUND A GROUP, AND THEN ADVANCE LIKE ROBOTS SAYING \"YOU MUST LEAVE\" BUT YOU CAN'T\n\n#FERGUSON #OAKLAND",
  "id" : 537460955420950528,
  "created_at" : "2014-11-26 04:20:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Yates",
      "screen_name" : "butteryates",
      "indices" : [ 0, 12 ],
      "id_str" : "43500462",
      "id" : 43500462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537458589816741888",
  "geo" : { },
  "id_str" : "537460528294031360",
  "in_reply_to_user_id" : 43500462,
  "text" : "@butteryates  don't let it happen, bust out and run, split up, stay moving. they want victories tonight.",
  "id" : 537460528294031360,
  "in_reply_to_status_id" : 537458589816741888,
  "created_at" : "2014-11-26 04:19:10 +0000",
  "in_reply_to_screen_name" : "butteryates",
  "in_reply_to_user_id_str" : "43500462",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Lede",
      "screen_name" : "TheDailyLede",
      "indices" : [ 3, 16 ],
      "id_str" : "2464784378",
      "id" : 2464784378
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheDailyLede\/status\/537458696880922625\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kjIhePbpDW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Vvw8gCEAE-t5t.jpg",
      "id_str" : "537458617205526529",
      "id" : 537458617205526529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Vvw8gCEAE-t5t.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/kjIhePbpDW"
    } ],
    "hashtags" : [ {
      "text" : "Calgary",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "Canada",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "MikeBrown",
      "indices" : [ 103, 113 ]
    }, {
      "text" : "BlackLivesMatter",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537459071457046528",
  "text" : "RT @TheDailyLede: A group of around 100 people in #Calgary #Canada have joined the #Ferguson bandwagon #MikeBrown #BlackLivesMatter http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheDailyLede\/status\/537458696880922625\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/kjIhePbpDW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Vvw8gCEAE-t5t.jpg",
        "id_str" : "537458617205526529",
        "id" : 537458617205526529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Vvw8gCEAE-t5t.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/kjIhePbpDW"
      } ],
      "hashtags" : [ {
        "text" : "Calgary",
        "indices" : [ 32, 40 ]
      }, {
        "text" : "Canada",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 65, 74 ]
      }, {
        "text" : "MikeBrown",
        "indices" : [ 85, 95 ]
      }, {
        "text" : "BlackLivesMatter",
        "indices" : [ 96, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537458696880922625",
    "text" : "A group of around 100 people in #Calgary #Canada have joined the #Ferguson bandwagon #MikeBrown #BlackLivesMatter http:\/\/t.co\/kjIhePbpDW",
    "id" : 537458696880922625,
    "created_at" : "2014-11-26 04:11:53 +0000",
    "user" : {
      "name" : "The Daily Lede",
      "screen_name" : "TheDailyLede",
      "protected" : false,
      "id_str" : "2464784378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483259318754504706\/x1Gx-ldz_normal.png",
      "id" : 2464784378,
      "verified" : false
    }
  },
  "id" : 537459071457046528,
  "created_at" : "2014-11-26 04:13:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Beidelman",
      "screen_name" : "maggiebeidelman",
      "indices" : [ 3, 19 ],
      "id_str" : "20946895",
      "id" : 20946895
    }, {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 89, 96 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/maggiebeidelman\/status\/537457938189672449\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/j75KNNMBVY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3VvJH_CIAA8-Ho.jpg",
      "id_str" : "537457933093576704",
      "id" : 537457933093576704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3VvJH_CIAA8-Ho.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/j75KNNMBVY"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "Oakland",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537458426448580608",
  "text" : "RT @maggiebeidelman: Hundreds of protesters marching to 24 fwy onramp #Ferguson #Oakland @ajplus http:\/\/t.co\/j75KNNMBVY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AJ+",
        "screen_name" : "ajplus",
        "indices" : [ 68, 75 ],
        "id_str" : "110396781",
        "id" : 110396781
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/maggiebeidelman\/status\/537457938189672449\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/j75KNNMBVY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3VvJH_CIAA8-Ho.jpg",
        "id_str" : "537457933093576704",
        "id" : 537457933093576704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3VvJH_CIAA8-Ho.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/j75KNNMBVY"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 49, 58 ]
      }, {
        "text" : "Oakland",
        "indices" : [ 59, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537457938189672449",
    "text" : "Hundreds of protesters marching to 24 fwy onramp #Ferguson #Oakland @ajplus http:\/\/t.co\/j75KNNMBVY",
    "id" : 537457938189672449,
    "created_at" : "2014-11-26 04:08:52 +0000",
    "user" : {
      "name" : "Maggie Beidelman",
      "screen_name" : "maggiebeidelman",
      "protected" : false,
      "id_str" : "20946895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646461040037724160\/UeTaZlBR_normal.jpg",
      "id" : 20946895,
      "verified" : false
    }
  },
  "id" : 537458426448580608,
  "created_at" : "2014-11-26 04:10:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren",
      "screen_name" : "LaurenF_Baby",
      "indices" : [ 3, 16 ],
      "id_str" : "151351503",
      "id" : 151351503
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537453705272905728",
  "text" : "RT @LaurenF_Baby: Respect to my Caucasian brothers and sisters fighting for justice #Ferguson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537452605891686402",
    "text" : "Respect to my Caucasian brothers and sisters fighting for justice #Ferguson",
    "id" : 537452605891686402,
    "created_at" : "2014-11-26 03:47:41 +0000",
    "user" : {
      "name" : "Lauren",
      "screen_name" : "LaurenF_Baby",
      "protected" : false,
      "id_str" : "151351503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683810727229001729\/npLbNDvo_normal.jpg",
      "id" : 151351503,
      "verified" : false
    }
  },
  "id" : 537453705272905728,
  "created_at" : "2014-11-26 03:52:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Egoo",
      "screen_name" : "DanEgoo",
      "indices" : [ 3, 11 ],
      "id_str" : "535125765",
      "id" : 535125765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537453670388883457",
  "text" : "RT @DanEgoo: Things happen when people come together for a common cause! #Ferguson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 60, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537452606398803968",
    "text" : "Things happen when people come together for a common cause! #Ferguson",
    "id" : 537452606398803968,
    "created_at" : "2014-11-26 03:47:41 +0000",
    "user" : {
      "name" : "Dan Egoo",
      "screen_name" : "DanEgoo",
      "protected" : false,
      "id_str" : "535125765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614274024332353536\/pCEnV8vw_normal.jpg",
      "id" : 535125765,
      "verified" : false
    }
  },
  "id" : 537453670388883457,
  "created_at" : "2014-11-26 03:51:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Yip",
      "screen_name" : "timdayipper",
      "indices" : [ 3, 15 ],
      "id_str" : "20526076",
      "id" : 20526076
    }, {
      "name" : "New York Post",
      "screen_name" : "nypost",
      "indices" : [ 54, 61 ],
      "id_str" : "17469289",
      "id" : 17469289
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OccupyHK",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/K9LDcBTIGO",
      "expanded_url" : "http:\/\/youtu.be\/4hHTNIYab5Q",
      "display_url" : "youtu.be\/4hHTNIYab5Q"
    } ]
  },
  "geo" : { },
  "id_str" : "537453123241926656",
  "text" : "RT @timdayipper: glad nothin' similar in #OccupyHK RT @nypost Car plows through protesters during #Ferguson rally in south Minneapolis http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New York Post",
        "screen_name" : "nypost",
        "indices" : [ 37, 44 ],
        "id_str" : "17469289",
        "id" : 17469289
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OccupyHK",
        "indices" : [ 24, 33 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 81, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/K9LDcBTIGO",
        "expanded_url" : "http:\/\/youtu.be\/4hHTNIYab5Q",
        "display_url" : "youtu.be\/4hHTNIYab5Q"
      } ]
    },
    "geo" : { },
    "id_str" : "537452773122375681",
    "text" : "glad nothin' similar in #OccupyHK RT @nypost Car plows through protesters during #Ferguson rally in south Minneapolis http:\/\/t.co\/K9LDcBTIGO",
    "id" : 537452773122375681,
    "created_at" : "2014-11-26 03:48:21 +0000",
    "user" : {
      "name" : "Tim Yip",
      "screen_name" : "timdayipper",
      "protected" : false,
      "id_str" : "20526076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458624000243953665\/9YzgnBjN_normal.jpeg",
      "id" : 20526076,
      "verified" : false
    }
  },
  "id" : 537453123241926656,
  "created_at" : "2014-11-26 03:49:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537451809606885376",
  "text" : "PEACE TO #FERGUSON TONIGHT\n\nLET THE POLICE-STATE HAVE THEIR EXPENSIVE PARADE",
  "id" : 537451809606885376,
  "created_at" : "2014-11-26 03:44:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Honey",
      "screen_name" : "devans00",
      "indices" : [ 3, 12 ],
      "id_str" : "14934284",
      "id" : 14934284
    }, {
      "name" : "Black Student Union",
      "screen_name" : "StanfordBSU",
      "indices" : [ 39, 51 ],
      "id_str" : "382757719",
      "id" : 382757719
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/StanfordBSU\/status\/537369847802232833\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UigOxiaauC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3UfBMKCAAAWZPg.jpg",
      "id_str" : "537369835844272128",
      "id" : 537369835844272128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3UfBMKCAAAWZPg.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UigOxiaauC"
    } ],
    "hashtags" : [ {
      "text" : "SiliconValley",
      "indices" : [ 14, 28 ]
    }, {
      "text" : "diein",
      "indices" : [ 29, 35 ]
    }, {
      "text" : "ferguson",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "paloalto",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "shutitdown",
      "indices" : [ 106, 117 ]
    }, {
      "text" : "mikebrown",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537450466540388355",
  "text" : "RT @devans00: #SiliconValley #diein RT @StanfordBSU: \"ashes, ashes, we all fall down\" #ferguson #paloalto #shutitdown #mikebrown http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Black Student Union",
        "screen_name" : "StanfordBSU",
        "indices" : [ 25, 37 ],
        "id_str" : "382757719",
        "id" : 382757719
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/StanfordBSU\/status\/537369847802232833\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/UigOxiaauC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3UfBMKCAAAWZPg.jpg",
        "id_str" : "537369835844272128",
        "id" : 537369835844272128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3UfBMKCAAAWZPg.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UigOxiaauC"
      } ],
      "hashtags" : [ {
        "text" : "SiliconValley",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "diein",
        "indices" : [ 15, 21 ]
      }, {
        "text" : "ferguson",
        "indices" : [ 72, 81 ]
      }, {
        "text" : "paloalto",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "shutitdown",
        "indices" : [ 92, 103 ]
      }, {
        "text" : "mikebrown",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537449830373531648",
    "text" : "#SiliconValley #diein RT @StanfordBSU: \"ashes, ashes, we all fall down\" #ferguson #paloalto #shutitdown #mikebrown http:\/\/t.co\/UigOxiaauC",
    "id" : 537449830373531648,
    "created_at" : "2014-11-26 03:36:39 +0000",
    "user" : {
      "name" : "Blue Honey",
      "screen_name" : "devans00",
      "protected" : false,
      "id_str" : "14934284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2892911005\/35c70a1d9eb9dafbfd28eb7b9b37594e_normal.jpeg",
      "id" : 14934284,
      "verified" : false
    }
  },
  "id" : 537450466540388355,
  "created_at" : "2014-11-26 03:39:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537449300804919297",
  "text" : "THESE PROTESTS ARE PROVING THE \"BLACK LIVES MATTER\" MANTRA\n\nTHIS IS BEAUTIFUL!\n\n#FERGUSON",
  "id" : 537449300804919297,
  "created_at" : "2014-11-26 03:34:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "oakland",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537437065286144000",
  "text" : "when police expect action, give peace\n\nhands up don't shoot\n\n#ferguson #oakland",
  "id" : 537437065286144000,
  "created_at" : "2014-11-26 02:45:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 122, 131 ]
    }, {
      "text" : "oakland",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537431539332571136",
  "text" : "possible uses for vehicles in protest\nassist people on foot\ncarry supplies\neasily block intersections\ndonate for bonfire\n\n#ferguson #oakland",
  "id" : 537431539332571136,
  "created_at" : "2014-11-26 02:23:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "oakland",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "Anonymous",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537431071025930240",
  "text" : "every protest needs an automobile brigade\n\n#ferguson #oakland #Anonymous",
  "id" : 537431071025930240,
  "created_at" : "2014-11-26 02:22:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 63, 71 ]
    }, {
      "text" : "ferguson",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537430166834647040",
  "text" : "where is the show off my whip brigade when the protest is on?\n\n#oakland #ferguson",
  "id" : 537430166834647040,
  "created_at" : "2014-11-26 02:18:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 122, 131 ]
    }, {
      "text" : "oakland",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537429130266959873",
  "text" : "nearly every american owns a Ford tank\nno reason you can't protest in your car\nvery effective that is why we stop traffic\n#ferguson #oakland",
  "id" : 537429130266959873,
  "created_at" : "2014-11-26 02:14:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 119, 128 ]
    }, {
      "text" : "oakland",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537428718784753664",
  "text" : "if you are in a car, ask somebody to nicely protest in front of you, so you have an excuse to stop and clog a roadway\n\n#ferguson #oakland",
  "id" : 537428718784753664,
  "created_at" : "2014-11-26 02:12:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537428230882340864",
  "text" : "recruit somebody with a real PoS car and burn it in the street\n\n#ferguson",
  "id" : 537428230882340864,
  "created_at" : "2014-11-26 02:10:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537427880821542912",
  "text" : "today we call for a new member of the protest:  people driving home\n\nencourage them to protest actively, with their car\n\n#ferguson",
  "id" : 537427880821542912,
  "created_at" : "2014-11-26 02:09:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fergsuon",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537427695399739393",
  "text" : "recruit people in cars to clog roadways\n\n#fergsuon",
  "id" : 537427695399739393,
  "created_at" : "2014-11-26 02:08:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537427597894770688",
  "text" : "people in cars can protest too, by stopping in the middle of the street and ceasing traffic\n\n#ferguson",
  "id" : 537427597894770688,
  "created_at" : "2014-11-26 02:08:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon James White",
      "screen_name" : "elonjames",
      "indices" : [ 3, 13 ],
      "id_str" : "1716581",
      "id" : 1716581
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537426245466599425",
  "text" : "RT @elonjames: My official rule for any news media that I do is that I will not have this conversation centered on property damage. #Fergus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 117, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537425247256211456",
    "text" : "My official rule for any news media that I do is that I will not have this conversation centered on property damage. #Ferguson",
    "id" : 537425247256211456,
    "created_at" : "2014-11-26 01:58:58 +0000",
    "user" : {
      "name" : "Elon James White",
      "screen_name" : "elonjames",
      "protected" : false,
      "id_str" : "1716581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728891037108862976\/zBW3Q2rq_normal.jpg",
      "id" : 1716581,
      "verified" : false
    }
  },
  "id" : 537426245466599425,
  "created_at" : "2014-11-26 02:02:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537425734914961409",
  "text" : "War, corruption, injustice, racism, education, health, immigration, economies.  \n\nIt's all one. \n\n#ferguson",
  "id" : 537425734914961409,
  "created_at" : "2014-11-26 02:00:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537423700211941377",
  "text" : "#ferguson\nis about Michael Brown\nis about Racism\nis about the Police State\nis about Wars\nis about all the things that piss you off about USA",
  "id" : 537423700211941377,
  "created_at" : "2014-11-26 01:52:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537417576125444097",
  "text" : "Who is the Grand Dragon of the Grand Jury?\n\n#ferguson",
  "id" : 537417576125444097,
  "created_at" : "2014-11-26 01:28:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537416952046551040",
  "text" : "Every killer cop case I think, surely they they let this one hang, if nothing else, for all the others.  Never happens.  Police gangsters.",
  "id" : 537416952046551040,
  "created_at" : "2014-11-26 01:26:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537416602057076736",
  "text" : "It shows how powerful the police are that they don't have to let one of their lowliest dogs answer to justice.\n\n#ferguson",
  "id" : 537416602057076736,
  "created_at" : "2014-11-26 01:24:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deena Pierott",
      "screen_name" : "deenapierott",
      "indices" : [ 3, 16 ],
      "id_str" : "18022517",
      "id" : 18022517
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537347034252984320",
  "text" : "RT @deenapierott: This injustice is so deep and sorrowful, and anguishing, and has been going on far too long - and permeates everything.#F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537345315368497152",
    "text" : "This injustice is so deep and sorrowful, and anguishing, and has been going on far too long - and permeates everything.#Ferguson",
    "id" : 537345315368497152,
    "created_at" : "2014-11-25 20:41:21 +0000",
    "user" : {
      "name" : "Deena Pierott",
      "screen_name" : "deenapierott",
      "protected" : false,
      "id_str" : "18022517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705135551993675776\/Q8pMruix_normal.jpg",
      "id" : 18022517,
      "verified" : false
    }
  },
  "id" : 537347034252984320,
  "created_at" : "2014-11-25 20:48:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537334232545521665",
  "text" : "racism is a perpetuated by systems + perpetrated by bad actors who will not admit to the premise, for fear of being racist by association.",
  "id" : 537334232545521665,
  "created_at" : "2014-11-25 19:57:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537330410389528576",
  "text" : "you gotta bedevil the devil",
  "id" : 537330410389528576,
  "created_at" : "2014-11-25 19:42:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537329488020115456",
  "text" : "if u agree with why protesters be protest'n\nwhere n = against injustice\nthen protester represent yr best self\nyr role keep speak'n\n#ferguson",
  "id" : 537329488020115456,
  "created_at" : "2014-11-25 19:38:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537324223392657408",
  "text" : "U NEED NOT SYMPATHISE WITH THE REASON TO ACKNOWLEDGE THE CAUSE\n\nA'BODY KNOW THE CAUSE IS POWERFUL INJUSTICE\n\nA'BODY CAN FEEL IT\n\n#FERGUSON",
  "id" : 537324223392657408,
  "created_at" : "2014-11-25 19:17:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537315586377019392",
  "text" : "my kingdom for a good camera",
  "id" : 537315586377019392,
  "created_at" : "2014-11-25 18:43:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537309421483728896",
  "text" : "#ferguson \n\nif you are at home gazing at media wondering why people break windows and start fires, u should probably stop taking those pills",
  "id" : 537309421483728896,
  "created_at" : "2014-11-25 18:18:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537308040739835904",
  "text" : "twitter broke their search with this retarded \"top news\" and \"most popular\" search results in place of real time updates.",
  "id" : 537308040739835904,
  "created_at" : "2014-11-25 18:13:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537304230025916417",
  "text" : "#ferguson\n\nthe destruction of property is not violence",
  "id" : 537304230025916417,
  "created_at" : "2014-11-25 17:58:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537285692145934336",
  "text" : "#OAKLAND #FERGUSON\n\nNO JUSTICE\n\nNO BUSINESS",
  "id" : 537285692145934336,
  "created_at" : "2014-11-25 16:44:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537157627130556418",
  "text" : "#OAKLAND #FERGUSON\n\nTHERE IS A LOT OF PRECEDENT FOR GROWTH AND CREATION, FOR CHANGE, AS A RESULT OF DESTRUCTION\n\nIT IS KIND OF UNIVERSAL",
  "id" : 537157627130556418,
  "created_at" : "2014-11-25 08:15:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twice as quit now",
      "screen_name" : "quitthebiz",
      "indices" : [ 3, 14 ],
      "id_str" : "16803112",
      "id" : 16803112
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537156361285431296",
  "text" : "RT @quitthebiz: @johnnyscript fire. In the street. Away from structures or cars. This isn't mayhem like after a sportsball championship.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "537151230854701056",
    "geo" : { },
    "id_str" : "537152361496449025",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript fire. In the street. Away from structures or cars. This isn't mayhem like after a sportsball championship.",
    "id" : 537152361496449025,
    "in_reply_to_status_id" : 537151230854701056,
    "created_at" : "2014-11-25 07:54:37 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Twice as quit now",
      "screen_name" : "quitthebiz",
      "protected" : false,
      "id_str" : "16803112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/129281264\/Photo_56_normal.jpg",
      "id" : 16803112,
      "verified" : false
    }
  },
  "id" : 537156361285431296,
  "created_at" : "2014-11-25 08:10:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537151230854701056",
  "text" : "#OAKLAND #FERGUSON\n\nAS LONG AS THERE ARE FIRES THE MAINSTREAM MEDIA WILL PAY ATTENTION",
  "id" : 537151230854701056,
  "created_at" : "2014-11-25 07:50:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537148748598493185",
  "text" : "#OAKLAND #FERGUSON\n\nALL THEY CARE ABOUT IS MONEY AND PROPERTY\n\nTHAT IS THE ONLY WAY YOU CAN HURT THEM, HERO",
  "id" : 537148748598493185,
  "created_at" : "2014-11-25 07:40:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537148017443221504",
  "text" : "#Oakland #FERGUSON\n\nTHE NEWS MEDIA REALLY LIKES THE FIRES\n\nTHE NEWS MEDIA SAYS IT WANTS MORE FIRES",
  "id" : 537148017443221504,
  "created_at" : "2014-11-25 07:37:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537136991821774849",
  "text" : "#OAKLAND #FERGUSON\n\nOAKLAND PROTESTERS NOT GETTING SHUT DOWN TONIGHT",
  "id" : 537136991821774849,
  "created_at" : "2014-11-25 06:53:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Storck",
      "screen_name" : "HazrdMC",
      "indices" : [ 3, 11 ],
      "id_str" : "1242910669",
      "id" : 1242910669
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 13, 26 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537136364689436672",
  "text" : "RT @HazrdMC: @johnnyscript I just landed in Oakland from Vegas. Shit is going down here.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "537135838803398656",
    "geo" : { },
    "id_str" : "537136170363142144",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript I just landed in Oakland from Vegas. Shit is going down here.",
    "id" : 537136170363142144,
    "in_reply_to_status_id" : 537135838803398656,
    "created_at" : "2014-11-25 06:50:17 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Tim Storck",
      "screen_name" : "HazrdMC",
      "protected" : false,
      "id_str" : "1242910669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708849693439057920\/y1_BVEXI_normal.jpg",
      "id" : 1242910669,
      "verified" : false
    }
  },
  "id" : 537136364689436672,
  "created_at" : "2014-11-25 06:51:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537135838803398656",
  "text" : "#OAKLAND #FERGUSON\n\nITS ONLY 10:47 IN OAKLAND \n\nIT LOOKS LIKE THE RAIDERS COULD RIDE THIS OUT ALL NIGHT, THE POLICE COMPLETELY OUTMATCHED",
  "id" : 537135838803398656,
  "created_at" : "2014-11-25 06:48:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BellaVOX",
      "screen_name" : "BellaEiko",
      "indices" : [ 0, 10 ],
      "id_str" : "41935041",
      "id" : 41935041
    }, {
      "name" : "Ustream",
      "screen_name" : "Ustream",
      "indices" : [ 11, 19 ],
      "id_str" : "5490392",
      "id" : 5490392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537132632778092544",
  "geo" : { },
  "id_str" : "537133333382062082",
  "in_reply_to_user_id" : 41935041,
  "text" : "@BellaEiko @Ustream  GET OUT OF YOUR CAR AND MARCH",
  "id" : 537133333382062082,
  "in_reply_to_status_id" : 537132632778092544,
  "created_at" : "2014-11-25 06:39:00 +0000",
  "in_reply_to_screen_name" : "BellaEiko",
  "in_reply_to_user_id_str" : "41935041",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537132819961507840",
  "text" : "#OAKLAND #FERGUSON\n\nPOLICE RADIO WENT SILENT",
  "id" : 537132819961507840,
  "created_at" : "2014-11-25 06:36:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/537132453177987072\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/G8TOOVASeB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3RHHnyCEAEnItR.jpg",
      "id_str" : "537132451827421185",
      "id" : 537132451827421185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3RHHnyCEAEnItR.jpg",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/G8TOOVASeB"
    } ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537132453177987072",
  "text" : "#OAKLAND PROTESTORS GONNA TAKE DOWNTOWN AND RIP THIS BADGE DOWN http:\/\/t.co\/G8TOOVASeB",
  "id" : 537132453177987072,
  "created_at" : "2014-11-25 06:35:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537131398096633857",
  "text" : "A LARGE CROWD IS HEADING DOWNTOWN TOWARD POLICE HQ\nMEANWHILE, THE POLICE ARE HELLA LOCKED UP ON THE 580 \n#OAKLAND #FERGUSON",
  "id" : 537131398096633857,
  "created_at" : "2014-11-25 06:31:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537130948404318208",
  "text" : "#OAKLAND #FERGUSON \n\nMY ADVICE ABANDON THAT FIRE ON MACARTHUR NEW 580",
  "id" : 537130948404318208,
  "created_at" : "2014-11-25 06:29:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLND",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537130637543485440",
  "text" : "#OAKLND #FERGUSON\n\nWILL THE PEOPLE RELIEVE THE OPD OF ITS GIANT BADGE TONIGHT?\n\nTRUE RAIDERS!!!",
  "id" : 537130637543485440,
  "created_at" : "2014-11-25 06:28:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537129445488750592",
  "text" : "THEY WILL PASSIVELY TRY TO CORRAL YOU WHEN THEY DON'T HAVE THE STRENGTH TO FORCE IT.  BEWARE.",
  "id" : 537129445488750592,
  "created_at" : "2014-11-25 06:23:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537129299791200256",
  "text" : "ONCE A FIRE HAS BEEN STARTED, ONLY ONE FIRE MAY OCCUPY THAT SPACE\n\nWHERE WILL THEY PUT ALL THEIR OTHER FIRES?\n\n#OAKLAND #FERGUSON",
  "id" : 537129299791200256,
  "created_at" : "2014-11-25 06:22:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLND",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537128899138686976",
  "text" : "#OAKLND #FERGUSON\nREMEMBER NOT TO GET CORRALLED OR TRAPPED IN INTERSECTIONS.  AS YOU APPROACH DOWNTOWN, RESIST URGE TO STAY IN LARGE GROUPS",
  "id" : 537128899138686976,
  "created_at" : "2014-11-25 06:21:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537127425159602176",
  "text" : "IF YOU CAN DISASSEMBLE AN UNMANNED POLICE BARRICADE, DO SO\n\n#OAKLAND #FERGUSON",
  "id" : 537127425159602176,
  "created_at" : "2014-11-25 06:15:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537126864305664000",
  "text" : "#OAKLAND #FERGUSON\n\nTHE NIGHT IS YOUNG AND THE POLICE ARE OVERWHELMED",
  "id" : 537126864305664000,
  "created_at" : "2014-11-25 06:13:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537126537103826944",
  "text" : "#OAKLAND #FERGUSON\n\nPOLICE OVERWHELMED\n\nKEEP MOVING, USE GUERILLA PROTEST TACTICS",
  "id" : 537126537103826944,
  "created_at" : "2014-11-25 06:12:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537126194060066817",
  "text" : "#OAKLAND #FERGUSON\n\nPOLICE CAN'T HANDLE IT \n\nCALL IN MORE PROTESTORS",
  "id" : 537126194060066817,
  "created_at" : "2014-11-25 06:10:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 12, 20 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537125693100810241",
  "text" : "MORE FIRE \n\n#OAKLAND #FERGUSON",
  "id" : 537125693100810241,
  "created_at" : "2014-11-25 06:08:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537125335800619012",
  "text" : "THE POLICE ADMIT THEY CAN'T STOP THE CROWD FROM HEADING NORTH ON GRAND!!!  \n\n#OAKLAND #FERGUSON",
  "id" : 537125335800619012,
  "created_at" : "2014-11-25 06:07:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537125211607293952",
  "text" : "IF U CAN GO NORTH\/EAST ON GRAND WHILE YOU CAN, CIRCLE BACK ON THE 580 SCENE\n\n#OAKLAND #FERGUSON",
  "id" : 537125211607293952,
  "created_at" : "2014-11-25 06:06:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537124755615121408",
  "text" : "DO NOT LET THEM CORRAL YOU SOUTH\/WEST ON GRAND (TOWARD DOWNTOWN)\n\n#OAKLAND #FERGUSON",
  "id" : 537124755615121408,
  "created_at" : "2014-11-25 06:04:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537124553822982145",
  "text" : "#OAKLAND #FERGUSON\n\nGO NORTH\/EAST ON GRAND UP NOW",
  "id" : 537124553822982145,
  "created_at" : "2014-11-25 06:04:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537124365364514816",
  "text" : "THEY WANT TO PUSH YOU SOUTHBOUND ON GRAND FROM VAN BUREB \n\nDO NOT GO SOUTH\/WEST ON GRAND\n\n#OAKLAND #Ferguson",
  "id" : 537124365364514816,
  "created_at" : "2014-11-25 06:03:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537123840644489216",
  "text" : "OAKLAND POLICE PRETTY STRETCHED OUT TBH",
  "id" : 537123840644489216,
  "created_at" : "2014-11-25 06:01:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537123590848528386",
  "text" : "#OAKLAND #FERGUSON\n\nTHEY WILL TRY TO FORCE YOU WEST ON GRAND\n\nTHEY DONT WANT YOU TAKING THEIR BACK ON THE HIGHWAY",
  "id" : 537123590848528386,
  "created_at" : "2014-11-25 06:00:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537122840965705728",
  "text" : "#OAKLAND #FERGUSON\n\nTHEY ARE NOT YET IN POSITION ON MACARTHUR, THAT IS YOUR ESCAPE",
  "id" : 537122840965705728,
  "created_at" : "2014-11-25 05:57:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537121184119144448",
  "text" : "#OAKLAND #FERGUSON\n\nwho has video on the 580 scene?",
  "id" : 537121184119144448,
  "created_at" : "2014-11-25 05:50:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537120578033836032",
  "text" : "#OAKLAND #FERGUSON\n\nPOLICE ARE MOVING FWD THEY THINK THEY HAVE YOU CONTAINED ON 580",
  "id" : 537120578033836032,
  "created_at" : "2014-11-25 05:48:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537120144120487936",
  "text" : "#OAKLAND #FERGUSON\n\nPOLICE COMING EAST AND WEST BOUND 580\n\nDONT GO TOWARD LAKE PARK AT WESLEY",
  "id" : 537120144120487936,
  "created_at" : "2014-11-25 05:46:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537119647187746816",
  "text" : "#OAKLAND\n\nTHEY ABOUT TO COME EASTBOUND 580 WITH VANS",
  "id" : 537119647187746816,
  "created_at" : "2014-11-25 05:44:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OAKLAND",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "FERGUSON",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537119345755705344",
  "text" : "#OAKLAND #FERGUSON\n\nTHEY SAY THEY ARE GOING TO LAKE PARK AND WESLEY FOR A MANEUVER\n\nSKRMISH LINES FORMING\n\nMOVE AROUND KEEP EM MOVING",
  "id" : 537119345755705344,
  "created_at" : "2014-11-25 05:43:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537118991643205632",
  "text" : "#oakland \n\nSKIRMISH LINES FORMING ON 580 ACTION NEAR TRAITOR JOES",
  "id" : 537118991643205632,
  "created_at" : "2014-11-25 05:42:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "ferguson",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537118861376491520",
  "text" : "#oakland #ferguson\n\nyou got the police pretty split up gg, but they are gonna crack on 580 action\n\nskirmish lines forming!!!!",
  "id" : 537118861376491520,
  "created_at" : "2014-11-25 05:41:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "ferguson",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537118064681050113",
  "text" : "#oakland #ferguson\npolice vans unit will be coming down westbond lanes\nand another east bound",
  "id" : 537118064681050113,
  "created_at" : "2014-11-25 05:38:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky K",
      "screen_name" : "_eekiv",
      "indices" : [ 3, 10 ],
      "id_str" : "357693657",
      "id" : 357693657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 12, 20 ]
    }, {
      "text" : "ferguson",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/126n9amAZw",
      "expanded_url" : "http:\/\/audio2.radioreference.com\/281582295",
      "display_url" : "audio2.radioreference.com\/281582295"
    } ]
  },
  "geo" : { },
  "id_str" : "537116399588499456",
  "text" : "RT @_eekiv: #Oakland people! Listen to the police radio here: http:\/\/t.co\/126n9amAZw #ferguson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "ferguson",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/126n9amAZw",
        "expanded_url" : "http:\/\/audio2.radioreference.com\/281582295",
        "display_url" : "audio2.radioreference.com\/281582295"
      } ]
    },
    "geo" : { },
    "id_str" : "537115241360793600",
    "text" : "#Oakland people! Listen to the police radio here: http:\/\/t.co\/126n9amAZw #ferguson",
    "id" : 537115241360793600,
    "created_at" : "2014-11-25 05:27:07 +0000",
    "user" : {
      "name" : "Vicky K",
      "screen_name" : "_eekiv",
      "protected" : false,
      "id_str" : "357693657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634438296941146112\/9xizlWtu_normal.jpg",
      "id" : 357693657,
      "verified" : false
    }
  },
  "id" : 537116399588499456,
  "created_at" : "2014-11-25 05:31:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/537111435063877632\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/27ldY5L6MB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Q0AQLCMAA6tgw.png",
      "id_str" : "537111434509824000",
      "id" : 537111434509824000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Q0AQLCMAA6tgw.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/27ldY5L6MB"
    } ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537111435063877632",
  "text" : "ABRAHAM LINCOLN SAID IF EVERY LAST DIME MADE ON THE BACKS SLAVERY IS LOST IN REDRESSING IT, SO IT SHALL BE #FERGUSON http:\/\/t.co\/27ldY5L6MB",
  "id" : 537111435063877632,
  "created_at" : "2014-11-25 05:11:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537110194694529024",
  "geo" : { },
  "id_str" : "537110450475786240",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah  guess who needs a talking-to, tonight...",
  "id" : 537110450475786240,
  "in_reply_to_status_id" : 537110194694529024,
  "created_at" : "2014-11-25 05:08:05 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537109624189485056",
  "text" : "\"Woe unto the world because of offenses; for it must needs be that offenses come, but woe to that man by whom the offense cometh.\" #ferguson",
  "id" : 537109624189485056,
  "created_at" : "2014-11-25 05:04:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537108459653591040",
  "text" : "Be peaceful and burn down every last pennies worth of their precious capital, which sucks life from communities &amp; leaves poison.\n\n#Ferguson",
  "id" : 537108459653591040,
  "created_at" : "2014-11-25 05:00:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537107028531888128",
  "text" : "there is a serious dearth of gifs about flags burning",
  "id" : 537107028531888128,
  "created_at" : "2014-11-25 04:54:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/537106799250251776\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/Ak16ZTWkSa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QvyZTCcAAb1fJ.jpg",
      "id_str" : "537106798394634240",
      "id" : 537106798394634240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QvyZTCcAAb1fJ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/Ak16ZTWkSa"
    } ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537106799250251776",
  "text" : "#ferguson http:\/\/t.co\/Ak16ZTWkSa",
  "id" : 537106799250251776,
  "created_at" : "2014-11-25 04:53:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 3, 19 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537106426603134976",
  "text" : "RT @brianloveswords: I am scared of police.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537105180446441473",
    "text" : "I am scared of police.",
    "id" : 537105180446441473,
    "created_at" : "2014-11-25 04:47:08 +0000",
    "user" : {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "protected" : false,
      "id_str" : "17177251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708196671532830721\/CzJPUvQD_normal.jpg",
      "id" : 17177251,
      "verified" : false
    }
  },
  "id" : 537106426603134976,
  "created_at" : "2014-11-25 04:52:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "indices" : [ 3, 12 ],
      "id_str" : "47862165",
      "id" : 47862165
    }, {
      "name" : "Hanni Hanson",
      "screen_name" : "hannimarie",
      "indices" : [ 99, 110 ],
      "id_str" : "125778244",
      "id" : 125778244
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/537104037855125505\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Lf5hHRn3VO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QtRlEIEAEAbj1.jpg",
      "id_str" : "537104035594375169",
      "id" : 537104035594375169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QtRlEIEAEAbj1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Lf5hHRn3VO"
    } ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537104245523107842",
  "text" : "RT @NewsRevo: Protesters in #Oakland have blocked the 580 freeway in solidarity with #Ferguson p\/v @hannimarie http:\/\/t.co\/Lf5hHRn3VO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hanni Hanson",
        "screen_name" : "hannimarie",
        "indices" : [ 85, 96 ],
        "id_str" : "125778244",
        "id" : 125778244
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/537104037855125505\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/Lf5hHRn3VO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QtRlEIEAEAbj1.jpg",
        "id_str" : "537104035594375169",
        "id" : 537104035594375169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QtRlEIEAEAbj1.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Lf5hHRn3VO"
      } ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 14, 22 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 71, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537104037855125505",
    "text" : "Protesters in #Oakland have blocked the 580 freeway in solidarity with #Ferguson p\/v @hannimarie http:\/\/t.co\/Lf5hHRn3VO",
    "id" : 537104037855125505,
    "created_at" : "2014-11-25 04:42:36 +0000",
    "user" : {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "protected" : false,
      "id_str" : "47862165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573963111272570880\/lpNfTgyM_normal.jpeg",
      "id" : 47862165,
      "verified" : false
    }
  },
  "id" : 537104245523107842,
  "created_at" : "2014-11-25 04:43:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537101413835223040",
  "text" : "if u don't think burning outsider corporate capital is fair protest of outsider capitalists' burning of human rights \n\nyou wrong\n\n#ferguson",
  "id" : 537101413835223040,
  "created_at" : "2014-11-25 04:32:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537100656058716160",
  "text" : "punks, do your punk fu #ferguson",
  "id" : 537100656058716160,
  "created_at" : "2014-11-25 04:29:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cayden",
      "screen_name" : "cayden",
      "indices" : [ 0, 7 ],
      "id_str" : "7618192",
      "id" : 7618192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537099339831586816",
  "geo" : { },
  "id_str" : "537100060610158592",
  "in_reply_to_user_id" : 7618192,
  "text" : "@cayden  SEPARATE AND DISPERSE INTO SMALLER GROUPS, MOVE FASTER THAN THE POLICE. SCATTER AND REGROUP",
  "id" : 537100060610158592,
  "in_reply_to_status_id" : 537099339831586816,
  "created_at" : "2014-11-25 04:26:47 +0000",
  "in_reply_to_screen_name" : "cayden",
  "in_reply_to_user_id_str" : "7618192",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537098852663173120",
  "text" : "free speech is powerful right now, u better use some, cuz they bought a ton of mainstream speech to use against you. #ferguson",
  "id" : 537098852663173120,
  "created_at" : "2014-11-25 04:21:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537098479315607552",
  "text" : "speech is free, use it to protest now the anti-protest tactics of paid-for propaganda  #ferguson",
  "id" : 537098479315607552,
  "created_at" : "2014-11-25 04:20:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537098236960325632",
  "text" : "the people will protest how they see fit to protest\n\nrepresent yourself in protest, or support with your free speech those who represent you",
  "id" : 537098236960325632,
  "created_at" : "2014-11-25 04:19:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537097803743236096",
  "text" : "if you don't think burning capital is a minimum viable expression for the protestation of burning human &amp; constitutional rights\n\nyou wrong",
  "id" : 537097803743236096,
  "created_at" : "2014-11-25 04:17:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537097008503193600",
  "text" : "we have reached two major milestones\n\n1.  the technical capabilities for superheroes\n2.  fascist fever\n\nits popcorn time",
  "id" : 537097008503193600,
  "created_at" : "2014-11-25 04:14:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537096065858535424",
  "text" : "reporting from fruitvale, sirens all over oakland  #ferguson",
  "id" : 537096065858535424,
  "created_at" : "2014-11-25 04:10:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537095306551103490",
  "text" : "google now gets a lot of election money too, and other government contracts.  its so fucky fuckky the whole shebangbang.",
  "id" : 537095306551103490,
  "created_at" : "2014-11-25 04:07:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537093566447636480",
  "geo" : { },
  "id_str" : "537094459360432128",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \nMSM get paid in lucrative contracts election time. That is why they are so pat with the government during conflicts #ferguson",
  "id" : 537094459360432128,
  "in_reply_to_status_id" : 537093566447636480,
  "created_at" : "2014-11-25 04:04:32 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537093566447636480",
  "text" : "The mainstream media is basically the Halliburton of propaganda. Private contractors for propaganda.  #ferguson",
  "id" : 537093566447636480,
  "created_at" : "2014-11-25 04:00:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537091745947725824",
  "geo" : { },
  "id_str" : "537092647748255744",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray That aint the media. Those are the police state's private propaganda contractors. Hella lucrative biz 4 elections. You are the media!",
  "id" : 537092647748255744,
  "in_reply_to_status_id" : 537091745947725824,
  "created_at" : "2014-11-25 03:57:20 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537090821355360256",
  "text" : "Protesters represent me.  #ferguson",
  "id" : 537090821355360256,
  "created_at" : "2014-11-25 03:50:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537089196226510849",
  "text" : "don't let police corral your protest or else they will corral you until you are surrounded and then squeeze if need to  #Ferguson",
  "id" : 537089196226510849,
  "created_at" : "2014-11-25 03:43:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Buckner",
      "screen_name" : "ethanbuckner",
      "indices" : [ 3, 16 ],
      "id_str" : "379434417",
      "id" : 379434417
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ethanbuckner\/status\/537086213660762113\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/CmkeSNsguG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QdD6kCIAAsiPS.jpg",
      "id_str" : "537086208661135360",
      "id" : 537086208661135360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QdD6kCIAAsiPS.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CmkeSNsguG"
    } ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 56, 64 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537086805921636352",
  "text" : "RT @ethanbuckner: At least 1000 marching up Broadway in #oakland. #Ferguson we got your back http:\/\/t.co\/CmkeSNsguG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ethanbuckner\/status\/537086213660762113\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/CmkeSNsguG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3QdD6kCIAAsiPS.jpg",
        "id_str" : "537086208661135360",
        "id" : 537086208661135360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3QdD6kCIAAsiPS.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CmkeSNsguG"
      } ],
      "hashtags" : [ {
        "text" : "oakland",
        "indices" : [ 38, 46 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 48, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537086213660762113",
    "text" : "At least 1000 marching up Broadway in #oakland. #Ferguson we got your back http:\/\/t.co\/CmkeSNsguG",
    "id" : 537086213660762113,
    "created_at" : "2014-11-25 03:31:46 +0000",
    "user" : {
      "name" : "Ethan Buckner",
      "screen_name" : "ethanbuckner",
      "protected" : false,
      "id_str" : "379434417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000553289427\/79089c47ec3ae780d7785bb55c912ace_normal.jpeg",
      "id" : 379434417,
      "verified" : false
    }
  },
  "id" : 537086805921636352,
  "created_at" : "2014-11-25 03:34:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537086112326369280",
  "text" : "I don't think the governments really appreciate the size of this snowball, altho they had the wherewithal to cast blame on social media LOL",
  "id" : 537086112326369280,
  "created_at" : "2014-11-25 03:31:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/nQv0zU11r6",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=D64KcZsD82E",
      "display_url" : "youtube.com\/watch?v=D64KcZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537084651160875009",
  "text" : "RT @michaelsayeth: Obama says \"There's never an excuse for violence\", as the leader of a \"monopoly of violence https:\/\/t.co\/nQv0zU11r6 #Fer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 116, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/nQv0zU11r6",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=D64KcZsD82E",
        "display_url" : "youtube.com\/watch?v=D64KcZ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "537082476460396544",
    "text" : "Obama says \"There's never an excuse for violence\", as the leader of a \"monopoly of violence https:\/\/t.co\/nQv0zU11r6 #Ferguson",
    "id" : 537082476460396544,
    "created_at" : "2014-11-25 03:16:55 +0000",
    "user" : {
      "name" : "michael",
      "screen_name" : "michaeldestroys",
      "protected" : false,
      "id_str" : "917928265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000764607767\/bd9b93c94e07a6688a37a3f319adac31_normal.png",
      "id" : 917928265,
      "verified" : false
    }
  },
  "id" : 537084651160875009,
  "created_at" : "2014-11-25 03:25:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537083433399250944",
  "text" : "move around, make the police move around, separate and reconverge, protest with guerilla tactics.\n\n#Ferguson",
  "id" : 537083433399250944,
  "created_at" : "2014-11-25 03:20:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537082626566144000",
  "text" : "bodies to ferguson!",
  "id" : 537082626566144000,
  "created_at" : "2014-11-25 03:17:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 110, 119 ]
    }, {
      "text" : "protestTactics",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537081406422130688",
  "text" : "disperse, and converge into smaller groups.  \n\nprotest from side streets, alleys, roofs.\n\nkeep moving around\n\n#ferguson #protestTactics",
  "id" : 537081406422130688,
  "created_at" : "2014-11-25 03:12:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537080923208949761",
  "text" : "always keep retreat lines open #ferguson",
  "id" : 537080923208949761,
  "created_at" : "2014-11-25 03:10:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537080212182151168",
  "text" : "i guess its gonna be time for anti-anti-protest tactics",
  "id" : 537080212182151168,
  "created_at" : "2014-11-25 03:07:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537079676565336064",
  "text" : "citizens surround police telling em to put hands up they are under arrest.  the video is by MSM, and from behind the police line.",
  "id" : 537079676565336064,
  "created_at" : "2014-11-25 03:05:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Creekmur",
      "screen_name" : "chuckcreekmur",
      "indices" : [ 3, 17 ],
      "id_str" : "12742212",
      "id" : 12742212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537078357003743233",
  "text" : "RT @chuckcreekmur: Mike Vick's dogs got more justice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537073203110481920",
    "text" : "Mike Vick's dogs got more justice.",
    "id" : 537073203110481920,
    "created_at" : "2014-11-25 02:40:04 +0000",
    "user" : {
      "name" : "Chuck Creekmur",
      "screen_name" : "chuckcreekmur",
      "protected" : false,
      "id_str" : "12742212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691503108376109056\/JEEwuzrb_normal.png",
      "id" : 12742212,
      "verified" : false
    }
  },
  "id" : 537078357003743233,
  "created_at" : "2014-11-25 03:00:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537078041202003968",
  "text" : "\"the family is going to have that loss for the rest of their lives\"",
  "id" : 537078041202003968,
  "created_at" : "2014-11-25 02:59:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537074990898614275",
  "text" : "I just don't get it\nA grand jury looked at the evidence and decided there would not be a trial\nI thought evidence was for trials?\n#ferguson",
  "id" : 537074990898614275,
  "created_at" : "2014-11-25 02:47:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537070842140561408",
  "text" : "wow they are really stirring the pot ny giving the grand jury's opinions on social media  #Ferguson",
  "id" : 537070842140561408,
  "created_at" : "2014-11-25 02:30:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537001794841243648",
  "text" : "Let us all pray this week in #Ferguson gives new meaning to Black Friday.",
  "id" : 537001794841243648,
  "created_at" : "2014-11-24 21:56:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536993988314542080",
  "geo" : { },
  "id_str" : "536994212240048128",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  and this was only to decide if the murder man would justly go to trial",
  "id" : 536994212240048128,
  "in_reply_to_status_id" : 536993988314542080,
  "created_at" : "2014-11-24 21:26:11 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536993988314542080",
  "text" : "grand jury decision 4 Michael Brown murder of Ferguson ann later.  it was delayed the weekend so they could barricade and call in defences.",
  "id" : 536993988314542080,
  "created_at" : "2014-11-24 21:25:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/Lq7cooAy0N",
      "expanded_url" : "http:\/\/www.pbfcomics.com\/96\/",
      "display_url" : "pbfcomics.com\/96\/"
    } ]
  },
  "geo" : { },
  "id_str" : "536988925152079873",
  "text" : "fuuuuuck http:\/\/t.co\/Lq7cooAy0N",
  "id" : 536988925152079873,
  "created_at" : "2014-11-24 21:05:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haskell",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536981055627350016",
  "geo" : { },
  "id_str" : "536982779779481600",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha I heard jack dorsey say original plan was to write twitter in ocaml. And I was originally gonna be a child celebrity. #haskell",
  "id" : 536982779779481600,
  "in_reply_to_status_id" : 536981055627350016,
  "created_at" : "2014-11-24 20:40:46 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536981049725550592",
  "text" : "as children we spoke in a kind of pigeon latin like this.\n\nchas ildren spe woke in uh pind of kigeon latin thike llis.\n\nmy 2nd language  &gt;_&lt;",
  "id" : 536981049725550592,
  "created_at" : "2014-11-24 20:33:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/EOLvZ2kQgW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1ytCEuuW2_A",
      "display_url" : "youtube.com\/watch?v=1ytCEu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "536822826238373889",
  "geo" : { },
  "id_str" : "536829898929602560",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack \n\nhttps:\/\/t.co\/EOLvZ2kQgW",
  "id" : 536829898929602560,
  "in_reply_to_status_id" : 536822826238373889,
  "created_at" : "2014-11-24 10:33:16 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536829270954225664",
  "text" : "tried to scratch the cursor and the mouse off the screen cuz im under attack",
  "id" : 536829270954225664,
  "created_at" : "2014-11-24 10:30:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536822779933249537",
  "text" : "more than once did I correct an algorithm only to have it lose itses charm",
  "id" : 536822779933249537,
  "created_at" : "2014-11-24 10:04:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536815312327282689",
  "geo" : { },
  "id_str" : "536821043055194112",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack \n\nTHIS AINT NO JOKE PEOPLEWARE",
  "id" : 536821043055194112,
  "in_reply_to_status_id" : 536815312327282689,
  "created_at" : "2014-11-24 09:58:04 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/zgFHzPQtb3",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Dog_Latin",
      "display_url" : "en.wikipedia.org\/wiki\/Dog_Latin"
    } ]
  },
  "geo" : { },
  "id_str" : "536796806902853633",
  "text" : "this need more examples http:\/\/t.co\/zgFHzPQtb3",
  "id" : 536796806902853633,
  "created_at" : "2014-11-24 08:21:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536665886300852225",
  "text" : "browser based god",
  "id" : 536665886300852225,
  "created_at" : "2014-11-23 23:41:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ZdIIAroXLr",
      "expanded_url" : "http:\/\/tinyletter.com\/humblemania",
      "display_url" : "tinyletter.com\/humblemania"
    } ]
  },
  "geo" : { },
  "id_str" : "536663802646122497",
  "text" : "first issuance dubbed\n\"one zero and infinite possibilities\"\nemails full o garballed txt\nyou won't believe its not bot\nhttp:\/\/t.co\/ZdIIAroXLr",
  "id" : 536663802646122497,
  "created_at" : "2014-11-23 23:33:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536643713523388416",
  "text" : "last night i fixed my favorite pants by putting my belt through inside-out, and rolling down the waste once.",
  "id" : 536643713523388416,
  "created_at" : "2014-11-23 22:13:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TinyLetter",
      "screen_name" : "tinyletter",
      "indices" : [ 129, 140 ],
      "id_str" : "205644739",
      "id" : 205644739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536612727146283009",
  "text" : "spent 2 days writing, to publish on sunday. then yr interface tricked me into tricking your system that I am abusive, wait 12hrs @tinyletter",
  "id" : 536612727146283009,
  "created_at" : "2014-11-23 20:10:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536382691998842880",
  "text" : "black people may never have had an ally as worthy as an anonymous mask",
  "id" : 536382691998842880,
  "created_at" : "2014-11-23 04:56:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Shaw",
      "screen_name" : "_alanshaw",
      "indices" : [ 0, 10 ],
      "id_str" : "35444603",
      "id" : 35444603
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 11, 20 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    }, {
      "name" : "NodeSchool",
      "screen_name" : "nodeschool",
      "indices" : [ 21, 32 ],
      "id_str" : "2194544334",
      "id" : 2194544334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535788665885458433",
  "geo" : { },
  "id_str" : "536378343965216768",
  "in_reply_to_user_id" : 35444603,
  "text" : "@_alanshaw @maxogden @nodeschool a lesson where you submit your entry to the cloud for peer style review via tumblr",
  "id" : 536378343965216768,
  "in_reply_to_status_id" : 535788665885458433,
  "created_at" : "2014-11-23 04:38:57 +0000",
  "in_reply_to_screen_name" : "_alanshaw",
  "in_reply_to_user_id_str" : "35444603",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Gfk9GgIL04",
      "expanded_url" : "http:\/\/tinyletter.com\/humblemania",
      "display_url" : "tinyletter.com\/humblemania"
    } ]
  },
  "geo" : { },
  "id_str" : "536375769086173184",
  "text" : "im warning you follower.  if you don't sign up for my newsletter, I will block you.  the deadline will be arbitrary.  http:\/\/t.co\/Gfk9GgIL04",
  "id" : 536375769086173184,
  "created_at" : "2014-11-23 04:28:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536374590419648513",
  "text" : "firefox should have gone the way of linux distros",
  "id" : 536374590419648513,
  "created_at" : "2014-11-23 04:24:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536373502656262145",
  "text" : "talking to your picture, i said \"you amuse me\"",
  "id" : 536373502656262145,
  "created_at" : "2014-11-23 04:19:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536367970918748160",
  "text" : "a good name is better\nthan silver and gold\nand no money\nno money\nno money\nno money\nno money\ncan buy a good name",
  "id" : 536367970918748160,
  "created_at" : "2014-11-23 03:57:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536366123227176961",
  "text" : "until perfect anonymity is simply achieved, i will continue obfuscating my true self, while barely masking my real identity.",
  "id" : 536366123227176961,
  "created_at" : "2014-11-23 03:50:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536352358255439872",
  "geo" : { },
  "id_str" : "536353736377913344",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove  show up and crush the scene",
  "id" : 536353736377913344,
  "in_reply_to_status_id" : 536352358255439872,
  "created_at" : "2014-11-23 03:01:10 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536244308332916737",
  "geo" : { },
  "id_str" : "536244593264574464",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nGo fast.",
  "id" : 536244593264574464,
  "in_reply_to_status_id" : 536244308332916737,
  "created_at" : "2014-11-22 19:47:28 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536244308332916737",
  "text" : "To the extent that the future defines &amp; affects the present, u actually need only travel forward fast as u wanna to change history.",
  "id" : 536244308332916737,
  "created_at" : "2014-11-22 19:46:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536242444044480512",
  "text" : "It is well n good the only thing I must do is keep my body alive &amp; happy.  Fate is exquisite with the rest.",
  "id" : 536242444044480512,
  "created_at" : "2014-11-22 19:38:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536235866738286592",
  "geo" : { },
  "id_str" : "536236445569003520",
  "in_reply_to_user_id" : 46961216,
  "text" : "@ednapiranha  which you build for, and in the process of, crafting your music \/ art",
  "id" : 536236445569003520,
  "in_reply_to_status_id" : 536235866738286592,
  "created_at" : "2014-11-22 19:15:06 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536233746379202560",
  "geo" : { },
  "id_str" : "536235866738286592",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha u also dont get web developer trophies 4 yr resume if u don't promo yr personal code projects",
  "id" : 536235866738286592,
  "in_reply_to_status_id" : 536233746379202560,
  "created_at" : "2014-11-22 19:12:48 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536234820754350080",
  "text" : "A: HEY SNAP OUT OF IT!!\n\nB: HUH, HUH WHAT?\n\nA: YOU WERE AMERICAN DREAMING",
  "id" : 536234820754350080,
  "created_at" : "2014-11-22 19:08:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/536016996404441088\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/g49nNbnRsL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3BQnhXCEAIA3lG.jpg",
      "id_str" : "536016995557183490",
      "id" : 536016995557183490,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3BQnhXCEAIA3lG.jpg",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g49nNbnRsL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536016047954866177",
  "geo" : { },
  "id_str" : "536016996404441088",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah http:\/\/t.co\/g49nNbnRsL",
  "id" : 536016996404441088,
  "in_reply_to_status_id" : 536016047954866177,
  "created_at" : "2014-11-22 04:43:05 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536014109830295552",
  "text" : "im doing the bring home some beer or whiskey rain dance",
  "id" : 536014109830295552,
  "created_at" : "2014-11-22 04:31:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/ZdIIAroXLr",
      "expanded_url" : "http:\/\/tinyletter.com\/humblemania",
      "display_url" : "tinyletter.com\/humblemania"
    } ]
  },
  "geo" : { },
  "id_str" : "535875493170774016",
  "text" : "I shall now delectify myself in writing at gross length the opening salvo for HUMBLEMANIA\n\nhttp:\/\/t.co\/ZdIIAroXLr",
  "id" : 535875493170774016,
  "created_at" : "2014-11-21 19:20:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535860311728095232",
  "text" : "sincerity thru silliness",
  "id" : 535860311728095232,
  "created_at" : "2014-11-21 18:20:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 98, 111 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/7dYJ4uCzwE",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/psych-io",
      "display_url" : "soundcloud.com\/johnnyscript\/p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535662726446460928",
  "geo" : { },
  "id_str" : "535666490721071104",
  "in_reply_to_user_id" : 46961216,
  "text" : "me and said man here in one such impromtu, him on guitar make no mistake https:\/\/t.co\/7dYJ4uCzwE\n\n@johnnyscript making mistakes on drums ;^D",
  "id" : 535666490721071104,
  "in_reply_to_status_id" : 535662726446460928,
  "created_at" : "2014-11-21 05:30:18 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535666178719375361",
  "text" : "oh no soundcloud",
  "id" : 535666178719375361,
  "created_at" : "2014-11-21 05:29:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535662726446460928",
  "text" : "my man here and amazing guitarist is complimented me about my first guitar recording of my first guitar recording says this hypnotizing flow",
  "id" : 535662726446460928,
  "created_at" : "2014-11-21 05:15:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535661459116535808",
  "text" : "what would  \"capitalist dunce cap\" look like iyo?",
  "id" : 535661459116535808,
  "created_at" : "2014-11-21 05:10:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535658702808682496",
  "text" : "btw which foresee months and weeks go bye bye",
  "id" : 535658702808682496,
  "created_at" : "2014-11-21 04:59:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535658531123245056",
  "text" : "our neighbors love our music, we play loud into the night any day of the current calendar configuration",
  "id" : 535658531123245056,
  "created_at" : "2014-11-21 04:58:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535657306797510656",
  "text" : "I have mastered the redwood astrocoustic style recording technique",
  "id" : 535657306797510656,
  "created_at" : "2014-11-21 04:53:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535657115134599168",
  "text" : "I use the Mono All One Recording Technique",
  "id" : 535657115134599168,
  "created_at" : "2014-11-21 04:53:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535656595074469888",
  "text" : "I'm distilling hundreds of folkhouse music recordings of many brilliant players recorded in the red redwood room.  There will be website.",
  "id" : 535656595074469888,
  "created_at" : "2014-11-21 04:50:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535654421707755520",
  "text" : "it's okay to be a champion in your own mind only, if you practice like a champion",
  "id" : 535654421707755520,
  "created_at" : "2014-11-21 04:42:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Om2JWwIe1M",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=3zTDtSq1RNU",
      "display_url" : "youtube.com\/watch?v=3zTDtS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535273941590609922",
  "text" : "Only Jonathan Richman tells the story of Abdul and Cleopatra\n\nhttp:\/\/t.co\/Om2JWwIe1M",
  "id" : 535273941590609922,
  "created_at" : "2014-11-20 03:30:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/535264094782496769\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/JiT1TP5HLY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B22j2wwIQAISvOp.png",
      "id_str" : "535264091921989634",
      "id" : 535264091921989634,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B22j2wwIQAISvOp.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JiT1TP5HLY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535264094782496769",
  "text" : "Barbie's Sister What's Her Name? and Barbie's Sister's What's Her Name?'s Intellectual Awakening http:\/\/t.co\/JiT1TP5HLY",
  "id" : 535264094782496769,
  "created_at" : "2014-11-20 02:51:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/535261375241920516\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ygzDb41oKj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B22hYYWIEAIdomc.png",
      "id_str" : "535261370951143426",
      "id" : 535261370951143426,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B22hYYWIEAIdomc.png",
      "sizes" : [ {
        "h" : 329,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/ygzDb41oKj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535261375241920516",
  "text" : "Barbie, Against All Odds http:\/\/t.co\/ygzDb41oKj",
  "id" : 535261375241920516,
  "created_at" : "2014-11-20 02:40:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535261030948302848",
  "text" : "wow, the barbie thing went so viral they just spit out the png you make now.  well done!",
  "id" : 535261030948302848,
  "created_at" : "2014-11-20 02:39:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/JjPpoh5Hbs",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/535177850882883584",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535257202089410560",
  "text" : "this tweet (not 'this' tweet but the one following the next right paren +' broke my RT record ') broke my RT record https:\/\/t.co\/JjPpoh5Hbs",
  "id" : 535257202089410560,
  "created_at" : "2014-11-20 02:23:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535233734224916480",
  "geo" : { },
  "id_str" : "535233973610643457",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords  do you know somebody who tattoos racoons?",
  "id" : 535233973610643457,
  "in_reply_to_status_id" : 535233734224916480,
  "created_at" : "2014-11-20 00:51:38 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535233797873496064",
  "text" : "facebook ewesers",
  "id" : 535233797873496064,
  "created_at" : "2014-11-20 00:50:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/11RBCMxN11",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/29477",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/29477"
    } ]
  },
  "geo" : { },
  "id_str" : "535216221751619584",
  "text" : "lol the barbie thing got hacked\n\nhttps:\/\/t.co\/11RBCMxN11",
  "id" : 535216221751619584,
  "created_at" : "2014-11-19 23:41:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535213337421029377",
  "text" : "So far today I ran some miles in the rain and wrote Barbie fan fiction.",
  "id" : 535213337421029377,
  "created_at" : "2014-11-19 23:29:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/535181894728839168\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/wIECJ8wqY9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B21ZGLCIMAILPej.png",
      "id_str" : "535181893302759426",
      "id" : 535181893302759426,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21ZGLCIMAILPej.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wIECJ8wqY9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535181894728839168",
  "text" : "when you code so hard... http:\/\/t.co\/wIECJ8wqY9",
  "id" : 535181894728839168,
  "created_at" : "2014-11-19 21:24:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/535181764554391554\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/f0q1w77KK8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B21Y-mxIcAAdSJq.png",
      "id_str" : "535181763308711936",
      "id" : 535181763308711936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21Y-mxIcAAdSJq.png",
      "sizes" : [ {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/f0q1w77KK8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535181764554391554",
  "text" : "Barbie's Little Bot http:\/\/t.co\/f0q1w77KK8",
  "id" : 535181764554391554,
  "created_at" : "2014-11-19 21:24:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/535181567820595200\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/O7S5ZQqX37",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B21YzJ6IQAAocpE.png",
      "id_str" : "535181566583259136",
      "id" : 535181566583259136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21YzJ6IQAAocpE.png",
      "sizes" : [ {
        "h" : 363,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/O7S5ZQqX37"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535181567820595200",
  "text" : "Encryption Barbie vs The NSA http:\/\/t.co\/O7S5ZQqX37",
  "id" : 535181567820595200,
  "created_at" : "2014-11-19 21:23:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/535180920849199104\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/LxHvlRMR2q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B21YNgAIIAEgQmx.png",
      "id_str" : "535180919678967809",
      "id" : 535180919678967809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21YNgAIIAEgQmx.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LxHvlRMR2q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535180920849199104",
  "text" : "Barbie on frameworks and code styles. http:\/\/t.co\/LxHvlRMR2q",
  "id" : 535180920849199104,
  "created_at" : "2014-11-19 21:20:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/535180185919041538\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/dEk4iewQVL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B21XitXIEAEYxbo.png",
      "id_str" : "535180184530718721",
      "id" : 535180184530718721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21XitXIEAEYxbo.png",
      "sizes" : [ {
        "h" : 549,
        "resize" : "fit",
        "w" : 557
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 549,
        "resize" : "fit",
        "w" : 557
      }, {
        "h" : 549,
        "resize" : "fit",
        "w" : 557
      } ],
      "display_url" : "pic.twitter.com\/dEk4iewQVL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535180185919041538",
  "text" : "ultimate control http:\/\/t.co\/dEk4iewQVL",
  "id" : 535180185919041538,
  "created_at" : "2014-11-19 21:17:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/535179792107466752\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/KlYa6SPkyQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B21XLpNIIAAGl96.png",
      "id_str" : "535179788278046720",
      "id" : 535179788278046720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21XLpNIIAAGl96.png",
      "sizes" : [ {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KlYa6SPkyQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535179792107466752",
  "text" : "programming can be very difficult... http:\/\/t.co\/KlYa6SPkyQ",
  "id" : 535179792107466752,
  "created_at" : "2014-11-19 21:16:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/dKMmEmbLiM",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/1773",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/1773"
    } ]
  },
  "geo" : { },
  "id_str" : "535177850882883584",
  "text" : "Barbie is shown here live coding her app\n\nhttps:\/\/t.co\/dKMmEmbLiM",
  "id" : 535177850882883584,
  "created_at" : "2014-11-19 21:08:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/kCcWutt5XY",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/1700",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/1700"
    } ]
  },
  "geo" : { },
  "id_str" : "535174785601642496",
  "text" : "programming is like ice cream\n\nhttps:\/\/t.co\/kCcWutt5XY",
  "id" : 535174785601642496,
  "created_at" : "2014-11-19 20:56:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/eniobPTXUK",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/1652",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/1652"
    } ]
  },
  "geo" : { },
  "id_str" : "535173078129840129",
  "text" : "it doubles every time I add 1\n\nhttps:\/\/t.co\/eniobPTXUK",
  "id" : 535173078129840129,
  "created_at" : "2014-11-19 20:49:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535172852262404096",
  "text" : "this barbie thing is totally my format",
  "id" : 535172852262404096,
  "created_at" : "2014-11-19 20:48:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/RSxJDN3iQ3",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/666",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/666"
    } ]
  },
  "geo" : { },
  "id_str" : "535171232443162626",
  "text" : "back-to-the-drawing-board-barbie  \n\nhttps:\/\/t.co\/RSxJDN3iQ3",
  "id" : 535171232443162626,
  "created_at" : "2014-11-19 20:42:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/RSxJDN3iQ3",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/666",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/666"
    } ]
  },
  "geo" : { },
  "id_str" : "535160732011470848",
  "text" : "don't be afraid https:\/\/t.co\/RSxJDN3iQ3",
  "id" : 535160732011470848,
  "created_at" : "2014-11-19 20:00:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535149736995876864",
  "text" : "\uD835\uDD36\uD835\uDD2C \uD835\uDD31\uD835\uDD25\uD835\uDD1E\uD835\uDD31 \uD835\uDD26\uD835\uDD30 \uD835\uDD25\uD835\uDD22\uD835\uDD35\uD835\uDD1E\uD835\uDD2E\uD835\uDD32\uD835\uDD22\uD835\uDD30\uD835\uDD31\uD835\uDD26\uD835\uDD2C\uD835\uDD2B\uD835\uDD1E\uD835\uDD1F\uD835\uDD29\uD835\uDD22!",
  "id" : 535149736995876864,
  "created_at" : "2014-11-19 19:16:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535149387404816385",
  "text" : "\uD835\uDD1A\uD835\uDD08 \uD835\uDD0A\uD835\uDD12\uD835\uDD17 \uD835\uDD73\uD835\uDD08\uD835\uDD1B\uD835\uDD04\uD835\uDD14\uD835\uDD18\uD835\uDD08\uD835\uDD16\uD835\uDD17\uD835\uDD74\uD835\uDD12\uD835\uDD11\uD835\uDD16 4 \uD835\uDD1C\uD835\uDD12\uD835\uDD18",
  "id" : 535149387404816385,
  "created_at" : "2014-11-19 19:15:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Dn8QofHCHD",
      "expanded_url" : "http:\/\/www.subrosaproject.org\/",
      "display_url" : "subrosaproject.org"
    } ]
  },
  "geo" : { },
  "id_str" : "535148577165938688",
  "text" : "This community anarchy space in Santa Cruz is good  http:\/\/t.co\/Dn8QofHCHD",
  "id" : 535148577165938688,
  "created_at" : "2014-11-19 19:12:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535146967937347585",
  "text" : "\uD835\uDD1E\uD835\uDD29\uD835\uDD29 \uD835\uDD2C\uD835\uDD23 \uD835\uDD2A\uD835\uDD36 \uD835\uDD20\uD835\uDD29\uD835\uDD1E\uD835\uDD26\uD835\uDD2A\uD835\uDD30 \uD835\uDD25\uD835\uDD22\uD835\uDD2F\uD835\uDD22 \uD835\uDD30\uD835\uDD25\uD835\uDD1E\uD835\uDD29\uD835\uDD29 \uD835\uDD24\uD835\uDD2C \uD835\uDD32\uD835\uDD2B\uD835\uDD2E\uD835\uDD32\uD835\uDD22\uD835\uDD30\uD835\uDD31\uD835\uDD26\uD835\uDD2C\uD835\uDD2B\uD835\uDD22\uD835\uDD21!",
  "id" : 535146967937347585,
  "created_at" : "2014-11-19 19:05:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535141279957778432",
  "text" : "All of my claims here shall go unquestioned.",
  "id" : 535141279957778432,
  "created_at" : "2014-11-19 18:43:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535137704628203521",
  "text" : "This is where I go to bitch about the IRL",
  "id" : 535137704628203521,
  "created_at" : "2014-11-19 18:29:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535137372762292224",
  "text" : "Try responding with questions that are based on your curiosity, not your doubts.",
  "id" : 535137372762292224,
  "created_at" : "2014-11-19 18:27:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535135932916441088",
  "geo" : { },
  "id_str" : "535136496286973952",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nI'll tell you why.  Cuz our culture has bred humans who think they know everything best.  That is patriarchy.",
  "id" : 535136496286973952,
  "in_reply_to_status_id" : 535135932916441088,
  "created_at" : "2014-11-19 18:24:17 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535135932916441088",
  "text" : "I have really had it with people who respond to what they do not understand with naysaying &amp; cynicism &amp; negativity. Why is that the default?",
  "id" : 535135932916441088,
  "created_at" : "2014-11-19 18:22:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535135276952461314",
  "text" : "RT @substack: \uD835\uDD2D\uD835\uDD2F\uD835\uDD2C\uD835\uDD31\uD835\uDD22\uD835\uDD20\uD835\uDD31 \uD835\uDD31\uD835\uDD25\uD835\uDD36\uD835\uDD30\uD835\uDD22\uD835\uDD29\uD835\uDD23 \uD835\uDD23\uD835\uDD2F\uD835\uDD2C\uD835\uDD2A \uD835\uDD30\uD835\uDD22\uD835\uDD1E\uD835\uDD2F\uD835\uDD20\uD835\uDD25 \uD835\uDD22\uD835\uDD2B\uD835\uDD24\uD835\uDD26\uD835\uDD2B\uD835\uDD22 \uD835\uDD26\uD835\uDD2B\uD835\uDD21\uD835\uDD22\uD835\uDD35\uD835\uDD26\uD835\uDD2B\uD835\uDD24",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535131806115594240",
    "text" : "\uD835\uDD2D\uD835\uDD2F\uD835\uDD2C\uD835\uDD31\uD835\uDD22\uD835\uDD20\uD835\uDD31 \uD835\uDD31\uD835\uDD25\uD835\uDD36\uD835\uDD30\uD835\uDD22\uD835\uDD29\uD835\uDD23 \uD835\uDD23\uD835\uDD2F\uD835\uDD2C\uD835\uDD2A \uD835\uDD30\uD835\uDD22\uD835\uDD1E\uD835\uDD2F\uD835\uDD20\uD835\uDD25 \uD835\uDD22\uD835\uDD2B\uD835\uDD24\uD835\uDD26\uD835\uDD2B\uD835\uDD22 \uD835\uDD26\uD835\uDD2B\uD835\uDD21\uD835\uDD22\uD835\uDD35\uD835\uDD26\uD835\uDD2B\uD835\uDD24",
    "id" : 535131806115594240,
    "created_at" : "2014-11-19 18:05:39 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 535135276952461314,
  "created_at" : "2014-11-19 18:19:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535098319555403776",
  "text" : "Santa Cruz has a \"Paradox Hotel\".\n\nThe Paradox Hotel - You can check in, but you're actually checking out.",
  "id" : 535098319555403776,
  "created_at" : "2014-11-19 15:52:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535097901806927873",
  "text" : "Last night I felt my last self-doubt as programmer.  It was a vestige from the days of not grokking. I caught my self doubter &amp; killed him.",
  "id" : 535097901806927873,
  "created_at" : "2014-11-19 15:50:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/SXgAtWlVBz",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/463",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/463"
    } ]
  },
  "geo" : { },
  "id_str" : "535092527523581952",
  "text" : "Barbie Tsue on the Art of Coding\n\nhttps:\/\/t.co\/SXgAtWlVBz",
  "id" : 535092527523581952,
  "created_at" : "2014-11-19 15:29:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/6qzkcjeTTM",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/417",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/417"
    } ]
  },
  "geo" : { },
  "id_str" : "535086785521401856",
  "text" : "this is fun i could do it all day\n\nhttps:\/\/t.co\/6qzkcjeTTM",
  "id" : 535086785521401856,
  "created_at" : "2014-11-19 15:06:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gzCUiAiWxw",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/398",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/398"
    } ]
  },
  "geo" : { },
  "id_str" : "535084563056189440",
  "text" : "https:\/\/t.co\/gzCUiAiWxw",
  "id" : 535084563056189440,
  "created_at" : "2014-11-19 14:57:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    }, {
      "name" : "Sartaj",
      "screen_name" : "sartaj",
      "indices" : [ 13, 20 ],
      "id_str" : "24467334",
      "id" : 24467334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535083216181272577",
  "geo" : { },
  "id_str" : "535083500949352448",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee CC\/ @sartaj u should make this if you can",
  "id" : 535083500949352448,
  "in_reply_to_status_id" : 535083216181272577,
  "created_at" : "2014-11-19 14:53:42 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/x4GpcA5rfb",
      "expanded_url" : "https:\/\/computer-engineer-barbie.herokuapp.com\/view\/383",
      "display_url" : "computer-engineer-barbie.herokuapp.com\/view\/383"
    } ]
  },
  "geo" : { },
  "id_str" : "535083182295494656",
  "text" : "https:\/\/t.co\/x4GpcA5rfb",
  "id" : 535083182295494656,
  "created_at" : "2014-11-19 14:52:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534966178666409984",
  "text" : "PLAN DRUNK  \/\/  EXECUTE SOBER",
  "id" : 534966178666409984,
  "created_at" : "2014-11-19 07:07:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534958879247851522",
  "text" : "this year, to mark my resolution to no more acknowledge gilded and sticky glossed holidays, the feast of the season will not be thursday #4",
  "id" : 534958879247851522,
  "created_at" : "2014-11-19 06:38:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534958109890842624",
  "text" : "EVERYBODY \nPARADE FOR THE MARKET\nTHAT IS AN ORDER",
  "id" : 534958109890842624,
  "created_at" : "2014-11-19 06:35:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OK Council",
      "screen_name" : "OKcouncil",
      "indices" : [ 0, 10 ],
      "id_str" : "414106728",
      "id" : 414106728
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 11, 23 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534956406080679936",
  "geo" : { },
  "id_str" : "534957663734349825",
  "in_reply_to_user_id" : 46961216,
  "text" : "@OKcouncil @marinakukso  As a result, people who prefer to do civic oriented work must instead resort to that BS parade called the market.",
  "id" : 534957663734349825,
  "in_reply_to_status_id" : 534956406080679936,
  "created_at" : "2014-11-19 06:33:40 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OK Council",
      "screen_name" : "OKcouncil",
      "indices" : [ 0, 10 ],
      "id_str" : "414106728",
      "id" : 414106728
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 11, 23 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534920323678740480",
  "geo" : { },
  "id_str" : "534956406080679936",
  "in_reply_to_user_id" : 414106728,
  "text" : "@OKcouncil @marinakukso  I'm young and self-educated and I spend the same percentage on rent, also in Oakland. We're paying off the banks.",
  "id" : 534956406080679936,
  "in_reply_to_status_id" : 534920323678740480,
  "created_at" : "2014-11-19 06:28:40 +0000",
  "in_reply_to_screen_name" : "OKcouncil",
  "in_reply_to_user_id_str" : "414106728",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534954647614533633",
  "text" : "Much of everything you do to others, to yourself you also do.  The backwards is also true.",
  "id" : 534954647614533633,
  "created_at" : "2014-11-19 06:21:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534953495653138432",
  "text" : "I'm have n hell of a time killing old Johnny.  He ain't dead yet &amp; unfortunately he fucked me, himself and I, which forebears consequences.",
  "id" : 534953495653138432,
  "created_at" : "2014-11-19 06:17:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534951382680236032",
  "geo" : { },
  "id_str" : "534951641972092928",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript but don't argue with me on this one",
  "id" : 534951641972092928,
  "in_reply_to_status_id" : 534951382680236032,
  "created_at" : "2014-11-19 06:09:45 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534951382680236032",
  "text" : "let us disagree to disagree",
  "id" : 534951382680236032,
  "created_at" : "2014-11-19 06:08:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534791644416323584",
  "text" : "have you gotten mad because of an internet connection today?  \n\nhang your head in shame!",
  "id" : 534791644416323584,
  "created_at" : "2014-11-18 19:33:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534790778703605760",
  "text" : "one day i will write a website",
  "id" : 534790778703605760,
  "created_at" : "2014-11-18 19:30:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534785811813003265",
  "geo" : { },
  "id_str" : "534788462466330624",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nproof: organized crime is for making money\n\nyou can make money on via the internet in myriad new ways and old",
  "id" : 534788462466330624,
  "in_reply_to_status_id" : 534785811813003265,
  "created_at" : "2014-11-18 19:21:19 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534785970387058688",
  "text" : "TAKING THE CRIME OUT OF \"ORGANIZED CRIME\"",
  "id" : 534785970387058688,
  "created_at" : "2014-11-18 19:11:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534785811813003265",
  "text" : "ergo the a modified gangster. all legal, of course.  so much behavior that was easier to do criminally can now be done legal via internet.",
  "id" : 534785811813003265,
  "created_at" : "2014-11-18 19:10:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534784920083001344",
  "text" : "rilly tho the system is designed to be bad at fighting gangsterism.  Police can't do it.  Army can't do it.  But it pays to keep fighting.",
  "id" : 534784920083001344,
  "created_at" : "2014-11-18 19:07:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chess",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534780921330040832",
  "text" : "The police state defined our strategy for to systematically revolt.  (They are white.)  We shall play the INDIO GANGSTER defence.  #chess",
  "id" : 534780921330040832,
  "created_at" : "2014-11-18 18:51:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534778575887806464",
  "text" : "If this system has as pretty much at war with each other, the future Romans are gonna be like damn the first Romans had nothing on Romans II",
  "id" : 534778575887806464,
  "created_at" : "2014-11-18 18:42:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534778003545681920",
  "text" : "current status, missing a lot of people",
  "id" : 534778003545681920,
  "created_at" : "2014-11-18 18:39:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/yix7wGsZW2",
      "expanded_url" : "https:\/\/www.youtube.com\/channel\/UCVTnOjyu7gxMCbh00aLS3gQ",
      "display_url" : "youtube.com\/channel\/UCVTnO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534764124358471680",
  "text" : "damn this woman confronting street harassment makes ME nervous about what will transpire, yet she is very brave.\n\nhttps:\/\/t.co\/yix7wGsZW2",
  "id" : 534764124358471680,
  "created_at" : "2014-11-18 17:44:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534762445231771649",
  "text" : "this society is really in desperate need of real ninjas",
  "id" : 534762445231771649,
  "created_at" : "2014-11-18 17:37:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534757774706503680",
  "text" : "mamas, don't yr babies grow up to be cat-callin' cow punchers",
  "id" : 534757774706503680,
  "created_at" : "2014-11-18 17:19:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 0, 8 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534744062528864256",
  "geo" : { },
  "id_str" : "534754461541888000",
  "in_reply_to_user_id" : 4784511,
  "text" : "@bigeasy  WHATCHA LOOK N AT",
  "id" : 534754461541888000,
  "in_reply_to_status_id" : 534744062528864256,
  "created_at" : "2014-11-18 17:06:13 +0000",
  "in_reply_to_screen_name" : "bigeasy",
  "in_reply_to_user_id_str" : "4784511",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534414602021244929",
  "text" : "Is thought the paradox of nature?",
  "id" : 534414602021244929,
  "created_at" : "2014-11-17 18:35:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayson Musson",
      "screen_name" : "therealhennessy",
      "indices" : [ 0, 16 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534391726040158208",
  "geo" : { },
  "id_str" : "534404737345400832",
  "in_reply_to_user_id" : 137090436,
  "text" : "@therealhennessy but what were you crying about?",
  "id" : 534404737345400832,
  "in_reply_to_status_id" : 534391726040158208,
  "created_at" : "2014-11-17 17:56:32 +0000",
  "in_reply_to_screen_name" : "therealhennessy",
  "in_reply_to_user_id_str" : "137090436",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534166227506040832",
  "text" : "these days\nany platitude qualifies as a cliche\nand\nanything vaguely strange is ironic\nwhereas\ncliche is actual ironically an actual cliche",
  "id" : 534166227506040832,
  "created_at" : "2014-11-17 02:08:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534163952003850240",
  "text" : "i garb for you\ni garb for the world",
  "id" : 534163952003850240,
  "created_at" : "2014-11-17 01:59:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    }, {
      "name" : "jennmonymonydollars",
      "screen_name" : "jennschiffer",
      "indices" : [ 17, 30 ],
      "id_str" : "12524622",
      "id" : 12524622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534015467636424704",
  "geo" : { },
  "id_str" : "534028751382663168",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords @jennschiffer whoever they are don't they know they are off by one?",
  "id" : 534028751382663168,
  "in_reply_to_status_id" : 534015467636424704,
  "created_at" : "2014-11-16 17:02:30 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran",
      "screen_name" : "KieranJWalsh",
      "indices" : [ 0, 13 ],
      "id_str" : "61234952",
      "id" : 61234952
    }, {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 14, 30 ],
      "id_str" : "17177251",
      "id" : 17177251
    }, {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 31, 42 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533777569615990786",
  "geo" : { },
  "id_str" : "533777717947146240",
  "in_reply_to_user_id" : 46961216,
  "text" : "@KieranJWalsh @brianloveswords @grayamelia \n\nacts like one too",
  "id" : 533777717947146240,
  "in_reply_to_status_id" : 533777569615990786,
  "created_at" : "2014-11-16 00:24:59 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran",
      "screen_name" : "KieranJWalsh",
      "indices" : [ 0, 13 ],
      "id_str" : "61234952",
      "id" : 61234952
    }, {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 14, 30 ],
      "id_str" : "17177251",
      "id" : 17177251
    }, {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 45, 56 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533738273446060033",
  "geo" : { },
  "id_str" : "533777569615990786",
  "in_reply_to_user_id" : 61234952,
  "text" : "@KieranJWalsh @brianloveswords  \n\nlooks like @grayamelia",
  "id" : 533777569615990786,
  "in_reply_to_status_id" : 533738273446060033,
  "created_at" : "2014-11-16 00:24:24 +0000",
  "in_reply_to_screen_name" : "KieranJWalsh",
  "in_reply_to_user_id_str" : "61234952",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533776639973658624",
  "text" : "no i do not believe in quantum entranglement, im with Einstein on this one.\n\nnot so on gravity tho",
  "id" : 533776639973658624,
  "created_at" : "2014-11-16 00:20:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/6T1KBssf7a",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/11\/16\/opinion\/sunday\/is-quantum-entanglement-real.html?_r=0",
      "display_url" : "nytimes.com\/2014\/11\/16\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533776433567793153",
  "text" : "this is horse shit and arrogant to boot http:\/\/t.co\/6T1KBssf7a\n\nwhy am i poor ass broke &amp; these clown gets chillions to test their pie ideas",
  "id" : 533776433567793153,
  "created_at" : "2014-11-16 00:19:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533766085401538560",
  "text" : "me like play game w doge\ndoge love me &gt; anything\ndoge want closeness to i\nme use kung fu 2 keep doge away  \nsimilar game woman play with man",
  "id" : 533766085401538560,
  "created_at" : "2014-11-15 23:38:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533544367080738816",
  "text" : "organic space flow",
  "id" : 533544367080738816,
  "created_at" : "2014-11-15 08:57:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533536861071753216",
  "text" : "combining leftovers into something new is like reverse asexual production",
  "id" : 533536861071753216,
  "created_at" : "2014-11-15 08:27:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533423797136011266",
  "text" : "i can synthesize the parts only i have with the parts everybody got since\n\nwow",
  "id" : 533423797136011266,
  "created_at" : "2014-11-15 00:58:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533421565434925056",
  "text" : "Do thyself this favor and pronounce hard the 3 tailing letters of the word calendar, so that you should realize its rude, beastly nature.",
  "id" : 533421565434925056,
  "created_at" : "2014-11-15 00:49:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533414760751308801",
  "text" : "thought is the processor of consciousness &amp; asserts our humanity\n\nwhy do anything w\/ yr human life but think &amp; love yr all one butt brain?",
  "id" : 533414760751308801,
  "created_at" : "2014-11-15 00:22:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533413482063212544",
  "text" : "your body is the but the butt of your being",
  "id" : 533413482063212544,
  "created_at" : "2014-11-15 00:17:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533411188819120128",
  "text" : "i bide almost all the time",
  "id" : 533411188819120128,
  "created_at" : "2014-11-15 00:08:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533408510256881664",
  "text" : "i feel just like a little cleopatra rn",
  "id" : 533408510256881664,
  "created_at" : "2014-11-14 23:57:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/WLbyuFGqb7",
      "expanded_url" : "http:\/\/www.stacyschiff.com\/cleopatra-a-life.html",
      "display_url" : "stacyschiff.com\/cleopatra-a-li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533390700998443008",
  "text" : "I never knew the history of Cleopatra, Caesar, Antony, etc until I read http:\/\/t.co\/WLbyuFGqb7 - the author tells a good history\n\ncrazy shit",
  "id" : 533390700998443008,
  "created_at" : "2014-11-14 22:47:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533386572863782912",
  "text" : "i think game graphic recently jumped the shark, landing ashore",
  "id" : 533386572863782912,
  "created_at" : "2014-11-14 22:30:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/wyBQnmxUf9",
      "expanded_url" : "http:\/\/www.addictedtowar.com\/atw1a.html",
      "display_url" : "addictedtowar.com\/atw1a.html"
    } ]
  },
  "geo" : { },
  "id_str" : "533371154439086080",
  "text" : "addicted to war http:\/\/t.co\/wyBQnmxUf9",
  "id" : 533371154439086080,
  "created_at" : "2014-11-14 21:29:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/t1108l1VaI",
      "expanded_url" : "http:\/\/bits.blogs.nytimes.com\/2014\/11\/13\/gift-from-ballmer-will-expand-computer-science-faculty-at-harvard\/?ref=technology&_r=0",
      "display_url" : "bits.blogs.nytimes.com\/2014\/11\/13\/gif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532988490389397504",
  "text" : "wow \nsuch charity\nso give tens hundreds of millions to an elite institute\nphew look out that window\nhttp:\/\/t.co\/t1108l1VaI",
  "id" : 532988490389397504,
  "created_at" : "2014-11-13 20:08:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532980594381426688",
  "text" : "Just as one may derive order from chaos, and chaos from order, so it follows that we may derive anarchy from total bureaucracy somecrazyhow.",
  "id" : 532980594381426688,
  "created_at" : "2014-11-13 19:37:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532961006604259328",
  "geo" : { },
  "id_str" : "532965043306909696",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  \n\n\/!\\ REPORT \/!\\\nSTARTUP FREE &amp; ON THE LOOSE\nALL HACKERS BE WAREZ\nSTARTUP MAY BE FUNDED &amp; LIKELY RIGHTEOUS\nUSE OF FOSS ADVISED",
  "id" : 532965043306909696,
  "in_reply_to_status_id" : 532961006604259328,
  "created_at" : "2014-11-13 18:35:43 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532963826782982145",
  "text" : "i invented the mirror to mirror peering protocol (m2mpp), \nu invent what it does, \nand you, \nover there, \ninvent how it looks in javascripts",
  "id" : 532963826782982145,
  "created_at" : "2014-11-13 18:30:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Drake",
      "screen_name" : "kyledrake",
      "indices" : [ 0, 10 ],
      "id_str" : "7171612",
      "id" : 7171612
    }, {
      "name" : "EINS78",
      "screen_name" : "EINS78",
      "indices" : [ 11, 18 ],
      "id_str" : "14301616",
      "id" : 14301616
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 19, 28 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Troy Howard",
      "screen_name" : "thoward37",
      "indices" : [ 29, 39 ],
      "id_str" : "89108994",
      "id" : 89108994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532878421156581376",
  "geo" : { },
  "id_str" : "532930511401140225",
  "in_reply_to_user_id" : 7171612,
  "text" : "@kyledrake @EINS78 @substack @thoward37  PLEASE PAY THIS FINE RANSOM",
  "id" : 532930511401140225,
  "in_reply_to_status_id" : 532878421156581376,
  "created_at" : "2014-11-13 16:18:29 +0000",
  "in_reply_to_screen_name" : "kyledrake",
  "in_reply_to_user_id_str" : "7171612",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    }, {
      "name" : "Yosuke FURUKAWA",
      "screen_name" : "yosuke_furukawa",
      "indices" : [ 10, 26 ],
      "id_str" : "39272335",
      "id" : 39272335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532888725118668801",
  "geo" : { },
  "id_str" : "532930292550750209",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden @yosuke_furukawa  KEWL MUSTACHE CAT",
  "id" : 532930292550750209,
  "in_reply_to_status_id" : 532888725118668801,
  "created_at" : "2014-11-13 16:17:37 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532677073148858368",
  "text" : "I added a tiny bit of courage to the cutting of the onion, and didn't cry this time, tho I wanted to, I could feel it.",
  "id" : 532677073148858368,
  "created_at" : "2014-11-12 23:31:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531845085412212737",
  "text" : "the past hundred years have been totally fucked.  what do you pine for?  post worldwar?  early petro chemical industry?  mass media telecom?",
  "id" : 531845085412212737,
  "created_at" : "2014-11-10 16:25:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531844600659726336",
  "text" : "can u imagine how ironic nostalgia of any kind is, in the age of future tech coming off the heels of these late ages?",
  "id" : 531844600659726336,
  "created_at" : "2014-11-10 16:23:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531842658847977472",
  "text" : "WIll there ever be justice for the case of the 90's radio pop band turning \"BIg Yellow Taxi\" into tailgate song?",
  "id" : 531842658847977472,
  "created_at" : "2014-11-10 16:15:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531838509544669186",
  "text" : "everybody in this land has a fear of the cancers and then they drive petrochemical soot covered tanks over their children's playground",
  "id" : 531838509544669186,
  "created_at" : "2014-11-10 15:59:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531832456765530112",
  "text" : "our landlord\n\"environmental economist\"\nbought house at the height of the bubble\nsays use gas 4 cheapness when I ask to rm HVAC to make space",
  "id" : 531832456765530112,
  "created_at" : "2014-11-10 15:35:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531564006708768768",
  "geo" : { },
  "id_str" : "531570113724424193",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  \n\nall of them\n(11) in moderation",
  "id" : 531570113724424193,
  "in_reply_to_status_id" : 531564006708768768,
  "created_at" : "2014-11-09 22:12:45 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531565768643579905",
  "geo" : { },
  "id_str" : "531569547791196160",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso methinks you might should board the next Arc Ship in the shipyard.\n\nsee u there.",
  "id" : 531569547791196160,
  "in_reply_to_status_id" : 531565768643579905,
  "created_at" : "2014-11-09 22:10:30 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531148505985712128",
  "text" : "that's all i care about that",
  "id" : 531148505985712128,
  "created_at" : "2014-11-08 18:17:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531148415070003200",
  "text" : "THAT MUSIC YOU LISTENED TO WAS NOT MEANT TO GET YOU THRU BAD TIMES SO YOU COULD BECOME A JELLY DONUT",
  "id" : 531148415070003200,
  "created_at" : "2014-11-08 18:17:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531148098609758209",
  "text" : "EVERY TECH COMPANY TURN YOUR EMPLOYEES LOOSE TO FUX WITH THE INTERNET MEDIUM LIKE THEY KNOW HOW AND RAISE A STINKING RED FLAG",
  "id" : 531148098609758209,
  "created_at" : "2014-11-08 18:15:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531147781918822400",
  "text" : "ONE WEEK LABOR STRIKE AND PARTY TO DENOUNCE THE SENATE'S CLAIMS TO LEGITIMACY!!!",
  "id" : 531147781918822400,
  "created_at" : "2014-11-08 18:14:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531147463755718656",
  "text" : "is this internet on?",
  "id" : 531147463755718656,
  "created_at" : "2014-11-08 18:13:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531147396965617664",
  "text" : "like, we need the media to start bitch slapping the government, and i am not talking about television news media, i mean the internet",
  "id" : 531147396965617664,
  "created_at" : "2014-11-08 18:13:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531147274206728192",
  "text" : "how can we get the media to back a claim the gov't has no claim to any mandate?",
  "id" : 531147274206728192,
  "created_at" : "2014-11-08 18:12:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531146442509787136",
  "text" : "i reckon a fix to the system for handle the reality of the situation of voter turnout would be a good one to the groin",
  "id" : 531146442509787136,
  "created_at" : "2014-11-08 18:09:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531145850227945472",
  "text" : "36% of voters estimated turnout\n\nhow can the government claim to have any mandate at all?",
  "id" : 531145850227945472,
  "created_at" : "2014-11-08 18:06:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/DfyKQ7UnSl",
      "expanded_url" : "https:\/\/firstlook.org\/theintercept\/2014\/11\/07\/voter-suppression\/",
      "display_url" : "firstlook.org\/theintercept\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531145700164128768",
  "text" : "aaahhhhh, lowest voter turnout in over a pentade\nhttps:\/\/t.co\/DfyKQ7UnSl",
  "id" : 531145700164128768,
  "created_at" : "2014-11-08 18:06:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531144473481199616",
  "text" : "the system does not have a protocol for \"no confidence\", but if there is any indicator, it is the withholding of votes.  Consent withheld!",
  "id" : 531144473481199616,
  "created_at" : "2014-11-08 18:01:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531143721853526016",
  "text" : "is there any valid information on nationwide voter turnout?",
  "id" : 531143721853526016,
  "created_at" : "2014-11-08 17:58:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531143078661222400",
  "text" : "\"Lose Yourself To Dance\" will be the next \"Superstition\", every live house band's appetizer.  We're gonna play it out anyway, tengo anos.",
  "id" : 531143078661222400,
  "created_at" : "2014-11-08 17:55:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530792433324277760",
  "text" : "I PUT A BUG IN YOU COMPUTAH\n\nBECUZ YOUR LIKENESS IS MYYYYYYYYYYYYN\n\nOOGA BOOGA HAH HA HAH",
  "id" : 530792433324277760,
  "created_at" : "2014-11-07 18:42:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530789004090675201",
  "geo" : { },
  "id_str" : "530790700153987072",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  bonus real police siren drive by mixed with my improvisational sirens at ~ 3:50 jus before the great big fonale",
  "id" : 530790700153987072,
  "in_reply_to_status_id" : 530789004090675201,
  "created_at" : "2014-11-07 18:35:39 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/3yWIExRuii",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/dsp-interface",
      "display_url" : "npmjs.org\/package\/dsp-in\u2026"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/A9H7A2KXON",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/raw-cut2",
      "display_url" : "soundcloud.com\/johnnyscript\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530789004090675201",
  "text" : "2 year old recording of me PLAYING bespoke javascript DSP audio synths w\/ early module https:\/\/t.co\/3yWIExRuii\n\nhttps:\/\/t.co\/A9H7A2KXON",
  "id" : 530789004090675201,
  "created_at" : "2014-11-07 18:28:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 0, 14 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530752629677490177",
  "geo" : { },
  "id_str" : "530760989000486913",
  "in_reply_to_user_id" : 379919160,
  "text" : "@MikolaLysenko un poco de todos",
  "id" : 530760989000486913,
  "in_reply_to_status_id" : 530752629677490177,
  "created_at" : "2014-11-07 16:37:35 +0000",
  "in_reply_to_screen_name" : "MikolaLysenko",
  "in_reply_to_user_id_str" : "379919160",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530747867929907200",
  "text" : "i suppose the time has come to stop jamming and copy paste the old onto the new, all the while boogie n",
  "id" : 530747867929907200,
  "created_at" : "2014-11-07 15:45:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530742872840994816",
  "text" : "im still ahead",
  "id" : 530742872840994816,
  "created_at" : "2014-11-07 15:25:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530727433776164865",
  "geo" : { },
  "id_str" : "530740415528316930",
  "in_reply_to_user_id" : 35235820,
  "text" : "@DLAGPrez  oaktown crips represent, okeedoke!",
  "id" : 530740415528316930,
  "in_reply_to_status_id" : 530727433776164865,
  "created_at" : "2014-11-07 15:15:50 +0000",
  "in_reply_to_screen_name" : "RichardinBK",
  "in_reply_to_user_id_str" : "35235820",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 13, 29 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530354649023668224",
  "geo" : { },
  "id_str" : "530411871765942273",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @brianloveswords \nLOS WEBS\nOH DOM\nOH EM DASH\nOH EM GEE DOGE\nI MEAN\nWHAT CAN YOU?\nTHE PROBLEM IS!\nAND THEN THERES!\nAND IM LIKE.",
  "id" : 530411871765942273,
  "in_reply_to_status_id" : 530354649023668224,
  "created_at" : "2014-11-06 17:30:19 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 39, 48 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/ImzWA8YLtS",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=6w0WFo8kTJ0",
      "display_url" : "youtube.com\/watch?v=6w0WFo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530166865020977153",
  "text" : "RT @substack: robot drawing a robot at @sudoroom https:\/\/t.co\/ImzWA8YLtS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sudo Room",
        "screen_name" : "sudoroom",
        "indices" : [ 25, 34 ],
        "id_str" : "411733308",
        "id" : 411733308
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/ImzWA8YLtS",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=6w0WFo8kTJ0",
        "display_url" : "youtube.com\/watch?v=6w0WFo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529962056032612352",
    "text" : "robot drawing a robot at @sudoroom https:\/\/t.co\/ImzWA8YLtS",
    "id" : 529962056032612352,
    "created_at" : "2014-11-05 11:42:55 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 530166865020977153,
  "created_at" : "2014-11-06 01:16:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noConfidence",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530053034865598464",
  "text" : "With only 50K votes cast in the mayoral race of Oakland, the clear vote is of no confidence.  #noConfidence",
  "id" : 530053034865598464,
  "created_at" : "2014-11-05 17:44:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529863442069344256",
  "text" : "WHAT PERCENTAGE OF VOTERS TURNT OUT?",
  "id" : 529863442069344256,
  "created_at" : "2014-11-05 05:11:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529861090113368065",
  "text" : "i am tempted to be humoured by these events\n\nbut no",
  "id" : 529861090113368065,
  "created_at" : "2014-11-05 05:01:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Hopper",
      "screen_name" : "DanHopp",
      "indices" : [ 3, 11 ],
      "id_str" : "44043497",
      "id" : 44043497
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DanHopp\/status\/529778633712226304\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Gvr3HaccmH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1om3AgCQAAtnrz.jpg",
      "id_str" : "529778632638480384",
      "id" : 529778632638480384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1om3AgCQAAtnrz.jpg",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Gvr3HaccmH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529860314594955265",
  "text" : "RT @DanHopp: Wow. CNN really going all-out: http:\/\/t.co\/Gvr3HaccmH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DanHopp\/status\/529778633712226304\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/Gvr3HaccmH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1om3AgCQAAtnrz.jpg",
        "id_str" : "529778632638480384",
        "id" : 529778632638480384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1om3AgCQAAtnrz.jpg",
        "sizes" : [ {
          "h" : 334,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Gvr3HaccmH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529778633712226304",
    "text" : "Wow. CNN really going all-out: http:\/\/t.co\/Gvr3HaccmH",
    "id" : 529778633712226304,
    "created_at" : "2014-11-04 23:34:03 +0000",
    "user" : {
      "name" : "Dan Hopper",
      "screen_name" : "DanHopp",
      "protected" : false,
      "id_str" : "44043497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528542376705683456\/-CFYgMf-_normal.jpeg",
      "id" : 44043497,
      "verified" : false
    }
  },
  "id" : 529860314594955265,
  "created_at" : "2014-11-05 04:58:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529828938730590208",
  "text" : "In Arkansas, they voted for a guy that said mexican drug cartel are getting into the terrorism business to attack Arkansas.",
  "id" : 529828938730590208,
  "created_at" : "2014-11-05 02:53:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529825054884782080",
  "text" : "IN THE USA YOU VOTE FOR AN INCH WHILE THEY TAKE MILES AND MILES AND MILES",
  "id" : 529825054884782080,
  "created_at" : "2014-11-05 02:38:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529824514369019904",
  "geo" : { },
  "id_str" : "529824864132022273",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  this is my vote",
  "id" : 529824864132022273,
  "in_reply_to_status_id" : 529824514369019904,
  "created_at" : "2014-11-05 02:37:45 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529824514369019904",
  "text" : "I voted.  I can't endorse a system that will ineluctably pervert my intents, and of course corrupt whomever gets elected.  Me nuh care.",
  "id" : 529824514369019904,
  "created_at" : "2014-11-05 02:36:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529822378130280448",
  "text" : "ITS COMPLETE PANDEMONACRACY OUT THERE FOLKS",
  "id" : 529822378130280448,
  "created_at" : "2014-11-05 02:27:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529821568264699904",
  "text" : "uh oh people are voting again",
  "id" : 529821568264699904,
  "created_at" : "2014-11-05 02:24:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/So1tD8QLoK",
      "expanded_url" : "http:\/\/einsteinforoakland.org\/",
      "display_url" : "einsteinforoakland.org"
    } ]
  },
  "geo" : { },
  "id_str" : "529731911766507521",
  "text" : "EINSTEIN FOR MAYOR OF OAKLAND http:\/\/t.co\/So1tD8QLoK",
  "id" : 529731911766507521,
  "created_at" : "2014-11-04 20:28:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529731630639120384",
  "text" : "mayor einstein will use legislation to prevent you from becoming a callous human being  #oakland",
  "id" : 529731630639120384,
  "created_at" : "2014-11-04 20:27:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529731371284324352",
  "text" : "vote einstein #oakland",
  "id" : 529731371284324352,
  "created_at" : "2014-11-04 20:26:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529729856469483523",
  "geo" : { },
  "id_str" : "529731248315707392",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript pit bulls would be very happy to pull us around instead of being sun burnt, starved and unkempt in your driveway.  #oakland",
  "id" : 529731248315707392,
  "in_reply_to_status_id" : 529729856469483523,
  "created_at" : "2014-11-04 20:25:46 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529729856469483523",
  "text" : "i remember last night's fading thoughts\n\npit bull chariots\n\npit bull powered public transit",
  "id" : 529729856469483523,
  "created_at" : "2014-11-04 20:20:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529702573297516544",
  "text" : "pit bulls are very intelligent",
  "id" : 529702573297516544,
  "created_at" : "2014-11-04 18:31:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529698681994215427",
  "text" : "my daily workout consists of tugs of war with a large pitbull, and pulling trees out by the root (and turning them into wizard staffs).",
  "id" : 529698681994215427,
  "created_at" : "2014-11-04 18:16:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/0ptFAqLWrW",
      "expanded_url" : "http:\/\/www.diyaudio.com\/forums\/analog-line-level\/99196-analog-pitch-shifting-2.html#post3817557",
      "display_url" : "diyaudio.com\/forums\/analog-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529566760039493632",
  "text" : "wow this sounds like it probably sounds awesome, and may be the \"simplest\" way to make an analog pitch shifter http:\/\/t.co\/0ptFAqLWrW",
  "id" : 529566760039493632,
  "created_at" : "2014-11-04 09:32:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529564835277574144",
  "text" : "hollar if u seen what I did there",
  "id" : 529564835277574144,
  "created_at" : "2014-11-04 09:24:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529564767657025536",
  "text" : "I discovered a paradox of CS \/ Info Theory!  It's the true write-only database, which guarantees a property you can't verify.",
  "id" : 529564767657025536,
  "created_at" : "2014-11-04 09:24:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529564395123126272",
  "text" : "loudbot is my siri, and there is no emoji to describe that",
  "id" : 529564395123126272,
  "created_at" : "2014-11-04 09:22:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/gfPY90KWhG",
      "expanded_url" : "https:\/\/github.com\/NHQ\/text-cloud\/blob\/master\/charletans.webs.md",
      "display_url" : "github.com\/NHQ\/text-cloud\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529562868266459136",
  "text" : "i wrote a story describing the internet https:\/\/t.co\/gfPY90KWhG",
  "id" : 529562868266459136,
  "created_at" : "2014-11-04 09:16:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/529554011003711488\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/JAJX3l5nOV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1lakRvCMAAfrnT.png",
      "id_str" : "529554010475212800",
      "id" : 529554010475212800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1lakRvCMAAfrnT.png",
      "sizes" : [ {
        "h" : 130,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 789
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 789
      } ],
      "display_url" : "pic.twitter.com\/JAJX3l5nOV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529554011003711488",
  "text" : "Is google's current doodle the All American Office Park, with a happy spinning bank? http:\/\/t.co\/JAJX3l5nOV",
  "id" : 529554011003711488,
  "created_at" : "2014-11-04 08:41:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529551517863260160",
  "text" : "lean in\nlean out\nlean in\nlean back again\nlean back in\nlean back back\nwhat color are your eyes?\nbut did you see the gorilla?",
  "id" : 529551517863260160,
  "created_at" : "2014-11-04 08:31:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/529533380434481152\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/I5gmFez1Dh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1lHzDrCMAACg9F.jpg",
      "id_str" : "529533373677449216",
      "id" : 529533373677449216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1lHzDrCMAACg9F.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/I5gmFez1Dh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529533380434481152",
  "text" : "My new beastie lil bear. http:\/\/t.co\/I5gmFez1Dh",
  "id" : 529533380434481152,
  "created_at" : "2014-11-04 07:19:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529435257456439297",
  "text" : "the pit bull purrs like a little bear, hence the name",
  "id" : 529435257456439297,
  "created_at" : "2014-11-04 00:49:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529431998050213888",
  "text" : "1.  h, a, double elle, oh!, double you, double ee, n \n\n2.  spells a word that is assonant with line one, heh",
  "id" : 529431998050213888,
  "created_at" : "2014-11-04 00:36:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529430742707617792",
  "text" : "ERR, BODY TOOK IT TOO SERIOUSLY",
  "id" : 529430742707617792,
  "created_at" : "2014-11-04 00:31:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529430196697300992",
  "text" : "DO THAT ONE MORE TIME AND I WILL USE WORDS SUGGESTIVE OF VIOLENT ACTS, METAPHORICALLY SPEAKING",
  "id" : 529430196697300992,
  "created_at" : "2014-11-04 00:29:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529429305579687936",
  "text" : "they never knew me was a supa dupa",
  "id" : 529429305579687936,
  "created_at" : "2014-11-04 00:25:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 0, 8 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529158903385575425",
  "geo" : { },
  "id_str" : "529295758781345792",
  "in_reply_to_user_id" : 433715578,
  "text" : "@Gyselie  \\o\/",
  "id" : 529295758781345792,
  "in_reply_to_status_id" : 529158903385575425,
  "created_at" : "2014-11-03 15:35:17 +0000",
  "in_reply_to_screen_name" : "Gyselie",
  "in_reply_to_user_id_str" : "433715578",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    }, {
      "name" : "Pepsi\u2122",
      "screen_name" : "pepsi",
      "indices" : [ 64, 70 ],
      "id_str" : "18139619",
      "id" : 18139619
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nexxylove\/status\/529233836438089730\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/QHpcJO2jPR",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B1g3XiOCYAAOyas.png",
      "id_str" : "529233833678233600",
      "id" : 529233833678233600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B1g3XiOCYAAOyas.png",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/QHpcJO2jPR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529294528596160512",
  "text" : "RT @nexxylove: current status: enjoying a delicious, refreshing @pepsi\u2122 http:\/\/t.co\/QHpcJO2jPR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pepsi\u2122",
        "screen_name" : "pepsi",
        "indices" : [ 49, 55 ],
        "id_str" : "18139619",
        "id" : 18139619
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nexxylove\/status\/529233836438089730\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/QHpcJO2jPR",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B1g3XiOCYAAOyas.png",
        "id_str" : "529233833678233600",
        "id" : 529233833678233600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B1g3XiOCYAAOyas.png",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/QHpcJO2jPR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529233836438089730",
    "text" : "current status: enjoying a delicious, refreshing @pepsi\u2122 http:\/\/t.co\/QHpcJO2jPR",
    "id" : 529233836438089730,
    "created_at" : "2014-11-03 11:29:13 +0000",
    "user" : {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719047162793828353\/ilHIszOy_normal.jpg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 529294528596160512,
  "created_at" : "2014-11-03 15:30:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 3, 16 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/cHnGJHYx3k",
      "expanded_url" : "http:\/\/www.tonedeaf.com.au\/424334\/1988-mixtape-by-kurt-cobain-has-been-found-and-its-insane.htm",
      "display_url" : "tonedeaf.com.au\/424334\/1988-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529294091457413121",
  "text" : "RT @CryptoCobain: Check out my new mixtape: http:\/\/t.co\/cHnGJHYx3k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/cHnGJHYx3k",
        "expanded_url" : "http:\/\/www.tonedeaf.com.au\/424334\/1988-mixtape-by-kurt-cobain-has-been-found-and-its-insane.htm",
        "display_url" : "tonedeaf.com.au\/424334\/1988-mi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529262047662714880",
    "text" : "Check out my new mixtape: http:\/\/t.co\/cHnGJHYx3k",
    "id" : 529262047662714880,
    "created_at" : "2014-11-03 13:21:20 +0000",
    "user" : {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "protected" : false,
      "id_str" : "2259434528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549171123884392448\/tzURuJbe_normal.jpeg",
      "id" : 2259434528,
      "verified" : false
    }
  },
  "id" : 529294091457413121,
  "created_at" : "2014-11-03 15:28:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Aria Stewart",
      "screen_name" : "aredridel",
      "indices" : [ 13, 23 ],
      "id_str" : "17950990",
      "id" : 17950990
    }, {
      "name" : "Maciej Ma\u0142ecki",
      "screen_name" : "maciejmalecki",
      "indices" : [ 24, 38 ],
      "id_str" : "263755874",
      "id" : 263755874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529291761689296896",
  "geo" : { },
  "id_str" : "529293092130947072",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @aredridel @maciejmalecki  i read that as \"causal style\" cuz dyslexia, and now I want to know what you mean by that",
  "id" : 529293092130947072,
  "in_reply_to_status_id" : 529291761689296896,
  "created_at" : "2014-11-03 15:24:41 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529141271504224256",
  "text" : "javascript stopped working",
  "id" : 529141271504224256,
  "created_at" : "2014-11-03 05:21:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haunted TweetBot",
      "screen_name" : "cwlcks",
      "indices" : [ 0, 7 ],
      "id_str" : "63545584",
      "id" : 63545584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528785642634113024",
  "geo" : { },
  "id_str" : "529081414562504704",
  "in_reply_to_user_id" : 63545584,
  "text" : "@cwlcks i am afraid of the ocean and not interested in conquering that one",
  "id" : 529081414562504704,
  "in_reply_to_status_id" : 528785642634113024,
  "created_at" : "2014-11-03 01:23:33 +0000",
  "in_reply_to_screen_name" : "cwlcks",
  "in_reply_to_user_id_str" : "63545584",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haunted TweetBot",
      "screen_name" : "cwlcks",
      "indices" : [ 0, 7 ],
      "id_str" : "63545584",
      "id" : 63545584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528785642634113024",
  "geo" : { },
  "id_str" : "529081255803879425",
  "in_reply_to_user_id" : 63545584,
  "text" : "@cwlcks  i don't have a boner for sailing but I know a lot of cyberhobos that do.  what are you doing at ucla?",
  "id" : 529081255803879425,
  "in_reply_to_status_id" : 528785642634113024,
  "created_at" : "2014-11-03 01:22:55 +0000",
  "in_reply_to_screen_name" : "cwlcks",
  "in_reply_to_user_id_str" : "63545584",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528746804750610434",
  "text" : "Is 500 mA infrared too much for my eyes?",
  "id" : 528746804750610434,
  "created_at" : "2014-11-02 03:13:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528728373850173440",
  "text" : "don't dress as your hero for halloween unless they are dead",
  "id" : 528728373850173440,
  "created_at" : "2014-11-02 02:00:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528705500733386752",
  "text" : "hint:  i will be dressed as a martyred transhumanist slut tonight",
  "id" : 528705500733386752,
  "created_at" : "2014-11-02 00:29:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528704702242775041",
  "text" : "Well, I do suppose the opposite of slutty is intellectual.",
  "id" : 528704702242775041,
  "created_at" : "2014-11-02 00:26:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528703543323025408",
  "text" : "there are only two costumes, slutty and the opposite.  All others are derived from the two.",
  "id" : 528703543323025408,
  "created_at" : "2014-11-02 00:22:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528702992644464640",
  "text" : "i usually dress like a slut, and tonight will be no different",
  "id" : 528702992644464640,
  "created_at" : "2014-11-02 00:19:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528702761391501313",
  "text" : "im gonna see if i can get the band to all dress up as Woman X",
  "id" : 528702761391501313,
  "created_at" : "2014-11-02 00:18:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haunted TweetBot",
      "screen_name" : "cwlcks",
      "indices" : [ 0, 7 ],
      "id_str" : "63545584",
      "id" : 63545584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528662119223263232",
  "geo" : { },
  "id_str" : "528667883279093762",
  "in_reply_to_user_id" : 63545584,
  "text" : "@cwlcks  did you sail to LA?",
  "id" : 528667883279093762,
  "in_reply_to_status_id" : 528662119223263232,
  "created_at" : "2014-11-01 22:00:20 +0000",
  "in_reply_to_screen_name" : "cwlcks",
  "in_reply_to_user_id_str" : "63545584",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528639713939161088",
  "text" : "twitter is such shit you cant even search yr own history wtf",
  "id" : 528639713939161088,
  "created_at" : "2014-11-01 20:08:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528637001528913920",
  "text" : "neither a word nor it's definition is the concept",
  "id" : 528637001528913920,
  "created_at" : "2014-11-01 19:57:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528636821081554945",
  "text" : "words done fooled us",
  "id" : 528636821081554945,
  "created_at" : "2014-11-01 19:56:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528631363641954305",
  "text" : "im playing some psyched out future shit tonight at the OMNI, mega space to dance in the ballroom.  come hear my bespoke web audio synths.",
  "id" : 528631363641954305,
  "created_at" : "2014-11-01 19:35:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 3, 18 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 46, 55 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528629983514619904",
  "text" : "yo @oaklanddancejs come to OMNI tonight for a @sudoroom costume ball.  4799 Shattuck Ave, Oakland.  Music starts 9-10.",
  "id" : 528629983514619904,
  "created_at" : "2014-11-01 19:29:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 3, 10 ],
      "id_str" : "291901937",
      "id" : 291901937
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LB2045\/status\/528612586745376770\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/mCTNYsDrSF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1YCWDzCQAAJKBj.jpg",
      "id_str" : "528612584262352896",
      "id" : 528612584262352896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1YCWDzCQAAJKBj.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1582
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1326,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mCTNYsDrSF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/2ySokYPSZD",
      "expanded_url" : "https:\/\/omnicommons.org\/wiki\/Event:2014\/11\/01_Transhuman_Masquerade_Ball",
      "display_url" : "omnicommons.org\/wiki\/Event:201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528617583084191744",
  "text" : "RT @LB2045: Tranhuman-themed masquerade ball tonight at the Oakland Omni Commons! https:\/\/t.co\/2ySokYPSZD http:\/\/t.co\/mCTNYsDrSF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LB2045\/status\/528612586745376770\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/mCTNYsDrSF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1YCWDzCQAAJKBj.jpg",
        "id_str" : "528612584262352896",
        "id" : 528612584262352896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1YCWDzCQAAJKBj.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1582
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 777,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1326,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mCTNYsDrSF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/2ySokYPSZD",
        "expanded_url" : "https:\/\/omnicommons.org\/wiki\/Event:2014\/11\/01_Transhuman_Masquerade_Ball",
        "display_url" : "omnicommons.org\/wiki\/Event:201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528612586745376770",
    "text" : "Tranhuman-themed masquerade ball tonight at the Oakland Omni Commons! https:\/\/t.co\/2ySokYPSZD http:\/\/t.co\/mCTNYsDrSF",
    "id" : 528612586745376770,
    "created_at" : "2014-11-01 18:20:36 +0000",
    "user" : {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "protected" : false,
      "id_str" : "291901937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524991844514418688\/hPkExiIp_normal.jpeg",
      "id" : 291901937,
      "verified" : false
    }
  },
  "id" : 528617583084191744,
  "created_at" : "2014-11-01 18:40:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528617519913775105",
  "text" : "all the world's a costume",
  "id" : 528617519913775105,
  "created_at" : "2014-11-01 18:40:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]