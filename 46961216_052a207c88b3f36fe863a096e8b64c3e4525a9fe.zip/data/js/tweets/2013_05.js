Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340312820606455808",
  "geo" : { },
  "id_str" : "340315070947020800",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs this is not a pipe",
  "id" : 340315070947020800,
  "in_reply_to_status_id" : 340312820606455808,
  "created_at" : "2013-05-31 03:53:30 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/VRj8k1nFp4",
      "expanded_url" : "http:\/\/politicalticker.blogs.cnn.com\/2013\/05\/30\/mccain-responds-to-syria-photo-controversy\/?hpt=po_c2&hpt=hp_t2",
      "display_url" : "politicalticker.blogs.cnn.com\/2013\/05\/30\/mcc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340312135412350976",
  "text" : "can we put this guy in a museum already http:\/\/t.co\/VRj8k1nFp4",
  "id" : 340312135412350976,
  "created_at" : "2013-05-31 03:41:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340309836564672513",
  "text" : "so much",
  "id" : 340309836564672513,
  "created_at" : "2013-05-31 03:32:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/9GtTmIyj2r",
      "expanded_url" : "http:\/\/instagram.com\/p\/Z9HD1Pj5Wx\/",
      "display_url" : "instagram.com\/p\/Z9HD1Pj5Wx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "340253602121650177",
  "text" : "What will we do with this 120 volt 2K watts \/ 12 volt 120 amp inverter \/ charger http:\/\/t.co\/9GtTmIyj2r",
  "id" : 340253602121650177,
  "created_at" : "2013-05-30 23:49:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 80, 89 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/9NlfPiFWcI",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Newcomb's_paradox",
      "display_url" : "en.wikipedia.org\/wiki\/Newcomb's\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339967434050138113",
  "text" : "I just thought of a new kind of casino game talking about Newcombs Paradox with @substack http:\/\/t.co\/9NlfPiFWcI",
  "id" : 339967434050138113,
  "created_at" : "2013-05-30 04:52:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339908973195059200",
  "text" : "One of the earliest ideas I had for a web thing was a service to have a real person read to you.",
  "id" : 339908973195059200,
  "created_at" : "2013-05-30 00:59:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339906336307425280",
  "text" : "i want to sit around and be told things",
  "id" : 339906336307425280,
  "created_at" : "2013-05-30 00:49:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Campbell",
      "screen_name" : "slajax",
      "indices" : [ 8, 15 ],
      "id_str" : "8308842",
      "id" : 8308842
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 28, 32 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339873853406863360",
  "geo" : { },
  "id_str" : "339878747454992384",
  "in_reply_to_user_id" : 8308842,
  "text" : "Thanks! @slajax and Thanks! @izs",
  "id" : 339878747454992384,
  "in_reply_to_status_id" : 339873853406863360,
  "created_at" : "2013-05-29 22:59:42 +0000",
  "in_reply_to_screen_name" : "slajax",
  "in_reply_to_user_id_str" : "8308842",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339870384956514304",
  "text" : "I need a Canadian to buy and lease me a Canadian .ca domain.",
  "id" : 339870384956514304,
  "created_at" : "2013-05-29 22:26:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "ponybear",
      "screen_name" : "ponybear",
      "indices" : [ 17, 26 ],
      "id_str" : "18341954",
      "id" : 18341954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/v24X3cfWFF",
      "expanded_url" : "http:\/\/pandodaily.com\/2013\/05\/29\/gumroad-launches-a-drop-dead-simple-and-cheap-video-streaming-solution-partners-with-maria-menounos-serial-buddies-film\/",
      "display_url" : "pandodaily.com\/2013\/05\/29\/gum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339866543141838848",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin @ponybear newslink http:\/\/t.co\/v24X3cfWFF",
  "id" : 339866543141838848,
  "created_at" : "2013-05-29 22:11:12 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339538067998257152",
  "geo" : { },
  "id_str" : "339589760114896896",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr it can look you straight in the eyes and tell you what it was last night.",
  "id" : 339589760114896896,
  "in_reply_to_status_id" : 339538067998257152,
  "created_at" : "2013-05-29 03:51:22 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mHYQZRnbct",
      "expanded_url" : "http:\/\/catarse.me\/pt\/leca",
      "display_url" : "catarse.me\/pt\/leca"
    } ]
  },
  "geo" : { },
  "id_str" : "339075224735723523",
  "text" : "\"Oriented to the infantile public the program aims to convey a message of inclusion and appreciation of differences\"  http:\/\/t.co\/mHYQZRnbct",
  "id" : 339075224735723523,
  "created_at" : "2013-05-27 17:46:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338129439303032832",
  "text" : "That was weird.",
  "id" : 338129439303032832,
  "created_at" : "2013-05-25 03:08:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/NivFSjy5Us",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=2nGW7-zbysc&oref=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D2nGW7-zbysc&has_verified=1",
      "display_url" : "youtube.com\/watch?v=2nGW7-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338114211207053312",
  "text" : "finale of live youtube comedy week, why didn;t I know about this. Reggie Watts coming up  http:\/\/t.co\/NivFSjy5Us",
  "id" : 338114211207053312,
  "created_at" : "2013-05-25 02:08:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "losmejor",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338105191578599426",
  "text" : "The siesta is for keeping mornings and nights, which are superior to middle days. #losmejor",
  "id" : 338105191578599426,
  "created_at" : "2013-05-25 01:32:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337711389772754945",
  "text" : "RT @IAM_SHAKESPEARE: I am determined to prove a villain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337699466880614400",
    "text" : "I am determined to prove a villain",
    "id" : 337699466880614400,
    "created_at" : "2013-05-23 22:40:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 337711389772754945,
  "created_at" : "2013-05-23 23:27:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dStUASSCmG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=2uqZhnqHMAg",
      "display_url" : "youtube.com\/watch?v=2uqZhn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337104453326999552",
  "text" : "http:\/\/t.co\/dStUASSCmG",
  "id" : 337104453326999552,
  "created_at" : "2013-05-22 07:15:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "luke arduini",
      "screen_name" : "luk",
      "indices" : [ 0, 4 ],
      "id_str" : "16569603",
      "id" : 16569603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/3sK4WbDwV2",
      "expanded_url" : "http:\/\/www.sfgate.com\/movies\/article\/Les-Blank-documentary-filmmaker-dies-4416133.php",
      "display_url" : "sfgate.com\/movies\/article\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336887052241104898",
  "geo" : { },
  "id_str" : "336889081411796993",
  "in_reply_to_user_id" : 16569603,
  "text" : "@luk Les Blank died a couple of weeks ago.  http:\/\/t.co\/3sK4WbDwV2",
  "id" : 336889081411796993,
  "in_reply_to_status_id" : 336887052241104898,
  "created_at" : "2013-05-21 16:59:50 +0000",
  "in_reply_to_screen_name" : "luk",
  "in_reply_to_user_id_str" : "16569603",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336679537406525440",
  "text" : "Moments ago I accidentally re-invented the t-short.",
  "id" : 336679537406525440,
  "created_at" : "2013-05-21 03:07:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336565147038519296",
  "text" : "$ lscd",
  "id" : 336565147038519296,
  "created_at" : "2013-05-20 19:32:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335864557958483970",
  "text" : "An Historical Reinaccurate",
  "id" : 335864557958483970,
  "created_at" : "2013-05-18 21:08:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335601747328372737",
  "text" : "RT @IAM_SHAKESPEARE: I give this heavy weight from off my head,",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335598121113505792",
    "text" : "I give this heavy weight from off my head,",
    "id" : 335598121113505792,
    "created_at" : "2013-05-18 03:30:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 335601747328372737,
  "created_at" : "2013-05-18 03:44:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335206348579016705",
  "text" : "CODE GOES HEAD FIRST",
  "id" : 335206348579016705,
  "created_at" : "2013-05-17 01:33:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimmy",
      "screen_name" : "arealliveghost",
      "indices" : [ 0, 15 ],
      "id_str" : "407895022",
      "id" : 407895022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335180975107608576",
  "geo" : { },
  "id_str" : "335188090853392384",
  "in_reply_to_user_id" : 407895022,
  "text" : "@aRealLiveGhost \"Con permisso, mademoiselle, do you know the wifi password?\"",
  "id" : 335188090853392384,
  "in_reply_to_status_id" : 335180975107608576,
  "created_at" : "2013-05-17 00:20:43 +0000",
  "in_reply_to_screen_name" : "arealliveghost",
  "in_reply_to_user_id_str" : "407895022",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eran blade hammer",
      "screen_name" : "eranhammer",
      "indices" : [ 1, 12 ],
      "id_str" : "346026614",
      "id" : 346026614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335160193371488257",
  "geo" : { },
  "id_str" : "335177925915709440",
  "in_reply_to_user_id" : 346026614,
  "text" : ".@eranhammer don't wrap your app in a try and a catch!",
  "id" : 335177925915709440,
  "in_reply_to_status_id" : 335160193371488257,
  "created_at" : "2013-05-16 23:40:19 +0000",
  "in_reply_to_screen_name" : "eranhammer",
  "in_reply_to_user_id_str" : "346026614",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335134518241550337",
  "text" : "the yinyang and the ouroborous is hilarious",
  "id" : 335134518241550337,
  "created_at" : "2013-05-16 20:47:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yinyang",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "nyancat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335132352693010433",
  "text" : "The ear is much faster than the eye. #yinyang #nyancat",
  "id" : 335132352693010433,
  "created_at" : "2013-05-16 20:39:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caolan McMahon",
      "screen_name" : "caolan",
      "indices" : [ 0, 7 ],
      "id_str" : "12185182",
      "id" : 12185182
    }, {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "indices" : [ 8, 13 ],
      "id_str" : "819606",
      "id" : 819606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/n1Zr2l4CrP",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/The_New_Colossus",
      "display_url" : "en.wikipedia.org\/wiki\/The_New_C\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "334926417907294208",
  "geo" : { },
  "id_str" : "334930606318317568",
  "in_reply_to_user_id" : 12185182,
  "text" : "@caolan @janl \"Give me yr tired, yr poor...\n the wretched refuse of yr teeming shore.\nSend these, the homeless...\"  http:\/\/t.co\/n1Zr2l4CrP",
  "id" : 334930606318317568,
  "in_reply_to_status_id" : 334926417907294208,
  "created_at" : "2013-05-16 07:17:33 +0000",
  "in_reply_to_screen_name" : "caolan",
  "in_reply_to_user_id_str" : "12185182",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334119406231752704",
  "text" : "CHIRPY DERPIES",
  "id" : 334119406231752704,
  "created_at" : "2013-05-14 01:34:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334036793143984128",
  "text" : "shoo Fed, don't bother me",
  "id" : 334036793143984128,
  "created_at" : "2013-05-13 20:05:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/YTuXTQx1EI",
      "expanded_url" : "http:\/\/poobah.com\/broadcast",
      "display_url" : "poobah.com\/broadcast"
    } ]
  },
  "geo" : { },
  "id_str" : "334035404703543296",
  "text" : "Space is the place. Launch off Ras G's podcasts http:\/\/t.co\/YTuXTQx1EI",
  "id" : 334035404703543296,
  "created_at" : "2013-05-13 20:00:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334034828066435073",
  "text" : "Look for the US Federal Government to take its global \"security\" limitations &amp; shortcomings out on its own people, like a terrorble dad.",
  "id" : 334034828066435073,
  "created_at" : "2013-05-13 19:58:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opsMonsanto",
      "indices" : [ 54, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/H8zTTHc5lX",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/05\/14\/business\/monsanto-victorious-in-genetic-seed-case.html?smid=tw-share&_r=2&",
      "display_url" : "nytimes.com\/2013\/05\/14\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334014891574824960",
  "text" : "MONSANTO WINS! GOOOOOOOOOOOOL!\nhttp:\/\/t.co\/H8zTTHc5lX #opsMonsanto",
  "id" : 334014891574824960,
  "created_at" : "2013-05-13 18:38:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 0, 7 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334010838354653184",
  "geo" : { },
  "id_str" : "334013134840930304",
  "in_reply_to_user_id" : 668423,
  "text" : "@mikeal RAGE PUKE",
  "id" : 334013134840930304,
  "in_reply_to_status_id" : 334010838354653184,
  "created_at" : "2013-05-13 18:31:51 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VimeoStaff",
      "screen_name" : "VimeoStaff",
      "indices" : [ 1, 12 ],
      "id_str" : "17663262",
      "id" : 17663262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NIKE",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334000811262750720",
  "geo" : { },
  "id_str" : "334011163463516160",
  "in_reply_to_user_id" : 17663262,
  "text" : ".@VimeoStaff As a paying user, I would prefer not to have your marketing, of all things, as a social distinction. Feel it? #NIKE",
  "id" : 334011163463516160,
  "in_reply_to_status_id" : 334000811262750720,
  "created_at" : "2013-05-13 18:24:01 +0000",
  "in_reply_to_screen_name" : "VimeoStaff",
  "in_reply_to_user_id_str" : "17663262",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VimeoStaff",
      "screen_name" : "VimeoStaff",
      "indices" : [ 1, 12 ],
      "id_str" : "17663262",
      "id" : 17663262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334000811262750720",
  "geo" : { },
  "id_str" : "334009461733744642",
  "in_reply_to_user_id" : 17663262,
  "text" : ".@VimeoStaff Sure, you all must disagree, for reasons you don't control, like management, marketing, corporate parentage, I understand.",
  "id" : 334009461733744642,
  "in_reply_to_status_id" : 334000811262750720,
  "created_at" : "2013-05-13 18:17:15 +0000",
  "in_reply_to_screen_name" : "VimeoStaff",
  "in_reply_to_user_id_str" : "17663262",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 113, 124 ],
      "id_str" : "5943942",
      "id" : 5943942
    }, {
      "name" : "Vimeo",
      "screen_name" : "Vimeo",
      "indices" : [ 126, 132 ],
      "id_str" : "14718218",
      "id" : 14718218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334000329605652480",
  "text" : "I think its very gauche when web destinations advertise their \"preimuim\" or \"pro\" users with special marks  cc\/ .@SoundCloud .@vimeo",
  "id" : 334000329605652480,
  "created_at" : "2013-05-13 17:40:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/dUN2ecKsY1",
      "expanded_url" : "http:\/\/dabblet.com\/gist\/5569976",
      "display_url" : "dabblet.com\/gist\/5569976"
    } ]
  },
  "geo" : { },
  "id_str" : "333999285450465281",
  "text" : "this is my go-to CSS background http:\/\/t.co\/dUN2ecKsY1",
  "id" : 333999285450465281,
  "created_at" : "2013-05-13 17:36:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333988115393941504",
  "text" : "RT @postcrunk: no new friends only because isolation is a byproduct of our economic system",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333981793546027008",
    "text" : "no new friends only because isolation is a byproduct of our economic system",
    "id" : 333981793546027008,
    "created_at" : "2013-05-13 16:27:19 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 333988115393941504,
  "created_at" : "2013-05-13 16:52:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 3, 12 ],
      "id_str" : "141834186",
      "id" : 141834186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333987486353211393",
  "text" : "RT @FearDept: The United States Department of Fear is a proud partner of the Seed and Pesticide Industry.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333987277380390912",
    "text" : "The United States Department of Fear is a proud partner of the Seed and Pesticide Industry.",
    "id" : 333987277380390912,
    "created_at" : "2013-05-13 16:49:06 +0000",
    "user" : {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "protected" : false,
      "id_str" : "141834186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453113104939761664\/9ZqHHvvA_normal.png",
      "id" : 141834186,
      "verified" : false
    }
  },
  "id" : 333987486353211393,
  "created_at" : "2013-05-13 16:49:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333666035326676993",
  "geo" : { },
  "id_str" : "333666649309855747",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden yeah I got that going. Is the error readout (which I saw in a live example somewher) part of that module, or an eval hack or what?",
  "id" : 333666649309855747,
  "in_reply_to_status_id" : 333666035326676993,
  "created_at" : "2013-05-12 19:35:03 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333663600843571200",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden where is that voxel.js code editor example with the side-by-side error readout?",
  "id" : 333663600843571200,
  "created_at" : "2013-05-12 19:22:56 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 3, 12 ],
      "id_str" : "141834186",
      "id" : 141834186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333636844640141313",
  "text" : "RT @FearDept: Freedom is countries opening their markets and financial systems to our corporate partners. Freedom is non-negotiable.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333612719271981057",
    "text" : "Freedom is countries opening their markets and financial systems to our corporate partners. Freedom is non-negotiable.",
    "id" : 333612719271981057,
    "created_at" : "2013-05-12 16:00:45 +0000",
    "user" : {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "protected" : false,
      "id_str" : "141834186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453113104939761664\/9ZqHHvvA_normal.png",
      "id" : 141834186,
      "verified" : false
    }
  },
  "id" : 333636844640141313,
  "created_at" : "2013-05-12 17:36:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333394236374405121",
  "text" : "why don't I be more descriptive with my code nouns, why don't I",
  "id" : 333394236374405121,
  "created_at" : "2013-05-12 01:32:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333017176741117953",
  "text" : "I have seen the future, and it is easy.",
  "id" : 333017176741117953,
  "created_at" : "2013-05-11 00:34:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/MJbzsxi7R7",
      "expanded_url" : "http:\/\/freearabs.com\/index.php\/fun-stuff\/fatwa-show\/340-the-woman-s-body-hair",
      "display_url" : "freearabs.com\/index.php\/fun-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "333016455853518849",
  "text" : "BODY HAIR FATWA http:\/\/t.co\/MJbzsxi7R7",
  "id" : 333016455853518849,
  "created_at" : "2013-05-11 00:31:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nathanjurgenson",
      "screen_name" : "nathanjurgenson",
      "indices" : [ 0, 16 ],
      "id_str" : "66025575",
      "id" : 66025575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332981425424957440",
  "geo" : { },
  "id_str" : "332982200972763137",
  "in_reply_to_user_id" : 66025575,
  "text" : "@nathanjurgenson blame it on the eh eh eh echo",
  "id" : 332982200972763137,
  "in_reply_to_status_id" : 332981425424957440,
  "created_at" : "2013-05-10 22:15:17 +0000",
  "in_reply_to_screen_name" : "nathanjurgenson",
  "in_reply_to_user_id_str" : "66025575",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/TcLOMpP3UM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=KkMwZgtHVnI",
      "display_url" : "youtube.com\/watch?v=KkMwZg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332958371684679680",
  "text" : "i'm gonna remix some bird call through a secret synthesizer http:\/\/t.co\/TcLOMpP3UM",
  "id" : 332958371684679680,
  "created_at" : "2013-05-10 20:40:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332539725263032321",
  "text" : "Reality Like",
  "id" : 332539725263032321,
  "created_at" : "2013-05-09 16:57:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332537847699611648",
  "text" : "Hippy Dipstribution",
  "id" : 332537847699611648,
  "created_at" : "2013-05-09 16:49:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331637481374109697",
  "text" : "The DSM shaped health &amp; system in USA, as well as the inter\/national commercial culture of bio- and psycho-logical melodrama. And it is BS.",
  "id" : 331637481374109697,
  "created_at" : "2013-05-07 05:11:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "rvagg",
      "indices" : [ 0, 6 ],
      "id_str" : "158704969",
      "id" : 158704969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331632513447501824",
  "geo" : { },
  "id_str" : "331635433949769729",
  "in_reply_to_user_id" : 158704969,
  "text" : "@rvagg yeah its bad. Same with FCC, FDA, &amp;co. Neutralized forces with their regulatory weight on the status quo. Corps callin the shots.",
  "id" : 331635433949769729,
  "in_reply_to_status_id" : 331632513447501824,
  "created_at" : "2013-05-07 05:03:43 +0000",
  "in_reply_to_screen_name" : "rvagg",
  "in_reply_to_user_id_str" : "158704969",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/zyO4FnQAsG",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/05\/07\/health\/psychiatrys-new-guide-falls-short-experts-say.html?hp",
      "display_url" : "nytimes.com\/2013\/05\/07\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331631752860798977",
  "text" : "This is encouraging http:\/\/t.co\/zyO4FnQAsG but the D.S.M. is a such a big stupid awful thing itself. So much is  regulated by it.",
  "id" : 331631752860798977,
  "created_at" : "2013-05-07 04:49:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhymefest",
      "screen_name" : "RHYMEFEST",
      "indices" : [ 0, 10 ],
      "id_str" : "18408457",
      "id" : 18408457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331599242806300672",
  "geo" : { },
  "id_str" : "331600821294886913",
  "in_reply_to_user_id" : 18408457,
  "text" : "@RHYMEFEST I'm refreshed by Tyler's response, but I think Mt. Dew is an evil, pestilent product rich blacks should not sell poor blacks on.",
  "id" : 331600821294886913,
  "in_reply_to_status_id" : 331599242806300672,
  "created_at" : "2013-05-07 02:46:11 +0000",
  "in_reply_to_screen_name" : "RHYMEFEST",
  "in_reply_to_user_id_str" : "18408457",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Hilowitz",
      "screen_name" : "dhilowitz",
      "indices" : [ 0, 10 ],
      "id_str" : "24695909",
      "id" : 24695909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331084709771739136",
  "geo" : { },
  "id_str" : "331085832624668673",
  "in_reply_to_user_id" : 24695909,
  "text" : "@dhilowitz Cool, if you do it, allow players to import avatars\/effigies of public figure heads the player wishes to chase, and beat down",
  "id" : 331085832624668673,
  "in_reply_to_status_id" : 331084709771739136,
  "created_at" : "2013-05-05 16:39:48 +0000",
  "in_reply_to_screen_name" : "dhilowitz",
  "in_reply_to_user_id_str" : "24695909",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Hilowitz",
      "screen_name" : "dhilowitz",
      "indices" : [ 0, 10 ],
      "id_str" : "24695909",
      "id" : 24695909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331082607406231553",
  "geo" : { },
  "id_str" : "331084670785683456",
  "in_reply_to_user_id" : 24695909,
  "text" : "@dhilowitz To chase and beat down a king wearing invisible clothes?",
  "id" : 331084670785683456,
  "in_reply_to_status_id" : 331082607406231553,
  "created_at" : "2013-05-05 16:35:11 +0000",
  "in_reply_to_screen_name" : "dhilowitz",
  "in_reply_to_user_id_str" : "24695909",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/YeugFOyIRt",
      "expanded_url" : "http:\/\/www.fbi.gov\/wanted\/wanted_terrorists",
      "display_url" : "fbi.gov\/wanted\/wanted_\u2026"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/gaXfMKfO1E",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=KDrAvwA2mf0",
      "display_url" : "youtube.com\/watch?v=KDrAvw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331083794415222784",
  "text" : "Cuban Made Film Doc of Assata Shakur ( Recently bumped to #2 on this FBI Wanted List: http:\/\/t.co\/YeugFOyIRt ) http:\/\/t.co\/gaXfMKfO1E",
  "id" : 331083794415222784,
  "created_at" : "2013-05-05 16:31:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "warOnWTF",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331073434119438336",
  "text" : "The federal government is still operating with cold war chills and civil rights backlash  #warOnWTF",
  "id" : 331073434119438336,
  "created_at" : "2013-05-05 15:50:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/FsvUPEuCvR",
      "expanded_url" : "http:\/\/www.pslweb.org\/liberationnews\/news\/assata-shakur-understanding-the-politics.html?utm_source=twitter&utm_medium=shared_article&utm_campaign=Liberation%20Newsletter",
      "display_url" : "pslweb.org\/liberationnews\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331071573295525888",
  "text" : "Look like Cuba is not getting off the Federal Shit List any time soon after all http:\/\/t.co\/FsvUPEuCvR",
  "id" : 331071573295525888,
  "created_at" : "2013-05-05 15:43:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/jQKcuBv5Cb",
      "expanded_url" : "http:\/\/news.firedoglake.com\/2013\/05\/03\/number-of-names-on-terrorism-suspect-database-jumps-to-875000\/",
      "display_url" : "news.firedoglake.com\/2013\/05\/03\/num\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331070521062068224",
  "text" : "the terrorism suspect name list needs to get leaked http:\/\/t.co\/jQKcuBv5Cb",
  "id" : 331070521062068224,
  "created_at" : "2013-05-05 15:38:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lego jedi ghost",
      "screen_name" : "lastcartridge",
      "indices" : [ 0, 14 ],
      "id_str" : "283885442",
      "id" : 283885442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/yN1gH9kNWu",
      "expanded_url" : "http:\/\/gog.com",
      "display_url" : "gog.com"
    } ]
  },
  "in_reply_to_status_id_str" : "330429519762714626",
  "geo" : { },
  "id_str" : "330504834774093825",
  "in_reply_to_user_id" : 283885442,
  "text" : "@lastcartridge I just bought both for 5bux at http:\/\/t.co\/yN1gH9kNWu",
  "id" : 330504834774093825,
  "in_reply_to_status_id" : 330429519762714626,
  "created_at" : "2013-05-04 02:11:07 +0000",
  "in_reply_to_screen_name" : "lastcartridge",
  "in_reply_to_user_id_str" : "283885442",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330428395009765379",
  "text" : "I really liked Masters of Orion 1 &amp; 2.",
  "id" : 330428395009765379,
  "created_at" : "2013-05-03 21:07:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jed Schmidt",
      "screen_name" : "jedschmidt",
      "indices" : [ 0, 11 ],
      "id_str" : "815114",
      "id" : 815114
    }, {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 12, 28 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/KVJUJz4zRD",
      "expanded_url" : "https:\/\/github.com\/nhq\/jsynth",
      "display_url" : "github.com\/nhq\/jsynth"
    } ]
  },
  "in_reply_to_status_id_str" : "330402191112278017",
  "geo" : { },
  "id_str" : "330405287611744256",
  "in_reply_to_user_id" : 815114,
  "text" : "@jedschmidt @brianloveswords there's also this one I am heavily into at the moment https:\/\/t.co\/KVJUJz4zRD ;^)",
  "id" : 330405287611744256,
  "in_reply_to_status_id" : 330402191112278017,
  "created_at" : "2013-05-03 19:35:33 +0000",
  "in_reply_to_screen_name" : "jedschmidt",
  "in_reply_to_user_id_str" : "815114",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "indices" : [ 3, 16 ],
      "id_str" : "97794798",
      "id" : 97794798
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 28, 40 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/4sL3awUOpt",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/thereremix",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330399776422113280",
  "text" : "RT @riverofdoubt: the homie @astromanies did something rly cool with my show on EVR! check it here https:\/\/t.co\/4sL3awUOpt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 10, 22 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/4sL3awUOpt",
        "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/thereremix",
        "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "330398045864878080",
    "geo" : { },
    "id_str" : "330398390900912128",
    "in_reply_to_user_id" : 46961216,
    "text" : "the homie @astromanies did something rly cool with my show on EVR! check it here https:\/\/t.co\/4sL3awUOpt",
    "id" : 330398390900912128,
    "in_reply_to_status_id" : 330398045864878080,
    "created_at" : "2013-05-03 19:08:09 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "protected" : false,
      "id_str" : "97794798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692916068864671745\/7esmD_jT_normal.png",
      "id" : 97794798,
      "verified" : false
    }
  },
  "id" : 330399776422113280,
  "created_at" : "2013-05-03 19:13:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    }, {
      "name" : "Jed Schmidt",
      "screen_name" : "jedschmidt",
      "indices" : [ 17, 28 ],
      "id_str" : "815114",
      "id" : 815114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330398530378272768",
  "geo" : { },
  "id_str" : "330399052153888770",
  "in_reply_to_user_id" : 46961216,
  "text" : "@brianloveswords @jedschmidt It is also a pretty awesome package of programming concepts",
  "id" : 330399052153888770,
  "in_reply_to_status_id" : 330398530378272768,
  "created_at" : "2013-05-03 19:10:47 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    }, {
      "name" : "Jed Schmidt",
      "screen_name" : "jedschmidt",
      "indices" : [ 17, 28 ],
      "id_str" : "815114",
      "id" : 815114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wO8ViBciHL",
      "expanded_url" : "https:\/\/github.com\/digego\/extempore",
      "display_url" : "github.com\/digego\/extempo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "330397760643813377",
  "geo" : { },
  "id_str" : "330398530378272768",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords @jedschmidt This the music thing I'm talking abt when I talk abt live coding AV in a Lisp dialect https:\/\/t.co\/wO8ViBciHL",
  "id" : 330398530378272768,
  "in_reply_to_status_id" : 330397760643813377,
  "created_at" : "2013-05-03 19:08:42 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330393975603212290",
  "geo" : { },
  "id_str" : "330398045864878080",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt I can't deny it. Arigato!",
  "id" : 330398045864878080,
  "in_reply_to_status_id" : 330393975603212290,
  "created_at" : "2013-05-03 19:06:47 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Top Conservative Cat",
      "screen_name" : "TeaPartyCat",
      "indices" : [ 3, 15 ],
      "id_str" : "27754737",
      "id" : 27754737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330395674350858240",
  "text" : "RT @TeaPartyCat: So far the \"who we've lost since last year\" video montage for the NRA convention is 74 hours long.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330394818696073216",
    "text" : "So far the \"who we've lost since last year\" video montage for the NRA convention is 74 hours long.",
    "id" : 330394818696073216,
    "created_at" : "2013-05-03 18:53:57 +0000",
    "user" : {
      "name" : "Top Conservative Cat",
      "screen_name" : "TeaPartyCat",
      "protected" : false,
      "id_str" : "27754737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000407713006\/fa28c8a5f59d5e6667c45a4269798bda_normal.jpeg",
      "id" : 27754737,
      "verified" : false
    }
  },
  "id" : 330395674350858240,
  "created_at" : "2013-05-03 18:57:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330393164886196226",
  "geo" : { },
  "id_str" : "330393571976953856",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt it's you man, it's you :D",
  "id" : 330393571976953856,
  "in_reply_to_status_id" : 330393164886196226,
  "created_at" : "2013-05-03 18:49:00 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maciej Ma\u0142ecki",
      "screen_name" : "maciejmalecki",
      "indices" : [ 0, 14 ],
      "id_str" : "263755874",
      "id" : 263755874
    }, {
      "name" : "marak",
      "screen_name" : "marak",
      "indices" : [ 15, 21 ],
      "id_str" : "110465841",
      "id" : 110465841
    }, {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 22, 36 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330391980871909377",
  "geo" : { },
  "id_str" : "330392981364412416",
  "in_reply_to_user_id" : 263755874,
  "text" : "@maciejmalecki @marak @jesusabdullah lol product placement",
  "id" : 330392981364412416,
  "in_reply_to_status_id" : 330391980871909377,
  "created_at" : "2013-05-03 18:46:39 +0000",
  "in_reply_to_screen_name" : "maciejmalecki",
  "in_reply_to_user_id_str" : "263755874",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/T56g8SM6pB",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/thereremix",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "330390758832087041",
  "geo" : { },
  "id_str" : "330392530300579842",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt https:\/\/t.co\/T56g8SM6pB",
  "id" : 330392530300579842,
  "in_reply_to_status_id" : 330390758832087041,
  "created_at" : "2013-05-03 18:44:52 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330391837137317888",
  "text" : "Every media source reports the gov't's employment numbers, aka \"kids writing their own report cards\", as legit news.",
  "id" : 330391837137317888,
  "created_at" : "2013-05-03 18:42:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330078110026432512",
  "text" : "Well, what we aught do with ole' garchy?",
  "id" : 330078110026432512,
  "created_at" : "2013-05-02 21:55:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330000262859223040",
  "text" : "AFAIKTIONATELY YOURS, EVERYBODY ALL THE TIME",
  "id" : 330000262859223040,
  "created_at" : "2013-05-02 16:46:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329820471245799424",
  "text" : "Debugging mobile safari on ipad via safari&gt;develop on OSX will decrease your ipad performance, and confuse you.",
  "id" : 329820471245799424,
  "created_at" : "2013-05-02 04:51:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329658682428252160",
  "text" : "Good thing I remember soon enough that I was developing for decent computers, and tested on one. iPad performance good.",
  "id" : 329658682428252160,
  "created_at" : "2013-05-01 18:08:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329658129660907522",
  "text" : "i need to be more careful, especially on this gSamslung Shlepbook. Crashes, shame on me. Poor web app perf got me blaming self, shame CPU.",
  "id" : 329658129660907522,
  "created_at" : "2013-05-01 18:06:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whenProgrammingRetards",
      "indices" : [ 83, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329654664406646785",
  "text" : "The thing I fear most is happening. Code that worked last week is not working now. #whenProgrammingRetards",
  "id" : 329654664406646785,
  "created_at" : "2013-05-01 17:52:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don't Read Comments",
      "screen_name" : "AvoidComments",
      "indices" : [ 3, 17 ],
      "id_str" : "977383291",
      "id" : 977383291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329608706956328961",
  "text" : "RT @AvoidComments: Pssssst. Hey, kid. You. Hey. Don't read the comments.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/youtube.com\" rel=\"nofollow\"\u003EDon't Read the Comments\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328909047313076224",
    "text" : "Pssssst. Hey, kid. You. Hey. Don't read the comments.",
    "id" : 328909047313076224,
    "created_at" : "2013-04-29 16:30:02 +0000",
    "user" : {
      "name" : "Don't Read Comments",
      "screen_name" : "AvoidComments",
      "protected" : false,
      "id_str" : "977383291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2909002988\/c31092c969c090761b04811d21983923_normal.png",
      "id" : 977383291,
      "verified" : false
    }
  },
  "id" : 329608706956328961,
  "created_at" : "2013-05-01 14:50:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "ponybear",
      "screen_name" : "ponybear",
      "indices" : [ 17, 26 ],
      "id_str" : "18341954",
      "id" : 18341954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/C2D1BNNTAT",
      "expanded_url" : "http:\/\/www.wipvideos.com\/",
      "display_url" : "wipvideos.com"
    }, {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/XDeJ3JGEFX",
      "expanded_url" : "http:\/\/pandodaily.com\/2013\/05\/01\/new-zealands-wip-makes-collaborative-video-editing-dead-easy\/",
      "display_url" : "pandodaily.com\/2013\/05\/01\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329608573137068034",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin @ponybear http:\/\/t.co\/C2D1BNNTAT http:\/\/t.co\/XDeJ3JGEFX",
  "id" : 329608573137068034,
  "created_at" : "2013-05-01 14:49:42 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 23, 34 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329608352478920704",
  "text" : "Secretary of Education @arneduncan is in S.F! BRING A No.2 PENCIL!",
  "id" : 329608352478920704,
  "created_at" : "2013-05-01 14:48:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 0, 11 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CPS",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329598610507460608",
  "geo" : { },
  "id_str" : "329606566556868610",
  "in_reply_to_user_id" : 44873497,
  "text" : "@arneduncan go back and retrace your steps through the still-miserably-broken public school systems you made your name running #CPS",
  "id" : 329606566556868610,
  "in_reply_to_status_id" : 329598610507460608,
  "created_at" : "2013-05-01 14:41:43 +0000",
  "in_reply_to_screen_name" : "JohnKingatED",
  "in_reply_to_user_id_str" : "44873497",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "ann friedman",
      "screen_name" : "annfriedman",
      "indices" : [ 21, 33 ],
      "id_str" : "20153725",
      "id" : 20153725
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BirthControl",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/0VSN2CGlu4",
      "expanded_url" : "http:\/\/bit.ly\/11Bh0LM",
      "display_url" : "bit.ly\/11Bh0LM"
    } ]
  },
  "geo" : { },
  "id_str" : "329605143198838786",
  "text" : "RT @AngelineGragzin: @annfriedman and I had a rousing conversation about #BirthControl today, published here in its entirety: http:\/\/t.co\/0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ann friedman",
        "screen_name" : "annfriedman",
        "indices" : [ 0, 12 ],
        "id_str" : "20153725",
        "id" : 20153725
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BirthControl",
        "indices" : [ 52, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/0VSN2CGlu4",
        "expanded_url" : "http:\/\/bit.ly\/11Bh0LM",
        "display_url" : "bit.ly\/11Bh0LM"
      } ]
    },
    "geo" : { },
    "id_str" : "329485386466353153",
    "in_reply_to_user_id" : 20153725,
    "text" : "@annfriedman and I had a rousing conversation about #BirthControl today, published here in its entirety: http:\/\/t.co\/0VSN2CGlu4",
    "id" : 329485386466353153,
    "created_at" : "2013-05-01 06:40:12 +0000",
    "in_reply_to_screen_name" : "annfriedman",
    "in_reply_to_user_id_str" : "20153725",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703307803574865921\/ZpTWouST_normal.jpg",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 329605143198838786,
  "created_at" : "2013-05-01 14:36:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]