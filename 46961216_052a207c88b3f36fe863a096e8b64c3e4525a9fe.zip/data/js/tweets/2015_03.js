Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/583037610789978112\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/pQk1pEPY26",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBddnR6VEAEZojT.jpg",
      "id_str" : "583037606172102657",
      "id" : 583037606172102657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBddnR6VEAEZojT.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pQk1pEPY26"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583037610789978112",
  "text" : "Preh sure my hair is on fleek ama http:\/\/t.co\/pQk1pEPY26",
  "id" : 583037610789978112,
  "created_at" : "2015-03-31 22:46:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "indices" : [ 3, 11 ],
      "id_str" : "885173964",
      "id" : 885173964
    }, {
      "name" : "Knight Foundation",
      "screen_name" : "knightfdn",
      "indices" : [ 122, 132 ],
      "id_str" : "14073364",
      "id" : 14073364
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newschallenge",
      "indices" : [ 55, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/Pd9zUfol34",
      "expanded_url" : "https:\/\/www.newschallenge.org\/challenge\/elections\/entries\/secure-polling-system-is-a-real-time-accurate-and-transparent-system-for-empowering-citizen-driven-anonymous-participatory-polling-with-an-engaging-and-rewarding-experience-for-voters",
      "display_url" : "newschallenge.org\/challenge\/elec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583034711263457280",
  "text" : "RT @jerquee: make your reps actually rep! please visit #newschallenge &amp; comment on our voting project with questions! @knightfdn https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Knight Foundation",
        "screen_name" : "knightfdn",
        "indices" : [ 109, 119 ],
        "id_str" : "14073364",
        "id" : 14073364
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "newschallenge",
        "indices" : [ 42, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/Pd9zUfol34",
        "expanded_url" : "https:\/\/www.newschallenge.org\/challenge\/elections\/entries\/secure-polling-system-is-a-real-time-accurate-and-transparent-system-for-empowering-citizen-driven-anonymous-participatory-polling-with-an-engaging-and-rewarding-experience-for-voters",
        "display_url" : "newschallenge.org\/challenge\/elec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "583034114854383618",
    "text" : "make your reps actually rep! please visit #newschallenge &amp; comment on our voting project with questions! @knightfdn https:\/\/t.co\/Pd9zUfol34",
    "id" : 583034114854383618,
    "created_at" : "2015-03-31 22:32:19 +0000",
    "user" : {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "protected" : false,
      "id_str" : "885173964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2879740670\/3705297a3d36fce362afdd93a090a3ea_normal.jpeg",
      "id" : 885173964,
      "verified" : false
    }
  },
  "id" : 583034711263457280,
  "created_at" : "2015-03-31 22:34:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583031561848672256",
  "geo" : { },
  "id_str" : "583034420463988737",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  building a Turing complete birdbath and hanging gardens ehhhhh",
  "id" : 583034420463988737,
  "in_reply_to_status_id" : 583031561848672256,
  "created_at" : "2015-03-31 22:33:32 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 0, 11 ],
      "id_str" : "407296703",
      "id" : 407296703
    }, {
      "name" : "Zachary Crockett",
      "screen_name" : "zzcrockett",
      "indices" : [ 12, 23 ],
      "id_str" : "1668490884",
      "id" : 1668490884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583024419758469120",
  "geo" : { },
  "id_str" : "583026914144604160",
  "in_reply_to_user_id" : 407296703,
  "text" : "@obensource @zzcrockett  congrats!  it's happening!!!",
  "id" : 583026914144604160,
  "in_reply_to_status_id" : 583024419758469120,
  "created_at" : "2015-03-31 22:03:43 +0000",
  "in_reply_to_screen_name" : "obensource",
  "in_reply_to_user_id_str" : "407296703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Crockett",
      "screen_name" : "zzcrockett",
      "indices" : [ 0, 11 ],
      "id_str" : "1668490884",
      "id" : 1668490884
    }, {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 12, 23 ],
      "id_str" : "407296703",
      "id" : 407296703
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "score",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580081894940803072",
  "geo" : { },
  "id_str" : "583022259964522496",
  "in_reply_to_user_id" : 1668490884,
  "text" : "@zzcrockett @obensource 'Though Chowning was a \u201Cmere\u201D percussionist with no discernable electronics skill'  haha me too!  #score",
  "id" : 583022259964522496,
  "in_reply_to_status_id" : 580081894940803072,
  "created_at" : "2015-03-31 21:45:13 +0000",
  "in_reply_to_screen_name" : "zzcrockett",
  "in_reply_to_user_id_str" : "1668490884",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582997671637434368",
  "geo" : { },
  "id_str" : "582999024120131584",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr happy modulo zero!",
  "id" : 582999024120131584,
  "in_reply_to_status_id" : 582997671637434368,
  "created_at" : "2015-03-31 20:12:53 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tidal",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582981765721145346",
  "text" : "#tidal is where the old world musical oligarchy will go to die.  Goodbye and good riddance to the 1990s and 2000s and Todays.  Hello Future!",
  "id" : 582981765721145346,
  "created_at" : "2015-03-31 19:04:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tidal",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582979367543898114",
  "text" : "Nothing could be better for music streaming and indie music than for all of the corporate mega sellouts to join one titanic bandwagon #tidal",
  "id" : 582979367543898114,
  "created_at" : "2015-03-31 18:54:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582978585440452610",
  "text" : "ISO algo wave and music hotnerds to label up and distro",
  "id" : 582978585440452610,
  "created_at" : "2015-03-31 18:51:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thePeople Oakland",
      "screen_name" : "thepeopleoak",
      "indices" : [ 3, 16 ],
      "id_str" : "122538295",
      "id" : 122538295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/OUVurP7xoK",
      "expanded_url" : "http:\/\/eepurl.com\/biyKdz",
      "display_url" : "eepurl.com\/biyKdz"
    } ]
  },
  "geo" : { },
  "id_str" : "582976589526335488",
  "text" : "RT @thepeopleoak: thePeople's Choice: \u00A0KAYA 6.0 | INCOGNITO | JAYVI VELASCO | THE PRESS CLUB | AFRODISCO | TAMBA - http:\/\/t.co\/OUVurP7xoK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.mailchimp.com\" rel=\"nofollow\"\u003EMailChimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/OUVurP7xoK",
        "expanded_url" : "http:\/\/eepurl.com\/biyKdz",
        "display_url" : "eepurl.com\/biyKdz"
      } ]
    },
    "geo" : { },
    "id_str" : "582972440952877056",
    "text" : "thePeople's Choice: \u00A0KAYA 6.0 | INCOGNITO | JAYVI VELASCO | THE PRESS CLUB | AFRODISCO | TAMBA - http:\/\/t.co\/OUVurP7xoK",
    "id" : 582972440952877056,
    "created_at" : "2015-03-31 18:27:15 +0000",
    "user" : {
      "name" : "thePeople Oakland",
      "screen_name" : "thepeopleoak",
      "protected" : false,
      "id_str" : "122538295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897706050\/ppl_heart_100_normal.gif",
      "id" : 122538295,
      "verified" : false
    }
  },
  "id" : 582976589526335488,
  "created_at" : "2015-03-31 18:43:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582971938915684352",
  "geo" : { },
  "id_str" : "582975253284020224",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden  play the \"telephone\" game over webRTC",
  "id" : 582975253284020224,
  "in_reply_to_status_id" : 582971938915684352,
  "created_at" : "2015-03-31 18:38:26 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582971614226186242",
  "text" : "MARKETING &amp; PROMOTION OF NEW TECH PRODUCTS ARE BORN AND USUALLY DIE IN THE UNCANNY VALLEY OF JOKES AND PRANKS",
  "id" : 582971614226186242,
  "created_at" : "2015-03-31 18:23:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L\u00FA\u00ED Smyth",
      "screen_name" : "yablochko",
      "indices" : [ 0, 10 ],
      "id_str" : "21051918",
      "id" : 21051918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582969353131450368",
  "geo" : { },
  "id_str" : "582971237674156032",
  "in_reply_to_user_id" : 21051918,
  "text" : "@yablochko  marketing and promo of new tech products live in the uncanny valley of jokes.",
  "id" : 582971237674156032,
  "in_reply_to_status_id" : 582969353131450368,
  "created_at" : "2015-03-31 18:22:28 +0000",
  "in_reply_to_screen_name" : "yablochko",
  "in_reply_to_user_id_str" : "21051918",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582968543966265344",
  "text" : "When I think of how I tried to convince my local bank's loan officer to loan me 20K for my local small web biz, I'M SAYING I JUS DONT KNOW",
  "id" : 582968543966265344,
  "created_at" : "2015-03-31 18:11:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582967953227964418",
  "text" : "I prefer retweets, if it is all the same to you.",
  "id" : 582967953227964418,
  "created_at" : "2015-03-31 18:09:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TIDAL",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582963890063089665",
  "text" : "Music streaming royalties should be logarithmic to favor small time indie artists.  #TIDAL",
  "id" : 582963890063089665,
  "created_at" : "2015-03-31 17:53:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582961720131457024",
  "text" : "I clearly do not know what I am doing.  Not Knowing works great for creativity, not so much for finances I guess.",
  "id" : 582961720131457024,
  "created_at" : "2015-03-31 17:44:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WLCEYOO8ha",
      "expanded_url" : "http:\/\/blogs.wsj.com\/venturecapital\/2015\/03\/05\/luxury-socks-startup-stance-raises-50m-to-expand-into-underwear\/",
      "display_url" : "blogs.wsj.com\/venturecapital\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582961362164416513",
  "text" : "hahaha 50 million to a sock and underwear \"startup\" and I can't get 20K from the bank to start a programming school  http:\/\/t.co\/WLCEYOO8ha",
  "id" : 582961362164416513,
  "created_at" : "2015-03-31 17:43:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "indices" : [ 3, 11 ],
      "id_str" : "14145296",
      "id" : 14145296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582961051223855104",
  "text" : "RT @susie_c: Their hair is very pretty tho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "582956423778291712",
    "geo" : { },
    "id_str" : "582956502849294337",
    "in_reply_to_user_id" : 14145296,
    "text" : "Their hair is very pretty tho",
    "id" : 582956502849294337,
    "in_reply_to_status_id" : 582956423778291712,
    "created_at" : "2015-03-31 17:23:55 +0000",
    "in_reply_to_screen_name" : "susie_c",
    "in_reply_to_user_id_str" : "14145296",
    "user" : {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "protected" : false,
      "id_str" : "14145296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656882091414585344\/JWq9-3gF_normal.png",
      "id" : 14145296,
      "verified" : false
    }
  },
  "id" : 582961051223855104,
  "created_at" : "2015-03-31 17:42:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582772750944575488",
  "text" : "If DJs tweet from their decks, it only makes sense to try to get them to play your songs by replying with a link.",
  "id" : 582772750944575488,
  "created_at" : "2015-03-31 05:13:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/lj8mVvAWAq",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/adaptive",
      "display_url" : "soundcloud.com\/johnnyscript\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582772413407989761",
  "text" : "this was magical when I recorded it, and it still is. https:\/\/t.co\/lj8mVvAWAq",
  "id" : 582772413407989761,
  "created_at" : "2015-03-31 05:12:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BURRITOS OVER PIZZA",
      "screen_name" : "LorenHell",
      "indices" : [ 0, 10 ],
      "id_str" : "231668409",
      "id" : 231668409
    }, {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "indices" : [ 11, 27 ],
      "id_str" : "87320284",
      "id" : 87320284
    }, {
      "name" : "Amaze88",
      "screen_name" : "Amaze88",
      "indices" : [ 28, 36 ],
      "id_str" : "142527876",
      "id" : 142527876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/OzafUI3eui",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/chicha-rapida-double-barrel-remix",
      "display_url" : "soundcloud.com\/folkstack\/chic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "582756221486125056",
  "geo" : { },
  "id_str" : "582772349616812033",
  "in_reply_to_user_id" : 231668409,
  "text" : "@LorenHell @veeveeveeveevee @Amaze88  DJ BUMP THIS TUMMY RUMBLER  https:\/\/t.co\/OzafUI3eui",
  "id" : 582772349616812033,
  "in_reply_to_status_id" : 582756221486125056,
  "created_at" : "2015-03-31 05:12:10 +0000",
  "in_reply_to_screen_name" : "LorenHell",
  "in_reply_to_user_id_str" : "231668409",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 0, 8 ],
      "id_str" : "185744472",
      "id" : 185744472
    }, {
      "name" : "Hugh Kennedy",
      "screen_name" : "hughskennedy",
      "indices" : [ 9, 22 ],
      "id_str" : "338334935",
      "id" : 338334935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582765982596247553",
  "geo" : { },
  "id_str" : "582769197853216769",
  "in_reply_to_user_id" : 185744472,
  "text" : "@Cabbibo @hughskennedy  CLICK OR BE CLICKED",
  "id" : 582769197853216769,
  "in_reply_to_status_id" : 582765982596247553,
  "created_at" : "2015-03-31 04:59:38 +0000",
  "in_reply_to_screen_name" : "Cabbibo",
  "in_reply_to_user_id_str" : "185744472",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/DUIAWGuRSG",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/dirt-muh-gurk",
      "display_url" : "soundcloud.com\/johnnyscript\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582757066634182656",
  "text" : "this is possibly the bass bassest I have recorded so far  https:\/\/t.co\/DUIAWGuRSG",
  "id" : 582757066634182656,
  "created_at" : "2015-03-31 04:11:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582751991270510592",
  "text" : "I am moved",
  "id" : 582751991270510592,
  "created_at" : "2015-03-31 03:51:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/nNzEIa68wr",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/surfin-george",
      "display_url" : "soundcloud.com\/folkstack\/surf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582751347558088705",
  "text" : "if you like rumblin bass, big psychic sounds, waves upon waves of delirious, awesome guitar, then let this blaze you https:\/\/t.co\/nNzEIa68wr",
  "id" : 582751347558088705,
  "created_at" : "2015-03-31 03:48:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582740894173900801",
  "text" : "im al jorge of the jungle rn on these drums lord have mercy",
  "id" : 582740894173900801,
  "created_at" : "2015-03-31 03:07:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 0, 15 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582669727534850048",
  "geo" : { },
  "id_str" : "582673665700929536",
  "in_reply_to_user_id" : 283708113,
  "text" : "@brownnoiseblog is the music world ready to own their own shit? P2P decentralized soundcloud w\/ bitcoin revenue. the technology is here fam.",
  "id" : 582673665700929536,
  "in_reply_to_status_id" : 582669727534850048,
  "created_at" : "2015-03-30 22:40:02 +0000",
  "in_reply_to_screen_name" : "brownnoiseblog",
  "in_reply_to_user_id_str" : "283708113",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582672539974938624",
  "text" : "well i'm really doing it",
  "id" : 582672539974938624,
  "created_at" : "2015-03-30 22:35:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/jXEnvk1COF",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/donde-el-antidoto",
      "display_url" : "soundcloud.com\/folkstack\/dond\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582604279560585216",
  "text" : "case: you missed it\n \nergo: here it is again, real whatchacall folk music. \"The Antidote\" https:\/\/t.co\/jXEnvk1COF\n\nlet this one ease in  ;^)",
  "id" : 582604279560585216,
  "created_at" : "2015-03-30 18:04:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582468416126132224",
  "text" : "i barely know you",
  "id" : 582468416126132224,
  "created_at" : "2015-03-30 09:04:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/582461877080305666\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/FkKbBfMMcL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBVR_IsVIAA1IGX.jpg",
      "id_str" : "582461871921373184",
      "id" : 582461871921373184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBVR_IsVIAA1IGX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FkKbBfMMcL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582461877080305666",
  "text" : "When u wake up for your next session and its 0130. http:\/\/t.co\/FkKbBfMMcL",
  "id" : 582461877080305666,
  "created_at" : "2015-03-30 08:38:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/jXEnvk1COF",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/donde-el-antidoto",
      "display_url" : "soundcloud.com\/folkstack\/dond\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582348182564171776",
  "text" : "Here ya go.  Raw cut.  Recorded earlier this month.  Love this guitar!  https:\/\/t.co\/jXEnvk1COF",
  "id" : 582348182564171776,
  "created_at" : "2015-03-30 01:06:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/6px5Ve5VY0",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/el-sonido-de-la-hora",
      "display_url" : "soundcloud.com\/folkstack\/el-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582335659123183617",
  "text" : "To put the next cut in context, here's the first recording of the same session: https:\/\/t.co\/6px5Ve5VY0  \n\nWhat follows is the antidote.",
  "id" : 582335659123183617,
  "created_at" : "2015-03-30 00:16:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582329932665135104",
  "text" : "I don't know why i'm sitting on this rare, unedited cut.  I am now gonna upload a groove which is perfect for how you are feeling today.",
  "id" : 582329932665135104,
  "created_at" : "2015-03-29 23:54:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582312315782967296",
  "text" : "Having made adequate synthetic birds chirps, I feel I have gained a level.",
  "id" : 582312315782967296,
  "created_at" : "2015-03-29 22:44:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/582280926048063489\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/1ygomvehkB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBStadtUMAAvzMp.jpg",
      "id_str" : "582280922000535552",
      "id" : 582280922000535552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBStadtUMAAvzMp.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/1ygomvehkB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582280926048063489",
  "text" : "sup http:\/\/t.co\/1ygomvehkB",
  "id" : 582280926048063489,
  "created_at" : "2015-03-29 20:39:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 7, 15 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/gPba64I6kk",
      "expanded_url" : "https:\/\/instagram.com\/p\/00zu9zgfHY\/",
      "display_url" : "instagram.com\/p\/00zu9zgfHY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "582280078723170304",
  "text" : "Yay!  \"@Gyselie: I have just completed my 3rd marathon in 2 weeks for my\u2026 https:\/\/t.co\/gPba64I6kk\"",
  "id" : 582280078723170304,
  "created_at" : "2015-03-29 20:36:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581672796708696064",
  "geo" : { },
  "id_str" : "581677083631341568",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  That Saudi Arabia is now performing outright air-strike offensives in the region does not bode well, methinks.",
  "id" : 581677083631341568,
  "in_reply_to_status_id" : 581672796708696064,
  "created_at" : "2015-03-28 04:39:58 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 13, 24 ],
      "id_str" : "15734539",
      "id" : 15734539
    }, {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "rvagg",
      "indices" : [ 25, 31 ],
      "id_str" : "158704969",
      "id" : 158704969
    }, {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 32, 39 ],
      "id_str" : "668423",
      "id" : 668423
    }, {
      "name" : "Derek Razo",
      "screen_name" : "DerekRazo",
      "indices" : [ 40, 50 ],
      "id_str" : "524788970",
      "id" : 524788970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581663437568106496",
  "geo" : { },
  "id_str" : "581663621626761216",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @FrozenFire @rvagg @mikeal @DerekRazo  pixels pls",
  "id" : 581663621626761216,
  "in_reply_to_status_id" : 581663437568106496,
  "created_at" : "2015-03-28 03:46:28 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 3, 18 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/OlDBGCqLtN",
      "expanded_url" : "http:\/\/dancejs.io",
      "display_url" : "dancejs.io"
    } ]
  },
  "geo" : { },
  "id_str" : "581640114037596160",
  "text" : "RT @oaklanddancejs: the Dance.js block party is only 24-hours away, grab your last minute tickets here: http:\/\/t.co\/OlDBGCqLtN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/OlDBGCqLtN",
        "expanded_url" : "http:\/\/dancejs.io",
        "display_url" : "dancejs.io"
      } ]
    },
    "geo" : { },
    "id_str" : "581615789561630720",
    "text" : "the Dance.js block party is only 24-hours away, grab your last minute tickets here: http:\/\/t.co\/OlDBGCqLtN",
    "id" : 581615789561630720,
    "created_at" : "2015-03-28 00:36:24 +0000",
    "user" : {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "protected" : false,
      "id_str" : "2797358358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508874020683403264\/xB2uWFmY_normal.png",
      "id" : 2797358358,
      "verified" : false
    }
  },
  "id" : 581640114037596160,
  "created_at" : "2015-03-28 02:13:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE",
      "screen_name" : "VICE",
      "indices" : [ 0, 5 ],
      "id_str" : "23818581",
      "id" : 23818581
    }, {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 6, 17 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581573677713588224",
  "geo" : { },
  "id_str" : "581629122750779392",
  "in_reply_to_user_id" : 23818581,
  "text" : "@VICE @grayamelia really good interview!",
  "id" : 581629122750779392,
  "in_reply_to_status_id" : 581573677713588224,
  "created_at" : "2015-03-28 01:29:23 +0000",
  "in_reply_to_screen_name" : "VICE",
  "in_reply_to_user_id_str" : "23818581",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE",
      "screen_name" : "VICE",
      "indices" : [ 3, 8 ],
      "id_str" : "23818581",
      "id" : 23818581
    }, {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 31, 42 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VICE\/status\/581573677713588224\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/VdtqavAEYT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBIqFNLUMAAE8Ik.jpg",
      "id_str" : "581573570809049088",
      "id" : 581573570809049088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBIqFNLUMAAE8Ik.jpg",
      "sizes" : [ {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 469
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 469
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 469
      } ],
      "display_url" : "pic.twitter.com\/VdtqavAEYT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/oKpC69AHKJ",
      "expanded_url" : "http:\/\/bit.ly\/1Nmi8tS",
      "display_url" : "bit.ly\/1Nmi8tS"
    } ]
  },
  "geo" : { },
  "id_str" : "581626741237555200",
  "text" : "RT @VICE: We spoke to novelist @grayamelia about her new book, egomania, &amp; demented, sexy Bible stories: http:\/\/t.co\/oKpC69AHKJ http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amelia Gray",
        "screen_name" : "grayamelia",
        "indices" : [ 21, 32 ],
        "id_str" : "181328570",
        "id" : 181328570
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VICE\/status\/581573677713588224\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/VdtqavAEYT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBIqFNLUMAAE8Ik.jpg",
        "id_str" : "581573570809049088",
        "id" : 581573570809049088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBIqFNLUMAAE8Ik.jpg",
        "sizes" : [ {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 469
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 469
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 469
        } ],
        "display_url" : "pic.twitter.com\/VdtqavAEYT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/oKpC69AHKJ",
        "expanded_url" : "http:\/\/bit.ly\/1Nmi8tS",
        "display_url" : "bit.ly\/1Nmi8tS"
      } ]
    },
    "geo" : { },
    "id_str" : "581573677713588224",
    "text" : "We spoke to novelist @grayamelia about her new book, egomania, &amp; demented, sexy Bible stories: http:\/\/t.co\/oKpC69AHKJ http:\/\/t.co\/VdtqavAEYT",
    "id" : 581573677713588224,
    "created_at" : "2015-03-27 21:49:04 +0000",
    "user" : {
      "name" : "VICE",
      "screen_name" : "VICE",
      "protected" : false,
      "id_str" : "23818581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672036189273120768\/4_Esv2H4_normal.jpg",
      "id" : 23818581,
      "verified" : true
    }
  },
  "id" : 581626741237555200,
  "created_at" : "2015-03-28 01:19:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ellenpao",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581565264338128896",
  "text" : "the jury has found nothing out of the ordinary #ellenpao",
  "id" : 581565264338128896,
  "created_at" : "2015-03-27 21:15:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581551065566318592",
  "text" : "if github is being DDOSed by *some* baidu redirects, then would DDOSing the rest of baidu be a fair counter-measure?  asking for a friend.",
  "id" : 581551065566318592,
  "created_at" : "2015-03-27 20:19:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581541419187191808",
  "geo" : { },
  "id_str" : "581542908391604224",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript   if this gets enuf subtweets I will attempt to crowdfund it, by convincing existing machines with CC data that they need it.",
  "id" : 581542908391604224,
  "in_reply_to_status_id" : 581541419187191808,
  "created_at" : "2015-03-27 19:46:48 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581541419187191808",
  "text" : "Good idea \/ bad idea?  Machinapedia, a wikepedia for machine's learning.",
  "id" : 581541419187191808,
  "created_at" : "2015-03-27 19:40:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dailysynth",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/Whd9EqNS6U",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=c30b90745e17b7c3ddaa",
      "display_url" : "requirebin.com\/?gist=c30b9074\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581540468594376704",
  "text" : "lots of params here.  good luck!  http:\/\/t.co\/Whd9EqNS6U\n\n#dailysynth",
  "id" : 581540468594376704,
  "created_at" : "2015-03-27 19:37:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581538680210395136",
  "geo" : { },
  "id_str" : "581539523810607104",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  the a\/an before words starting with h thing is debatable, but me nuh care either way.  which is to say i am not ambivalent.",
  "id" : 581539523810607104,
  "in_reply_to_status_id" : 581538680210395136,
  "created_at" : "2015-03-27 19:33:21 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/EE3cx2t004",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Graviton",
      "display_url" : "en.wikipedia.org\/wiki\/Graviton"
    } ]
  },
  "in_reply_to_status_id_str" : "581537593579302912",
  "geo" : { },
  "id_str" : "581538680210395136",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  I have edited wikipedia to reflect this.  First line: http:\/\/t.co\/EE3cx2t004",
  "id" : 581538680210395136,
  "in_reply_to_status_id" : 581537593579302912,
  "created_at" : "2015-03-27 19:30:00 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581537593579302912",
  "text" : "One of my least favorite linguistic smartypantsisms the use of \"theoretical\" for the obviously \"hypothetical\".  #science",
  "id" : 581537593579302912,
  "created_at" : "2015-03-27 19:25:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581536029011619840",
  "text" : "a description, or model, is not an explanation  #science",
  "id" : 581536029011619840,
  "created_at" : "2015-03-27 19:19:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581535555923501056",
  "text" : "I have reason to believe that the chinese gobernment are DDOSing my internets personally.",
  "id" : 581535555923501056,
  "created_at" : "2015-03-27 19:17:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/7YHlQFn9eZ",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=6093984",
      "display_url" : "requirebin.com\/?gist=6093984"
    }, {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/2F4EEh2MHv",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=6094039",
      "display_url" : "requirebin.com\/?gist=6094039"
    }, {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Y4hrW2QEJn",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=6094056",
      "display_url" : "requirebin.com\/?gist=6094056"
    }, {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/zjMGZOok3k",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=6110578",
      "display_url" : "requirebin.com\/?gist=6110578"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/lJ8RSz9PIK",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=6094074",
      "display_url" : "requirebin.com\/?gist=6094074"
    } ]
  },
  "in_reply_to_status_id_str" : "581529482332377088",
  "geo" : { },
  "id_str" : "581530538999037952",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon  \nhttp:\/\/t.co\/7YHlQFn9eZ\nhttp:\/\/t.co\/2F4EEh2MHv\nhttp:\/\/t.co\/Y4hrW2QEJn\nhttp:\/\/t.co\/zjMGZOok3k\nhttp:\/\/t.co\/lJ8RSz9PIK",
  "id" : 581530538999037952,
  "in_reply_to_status_id" : 581529482332377088,
  "created_at" : "2015-03-27 18:57:39 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dailysynth",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/Whd9Er5tvu",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=c30b90745e17b7c3ddaa",
      "display_url" : "requirebin.com\/?gist=c30b9074\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581526915779018752",
  "text" : "robododo \n\nhttp:\/\/t.co\/Whd9Er5tvu\n\n#dailysynth",
  "id" : 581526915779018752,
  "created_at" : "2015-03-27 18:43:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 3, 15 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ceinci",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581506687065931776",
  "text" : "RT @vrroanhorse: We try to take a human centered design approach by asking communities what they want before suggesting solutions. \n #ceinci",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/erased4838853.com\" rel=\"nofollow\"\u003Eerased4838853\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ceinci",
        "indices" : [ 116, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581505861169897472",
    "text" : "We try to take a human centered design approach by asking communities what they want before suggesting solutions. \n #ceinci",
    "id" : 581505861169897472,
    "created_at" : "2015-03-27 17:19:35 +0000",
    "user" : {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "protected" : false,
      "id_str" : "557228721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652515840194056193\/vt9WrUY__normal.jpg",
      "id" : 557228721,
      "verified" : false
    }
  },
  "id" : 581506687065931776,
  "created_at" : "2015-03-27 17:22:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581479162096930816",
  "text" : "Selfies are my only consolation lately.",
  "id" : 581479162096930816,
  "created_at" : "2015-03-27 15:33:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/581478750174359552\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NefeV4isbK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBHT1yjUYAAu7Ia.jpg",
      "id_str" : "581478747963940864",
      "id" : 581478747963940864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBHT1yjUYAAu7Ia.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/NefeV4isbK"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/581478750174359552\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NefeV4isbK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBHT10gUQAAppqh.jpg",
      "id_str" : "581478748488220672",
      "id" : 581478748488220672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBHT10gUQAAppqh.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/NefeV4isbK"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/581478750174359552\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NefeV4isbK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBHT14GUcAAbwt-.jpg",
      "id_str" : "581478749452922880",
      "id" : 581478749452922880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBHT14GUcAAbwt-.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/NefeV4isbK"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/581478750174359552\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NefeV4isbK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBHT15MUQAAPFqm.jpg",
      "id_str" : "581478749746511872",
      "id" : 581478749746511872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBHT15MUQAAPFqm.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/NefeV4isbK"
    } ],
    "hashtags" : [ {
      "text" : "human",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581478750174359552",
  "text" : "I was hella depressed yesterday.  So I rolled around on the floor and took some selfies with little bear.  #human http:\/\/t.co\/NefeV4isbK",
  "id" : 581478750174359552,
  "created_at" : "2015-03-27 15:31:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 3, 14 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/vSFOB1pD48",
      "expanded_url" : "https:\/\/vine.co\/v\/O3JxdAumBLB",
      "display_url" : "vine.co\/v\/O3JxdAumBLB"
    } ]
  },
  "geo" : { },
  "id_str" : "581267470058688512",
  "text" : "RT @legittalon: Dat interview flow  https:\/\/t.co\/vSFOB1pD48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/vine.co\" rel=\"nofollow\"\u003EVine for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/vSFOB1pD48",
        "expanded_url" : "https:\/\/vine.co\/v\/O3JxdAumBLB",
        "display_url" : "vine.co\/v\/O3JxdAumBLB"
      } ]
    },
    "geo" : { },
    "id_str" : "581263645700657152",
    "text" : "Dat interview flow  https:\/\/t.co\/vSFOB1pD48",
    "id" : 581263645700657152,
    "created_at" : "2015-03-27 01:17:07 +0000",
    "user" : {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "protected" : false,
      "id_str" : "64105403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516448568706486274\/5oBt_x03_normal.png",
      "id" : 64105403,
      "verified" : false
    }
  },
  "id" : 581267470058688512,
  "created_at" : "2015-03-27 01:32:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/E98VVBrZmV",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=E58qLXBfLrs",
      "display_url" : "youtube.com\/watch?v=E58qLX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581184813371101184",
  "text" : "The overarching problem w the tech industry is that everybody high AF off their fortune &amp; social status, like Kanye https:\/\/t.co\/E98VVBrZmV",
  "id" : 581184813371101184,
  "created_at" : "2015-03-26 20:03:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581183428680425472",
  "text" : "RT @modulhaus3000: Hiring?  Of course you are.  Willing to take on a part time programmer?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581179700233547776",
    "text" : "Hiring?  Of course you are.  Willing to take on a part time programmer?",
    "id" : 581179700233547776,
    "created_at" : "2015-03-26 19:43:32 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 581183428680425472,
  "created_at" : "2015-03-26 19:58:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nodeconf",
      "screen_name" : "nodeconf",
      "indices" : [ 0, 9 ],
      "id_str" : "186697923",
      "id" : 186697923
    }, {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 47, 55 ],
      "id_str" : "185744472",
      "id" : 185744472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581136919376973824",
  "geo" : { },
  "id_str" : "581138496846368768",
  "in_reply_to_user_id" : 46961216,
  "text" : "@nodeconf it wasn't about me tho, it was about @Cabbibo  :^\\",
  "id" : 581138496846368768,
  "in_reply_to_status_id" : 581136919376973824,
  "created_at" : "2015-03-26 16:59:49 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nodeconf",
      "screen_name" : "nodeconf",
      "indices" : [ 22, 31 ],
      "id_str" : "186697923",
      "id" : 186697923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581136919376973824",
  "text" : "Casually browsing the @nodeconf RFP repo, I saw issue 41 \"Code art for the masses\".  I clicked and, behold!, saw my name dropped.  Cuz YEAH",
  "id" : 581136919376973824,
  "created_at" : "2015-03-26 16:53:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "javascript",
      "indices" : [ 113, 124 ]
    }, {
      "text" : "html",
      "indices" : [ 125, 130 ]
    }, {
      "text" : "css",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "oakland",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581123628802019328",
  "text" : "RT @modulhaus3000: Want to upgrade your web dev skills?  Ask us about 1-on-1 or group tutoring in the Bay Area.  #javascript #html #css #no\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "javascript",
        "indices" : [ 94, 105 ]
      }, {
        "text" : "html",
        "indices" : [ 106, 111 ]
      }, {
        "text" : "css",
        "indices" : [ 112, 116 ]
      }, {
        "text" : "nodejs",
        "indices" : [ 117, 124 ]
      }, {
        "text" : "oakland",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581123174181425152",
    "text" : "Want to upgrade your web dev skills?  Ask us about 1-on-1 or group tutoring in the Bay Area.  #javascript #html #css #nodejs #oakland",
    "id" : 581123174181425152,
    "created_at" : "2015-03-26 15:58:56 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 581123628802019328,
  "created_at" : "2015-03-26 16:00:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581117503046209536",
  "text" : "i'm basically playing my fiddle while this ship sinks",
  "id" : 581117503046209536,
  "created_at" : "2015-03-26 15:36:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 3, 14 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581117080407126017",
  "text" : "RT @grayamelia: I quit my job in order to pursue my dream of getting a job somewhere else",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581087724591009792",
    "text" : "I quit my job in order to pursue my dream of getting a job somewhere else",
    "id" : 581087724591009792,
    "created_at" : "2015-03-26 13:38:04 +0000",
    "user" : {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "protected" : false,
      "id_str" : "181328570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542768392499761152\/NN148tlm_normal.png",
      "id" : 181328570,
      "verified" : false
    }
  },
  "id" : 581117080407126017,
  "created_at" : "2015-03-26 15:34:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/PGvuQqyFIH",
      "expanded_url" : "http:\/\/i.imgur.com\/W5VPdQc.jpg",
      "display_url" : "i.imgur.com\/W5VPdQc.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "581116937364643840",
  "text" : "RT @TheHatGhost: Check out this image http:\/\/t.co\/PGvuQqyFIH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/PGvuQqyFIH",
        "expanded_url" : "http:\/\/i.imgur.com\/W5VPdQc.jpg",
        "display_url" : "i.imgur.com\/W5VPdQc.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "581093076573257729",
    "text" : "Check out this image http:\/\/t.co\/PGvuQqyFIH",
    "id" : 581093076573257729,
    "created_at" : "2015-03-26 13:59:20 +0000",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606927351168036864\/lzGOA4HX_normal.jpg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 581116937364643840,
  "created_at" : "2015-03-26 15:34:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580854162247667713",
  "text" : "im running out of images I accidentally created building web apps to use as song cover arts",
  "id" : 580854162247667713,
  "created_at" : "2015-03-25 22:09:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dailySynth",
      "indices" : [ 86, 97 ]
    }, {
      "text" : "music4programming",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2rysIcOywU",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/vibenspiel",
      "display_url" : "soundcloud.com\/folkstack\/vibe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580849961392181248",
  "text" : "today's live code sesh was 193 compiles over 30 minutes.  No beat.  Ambient, chimesy. #dailySynth #music4programming https:\/\/t.co\/2rysIcOywU",
  "id" : 580849961392181248,
  "created_at" : "2015-03-25 21:53:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK LOVE",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 3, 15 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580841992797601792",
  "text" : "RT @JUNGLEPUSSY: YOU NOT BETTER THAN ME CUZ YOU HAVE INVESTORS. MY VISIONS GET EXECUTED OFF SWEAT AND TEARS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580840622015320064",
    "text" : "YOU NOT BETTER THAN ME CUZ YOU HAVE INVESTORS. MY VISIONS GET EXECUTED OFF SWEAT AND TEARS",
    "id" : 580840622015320064,
    "created_at" : "2015-03-25 21:16:10 +0000",
    "user" : {
      "name" : "BLACK LOVE",
      "screen_name" : "JUNGLEPUSSY",
      "protected" : false,
      "id_str" : "15819295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669258125707493376\/F7rYnkx3_normal.jpg",
      "id" : 15819295,
      "verified" : false
    }
  },
  "id" : 580841992797601792,
  "created_at" : "2015-03-25 21:21:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/ZB1GgquVUf",
      "expanded_url" : "http:\/\/node.module.club",
      "display_url" : "node.module.club"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EEGtB87Zqi",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/241d560df4cc4094d512",
      "display_url" : "gist.github.com\/NHQ\/241d560df4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580811180597383168",
  "text" : "a PITA to recover but my live code station http:\/\/t.co\/ZB1GgquVUf saves diffs 4 each compile 4 each session locally  https:\/\/t.co\/EEGtB87Zqi",
  "id" : 580811180597383168,
  "created_at" : "2015-03-25 19:19:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoolReve",
      "screen_name" : "CoolReve",
      "indices" : [ 3, 12 ],
      "id_str" : "310504170",
      "id" : 310504170
    }, {
      "name" : "Nah Right?",
      "screen_name" : "nahright",
      "indices" : [ 15, 24 ],
      "id_str" : "14687772",
      "id" : 14687772
    }, {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "indices" : [ 43, 59 ],
      "id_str" : "87320284",
      "id" : 87320284
    }, {
      "name" : "DelTheFunkyHomosapie",
      "screen_name" : "DelHIERO",
      "indices" : [ 65, 74 ],
      "id_str" : "24143898",
      "id" : 24143898
    }, {
      "name" : "LadybugMecca",
      "screen_name" : "DJLadyMecca",
      "indices" : [ 81, 93 ],
      "id_str" : "358967761",
      "id" : 358967761
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nahright\/status\/580789668377190400\/photo\/1",
      "indices" : [ 147, 148 ],
      "url" : "http:\/\/t.co\/mXnqNB8BLQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA9hHyPVIAEjNyz.jpg",
      "id_str" : "580789663327133697",
      "id" : 580789663327133697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA9hHyPVIAEjNyz.jpg",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/mXnqNB8BLQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/v9QRJUvLkl",
      "expanded_url" : "http:\/\/bit.ly\/18XxeZr",
      "display_url" : "bit.ly\/18XxeZr"
    } ]
  },
  "geo" : { },
  "id_str" : "580796264826081280",
  "text" : "RT @CoolReve: \"@nahright: Video: Kool A.D.(@veeveeveeveevee) ft. @DelHIERO &amp; @DJLadyMecca - \"Life &amp; Time\"  http:\/\/t.co\/v9QRJUvLkl http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nah Right?",
        "screen_name" : "nahright",
        "indices" : [ 1, 10 ],
        "id_str" : "14687772",
        "id" : 14687772
      }, {
        "name" : "KOOL A.D.",
        "screen_name" : "veeveeveeveevee",
        "indices" : [ 29, 45 ],
        "id_str" : "87320284",
        "id" : 87320284
      }, {
        "name" : "DelTheFunkyHomosapie",
        "screen_name" : "DelHIERO",
        "indices" : [ 51, 60 ],
        "id_str" : "24143898",
        "id" : 24143898
      }, {
        "name" : "LadybugMecca",
        "screen_name" : "DJLadyMecca",
        "indices" : [ 67, 79 ],
        "id_str" : "358967761",
        "id" : 358967761
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nahright\/status\/580789668377190400\/photo\/1",
        "indices" : [ 124, 146 ],
        "url" : "http:\/\/t.co\/mXnqNB8BLQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CA9hHyPVIAEjNyz.jpg",
        "id_str" : "580789663327133697",
        "id" : 580789663327133697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA9hHyPVIAEjNyz.jpg",
        "sizes" : [ {
          "h" : 484,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/mXnqNB8BLQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/v9QRJUvLkl",
        "expanded_url" : "http:\/\/bit.ly\/18XxeZr",
        "display_url" : "bit.ly\/18XxeZr"
      } ]
    },
    "geo" : { },
    "id_str" : "580793397037821952",
    "text" : "\"@nahright: Video: Kool A.D.(@veeveeveeveevee) ft. @DelHIERO &amp; @DJLadyMecca - \"Life &amp; Time\"  http:\/\/t.co\/v9QRJUvLkl http:\/\/t.co\/mXnqNB8BLQ\"",
    "id" : 580793397037821952,
    "created_at" : "2015-03-25 18:08:31 +0000",
    "user" : {
      "name" : "CoolReve",
      "screen_name" : "CoolReve",
      "protected" : false,
      "id_str" : "310504170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709250891140829185\/06J1e_1p_normal.jpg",
      "id" : 310504170,
      "verified" : false
    }
  },
  "id" : 580796264826081280,
  "created_at" : "2015-03-25 18:19:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580787934783094784",
  "text" : "Happily expending my energy expressing supersuperlatives on people I love, admire and cococonspire.",
  "id" : 580787934783094784,
  "created_at" : "2015-03-25 17:46:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580783689656717312",
  "text" : "A Scientard.",
  "id" : 580783689656717312,
  "created_at" : "2015-03-25 17:29:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580783654323908608",
  "text" : "A Wizard, A True Scientist.",
  "id" : 580783654323908608,
  "created_at" : "2015-03-25 17:29:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5YcEdaJaKZ",
      "expanded_url" : "http:\/\/modulha.us\/agency",
      "display_url" : "modulha.us\/agency"
    } ]
  },
  "geo" : { },
  "id_str" : "580769796905525248",
  "text" : "RT @modulhaus3000: Are you indie open source developer?  Creative programmer?  How can we assist you? give us your thoughts.  see also:  ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/5YcEdaJaKZ",
        "expanded_url" : "http:\/\/modulha.us\/agency",
        "display_url" : "modulha.us\/agency"
      } ]
    },
    "geo" : { },
    "id_str" : "580766402732126210",
    "text" : "Are you indie open source developer?  Creative programmer?  How can we assist you? give us your thoughts.  see also:  http:\/\/t.co\/5YcEdaJaKZ",
    "id" : 580766402732126210,
    "created_at" : "2015-03-25 16:21:15 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 580769796905525248,
  "created_at" : "2015-03-25 16:34:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    }, {
      "name" : "Udacity",
      "screen_name" : "udacity",
      "indices" : [ 19, 27 ],
      "id_str" : "326912209",
      "id" : 326912209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580769424954658817",
  "text" : "RT @modulhaus3000: @udacity  very few people can make actual working complex apps in only ten hours.  modulhaus  archagents are among those\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Udacity",
        "screen_name" : "udacity",
        "indices" : [ 0, 8 ],
        "id_str" : "326912209",
        "id" : 326912209
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "578580966848888832",
    "geo" : { },
    "id_str" : "580767056108204032",
    "in_reply_to_user_id" : 326912209,
    "text" : "@udacity  very few people can make actual working complex apps in only ten hours.  modulhaus  archagents are among those few.",
    "id" : 580767056108204032,
    "in_reply_to_status_id" : 578580966848888832,
    "created_at" : "2015-03-25 16:23:50 +0000",
    "in_reply_to_screen_name" : "udacity",
    "in_reply_to_user_id_str" : "326912209",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 580769424954658817,
  "created_at" : "2015-03-25 16:33:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 3, 14 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580762792099119104",
  "text" : "RT @whichlight: @johnnyscript how to use beat drops in your story arc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "580761957063491586",
    "geo" : { },
    "id_str" : "580762689460412417",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript how to use beat drops in your story arc",
    "id" : 580762689460412417,
    "in_reply_to_status_id" : 580761957063491586,
    "created_at" : "2015-03-25 16:06:29 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "protected" : false,
      "id_str" : "17092251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582894470452133888\/uBlV4V8-_normal.jpg",
      "id" : 17092251,
      "verified" : false
    }
  },
  "id" : 580762792099119104,
  "created_at" : "2015-03-25 16:06:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580759140827549696",
  "geo" : { },
  "id_str" : "580761957063491586",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  ur so newsiemo",
  "id" : 580761957063491586,
  "in_reply_to_status_id" : 580759140827549696,
  "created_at" : "2015-03-25 16:03:35 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580760946865377280",
  "text" : "accept me as my avatar",
  "id" : 580760946865377280,
  "created_at" : "2015-03-25 15:59:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "Vox Media",
      "screen_name" : "voxmediainc",
      "indices" : [ 12, 24 ],
      "id_str" : "386175131",
      "id" : 386175131
    }, {
      "name" : "Embedly",
      "screen_name" : "embedly",
      "indices" : [ 25, 33 ],
      "id_str" : "82485597",
      "id" : 82485597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580752450883309568",
  "geo" : { },
  "id_str" : "580757890446671872",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight @voxmediainc @embedly  ambient storytelling?  what's next, shoegaze news?",
  "id" : 580757890446671872,
  "in_reply_to_status_id" : 580752450883309568,
  "created_at" : "2015-03-25 15:47:25 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580614301003726849",
  "text" : "yo necesito bebir la chicha",
  "id" : 580614301003726849,
  "created_at" : "2015-03-25 06:16:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580550436496764928",
  "text" : "TIL TTL DIY",
  "id" : 580550436496764928,
  "created_at" : "2015-03-25 02:03:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580547391570448384",
  "geo" : { },
  "id_str" : "580550288161017856",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  idk why I ask, I'm cursed to do it all myself DIY TILL I DIE",
  "id" : 580550288161017856,
  "in_reply_to_status_id" : 580547391570448384,
  "created_at" : "2015-03-25 02:02:29 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580547391570448384",
  "text" : "Anybody know an indie music label that would be a good fit for algo music and artistry, with live band?  I can't sit on this much longer.",
  "id" : 580547391570448384,
  "created_at" : "2015-03-25 01:50:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580545514330054657",
  "text" : "I don't know what's worse, google autosuggesting inane-related searches, or twitter autosuggesting some stranger every word I type.",
  "id" : 580545514330054657,
  "created_at" : "2015-03-25 01:43:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580498005599600640",
  "text" : "inbox zero for your bowels",
  "id" : 580498005599600640,
  "created_at" : "2015-03-24 22:34:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edm",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "edm",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580493944758374401",
  "text" : "#edm is 1990's b side pop songs set to a techno beat.  #edm is technobro.",
  "id" : 580493944758374401,
  "created_at" : "2015-03-24 22:18:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 0, 6 ],
      "id_str" : "15453",
      "id" : 15453
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 7, 11 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571453200093437952",
  "geo" : { },
  "id_str" : "580493641162104833",
  "in_reply_to_user_id" : 15453,
  "text" : "@seldo @izs  module.sexports",
  "id" : 580493641162104833,
  "in_reply_to_status_id" : 571453200093437952,
  "created_at" : "2015-03-24 22:17:23 +0000",
  "in_reply_to_screen_name" : "seldo",
  "in_reply_to_user_id_str" : "15453",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "algowave",
      "indices" : [ 11, 20 ]
    }, {
      "text" : "dailySynth",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/tPLumouSNO",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=9ddc27207ae05c2af57d",
      "display_url" : "requirebin.com\/?gist=9ddc2720\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580477913956519936",
  "text" : "More fresh #algowave.  Jus working sum overtone distributions.  Hear these groovy vibes!  #dailySynth\n\nhttp:\/\/t.co\/tPLumouSNO",
  "id" : 580477913956519936,
  "created_at" : "2015-03-24 21:14:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/1gEuToxVVF",
      "expanded_url" : "https:\/\/system76.com\/laptops\/galago",
      "display_url" : "system76.com\/laptops\/galago"
    } ]
  },
  "in_reply_to_status_id_str" : "580470196630089729",
  "geo" : { },
  "id_str" : "580472674482257920",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon i got one of these, have been very happy with it https:\/\/t.co\/1gEuToxVVF",
  "id" : 580472674482257920,
  "in_reply_to_status_id" : 580470196630089729,
  "created_at" : "2015-03-24 20:54:04 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mystery",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580426529907298305",
  "text" : "I wrote these timing algorithm, gave them swing params, and but they always have to warm up a few rounds before they settle into it #mystery",
  "id" : 580426529907298305,
  "created_at" : "2015-03-24 17:50:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dailySynth",
      "indices" : [ 117, 128 ]
    }, {
      "text" : "algofolk",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/rdu6SIeckC",
      "expanded_url" : "https:\/\/youtu.be\/sCW5ukgbQxI?t=10m30s",
      "display_url" : "youtu.be\/sCW5ukgbQxI?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580384125917364224",
  "text" : "First thing I did this morning was practice muh live coded music. Not bad for an exercise:  https:\/\/t.co\/rdu6SIeckC  #dailySynth #algofolk",
  "id" : 580384125917364224,
  "created_at" : "2015-03-24 15:02:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shiftEnter",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ZB1GgquVUf",
      "expanded_url" : "http:\/\/node.module.club",
      "display_url" : "node.module.club"
    } ]
  },
  "geo" : { },
  "id_str" : "580375492852740096",
  "text" : "I should upgrade my browserify async require live code app with more features but nah http:\/\/t.co\/ZB1GgquVUf #shiftEnter",
  "id" : 580375492852740096,
  "created_at" : "2015-03-24 14:27:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580236198502748160",
  "text" : "Cowboy Bebop is singing my life slowly with its songs.",
  "id" : 580236198502748160,
  "created_at" : "2015-03-24 05:14:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/o1rIjrK6Sl",
      "expanded_url" : "http:\/\/www.theatlantic.com\/politics\/archive\/2015\/03\/The-Gangsters-Of-Ferguson\/386893\/?utm_source=btn-twitter-ctrl1",
      "display_url" : "theatlantic.com\/politics\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580174984078741504",
  "text" : "Anytown, USA  http:\/\/t.co\/o1rIjrK6Sl",
  "id" : 580174984078741504,
  "created_at" : "2015-03-24 01:11:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Roy",
      "screen_name" : "JessicaKRoy",
      "indices" : [ 3, 15 ],
      "id_str" : "22278197",
      "id" : 22278197
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JessicaKRoy\/status\/578955470876094464\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/iYO8anlMmj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjc7r4XEAAlv6B.jpg",
      "id_str" : "578955470066618368",
      "id" : 578955470066618368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjc7r4XEAAlv6B.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 529
      } ],
      "display_url" : "pic.twitter.com\/iYO8anlMmj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/xIEJ0d0OrE",
      "expanded_url" : "http:\/\/nymag.com\/daily\/intelligencer\/2015\/03\/college-catalogue-shows-white-men-winning-it-all.html",
      "display_url" : "nymag.com\/daily\/intellig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579984211790032897",
  "text" : "RT @JessicaKRoy: University Catalog Cover Accidentally Becomes Perfect Metaphor for America http:\/\/t.co\/xIEJ0d0OrE http:\/\/t.co\/iYO8anlMmj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JessicaKRoy\/status\/578955470876094464\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/iYO8anlMmj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjc7r4XEAAlv6B.jpg",
        "id_str" : "578955470066618368",
        "id" : 578955470066618368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjc7r4XEAAlv6B.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 529
        } ],
        "display_url" : "pic.twitter.com\/iYO8anlMmj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/xIEJ0d0OrE",
        "expanded_url" : "http:\/\/nymag.com\/daily\/intelligencer\/2015\/03\/college-catalogue-shows-white-men-winning-it-all.html",
        "display_url" : "nymag.com\/daily\/intellig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578955470876094464",
    "text" : "University Catalog Cover Accidentally Becomes Perfect Metaphor for America http:\/\/t.co\/xIEJ0d0OrE http:\/\/t.co\/iYO8anlMmj",
    "id" : 578955470876094464,
    "created_at" : "2015-03-20 16:25:15 +0000",
    "user" : {
      "name" : "Jessica Roy",
      "screen_name" : "JessicaKRoy",
      "protected" : false,
      "id_str" : "22278197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704370711398199296\/iY4tTMcW_normal.jpg",
      "id" : 22278197,
      "verified" : true
    }
  },
  "id" : 579984211790032897,
  "created_at" : "2015-03-23 12:33:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/m8Xif8iwxq",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/groove-n-is-the-heart",
      "display_url" : "soundcloud.com\/johnnyscript\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579805781077282818",
  "text" : "play this javascript \/ midi \/ live recorded cover song for the hundred and first time https:\/\/t.co\/m8Xif8iwxq",
  "id" : 579805781077282818,
  "created_at" : "2015-03-23 00:44:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579800510070296576",
  "text" : "I just realized that this body bag I got is a replacement for twitter.",
  "id" : 579800510070296576,
  "created_at" : "2015-03-23 00:23:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579797131638116352",
  "text" : "I discovered a new acronym.  WITS:  which is to say",
  "id" : 579797131638116352,
  "created_at" : "2015-03-23 00:09:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene - Our Oakland",
      "screen_name" : "DIYGene",
      "indices" : [ 0, 8 ],
      "id_str" : "90479930",
      "id" : 90479930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579794019896541184",
  "geo" : { },
  "id_str" : "579795530068307968",
  "in_reply_to_user_id" : 90479930,
  "text" : "@DIYGene  I think all parentheticals are digressions, cuz syntax",
  "id" : 579795530068307968,
  "in_reply_to_status_id" : 579794019896541184,
  "created_at" : "2015-03-23 00:03:21 +0000",
  "in_reply_to_screen_name" : "DIYGene",
  "in_reply_to_user_id_str" : "90479930",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579795061329698817",
  "text" : "The fact that untold millions of people post basically unedited shit to the internet is perhaps the greatest argument against copyrights.",
  "id" : 579795061329698817,
  "created_at" : "2015-03-23 00:01:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579794618138537984",
  "text" : "Everything you put in a parenthesis is skippable garbage.  Oh, it was important?  Separate your thoughts and make meaningful sentences.",
  "id" : 579794618138537984,
  "created_at" : "2015-03-22 23:59:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene - Our Oakland",
      "screen_name" : "DIYGene",
      "indices" : [ 3, 11 ],
      "id_str" : "90479930",
      "id" : 90479930
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 13, 26 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579794165518610432",
  "text" : "RT @DIYGene: @johnnyscript do not put digressions (parenthetical or otherwise) in the middle of a sentence...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "579792464451522560",
    "geo" : { },
    "id_str" : "579794019896541184",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript do not put digressions (parenthetical or otherwise) in the middle of a sentence...",
    "id" : 579794019896541184,
    "in_reply_to_status_id" : 579792464451522560,
    "created_at" : "2015-03-22 23:57:21 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Gene - Our Oakland",
      "screen_name" : "DIYGene",
      "protected" : false,
      "id_str" : "90479930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656265936257716224\/M4rE9jcl_normal.jpg",
      "id" : 90479930,
      "verified" : false
    }
  },
  "id" : 579794165518610432,
  "created_at" : "2015-03-22 23:57:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 3, 14 ],
      "id_str" : "64105403",
      "id" : 64105403
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579793377308250112",
  "text" : "RT @legittalon: @johnnyscript I dig it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "579793172202569728",
    "geo" : { },
    "id_str" : "579793246966009856",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript I dig it.",
    "id" : 579793246966009856,
    "in_reply_to_status_id" : 579793172202569728,
    "created_at" : "2015-03-22 23:54:16 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "protected" : false,
      "id_str" : "64105403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516448568706486274\/5oBt_x03_normal.png",
      "id" : 64105403,
      "verified" : false
    }
  },
  "id" : 579793377308250112,
  "created_at" : "2015-03-22 23:54:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 3, 14 ],
      "id_str" : "64105403",
      "id" : 64105403
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579793368219176960",
  "text" : "RT @legittalon: @johnnyscript which writer is that?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "579792464451522560",
    "geo" : { },
    "id_str" : "579792985925156864",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript which writer is that?",
    "id" : 579792985925156864,
    "in_reply_to_status_id" : 579792464451522560,
    "created_at" : "2015-03-22 23:53:14 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "protected" : false,
      "id_str" : "64105403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516448568706486274\/5oBt_x03_normal.png",
      "id" : 64105403,
      "verified" : false
    }
  },
  "id" : 579793368219176960,
  "created_at" : "2015-03-22 23:54:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579792464451522560",
  "geo" : { },
  "id_str" : "579793304235028480",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  every writer who reads this should give me 3 credits worth of college tuition money and unending gracious thankings.",
  "id" : 579793304235028480,
  "in_reply_to_status_id" : 579792464451522560,
  "created_at" : "2015-03-22 23:54:30 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 12, 25 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579792985925156864",
  "geo" : { },
  "id_str" : "579793172202569728",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon @johnnyscript",
  "id" : 579793172202569728,
  "in_reply_to_status_id" : 579792985925156864,
  "created_at" : "2015-03-22 23:53:58 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579792464451522560",
  "text" : "Here: a pro writer tip from one of the best writers ever lived.  Do not put parenthetical digressions in the middle of a sentence.",
  "id" : 579792464451522560,
  "created_at" : "2015-03-22 23:51:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579790795835768832",
  "text" : "god damn nobody can write for shit how am I supposed to follow",
  "id" : 579790795835768832,
  "created_at" : "2015-03-22 23:44:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579789170236735488",
  "text" : "im fundefined",
  "id" : 579789170236735488,
  "created_at" : "2015-03-22 23:38:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579788710440370176",
  "text" : "few things make me as happy as my lil singing bear",
  "id" : 579788710440370176,
  "created_at" : "2015-03-22 23:36:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keegan Stephan",
      "screen_name" : "KeeganNYC",
      "indices" : [ 3, 13 ],
      "id_str" : "93879982",
      "id" : 93879982
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/KeeganNYC\/status\/579708110836768768\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/eGTEZ939fl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAuJcrSWcAA_I2m.jpg",
      "id_str" : "579708102796275712",
      "id" : 579708102796275712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAuJcrSWcAA_I2m.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eGTEZ939fl"
    } ],
    "hashtags" : [ {
      "text" : "JohnCollado",
      "indices" : [ 29, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579741818134261760",
  "text" : "RT @KeeganNYC: 9 facts about #JohnCollado, unarmed, shot &amp; killed by NYPD cop who didn't identify himself as John broke up a fight. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/KeeganNYC\/status\/579708110836768768\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/eGTEZ939fl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAuJcrSWcAA_I2m.jpg",
        "id_str" : "579708102796275712",
        "id" : 579708102796275712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAuJcrSWcAA_I2m.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/eGTEZ939fl"
      } ],
      "hashtags" : [ {
        "text" : "JohnCollado",
        "indices" : [ 14, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "579708110836768768",
    "text" : "9 facts about #JohnCollado, unarmed, shot &amp; killed by NYPD cop who didn't identify himself as John broke up a fight. http:\/\/t.co\/eGTEZ939fl",
    "id" : 579708110836768768,
    "created_at" : "2015-03-22 18:15:58 +0000",
    "user" : {
      "name" : "Keegan Stephan",
      "screen_name" : "KeeganNYC",
      "protected" : false,
      "id_str" : "93879982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696764273687715843\/7DcwCFz3_normal.png",
      "id" : 93879982,
      "verified" : false
    }
  },
  "id" : 579741818134261760,
  "created_at" : "2015-03-22 20:29:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "what",
      "indices" : [ 12, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579678714360803328",
  "text" : "httpgeebees #what",
  "id" : 579678714360803328,
  "created_at" : "2015-03-22 16:19:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avinash",
      "screen_name" : "avinashtn",
      "indices" : [ 0, 10 ],
      "id_str" : "16806380",
      "id" : 16806380
    }, {
      "name" : "Jan Vlnas",
      "screen_name" : "janvlnas",
      "indices" : [ 11, 20 ],
      "id_str" : "244909101",
      "id" : 244909101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579504319407353856",
  "geo" : { },
  "id_str" : "579672236203712512",
  "in_reply_to_user_id" : 16806380,
  "text" : "@avinashtn @janvlnas  success!",
  "id" : 579672236203712512,
  "in_reply_to_status_id" : 579504319407353856,
  "created_at" : "2015-03-22 15:53:25 +0000",
  "in_reply_to_screen_name" : "avinashtn",
  "in_reply_to_user_id_str" : "16806380",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 3, 11 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/KmtdvG0Gml",
      "expanded_url" : "https:\/\/instagram.com\/p\/0iIwZTgfAI\/",
      "display_url" : "instagram.com\/p\/0iIwZTgfAI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "579658365686579200",
  "text" : "RT @Gyselie: #oakland marathon @ The Oakland Marathon https:\/\/t.co\/KmtdvG0Gml",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oakland",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/KmtdvG0Gml",
        "expanded_url" : "https:\/\/instagram.com\/p\/0iIwZTgfAI\/",
        "display_url" : "instagram.com\/p\/0iIwZTgfAI\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.795554204, -122.207031008 ]
    },
    "id_str" : "579651296782880768",
    "text" : "#oakland marathon @ The Oakland Marathon https:\/\/t.co\/KmtdvG0Gml",
    "id" : 579651296782880768,
    "created_at" : "2015-03-22 14:30:13 +0000",
    "user" : {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "protected" : false,
      "id_str" : "433715578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469656620155154432\/1XOA8tYu_normal.jpeg",
      "id" : 433715578,
      "verified" : false
    }
  },
  "id" : 579658365686579200,
  "created_at" : "2015-03-22 14:58:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 0, 8 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579658298720309248",
  "in_reply_to_user_id" : 433715578,
  "text" : "@Gyselie's running her 25th marathon!  #oakland",
  "id" : 579658298720309248,
  "created_at" : "2015-03-22 14:58:02 +0000",
  "in_reply_to_screen_name" : "Gyselie",
  "in_reply_to_user_id_str" : "433715578",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579314499175366656",
  "geo" : { },
  "id_str" : "579330456887275520",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  We were arrested by the hundreds in Chicago.  I was detained 24 hours.  All suspected a federal coordinated anti-protest.",
  "id" : 579330456887275520,
  "in_reply_to_status_id" : 579314499175366656,
  "created_at" : "2015-03-21 17:15:19 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579207341872013312",
  "text" : "career sites and dating sites should trade",
  "id" : 579207341872013312,
  "created_at" : "2015-03-21 09:06:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ijeoma Oluo",
      "screen_name" : "IjeomaOluo",
      "indices" : [ 3, 14 ],
      "id_str" : "427505253",
      "id" : 427505253
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/IjeomaOluo\/status\/579158021869297664\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/iuKinikjIf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAmVFUrUwAA7vYz.jpg",
      "id_str" : "579157945776128000",
      "id" : 579157945776128000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAmVFUrUwAA7vYz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iuKinikjIf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579206021475799040",
  "text" : "RT @IjeomaOluo: If someone asks why you aren't married http:\/\/t.co\/iuKinikjIf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/IjeomaOluo\/status\/579158021869297664\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/iuKinikjIf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAmVFUrUwAA7vYz.jpg",
        "id_str" : "579157945776128000",
        "id" : 579157945776128000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAmVFUrUwAA7vYz.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iuKinikjIf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "579158021869297664",
    "text" : "If someone asks why you aren't married http:\/\/t.co\/iuKinikjIf",
    "id" : 579158021869297664,
    "created_at" : "2015-03-21 05:50:07 +0000",
    "user" : {
      "name" : "Ijeoma Oluo",
      "screen_name" : "IjeomaOluo",
      "protected" : false,
      "id_str" : "427505253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718980437725413376\/ou_OdklL_normal.jpg",
      "id" : 427505253,
      "verified" : false
    }
  },
  "id" : 579206021475799040,
  "created_at" : "2015-03-21 09:00:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579144340070526977",
  "geo" : { },
  "id_str" : "579145031442776064",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nCase in Point, one I make often.  It's simple for anybody to write a mobile app with full device access.  Not so w HTML5IVES",
  "id" : 579145031442776064,
  "in_reply_to_status_id" : 579144340070526977,
  "created_at" : "2015-03-21 04:58:30 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Vlnas",
      "screen_name" : "janvlnas",
      "indices" : [ 0, 9 ],
      "id_str" : "244909101",
      "id" : 244909101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579143838440243200",
  "geo" : { },
  "id_str" : "579144560464384001",
  "in_reply_to_user_id" : 244909101,
  "text" : "@janvlnas  What about mozilla?  Do you mean their browser, or the hundred other semi-unrelated projects keeping them from pushing the bar?",
  "id" : 579144560464384001,
  "in_reply_to_status_id" : 579143838440243200,
  "created_at" : "2015-03-21 04:56:37 +0000",
  "in_reply_to_screen_name" : "janvlnas",
  "in_reply_to_user_id_str" : "244909101",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579143684395913216",
  "geo" : { },
  "id_str" : "579144340070526977",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nVendors effectively made mobile OSes the target, cuz short term profits, leaving browser specs to creep along.",
  "id" : 579144340070526977,
  "in_reply_to_status_id" : 579143684395913216,
  "created_at" : "2015-03-21 04:55:45 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579143460986327041",
  "geo" : { },
  "id_str" : "579143684395913216",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nDon't get me wrong, I am in favor of open standards.  The standards are not moving fast enough.  Browser are behind mobile!",
  "id" : 579143684395913216,
  "in_reply_to_status_id" : 579143460986327041,
  "created_at" : "2015-03-21 04:53:08 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579143460986327041",
  "text" : "Incompatibilities are a sign of evolution.  Browsers aren't incompatible enough.",
  "id" : 579143460986327041,
  "created_at" : "2015-03-21 04:52:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579142850304036864",
  "text" : "since browsers are basically becoming the de facto OS, we need the Linux variations of web browsers.",
  "id" : 579142850304036864,
  "created_at" : "2015-03-21 04:49:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579129706710114305",
  "geo" : { },
  "id_str" : "579142033966653440",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript im sayin a browser developed in the open, no corporate parent to ossify legacy crap.  Free and open innovation sans blockages.",
  "id" : 579142033966653440,
  "in_reply_to_status_id" : 579129706710114305,
  "created_at" : "2015-03-21 04:46:35 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579129706710114305",
  "text" : "we need a browser that is to browsers what io.js is to node.js",
  "id" : 579129706710114305,
  "created_at" : "2015-03-21 03:57:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/RtAEi0eYGm",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=V869xTCYSHw",
      "display_url" : "youtube.com\/watch?v=V869xT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579077903842877442",
  "text" : "aqui, tenga unas palomitas https:\/\/t.co\/RtAEi0eYGm",
  "id" : 579077903842877442,
  "created_at" : "2015-03-21 00:31:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579071289186381826",
  "text" : "append only typing",
  "id" : 579071289186381826,
  "created_at" : "2015-03-21 00:05:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/wJFY2FJFbu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Nv_HQuDTZso",
      "display_url" : "youtube.com\/watch?v=Nv_HQu\u2026"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/6px5Ve5VY0",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/el-sonido-de-la-hora",
      "display_url" : "soundcloud.com\/folkstack\/el-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579070584270684160",
  "text" : "if you like enjoy (and you will)\nhttps:\/\/t.co\/wJFY2FJFbu\nyou'll [insert feeling here] what I did with it\nhttps:\/\/t.co\/6px5Ve5VY0",
  "id" : 579070584270684160,
  "created_at" : "2015-03-21 00:02:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chicha",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/rAkQsoTX38",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=cokEBMfwRNQ",
      "display_url" : "youtube.com\/watch?v=cokEBM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579068078123720704",
  "text" : "the hungry song https:\/\/t.co\/rAkQsoTX38  #chicha",
  "id" : 579068078123720704,
  "created_at" : "2015-03-20 23:52:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/ddmxmNcCfZ",
      "expanded_url" : "http:\/\/greenwoodrhythmcoalition.bandcamp.com\/track\/colombia",
      "display_url" : "greenwoodrhythmcoalition.bandcamp.com\/track\/colombia"
    } ]
  },
  "geo" : { },
  "id_str" : "579054244717711360",
  "text" : "yehaw http:\/\/t.co\/ddmxmNcCfZ",
  "id" : 579054244717711360,
  "created_at" : "2015-03-20 22:57:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ZA0qxBKLsY",
      "expanded_url" : "http:\/\/www.eastbayexpress.com\/oakland\/california-targets-wrong-water-wasters\/Content?oid=4222724",
      "display_url" : "eastbayexpress.com\/oakland\/califo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579011985477541888",
  "text" : "RT @marinakukso: \"California Targets Wrong Water Wasters\" http:\/\/t.co\/ZA0qxBKLsY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/ZA0qxBKLsY",
        "expanded_url" : "http:\/\/www.eastbayexpress.com\/oakland\/california-targets-wrong-water-wasters\/Content?oid=4222724",
        "display_url" : "eastbayexpress.com\/oakland\/califo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "579010192806944768",
    "text" : "\"California Targets Wrong Water Wasters\" http:\/\/t.co\/ZA0qxBKLsY",
    "id" : 579010192806944768,
    "created_at" : "2015-03-20 20:02:42 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 579011985477541888,
  "created_at" : "2015-03-20 20:09:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bandcamp",
      "screen_name" : "Bandcamp",
      "indices" : [ 0, 9 ],
      "id_str" : "16705752",
      "id" : 16705752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578598413979127808",
  "geo" : { },
  "id_str" : "578599274356830208",
  "in_reply_to_user_id" : 16705752,
  "text" : "@Bandcamp  hey that means you can start streaming at a decent quality instead of that awful sad 128 bitrate you stream at now!",
  "id" : 578599274356830208,
  "in_reply_to_status_id" : 578598413979127808,
  "created_at" : "2015-03-19 16:49:51 +0000",
  "in_reply_to_screen_name" : "Bandcamp",
  "in_reply_to_user_id_str" : "16705752",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "fruitvale",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578448648213798912",
  "text" : "many extra shots fired tonight, popped off slowly #oakland #fruitvale",
  "id" : 578448648213798912,
  "created_at" : "2015-03-19 06:51:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 0, 11 ],
      "id_str" : "15734539",
      "id" : 15734539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578246173829521408",
  "geo" : { },
  "id_str" : "578247579776897024",
  "in_reply_to_user_id" : 15734539,
  "text" : "@FrozenFire  \ndon't \npush \nme\ncuz \ni'm \nclose \nto\nedge\ncases",
  "id" : 578247579776897024,
  "in_reply_to_status_id" : 578246173829521408,
  "created_at" : "2015-03-18 17:32:20 +0000",
  "in_reply_to_screen_name" : "FrozenFire",
  "in_reply_to_user_id_str" : "15734539",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 133, 140 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 139, 140 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578246148965539840",
  "text" : "RT @modulhaus3000: Is your architecture service oriented?  Design ahead, and have one of your a service built by Modulhaus.  Contact @subst\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "substack",
        "screen_name" : "substack",
        "indices" : [ 114, 123 ],
        "id_str" : "125027291",
        "id" : 125027291
      }, {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 127, 140 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "578246012361297920",
    "text" : "Is your architecture service oriented?  Design ahead, and have one of your a service built by Modulhaus.  Contact @substack or @johnnyscript",
    "id" : 578246012361297920,
    "created_at" : "2015-03-18 17:26:07 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 578246148965539840,
  "created_at" : "2015-03-18 17:26:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/6px5Ve5VY0",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/el-sonido-de-la-hora",
      "display_url" : "soundcloud.com\/folkstack\/el-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578113364758437888",
  "text" : "El Sonido de la hora  \n\nhttps:\/\/t.co\/6px5Ve5VY0",
  "id" : 578113364758437888,
  "created_at" : "2015-03-18 08:39:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Ary",
      "screen_name" : "John_Ary",
      "indices" : [ 3, 12 ],
      "id_str" : "116096952",
      "id" : 116096952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSW",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/73Hb2RkRul",
      "expanded_url" : "http:\/\/www.latina.com\/lifestyle\/our-issues\/austin-landlords-demolish-pinata-store-jumpolin-sxsw-party",
      "display_url" : "latina.com\/lifestyle\/our-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578045270002311169",
  "text" : "RT @John_Ary: Landlords demolished a family's business without their knowledge to make room for a #SXSW party.  http:\/\/t.co\/73Hb2RkRul",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSW",
        "indices" : [ 84, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/73Hb2RkRul",
        "expanded_url" : "http:\/\/www.latina.com\/lifestyle\/our-issues\/austin-landlords-demolish-pinata-store-jumpolin-sxsw-party",
        "display_url" : "latina.com\/lifestyle\/our-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577915166500638720",
    "text" : "Landlords demolished a family's business without their knowledge to make room for a #SXSW party.  http:\/\/t.co\/73Hb2RkRul",
    "id" : 577915166500638720,
    "created_at" : "2015-03-17 19:31:27 +0000",
    "user" : {
      "name" : "John Ary",
      "screen_name" : "John_Ary",
      "protected" : false,
      "id_str" : "116096952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632195162999926784\/OK2lLh8k_normal.jpg",
      "id" : 116096952,
      "verified" : false
    }
  },
  "id" : 578045270002311169,
  "created_at" : "2015-03-18 04:08:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578022114910818305",
  "text" : "If you ever wanna \ncheck out my heart\n\nThis has been half a lyric.",
  "id" : 578022114910818305,
  "created_at" : "2015-03-18 02:36:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/nNzEIa68wr",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/surfin-george",
      "display_url" : "soundcloud.com\/folkstack\/surf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578007165794795520",
  "text" : "The image for this song is a screencap of a CSS 3D experiment I wrote a long time ago.  an actual font stack.\n\nhttps:\/\/t.co\/nNzEIa68wr",
  "id" : 578007165794795520,
  "created_at" : "2015-03-18 01:37:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 50, 59 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/LeFemO8R2l",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/lotr-the-missing-poop-break-montages",
      "display_url" : "soundcloud.com\/folkstack\/lotr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578006601182789634",
  "text" : "LOTR:  The Missing Poop Break Montages, by me and @substack \nhttps:\/\/t.co\/LeFemO8R2l",
  "id" : 578006601182789634,
  "created_at" : "2015-03-18 01:34:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577932738113638400",
  "text" : "If the internet was a game of cards, there would be a card called One Weird Trick, and you could play it on anything.",
  "id" : 577932738113638400,
  "created_at" : "2015-03-17 20:41:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577683220906393600",
  "geo" : { },
  "id_str" : "577691182794289152",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  i'm scared I want off!",
  "id" : 577691182794289152,
  "in_reply_to_status_id" : 577683220906393600,
  "created_at" : "2015-03-17 04:41:25 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/AlanBZqua5",
      "expanded_url" : "http:\/\/studio.substack.net\/-\/recent",
      "display_url" : "studio.substack.net\/-\/recent"
    } ]
  },
  "geo" : { },
  "id_str" : "577679862799806464",
  "text" : "RT @substack: taught kids how to make code music today at the library for teen week: http:\/\/t.co\/AlanBZqua5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/AlanBZqua5",
        "expanded_url" : "http:\/\/studio.substack.net\/-\/recent",
        "display_url" : "studio.substack.net\/-\/recent"
      } ]
    },
    "geo" : { },
    "id_str" : "577676568765435905",
    "text" : "taught kids how to make code music today at the library for teen week: http:\/\/t.co\/AlanBZqua5",
    "id" : 577676568765435905,
    "created_at" : "2015-03-17 03:43:21 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 577679862799806464,
  "created_at" : "2015-03-17 03:56:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577675815250333696",
  "text" : "I think I'm almost good enough to busk.",
  "id" : 577675815250333696,
  "created_at" : "2015-03-17 03:40:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/v8lEWGHLSk",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/omegaman",
      "display_url" : "soundcloud.com\/folkstack\/omeg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577674978717356032",
  "text" : "This is the track I was looking for when I got sidetracked by the forgotten poop monologue.  The heavy shit.  https:\/\/t.co\/v8lEWGHLSk",
  "id" : 577674978717356032,
  "created_at" : "2015-03-17 03:37:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577662168105005057",
  "geo" : { },
  "id_str" : "577667490689384448",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  Featuring Gandalf the Wizard who has Automated Away one and two with zeros and ones.",
  "id" : 577667490689384448,
  "in_reply_to_status_id" : 577662168105005057,
  "created_at" : "2015-03-17 03:07:16 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/LeFemO8R2l",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/lotr-the-missing-poop-break-montages",
      "display_url" : "soundcloud.com\/folkstack\/lotr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577662168105005057",
  "text" : "Nobody asked for it, so here it is!  Story time with me and substack.  LotR:  The Missing Poop Break Montages.  \n\nhttps:\/\/t.co\/LeFemO8R2l",
  "id" : 577662168105005057,
  "created_at" : "2015-03-17 02:46:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 81, 90 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577646600438206464",
  "text" : "I'm cracking up listening to a recording of improvised music &amp; story by me n @substack dubbed \"Lord of the Rings: the Poop Break Montages\".",
  "id" : 577646600438206464,
  "created_at" : "2015-03-17 01:44:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stones Throw",
      "screen_name" : "stonesthrow",
      "indices" : [ 3, 15 ],
      "id_str" : "7495882",
      "id" : 7495882
    }, {
      "name" : "James Pants",
      "screen_name" : "sirjamespants",
      "indices" : [ 61, 75 ],
      "id_str" : "157451644",
      "id" : 157451644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/oRy9NyzUKE",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=KAUyPTDFO9Y",
      "display_url" : "youtube.com\/watch?v=KAUyPT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577634173772431360",
  "text" : "RT @stonesthrow: James Pants \u201CBroth\u201D https:\/\/t.co\/oRy9NyzUKE @sirjamespants",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Pants",
        "screen_name" : "sirjamespants",
        "indices" : [ 44, 58 ],
        "id_str" : "157451644",
        "id" : 157451644
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/oRy9NyzUKE",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=KAUyPTDFO9Y",
        "display_url" : "youtube.com\/watch?v=KAUyPT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577627116369379328",
    "text" : "James Pants \u201CBroth\u201D https:\/\/t.co\/oRy9NyzUKE @sirjamespants",
    "id" : 577627116369379328,
    "created_at" : "2015-03-17 00:26:50 +0000",
    "user" : {
      "name" : "Stones Throw",
      "screen_name" : "stonesthrow",
      "protected" : false,
      "id_str" : "7495882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2581120474\/r1b526mdxnhlfot7dd80_normal.jpeg",
      "id" : 7495882,
      "verified" : true
    }
  },
  "id" : 577634173772431360,
  "created_at" : "2015-03-17 00:54:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/YWN6ohl6Zf",
      "expanded_url" : "http:\/\/www.offourbacks.org\/malepat.htm",
      "display_url" : "offourbacks.org\/malepat.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "577627261538430976",
  "text" : "RT @marinakukso: exploring male-pattern violence http:\/\/t.co\/YWN6ohl6Zf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/YWN6ohl6Zf",
        "expanded_url" : "http:\/\/www.offourbacks.org\/malepat.htm",
        "display_url" : "offourbacks.org\/malepat.htm"
      } ]
    },
    "geo" : { },
    "id_str" : "577619194335797248",
    "text" : "exploring male-pattern violence http:\/\/t.co\/YWN6ohl6Zf",
    "id" : 577619194335797248,
    "created_at" : "2015-03-16 23:55:22 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 577627261538430976,
  "created_at" : "2015-03-17 00:27:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577547476489478144",
  "geo" : { },
  "id_str" : "577549353222430720",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross  psshhh those could have been made giant, \"prehistoric\", plasma-slime alien slugs on their migration through our solar system.",
  "id" : 577549353222430720,
  "in_reply_to_status_id" : 577547476489478144,
  "created_at" : "2015-03-16 19:17:50 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577548450817912832",
  "text" : "RT @modulhaus3000: Lots of people talk about distributed dev teams.  Do they talk about it... in the office?  Where does the conversation e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "577547661663866880",
    "text" : "Lots of people talk about distributed dev teams.  Do they talk about it... in the office?  Where does the conversation end?",
    "id" : 577547661663866880,
    "created_at" : "2015-03-16 19:11:07 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 577548450817912832,
  "created_at" : "2015-03-16 19:14:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577543639028539392",
  "geo" : { },
  "id_str" : "577545016135983104",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee  don't make me slap you interface",
  "id" : 577545016135983104,
  "in_reply_to_status_id" : 577543639028539392,
  "created_at" : "2015-03-16 19:00:36 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/6aLnK9Es5f",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/computer-chess-brains",
      "display_url" : "soundcloud.com\/folkstack\/comp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "577460220198137858",
  "geo" : { },
  "id_str" : "577509113258639360",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight here's an artefact ;^b  https:\/\/t.co\/6aLnK9Es5f",
  "id" : 577509113258639360,
  "in_reply_to_status_id" : 577460220198137858,
  "created_at" : "2015-03-16 16:37:56 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6aLnK9mRdH",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/computer-chess-brains",
      "display_url" : "soundcloud.com\/folkstack\/comp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577391106624741376",
  "text" : "I wasn't prepared to record so I had to cut this hot take shamefully w\/ a laptop mic.  At this point, algos takover  https:\/\/t.co\/6aLnK9mRdH",
  "id" : 577391106624741376,
  "created_at" : "2015-03-16 08:49:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577371736565395457",
  "text" : "gibberish, the working parts",
  "id" : 577371736565395457,
  "created_at" : "2015-03-16 07:32:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577369170074980352",
  "geo" : { },
  "id_str" : "577370607710380032",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  is that... auto snooze?",
  "id" : 577370607710380032,
  "in_reply_to_status_id" : 577369170074980352,
  "created_at" : "2015-03-16 07:27:34 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577370192260378624",
  "text" : "I have come down the mountain with this one.",
  "id" : 577370192260378624,
  "created_at" : "2015-03-16 07:25:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577368001692860416",
  "text" : "modular is to synthesis",
  "id" : 577368001692860416,
  "created_at" : "2015-03-16 07:17:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577367592798588928",
  "text" : "I've been writings synths for a couple years.  Now I am writing them daily.  They are proliferating uncontrollably.",
  "id" : 577367592798588928,
  "created_at" : "2015-03-16 07:15:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577366903410143232",
  "text" : "I have created a most amazing magical synthesizer.  It's too much, it's fucking with me.",
  "id" : 577366903410143232,
  "created_at" : "2015-03-16 07:12:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/kyzWPsxQk8",
      "expanded_url" : "https:\/\/www.kickstarter.com\/discover\/categories\/music\/country%20&%20folk?ref=category_modal&sort=magic",
      "display_url" : "kickstarter.com\/discover\/categ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577233199220137984",
  "text" : "folk music is not country music  ;^(\nhttps:\/\/t.co\/kyzWPsxQk8",
  "id" : 577233199220137984,
  "created_at" : "2015-03-15 22:21:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576923430840238080",
  "text" : "switch it up and be consistent yall",
  "id" : 576923430840238080,
  "created_at" : "2015-03-15 01:50:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 9, 21 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/576855944849543168\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/0k2SyRR8jC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAFnbHnUsAIg1AH.jpg",
      "id_str" : "576855942878244866",
      "id" : 576855942878244866,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAFnbHnUsAIg1AH.jpg",
      "sizes" : [ {
        "h" : 210,
        "resize" : "fit",
        "w" : 176
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 176
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 176
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 176
      } ],
      "display_url" : "pic.twitter.com\/0k2SyRR8jC"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/576855944849543168\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/0k2SyRR8jC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAFnbKjUUAEvD7l.jpg",
      "id_str" : "576855943666749441",
      "id" : 576855943666749441,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAFnbKjUUAEvD7l.jpg",
      "sizes" : [ {
        "h" : 582,
        "resize" : "fit",
        "w" : 402
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 402
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 402
      } ],
      "display_url" : "pic.twitter.com\/0k2SyRR8jC"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/576855944849543168\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/0k2SyRR8jC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAFnbMPUUAA5lmO.jpg",
      "id_str" : "576855944119734272",
      "id" : 576855944119734272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAFnbMPUUAA5lmO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/0k2SyRR8jC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576854203634581504",
  "geo" : { },
  "id_str" : "576855944849543168",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee @dominictarr SSB Crab vs NSA Octopus? http:\/\/t.co\/0k2SyRR8jC",
  "id" : 576855944849543168,
  "in_reply_to_status_id" : 576854203634581504,
  "created_at" : "2015-03-14 21:22:29 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 9, 21 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576828381519450112",
  "geo" : { },
  "id_str" : "576853280388562945",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee @dominictarr  sweet emoji",
  "id" : 576853280388562945,
  "in_reply_to_status_id" : 576828381519450112,
  "created_at" : "2015-03-14 21:11:54 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myles Borins",
      "screen_name" : "thealphanerd",
      "indices" : [ 0, 13 ],
      "id_str" : "150664007",
      "id" : 150664007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576632611621216256",
  "geo" : { },
  "id_str" : "576640958122475521",
  "in_reply_to_user_id" : 150664007,
  "text" : "@thealphanerd  Technically, you can serialize nintendo controllers over MIDI.  We could have * with serial, UDP, TCP.  Instead we get APIs.",
  "id" : 576640958122475521,
  "in_reply_to_status_id" : 576632611621216256,
  "created_at" : "2015-03-14 07:08:12 +0000",
  "in_reply_to_screen_name" : "thealphanerd",
  "in_reply_to_user_id_str" : "150664007",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576630173023375360",
  "text" : "Browser almost support MIDI.  It should only take 15 years before they will support OSC.  Somewhere in between, nintendo controllers?",
  "id" : 576630173023375360,
  "created_at" : "2015-03-14 06:25:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/3XNb5I3UNm",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ErCOTdIruoc",
      "display_url" : "youtube.com\/watch?v=ErCOTd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "576601154269802496",
  "text" : "this is amazing, and science should always be this funky https:\/\/t.co\/3XNb5I3UNm",
  "id" : 576601154269802496,
  "created_at" : "2015-03-14 04:30:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576466075019296768",
  "text" : "base text",
  "id" : 576466075019296768,
  "created_at" : "2015-03-13 19:33:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 3, 14 ],
      "id_str" : "14236976",
      "id" : 14236976
    }, {
      "name" : "The Silent Barn",
      "screen_name" : "TheSilentBarn",
      "indices" : [ 42, 56 ],
      "id_str" : "69404126",
      "id" : 69404126
    }, {
      "name" : "Dan Friel",
      "screen_name" : "dfrieldfriel",
      "indices" : [ 60, 73 ],
      "id_str" : "187674282",
      "id" : 187674282
    }, {
      "name" : "Beech Creeps",
      "screen_name" : "BeechCreeps",
      "indices" : [ 78, 90 ],
      "id_str" : "2350417615",
      "id" : 2350417615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576164404078637056",
  "text" : "RT @ToddBailey: Playing a show tonight at @TheSilentBarn w\/ @dfrieldfriel and @BeechCreeps and my goofy video synth prototype. Colors jus' \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Silent Barn",
        "screen_name" : "TheSilentBarn",
        "indices" : [ 26, 40 ],
        "id_str" : "69404126",
        "id" : 69404126
      }, {
        "name" : "Dan Friel",
        "screen_name" : "dfrieldfriel",
        "indices" : [ 44, 57 ],
        "id_str" : "187674282",
        "id" : 187674282
      }, {
        "name" : "Beech Creeps",
        "screen_name" : "BeechCreeps",
        "indices" : [ 62, 74 ],
        "id_str" : "2350417615",
        "id" : 2350417615
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "576155056732561409",
    "text" : "Playing a show tonight at @TheSilentBarn w\/ @dfrieldfriel and @BeechCreeps and my goofy video synth prototype. Colors jus' sloppin errywhere",
    "id" : 576155056732561409,
    "created_at" : "2015-03-12 22:57:24 +0000",
    "user" : {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "protected" : false,
      "id_str" : "14236976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502885261\/TB_Cropped_5_normal.jpg",
      "id" : 14236976,
      "verified" : false
    }
  },
  "id" : 576164404078637056,
  "created_at" : "2015-03-12 23:34:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 13, 21 ],
      "id_str" : "33519541",
      "id" : 33519541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "575883155376242689",
  "geo" : { },
  "id_str" : "575897952318791680",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @pfrazee Hermit the Crab",
  "id" : 575897952318791680,
  "in_reply_to_status_id" : 575883155376242689,
  "created_at" : "2015-03-12 05:55:46 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575743955414970368",
  "text" : "I try not to read articles and blog posts or news you post links to, but I do click the ads.  That's teamwork.",
  "id" : 575743955414970368,
  "created_at" : "2015-03-11 19:43:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/OzafUI3eui",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/chicha-rapida-double-barrel-remix",
      "display_url" : "soundcloud.com\/folkstack\/chic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575736821184749568",
  "text" : "listen to this monstrous bassy skippin chicha, a hot take I made last night. recorded live man y machinas en mono!  https:\/\/t.co\/OzafUI3eui",
  "id" : 575736821184749568,
  "created_at" : "2015-03-11 19:15:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/G8L89Swz81",
      "expanded_url" : "http:\/\/modulha.us\/public-works\/",
      "display_url" : "modulha.us\/public-works\/"
    } ]
  },
  "geo" : { },
  "id_str" : "575714520196247552",
  "text" : "RT @modulhaus3000: We're into open sourcing civic software.  We must be brave.  http:\/\/t.co\/G8L89Swz81",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/G8L89Swz81",
        "expanded_url" : "http:\/\/modulha.us\/public-works\/",
        "display_url" : "modulha.us\/public-works\/"
      } ]
    },
    "geo" : { },
    "id_str" : "575714436268224512",
    "text" : "We're into open sourcing civic software.  We must be brave.  http:\/\/t.co\/G8L89Swz81",
    "id" : 575714436268224512,
    "created_at" : "2015-03-11 17:46:32 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 575714520196247552,
  "created_at" : "2015-03-11 17:46:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/zA96yFpS6F",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=xlboV3S1zw0",
      "display_url" : "youtube.com\/watch?v=xlboV3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575564745345990656",
  "text" : "stare into the flaming accordion jesus https:\/\/t.co\/zA96yFpS6F",
  "id" : 575564745345990656,
  "created_at" : "2015-03-11 07:51:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/OzafUHLDCK",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/chicha-rapida-double-barrel-remix",
      "display_url" : "soundcloud.com\/folkstack\/chic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575543342202777601",
  "text" : "play this one on your most bassed system https:\/\/t.co\/OzafUHLDCK\n\nBut turn it down before it auto plays the next bass rendition.  Lo siento.",
  "id" : 575543342202777601,
  "created_at" : "2015-03-11 06:26:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/HsShKLr1jz",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=tC1XtnLRLPM",
      "display_url" : "youtube.com\/watch?v=tC1Xtn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575470007456399360",
  "text" : "blurred lines feminist cover https:\/\/t.co\/HsShKLr1jz",
  "id" : 575470007456399360,
  "created_at" : "2015-03-11 01:35:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Figueroa",
      "screen_name" : "Jewyorican",
      "indices" : [ 0, 11 ],
      "id_str" : "25407830",
      "id" : 25407830
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 12, 16 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "575422222128529408",
  "geo" : { },
  "id_str" : "575468218426392577",
  "in_reply_to_user_id" : 25407830,
  "text" : "@Jewyorican @izs  getting sued for playing a disco beat is sort of like getting sued for writing a for loop",
  "id" : 575468218426392577,
  "in_reply_to_status_id" : 575422222128529408,
  "created_at" : "2015-03-11 01:28:09 +0000",
  "in_reply_to_screen_name" : "Jewyorican",
  "in_reply_to_user_id_str" : "25407830",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575352196734169088",
  "text" : "and now to take my air horn for a walk",
  "id" : 575352196734169088,
  "created_at" : "2015-03-10 17:47:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/NikaIh0Wsi",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/two-synths",
      "display_url" : "soundcloud.com\/johnnyscript\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575351985521606656",
  "text" : "jus recorded me playing two bespoke synths I wrote, both running out of browser.  with little bear for an air horn. https:\/\/t.co\/NikaIh0Wsi",
  "id" : 575351985521606656,
  "created_at" : "2015-03-10 17:46:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 68, 81 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575332952109793280",
  "text" : "RT @modulhaus3000: modulhaus needs an avatar.  this one was made by @johnnyscript prototyping bespoke strokes.  \n\nIs it pi?  Is it a face? \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 49, 62 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "575332783708446720",
    "text" : "modulhaus needs an avatar.  this one was made by @johnnyscript prototyping bespoke strokes.  \n\nIs it pi?  Is it a face?  What of pi &amp; faces?",
    "id" : 575332783708446720,
    "created_at" : "2015-03-10 16:29:59 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 575332952109793280,
  "created_at" : "2015-03-10 16:30:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575320783490174976",
  "text" : "s\/t I wish I was as ugly as the world makes me feel!\nbut that is impossibly against my nature.\nand so few can empathize!\nwell I feel better.",
  "id" : 575320783490174976,
  "created_at" : "2015-03-10 15:42:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SecuriTay",
      "screen_name" : "SwiftOnSecurity",
      "indices" : [ 0, 16 ],
      "id_str" : "2436389418",
      "id" : 2436389418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "575312048550199297",
  "geo" : { },
  "id_str" : "575317603117219840",
  "in_reply_to_user_id" : 2436389418,
  "text" : "@SwiftOnSecurity  I can change, Tay Tay, I can change!!!",
  "id" : 575317603117219840,
  "in_reply_to_status_id" : 575312048550199297,
  "created_at" : "2015-03-10 15:29:40 +0000",
  "in_reply_to_screen_name" : "SwiftOnSecurity",
  "in_reply_to_user_id_str" : "2436389418",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/6yUPVrHrrc",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/keys-modular-led-music-keyboard-with-gestures",
      "display_url" : "indiegogo.com\/projects\/keys-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575317250451767298",
  "text" : "well this hi tech weak shit is a kick in the pants to get my mad synths wares to market  https:\/\/t.co\/6yUPVrHrrc\n\nbutt I'm all out of pants.",
  "id" : 575317250451767298,
  "created_at" : "2015-03-10 15:28:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bex April May",
      "screen_name" : "bexlectric",
      "indices" : [ 3, 14 ],
      "id_str" : "236561938",
      "id" : 236561938
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bexlectric\/status\/575049120685166592\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/KSoeN220D4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B_r79GiWIAA8Vxu.png",
      "id_str" : "575048929588420608",
      "id" : 575048929588420608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B_r79GiWIAA8Vxu.png",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/KSoeN220D4"
    } ],
    "hashtags" : [ {
      "text" : "youtried",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575302837351026691",
  "text" : "RT @bexlectric: Just want to give this robot goalie a big hug #youtried http:\/\/t.co\/KSoeN220D4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bexlectric\/status\/575049120685166592\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/KSoeN220D4",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B_r79GiWIAA8Vxu.png",
        "id_str" : "575048929588420608",
        "id" : 575048929588420608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B_r79GiWIAA8Vxu.png",
        "sizes" : [ {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/KSoeN220D4"
      } ],
      "hashtags" : [ {
        "text" : "youtried",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "575049120685166592",
    "text" : "Just want to give this robot goalie a big hug #youtried http:\/\/t.co\/KSoeN220D4",
    "id" : 575049120685166592,
    "created_at" : "2015-03-09 21:42:48 +0000",
    "user" : {
      "name" : "Bex April May",
      "screen_name" : "bexlectric",
      "protected" : false,
      "id_str" : "236561938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702951539812528128\/9lOXnQrW_normal.jpg",
      "id" : 236561938,
      "verified" : true
    }
  },
  "id" : 575302837351026691,
  "created_at" : "2015-03-10 14:30:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 0, 7 ],
      "id_str" : "6121912",
      "id" : 6121912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575100608631431169",
  "in_reply_to_user_id" : 6121912,
  "text" : "@visnup arf arf when is node knockout?",
  "id" : 575100608631431169,
  "created_at" : "2015-03-10 01:07:24 +0000",
  "in_reply_to_screen_name" : "visnup",
  "in_reply_to_user_id_str" : "6121912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575049760349933568",
  "text" : "interests:  self-mummification",
  "id" : 575049760349933568,
  "created_at" : "2015-03-09 21:45:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Scott ANDERSON",
      "screen_name" : "treenopie",
      "indices" : [ 0, 10 ],
      "id_str" : "976380487",
      "id" : 976380487
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "modulhaus",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574972324249669632",
  "geo" : { },
  "id_str" : "575044189504720896",
  "in_reply_to_user_id" : 976380487,
  "text" : "@treenopie  also join #modulhaus on irc",
  "id" : 575044189504720896,
  "in_reply_to_status_id" : 574972324249669632,
  "created_at" : "2015-03-09 21:23:13 +0000",
  "in_reply_to_screen_name" : "treenopie",
  "in_reply_to_user_id_str" : "976380487",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Scott ANDERSON",
      "screen_name" : "treenopie",
      "indices" : [ 0, 10 ],
      "id_str" : "976380487",
      "id" : 976380487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574972324249669632",
  "geo" : { },
  "id_str" : "575041097958694912",
  "in_reply_to_user_id" : 976380487,
  "text" : "@treenopie a lil messy.  server: server.js, client pre-bundle: entry.js, style: public\/style.css &amp; site.css",
  "id" : 575041097958694912,
  "in_reply_to_status_id" : 574972324249669632,
  "created_at" : "2015-03-09 21:10:56 +0000",
  "in_reply_to_screen_name" : "treenopie",
  "in_reply_to_user_id_str" : "976380487",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Scott ANDERSON",
      "screen_name" : "treenopie",
      "indices" : [ 0, 10 ],
      "id_str" : "976380487",
      "id" : 976380487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/4vThVDssix",
      "expanded_url" : "https:\/\/github.com\/modulhaus\/daylabor",
      "display_url" : "github.com\/modulhaus\/dayl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "574972324249669632",
  "geo" : { },
  "id_str" : "575037616107577345",
  "in_reply_to_user_id" : 976380487,
  "text" : "@treenopie   https:\/\/t.co\/4vThVDssix",
  "id" : 575037616107577345,
  "in_reply_to_status_id" : 574972324249669632,
  "created_at" : "2015-03-09 20:57:06 +0000",
  "in_reply_to_screen_name" : "treenopie",
  "in_reply_to_user_id_str" : "976380487",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/u6wmTMCvmC",
      "expanded_url" : "http:\/\/daylabor.modulha.us",
      "display_url" : "daylabor.modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "574955246025338880",
  "text" : "one full stack web developer posted http:\/\/t.co\/u6wmTMCvmC",
  "id" : 574955246025338880,
  "created_at" : "2015-03-09 15:29:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "574774729141149698",
  "geo" : { },
  "id_str" : "574921931029250049",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove  haha @ 1:49 nexxy love known to let the trademark...  drop.",
  "id" : 574921931029250049,
  "in_reply_to_status_id" : 574774729141149698,
  "created_at" : "2015-03-09 13:17:24 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "modulhaus",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574302608170463232",
  "text" : "next phases of #modulhaus:  representing more hackers and projects.  What will that look like?? Also, tidying up the enterprise offerings...",
  "id" : 574302608170463232,
  "created_at" : "2015-03-07 20:16:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/dblSvt5THs",
      "expanded_url" : "http:\/\/daylabor.modulha.us\/",
      "display_url" : "daylabor.modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "574265449367519232",
  "text" : "i'm posted up at the spot check it out http:\/\/t.co\/dblSvt5THs",
  "id" : 574265449367519232,
  "created_at" : "2015-03-07 17:48:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/dblSvt5THs",
      "expanded_url" : "http:\/\/daylabor.modulha.us\/",
      "display_url" : "daylabor.modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "573967505309327360",
  "text" : "I made this day labor site for hackers http:\/\/t.co\/dblSvt5THs",
  "id" : 573967505309327360,
  "created_at" : "2015-03-06 22:04:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "indices" : [ 0, 8 ],
      "id_str" : "885173964",
      "id" : 885173964
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 9, 21 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573591627769344001",
  "geo" : { },
  "id_str" : "573594090563993600",
  "in_reply_to_user_id" : 885173964,
  "text" : "@jerquee @marinakukso  oh c'mon she was totally asking for that article to be written",
  "id" : 573594090563993600,
  "in_reply_to_status_id" : 573591627769344001,
  "created_at" : "2015-03-05 21:21:02 +0000",
  "in_reply_to_screen_name" : "jerquee",
  "in_reply_to_user_id_str" : "885173964",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/t32cDDtdkE",
      "expanded_url" : "http:\/\/daylabor.modulha.us\/posted\/06e13bb0-c37d-11e4-9e62-4fcc9d2b1deb",
      "display_url" : "daylabor.modulha.us\/posted\/06e13bb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573593861399826432",
  "text" : "I'm posted up here http:\/\/t.co\/t32cDDtdkE\n\nI'll be out back practicing muh kung fu in the sun.",
  "id" : 573593861399826432,
  "created_at" : "2015-03-05 21:20:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Coe",
      "screen_name" : "BenjaminCoe",
      "indices" : [ 3, 15 ],
      "id_str" : "24659495",
      "id" : 24659495
    }, {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 35, 50 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573586981315198976",
  "text" : "RT @BenjaminCoe: planning the next @oaklanddancejs for March 28th, want to give a talk or DJ let me know.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dance.js",
        "screen_name" : "oaklanddancejs",
        "indices" : [ 18, 33 ],
        "id_str" : "2797358358",
        "id" : 2797358358
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573335353081368576",
    "text" : "planning the next @oaklanddancejs for March 28th, want to give a talk or DJ let me know.",
    "id" : 573335353081368576,
    "created_at" : "2015-03-05 04:12:54 +0000",
    "user" : {
      "name" : "Benjamin Coe",
      "screen_name" : "BenjaminCoe",
      "protected" : false,
      "id_str" : "24659495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691352988556734464\/PVv6Rp6-_normal.png",
      "id" : 24659495,
      "verified" : false
    }
  },
  "id" : 573586981315198976,
  "created_at" : "2015-03-05 20:52:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 3, 14 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573535012412227584",
  "text" : "RT @grayamelia: Yes, baggie of tomato sauce filled to bursting and swelling in the morning sun, I hope you have a good Thursday too",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573521901651300352",
    "text" : "Yes, baggie of tomato sauce filled to bursting and swelling in the morning sun, I hope you have a good Thursday too",
    "id" : 573521901651300352,
    "created_at" : "2015-03-05 16:34:11 +0000",
    "user" : {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "protected" : false,
      "id_str" : "181328570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542768392499761152\/NN148tlm_normal.png",
      "id" : 181328570,
      "verified" : false
    }
  },
  "id" : 573535012412227584,
  "created_at" : "2015-03-05 17:26:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wKw5TmYFML",
      "expanded_url" : "http:\/\/daylabor.modulha.us",
      "display_url" : "daylabor.modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "573534658689806336",
  "text" : "RT @modulhaus3000: Help get the word out.  Hacker Day Labor.  Skip the hassles and get somebody on the job today.  http:\/\/t.co\/wKw5TmYFML",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/wKw5TmYFML",
        "expanded_url" : "http:\/\/daylabor.modulha.us",
        "display_url" : "daylabor.modulha.us"
      } ]
    },
    "geo" : { },
    "id_str" : "573529926663438336",
    "text" : "Help get the word out.  Hacker Day Labor.  Skip the hassles and get somebody on the job today.  http:\/\/t.co\/wKw5TmYFML",
    "id" : 573529926663438336,
    "created_at" : "2015-03-05 17:06:04 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 573534658689806336,
  "created_at" : "2015-03-05 17:24:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dominictarr\/status\/573371409428135936\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/DlMwJRRwEt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_UGQa5UQAAZXg7.jpg",
      "id_str" : "573371406727004160",
      "id" : 573371406727004160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_UGQa5UQAAZXg7.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DlMwJRRwEt"
    } ],
    "hashtags" : [ {
      "text" : "AdventuresWithStandingDesk",
      "indices" : [ 17, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573378338573582336",
  "text" : "RT @dominictarr: #AdventuresWithStandingDesk http:\/\/t.co\/DlMwJRRwEt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dominictarr\/status\/573371409428135936\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/DlMwJRRwEt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_UGQa5UQAAZXg7.jpg",
        "id_str" : "573371406727004160",
        "id" : 573371406727004160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_UGQa5UQAAZXg7.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DlMwJRRwEt"
      } ],
      "hashtags" : [ {
        "text" : "AdventuresWithStandingDesk",
        "indices" : [ 0, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573371409428135936",
    "text" : "#AdventuresWithStandingDesk http:\/\/t.co\/DlMwJRRwEt",
    "id" : 573371409428135936,
    "created_at" : "2015-03-05 06:36:11 +0000",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712569197126160384\/nvnXBzt-_normal.jpg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 573378338573582336,
  "created_at" : "2015-03-05 07:03:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/XtT2KF0WzC",
      "expanded_url" : "http:\/\/daylabor.modulha.us\/",
      "display_url" : "daylabor.modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "573331039784865793",
  "text" : "RT @modulhaus3000: hackers already posting up!  http:\/\/t.co\/XtT2KF0WzC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/XtT2KF0WzC",
        "expanded_url" : "http:\/\/daylabor.modulha.us\/",
        "display_url" : "daylabor.modulha.us"
      } ]
    },
    "geo" : { },
    "id_str" : "573328763519291392",
    "text" : "hackers already posting up!  http:\/\/t.co\/XtT2KF0WzC",
    "id" : 573328763519291392,
    "created_at" : "2015-03-05 03:46:43 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 573331039784865793,
  "created_at" : "2015-03-05 03:55:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/dblSvt5THs",
      "expanded_url" : "http:\/\/daylabor.modulha.us\/",
      "display_url" : "daylabor.modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "573286093623185409",
  "text" : "post up day or night\nhttp:\/\/t.co\/dblSvt5THs",
  "id" : 573286093623185409,
  "created_at" : "2015-03-05 00:57:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/dMIZB21WHR",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/jasonwells\/ex-american-apparel-chief-rallies-workers-to-organize-at-sec#.wm7z5vk43",
      "display_url" : "buzzfeed.com\/jasonwells\/ex-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573269019488202752",
  "text" : "corporate labor drama at american apparel http:\/\/t.co\/dMIZB21WHR",
  "id" : 573269019488202752,
  "created_at" : "2015-03-04 23:49:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573218070719672320",
  "text" : "I've got 18446744073709551616 ipv6 address\nBut I don't know how to use a single one",
  "id" : 573218070719672320,
  "created_at" : "2015-03-04 20:26:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573063895092363264",
  "text" : "two twitter accounts is twice as bad",
  "id" : 573063895092363264,
  "created_at" : "2015-03-04 10:14:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/572895547855532032\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/lw7GKizE9B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_NVdw8U0AAZWJt.png",
      "id_str" : "572895547448676352",
      "id" : 572895547448676352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_NVdw8U0AAZWJt.png",
      "sizes" : [ {
        "h" : 899,
        "resize" : "fit",
        "w" : 1840
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lw7GKizE9B"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572895547855532032",
  "text" : "FOMO Distribution http:\/\/t.co\/lw7GKizE9B",
  "id" : 572895547855532032,
  "created_at" : "2015-03-03 23:05:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProjectAinita",
      "screen_name" : "ProjectAinita",
      "indices" : [ 3, 17 ],
      "id_str" : "1267368498",
      "id" : 1267368498
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ProjectAinita\/status\/572763631944933376\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7tOzE4WugE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_LdfOFVEAA2ntS.jpg",
      "id_str" : "572763631055605760",
      "id" : 572763631055605760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_LdfOFVEAA2ntS.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7tOzE4WugE"
    } ],
    "hashtags" : [ {
      "text" : "bandwidth",
      "indices" : [ 48, 58 ]
    }, {
      "text" : "Iran",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "3G",
      "indices" : [ 89, 92 ]
    }, {
      "text" : "LTE",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "ICDIran",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "CTFestival",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572854680277020672",
  "text" : "RT @ProjectAinita: 800% increase in mobile data #bandwidth in #Iran in past 12 months as #3G and #LTE kicked in. #ICDIran #CTFestival http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ProjectAinita\/status\/572763631944933376\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/7tOzE4WugE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_LdfOFVEAA2ntS.jpg",
        "id_str" : "572763631055605760",
        "id" : 572763631055605760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_LdfOFVEAA2ntS.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7tOzE4WugE"
      } ],
      "hashtags" : [ {
        "text" : "bandwidth",
        "indices" : [ 29, 39 ]
      }, {
        "text" : "Iran",
        "indices" : [ 43, 48 ]
      }, {
        "text" : "3G",
        "indices" : [ 70, 73 ]
      }, {
        "text" : "LTE",
        "indices" : [ 78, 82 ]
      }, {
        "text" : "ICDIran",
        "indices" : [ 94, 102 ]
      }, {
        "text" : "CTFestival",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572763631944933376",
    "text" : "800% increase in mobile data #bandwidth in #Iran in past 12 months as #3G and #LTE kicked in. #ICDIran #CTFestival http:\/\/t.co\/7tOzE4WugE",
    "id" : 572763631944933376,
    "created_at" : "2015-03-03 14:21:05 +0000",
    "user" : {
      "name" : "ProjectAinita",
      "screen_name" : "ProjectAinita",
      "protected" : false,
      "id_str" : "1267368498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3379290013\/ef9a894f4542918c2b83067eca2e174e_normal.png",
      "id" : 1267368498,
      "verified" : false
    }
  },
  "id" : 572854680277020672,
  "created_at" : "2015-03-03 20:22:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572854489796890625",
  "text" : "Netanyahoo trynna get us to squeeze Iran, but Iran is about to have an internet spring revolution. Maybe we should be patient, eat popcorn.",
  "id" : 572854489796890625,
  "created_at" : "2015-03-03 20:22:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProjectAinita",
      "screen_name" : "ProjectAinita",
      "indices" : [ 0, 14 ],
      "id_str" : "1267368498",
      "id" : 1267368498
    }, {
      "name" : "april glaser",
      "screen_name" : "aprilaser",
      "indices" : [ 15, 25 ],
      "id_str" : "210056653",
      "id" : 210056653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572763631944933376",
  "geo" : { },
  "id_str" : "572853026999812096",
  "in_reply_to_user_id" : 1267368498,
  "text" : "@ProjectAinita @aprilaser  that's revolting!",
  "id" : 572853026999812096,
  "in_reply_to_status_id" : 572763631944933376,
  "created_at" : "2015-03-03 20:16:19 +0000",
  "in_reply_to_screen_name" : "ProjectAinita",
  "in_reply_to_user_id_str" : "1267368498",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572847905687638016",
  "text" : "There are too many TLDs now, which is problematic, cuz I love naming things, andbutcuz I hate the DNS.",
  "id" : 572847905687638016,
  "created_at" : "2015-03-03 19:55:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572824946671546369",
  "text" : "nobody is has a government for a friend",
  "id" : 572824946671546369,
  "created_at" : "2015-03-03 18:24:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572824622988709888",
  "text" : "friendship between two totalitarian states (where state is state)",
  "id" : 572824622988709888,
  "created_at" : "2015-03-03 18:23:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Intercept FLM",
      "screen_name" : "the_intercept",
      "indices" : [ 3, 17 ],
      "id_str" : "719972682322853888",
      "id" : 719972682322853888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/lILMX6eFq9",
      "expanded_url" : "http:\/\/interc.pt\/18F6jC2",
      "display_url" : "interc.pt\/18F6jC2"
    } ]
  },
  "geo" : { },
  "id_str" : "572585498473988096",
  "text" : "RT @the_intercept: Netanyahu is expected to tell Congress an Iranian bomb is imminent- just as he warned in 1992, 1995, 2002, 2009, 2012 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/lILMX6eFq9",
        "expanded_url" : "http:\/\/interc.pt\/18F6jC2",
        "display_url" : "interc.pt\/18F6jC2"
      } ]
    },
    "geo" : { },
    "id_str" : "572476491939758082",
    "text" : "Netanyahu is expected to tell Congress an Iranian bomb is imminent- just as he warned in 1992, 1995, 2002, 2009, 2012 http:\/\/t.co\/lILMX6eFq9",
    "id" : 572476491939758082,
    "created_at" : "2015-03-02 19:20:06 +0000",
    "user" : {
      "name" : "The Intercept",
      "screen_name" : "theintercept",
      "protected" : false,
      "id_str" : "2329066872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621138310585409536\/mSJHNbO6_normal.png",
      "id" : 2329066872,
      "verified" : true
    }
  },
  "id" : 572585498473988096,
  "created_at" : "2015-03-03 02:33:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572584407703269377",
  "text" : "TTL TIL I DIE",
  "id" : 572584407703269377,
  "created_at" : "2015-03-03 02:28:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 39, 47 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572554595865518080",
  "text" : "I collabed remotely 3 node knockouts w\/@soldair. He always did the horse's share.  A natural, hacking beast! Compared to him most are newbs.",
  "id" : 572554595865518080,
  "created_at" : "2015-03-03 00:30:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 3, 11 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572549978461118464",
  "text" : "RT @soldair: Any node companies looking for a remote node dev? My excellent journey with pinocc.io has come to an end.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572441487599783937",
    "text" : "Any node companies looking for a remote node dev? My excellent journey with pinocc.io has come to an end.",
    "id" : 572441487599783937,
    "created_at" : "2015-03-02 17:01:00 +0000",
    "user" : {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "protected" : false,
      "id_str" : "16893912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654320052162924549\/DjQ_KPJy_normal.png",
      "id" : 16893912,
      "verified" : false
    }
  },
  "id" : 572549978461118464,
  "created_at" : "2015-03-03 00:12:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "modulhuas",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5YcEdaJaKZ",
      "expanded_url" : "http:\/\/modulha.us\/agency",
      "display_url" : "modulha.us\/agency"
    } ]
  },
  "geo" : { },
  "id_str" : "572517828995125248",
  "text" : "RT @modulhaus3000: We've been jamming concepts for #modulhuas a long time.  This draft covers a candidate for core:  http:\/\/t.co\/5YcEdaJaKZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "modulhuas",
        "indices" : [ 32, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/5YcEdaJaKZ",
        "expanded_url" : "http:\/\/modulha.us\/agency",
        "display_url" : "modulha.us\/agency"
      } ]
    },
    "geo" : { },
    "id_str" : "572494941760307201",
    "text" : "We've been jamming concepts for #modulhuas a long time.  This draft covers a candidate for core:  http:\/\/t.co\/5YcEdaJaKZ",
    "id" : 572494941760307201,
    "created_at" : "2015-03-02 20:33:25 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 572517828995125248,
  "created_at" : "2015-03-02 22:04:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572496198138871808",
  "text" : "In English, \"this\" always refers to you know what.",
  "id" : 572496198138871808,
  "created_at" : "2015-03-02 20:38:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelson Minar",
      "screen_name" : "nelson",
      "indices" : [ 3, 10 ],
      "id_str" : "10051",
      "id" : 10051
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nelson\/status\/572481883558191104\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/JXMcidKANk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_HdPVJUwAAQ_ac.png",
      "id_str" : "572481883096793088",
      "id" : 572481883096793088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_HdPVJUwAAQ_ac.png",
      "sizes" : [ {
        "h" : 938,
        "resize" : "fit",
        "w" : 791
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 938,
        "resize" : "fit",
        "w" : 791
      }, {
        "h" : 712,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JXMcidKANk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572489436333654016",
  "text" : "RT @nelson: We should remove the genocidal Andrew Jackson from the US $20 and replace him with bad-ass Frederick Douglass. http:\/\/t.co\/JXMc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nelson\/status\/572481883558191104\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/JXMcidKANk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_HdPVJUwAAQ_ac.png",
        "id_str" : "572481883096793088",
        "id" : 572481883096793088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_HdPVJUwAAQ_ac.png",
        "sizes" : [ {
          "h" : 938,
          "resize" : "fit",
          "w" : 791
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 938,
          "resize" : "fit",
          "w" : 791
        }, {
          "h" : 712,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JXMcidKANk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572481883558191104",
    "text" : "We should remove the genocidal Andrew Jackson from the US $20 and replace him with bad-ass Frederick Douglass. http:\/\/t.co\/JXMcidKANk",
    "id" : 572481883558191104,
    "created_at" : "2015-03-02 19:41:31 +0000",
    "user" : {
      "name" : "Nelson Minar",
      "screen_name" : "nelson",
      "protected" : false,
      "id_str" : "10051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/506883834822926336\/MxrZ0ufJ_normal.jpeg",
      "id" : 10051,
      "verified" : false
    }
  },
  "id" : 572489436333654016,
  "created_at" : "2015-03-02 20:11:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelson Minar",
      "screen_name" : "nelson",
      "indices" : [ 0, 7 ],
      "id_str" : "10051",
      "id" : 10051
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 8, 12 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Fu7DpQ0D1R",
      "expanded_url" : "http:\/\/teachingamericanhistory.org\/library\/document\/oration-in-memory-of-abraham-lincoln\/",
      "display_url" : "teachingamericanhistory.org\/library\/docume\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "572481883558191104",
  "geo" : { },
  "id_str" : "572489424186974208",
  "in_reply_to_user_id" : 10051,
  "text" : "@nelson @izs  this always gives me the tingles http:\/\/t.co\/Fu7DpQ0D1R",
  "id" : 572489424186974208,
  "in_reply_to_status_id" : 572481883558191104,
  "created_at" : "2015-03-02 20:11:29 +0000",
  "in_reply_to_screen_name" : "nelson",
  "in_reply_to_user_id_str" : "10051",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572480714416889856",
  "text" : "RT @modulhaus3000: RT AND DO THE HOKEY POKEY IF YOU VIM COMMAND BROWSER TABS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572480461974339584",
    "text" : "RT AND DO THE HOKEY POKEY IF YOU VIM COMMAND BROWSER TABS",
    "id" : 572480461974339584,
    "created_at" : "2015-03-02 19:35:52 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 572480714416889856,
  "created_at" : "2015-03-02 19:36:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "indices" : [ 3, 18 ],
      "id_str" : "620142261",
      "id" : 620142261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572452974414282753",
  "text" : "RT @KimKierkegaard: Scheherazade kept herself alive by telling tales. I keep myself alive by taking selfies.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572452118487011329",
    "text" : "Scheherazade kept herself alive by telling tales. I keep myself alive by taking selfies.",
    "id" : 572452118487011329,
    "created_at" : "2015-03-02 17:43:15 +0000",
    "user" : {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "protected" : false,
      "id_str" : "620142261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2346161730\/images-2_normal.jpg",
      "id" : 620142261,
      "verified" : false
    }
  },
  "id" : 572452974414282753,
  "created_at" : "2015-03-02 17:46:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572451619796754432",
  "geo" : { },
  "id_str" : "572451835862102016",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  rong comand johny",
  "id" : 572451835862102016,
  "in_reply_to_status_id" : 572451619796754432,
  "created_at" : "2015-03-02 17:42:07 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572451619796754432",
  "text" : "is freenode down?  or is it just me getting hacked?",
  "id" : 572451619796754432,
  "created_at" : "2015-03-02 17:41:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 3, 16 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/occupythemob\/status\/572222629215637505\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/1pnKE1pGfV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Dxb6JWoAEgKR_.jpg",
      "id_str" : "572222614443302913",
      "id" : 572222614443302913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Dxb6JWoAEgKR_.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/1pnKE1pGfV"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/occupythemob\/status\/572222629215637505\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/1pnKE1pGfV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_DxcVyW8AAr3kD.jpg",
      "id_str" : "572222621863047168",
      "id" : 572222621863047168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_DxcVyW8AAr3kD.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1pnKE1pGfV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572247777129857025",
  "text" : "RT @occupythemob: There are only 6 Northern White Rhinos remaining in the world. They have armed bodyguard protection 24\/7. http:\/\/t.co\/1pn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/occupythemob\/status\/572222629215637505\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/1pnKE1pGfV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Dxb6JWoAEgKR_.jpg",
        "id_str" : "572222614443302913",
        "id" : 572222614443302913,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Dxb6JWoAEgKR_.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/1pnKE1pGfV"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/occupythemob\/status\/572222629215637505\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/1pnKE1pGfV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_DxcVyW8AAr3kD.jpg",
        "id_str" : "572222621863047168",
        "id" : 572222621863047168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_DxcVyW8AAr3kD.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1pnKE1pGfV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572222629215637505",
    "text" : "There are only 6 Northern White Rhinos remaining in the world. They have armed bodyguard protection 24\/7. http:\/\/t.co\/1pnKE1pGfV",
    "id" : 572222629215637505,
    "created_at" : "2015-03-02 02:31:20 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "AnonyMobLife",
      "protected" : false,
      "id_str" : "341908197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627989340111654912\/Xo6hS4Ab_normal.jpg",
      "id" : 341908197,
      "verified" : false
    }
  },
  "id" : 572247777129857025,
  "created_at" : "2015-03-02 04:11:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572243518288076800",
  "text" : "still inventing\n\n,|^)",
  "id" : 572243518288076800,
  "created_at" : "2015-03-02 03:54:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DigitalOcean",
      "screen_name" : "digitalocean",
      "indices" : [ 1, 14 ],
      "id_str" : "457033547",
      "id" : 457033547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572241431189975040",
  "geo" : { },
  "id_str" : "572242623412359168",
  "in_reply_to_user_id" : 457033547,
  "text" : ".@digitalocean  I did a minute ago.  but also I have to vent technopian absurdities, like everyone else.",
  "id" : 572242623412359168,
  "in_reply_to_status_id" : 572241431189975040,
  "created_at" : "2015-03-02 03:50:47 +0000",
  "in_reply_to_screen_name" : "digitalocean",
  "in_reply_to_user_id_str" : "457033547",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DigitalOcean",
      "screen_name" : "digitalocean",
      "indices" : [ 6, 19 ],
      "id_str" : "457033547",
      "id" : 457033547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572240848802332672",
  "text" : "i owe @digitalocean less than 5 bux\nbut they can't bill les than 5 bux\nso I can't pay my bill...\nyet their bots are sending me DEL threats",
  "id" : 572240848802332672,
  "created_at" : "2015-03-02 03:43:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Cyrin",
      "screen_name" : "lynnmagic",
      "indices" : [ 0, 10 ],
      "id_str" : "3235701608",
      "id" : 3235701608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572178732493905920",
  "geo" : { },
  "id_str" : "572184874171305984",
  "in_reply_to_user_id" : 2212879538,
  "text" : "@LynnMagic  tweet to (or contact) queer \/ trans advocates *directly*, ask for advice.",
  "id" : 572184874171305984,
  "in_reply_to_status_id" : 572178732493905920,
  "created_at" : "2015-03-02 00:01:19 +0000",
  "in_reply_to_screen_name" : "lynncyrin",
  "in_reply_to_user_id_str" : "2212879538",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/cyiHDeietE",
      "expanded_url" : "http:\/\/youtu.be\/Ow_OjkSLZDI?t=23m39s",
      "display_url" : "youtu.be\/Ow_OjkSLZDI?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572130253365100544",
  "text" : "Found: \"Psychedelic\" Peruvian Cumbia version of Fur Elise http:\/\/t.co\/cyiHDeietE",
  "id" : 572130253365100544,
  "created_at" : "2015-03-01 20:24:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isis",
      "indices" : [ 9, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572125358004183040",
  "text" : "war with #isis? \nmore like that depends on what the definition if is is",
  "id" : 572125358004183040,
  "created_at" : "2015-03-01 20:04:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Cyrin",
      "screen_name" : "lynnmagic",
      "indices" : [ 0, 10 ],
      "id_str" : "3235701608",
      "id" : 3235701608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/MVlAdviHdH",
      "expanded_url" : "https:\/\/github.com\/ssbc\/scuttlebot",
      "display_url" : "github.com\/ssbc\/scuttlebot"
    } ]
  },
  "in_reply_to_status_id_str" : "571919260546547713",
  "geo" : { },
  "id_str" : "572107514944200704",
  "in_reply_to_user_id" : 2212879538,
  "text" : "@LynnMagic  don't build a social network alone https:\/\/t.co\/MVlAdviHdH",
  "id" : 572107514944200704,
  "in_reply_to_status_id" : 571919260546547713,
  "created_at" : "2015-03-01 18:53:55 +0000",
  "in_reply_to_screen_name" : "lynncyrin",
  "in_reply_to_user_id_str" : "2212879538",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572105347680235522",
  "text" : "RT @TheHatGhost: @johnnyscript you were the recipient of my son's first tweet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572039414337155072",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript you were the recipient of my son's first tweet.",
    "id" : 572039414337155072,
    "created_at" : "2015-03-01 14:23:19 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606927351168036864\/lzGOA4HX_normal.jpg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 572105347680235522,
  "created_at" : "2015-03-01 18:45:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 3, 15 ],
      "id_str" : "557228721",
      "id" : 557228721
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572105337680994305",
  "text" : "RT @vrroanhorse: @johnnyscript  pctzta.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "571053035721338881",
    "geo" : { },
    "id_str" : "572038834717892608",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript  pctzta.",
    "id" : 572038834717892608,
    "in_reply_to_status_id" : 571053035721338881,
    "created_at" : "2015-03-01 14:21:00 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "protected" : false,
      "id_str" : "557228721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652515840194056193\/vt9WrUY__normal.jpg",
      "id" : 557228721,
      "verified" : false
    }
  },
  "id" : 572105337680994305,
  "created_at" : "2015-03-01 18:45:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571917335902093312",
  "text" : "the reason why dogs are loyal is because we enlighten them.  that's right.  dogs can become enlightened.  but they never lose that feeling.",
  "id" : 571917335902093312,
  "created_at" : "2015-03-01 06:18:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571915752522956800",
  "text" : "rocksteady is a curse",
  "id" : 571915752522956800,
  "created_at" : "2015-03-01 06:11:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571915197964689408",
  "geo" : { },
  "id_str" : "571915463912923136",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  learnin'",
  "id" : 571915463912923136,
  "in_reply_to_status_id" : 571915197964689408,
  "created_at" : "2015-03-01 06:10:46 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571914945345929216",
  "text" : "i prefer getting along with animals.  that includes humans, when they being animals.  usually they are aliens, being, tho.",
  "id" : 571914945345929216,
  "created_at" : "2015-03-01 06:08:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]