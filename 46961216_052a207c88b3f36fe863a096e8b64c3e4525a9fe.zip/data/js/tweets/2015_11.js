Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671477623390756865",
  "geo" : { },
  "id_str" : "671490110290944001",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  squad goals: acute",
  "id" : 671490110290944001,
  "in_reply_to_status_id" : 671477623390756865,
  "created_at" : "2015-12-01 00:44:52 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671160806055145472",
  "geo" : { },
  "id_str" : "671183054170361856",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  I won't  &gt;_&lt;  Kd8",
  "id" : 671183054170361856,
  "in_reply_to_status_id" : 671160806055145472,
  "created_at" : "2015-11-30 04:24:44 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brit Bennett",
      "screen_name" : "britrbennett",
      "indices" : [ 3, 16 ],
      "id_str" : "612190532",
      "id" : 612190532
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/britrbennett\/status\/670740985333198848\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/XwbQmZKy4i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7zXr5VEAE22d0.jpg",
      "id_str" : "670740982770503681",
      "id" : 670740982770503681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7zXr5VEAE22d0.jpg",
      "sizes" : [ {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/XwbQmZKy4i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671146274142494720",
  "text" : "RT @britrbennett: The nuance and complexity afforded to this guy's motives is astounding. https:\/\/t.co\/XwbQmZKy4i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/britrbennett\/status\/670740985333198848\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/XwbQmZKy4i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7zXr5VEAE22d0.jpg",
        "id_str" : "670740982770503681",
        "id" : 670740982770503681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7zXr5VEAE22d0.jpg",
        "sizes" : [ {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        } ],
        "display_url" : "pic.twitter.com\/XwbQmZKy4i"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670740985333198848",
    "text" : "The nuance and complexity afforded to this guy's motives is astounding. https:\/\/t.co\/XwbQmZKy4i",
    "id" : 670740985333198848,
    "created_at" : "2015-11-28 23:08:07 +0000",
    "user" : {
      "name" : "Brit Bennett",
      "screen_name" : "britrbennett",
      "protected" : false,
      "id_str" : "612190532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478946910632304640\/BBAnKwdL_normal.jpeg",
      "id" : 612190532,
      "verified" : false
    }
  },
  "id" : 671146274142494720,
  "created_at" : "2015-11-30 01:58:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2102\u0127\u0451\u2113\u00A7\u03B5\u00E5\u264E (x_x)",
      "screen_name" : "SheSpeakDaTruth",
      "indices" : [ 3, 19 ],
      "id_str" : "1282062920",
      "id" : 1282062920
    }, {
      "name" : "Kate Thayer",
      "screen_name" : "knthayer",
      "indices" : [ 21, 30 ],
      "id_str" : "21232327",
      "id" : 21232327
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SheSpeakDaTruth\/status\/670750397636722688\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/wB6FhtQUjn",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CU776tdUwAEbPpt.png",
      "id_str" : "670750380578357249",
      "id" : 670750380578357249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CU776tdUwAEbPpt.png",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/wB6FhtQUjn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671145223452495873",
  "text" : "RT @SheSpeakDaTruth: @knthayer omg lets cry for the whitegirl who couldnt get the supercute shoes while blackboys r shot getting skittles h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Thayer",
        "screen_name" : "knthayer",
        "indices" : [ 0, 9 ],
        "id_str" : "21232327",
        "id" : 21232327
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SheSpeakDaTruth\/status\/670750397636722688\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wB6FhtQUjn",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CU776tdUwAEbPpt.png",
        "id_str" : "670750380578357249",
        "id" : 670750380578357249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CU776tdUwAEbPpt.png",
        "sizes" : [ {
          "h" : 180,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/wB6FhtQUjn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "670747632453689344",
    "geo" : { },
    "id_str" : "670750397636722688",
    "in_reply_to_user_id" : 1282062920,
    "text" : "@knthayer omg lets cry for the whitegirl who couldnt get the supercute shoes while blackboys r shot getting skittles https:\/\/t.co\/wB6FhtQUjn",
    "id" : 670750397636722688,
    "in_reply_to_status_id" : 670747632453689344,
    "created_at" : "2015-11-28 23:45:31 +0000",
    "in_reply_to_screen_name" : "SheSpeakDaTruth",
    "in_reply_to_user_id_str" : "1282062920",
    "user" : {
      "name" : "\u2102\u0127\u0451\u2113\u00A7\u03B5\u00E5\u264E (x_x)",
      "screen_name" : "SheSpeakDaTruth",
      "protected" : false,
      "id_str" : "1282062920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638524490369138688\/7D4wpPcw_normal.jpg",
      "id" : 1282062920,
      "verified" : false
    }
  },
  "id" : 671145223452495873,
  "created_at" : "2015-11-30 01:54:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "indices" : [ 3, 11 ],
      "id_str" : "885173964",
      "id" : 885173964
    }, {
      "name" : "SFChronicle",
      "screen_name" : "sfchronicle",
      "indices" : [ 18, 30 ],
      "id_str" : "121597316",
      "id" : 121597316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/H10evBBuY4",
      "expanded_url" : "http:\/\/webcache.googleusercontent.com\/search?q=cache:B_sctnVyrC4J:www.sfchronicle.com\/bayarea\/article\/Black-Oakland-residents-stopped-searched-with-6662485.php+&cd=1&hl=en&ct=clnk&gl=us",
      "display_url" : "webcache.googleusercontent.com\/search?q=cache\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671145064861720576",
  "text" : "RT @jerquee: this @sfchronicle Racial Profiling story made it to the front page of Google News before it was apparently deleted https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SFChronicle",
        "screen_name" : "sfchronicle",
        "indices" : [ 5, 17 ],
        "id_str" : "121597316",
        "id" : 121597316
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/H10evBBuY4",
        "expanded_url" : "http:\/\/webcache.googleusercontent.com\/search?q=cache:B_sctnVyrC4J:www.sfchronicle.com\/bayarea\/article\/Black-Oakland-residents-stopped-searched-with-6662485.php+&cd=1&hl=en&ct=clnk&gl=us",
        "display_url" : "webcache.googleusercontent.com\/search?q=cache\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671140885514608640",
    "text" : "this @sfchronicle Racial Profiling story made it to the front page of Google News before it was apparently deleted https:\/\/t.co\/H10evBBuY4",
    "id" : 671140885514608640,
    "created_at" : "2015-11-30 01:37:10 +0000",
    "user" : {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "protected" : false,
      "id_str" : "885173964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2879740670\/3705297a3d36fce362afdd93a090a3ea_normal.jpeg",
      "id" : 885173964,
      "verified" : false
    }
  },
  "id" : 671145064861720576,
  "created_at" : "2015-11-30 01:53:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E HarlemPreservation",
      "screen_name" : "EH_Preservation",
      "indices" : [ 3, 19 ],
      "id_str" : "365466063",
      "id" : 365466063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/1j9yggjsCm",
      "expanded_url" : "http:\/\/fb.me\/3bCQVEqSL",
      "display_url" : "fb.me\/3bCQVEqSL"
    } ]
  },
  "geo" : { },
  "id_str" : "671144941570105345",
  "text" : "RT @EH_Preservation: Black church in Oakland faces $3,500 fine because White residents annoyed by choir singing https:\/\/t.co\/1j9yggjsCm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/1j9yggjsCm",
        "expanded_url" : "http:\/\/fb.me\/3bCQVEqSL",
        "display_url" : "fb.me\/3bCQVEqSL"
      } ]
    },
    "geo" : { },
    "id_str" : "659381203166822400",
    "text" : "Black church in Oakland faces $3,500 fine because White residents annoyed by choir singing https:\/\/t.co\/1j9yggjsCm",
    "id" : 659381203166822400,
    "created_at" : "2015-10-28 14:48:24 +0000",
    "user" : {
      "name" : "E HarlemPreservation",
      "screen_name" : "EH_Preservation",
      "protected" : false,
      "id_str" : "365466063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1584166084\/303904_2388967573613_1533556349_32691408_104910619_n_normal.jpg",
      "id" : 365466063,
      "verified" : false
    }
  },
  "id" : 671144941570105345,
  "created_at" : "2015-11-30 01:53:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "668512021902569472",
  "geo" : { },
  "id_str" : "671141440903360512",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  yo flash me a pic of the board one time  ;^P",
  "id" : 671141440903360512,
  "in_reply_to_status_id" : 668512021902569472,
  "created_at" : "2015-11-30 01:39:23 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 0, 9 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 10, 21 ],
      "id_str" : "15734539",
      "id" : 15734539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "670716460868743168",
  "geo" : { },
  "id_str" : "670716885722382337",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jfhbrook @FrozenFire  Adele is a sandwich franchise from the UK",
  "id" : 670716885722382337,
  "in_reply_to_status_id" : 670716460868743168,
  "created_at" : "2015-11-28 21:32:21 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670356177587302401",
  "text" : "go shopping today, and don't buy anything, but knock down everything in sight.  #BlackFriday",
  "id" : 670356177587302401,
  "created_at" : "2015-11-27 21:39:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670346289859596288",
  "text" : "go shopping today, and don't buy anything, but knock down everything in sight.",
  "id" : 670346289859596288,
  "created_at" : "2015-11-27 20:59:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670008686576701440",
  "text" : "unhappy statism to all ya dummies",
  "id" : 670008686576701440,
  "created_at" : "2015-11-26 22:38:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669995440557813760",
  "text" : "*GOBBLES THE UNITED STATES OF AMERIKA*",
  "id" : 669995440557813760,
  "created_at" : "2015-11-26 21:45:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abrara",
      "screen_name" : "Abrara_Rageh",
      "indices" : [ 3, 16 ],
      "id_str" : "244947603",
      "id" : 244947603
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Abrara_Rageh\/status\/669257204403277824\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/HPGOqhJXLE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmt4BXUwAA3qRr.jpg",
      "id_str" : "669257197591773184",
      "id" : 669257197591773184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmt4BXUwAA3qRr.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/HPGOqhJXLE"
    } ],
    "hashtags" : [ {
      "text" : "4thPrecinctShutDown",
      "indices" : [ 51, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669625296568602625",
  "text" : "RT @Abrara_Rageh: One of the guys shot yesterday @ #4thPrecinctShutDown here today with a cane. https:\/\/t.co\/HPGOqhJXLE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Abrara_Rageh\/status\/669257204403277824\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/HPGOqhJXLE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUmt4BXUwAA3qRr.jpg",
        "id_str" : "669257197591773184",
        "id" : 669257197591773184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUmt4BXUwAA3qRr.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/HPGOqhJXLE"
      } ],
      "hashtags" : [ {
        "text" : "4thPrecinctShutDown",
        "indices" : [ 33, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669257204403277824",
    "text" : "One of the guys shot yesterday @ #4thPrecinctShutDown here today with a cane. https:\/\/t.co\/HPGOqhJXLE",
    "id" : 669257204403277824,
    "created_at" : "2015-11-24 20:52:06 +0000",
    "user" : {
      "name" : "Abrara",
      "screen_name" : "Abrara_Rageh",
      "protected" : false,
      "id_str" : "244947603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723605219490177024\/76vKXql1_normal.jpg",
      "id" : 244947603,
      "verified" : false
    }
  },
  "id" : 669625296568602625,
  "created_at" : "2015-11-25 21:14:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendell Pierce",
      "screen_name" : "WendellPierce",
      "indices" : [ 3, 17 ],
      "id_str" : "247114704",
      "id" : 247114704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669624664789016576",
  "text" : "RT @WendellPierce: If every Black male 18-35 applied for a conceal&amp; carry permit, and then joined NRA in one day; there would be gun contro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668630026800074753",
    "text" : "If every Black male 18-35 applied for a conceal&amp; carry permit, and then joined NRA in one day; there would be gun control laws in a second",
    "id" : 668630026800074753,
    "created_at" : "2015-11-23 03:19:55 +0000",
    "user" : {
      "name" : "Wendell Pierce",
      "screen_name" : "WendellPierce",
      "protected" : false,
      "id_str" : "247114704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725460021518176256\/Kmqsq7YF_normal.jpg",
      "id" : 247114704,
      "verified" : true
    }
  },
  "id" : 669624664789016576,
  "created_at" : "2015-11-25 21:12:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 3, 15 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 51, 68 ]
    }, {
      "text" : "ThanksgivingWithBlackFamilies",
      "indices" : [ 69, 99 ]
    }, {
      "text" : "Oakland",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/zFglqdowSS",
      "expanded_url" : "http:\/\/www.talkoakland.org\/blog",
      "display_url" : "talkoakland.org\/blog"
    } ]
  },
  "geo" : { },
  "id_str" : "669287223490035712",
  "text" : "RT @TalkOakland: Identity: https:\/\/t.co\/zFglqdowSS #BlackLivesMatter #ThanksgivingWithBlackFamilies #Oakland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ 34, 51 ]
      }, {
        "text" : "ThanksgivingWithBlackFamilies",
        "indices" : [ 52, 82 ]
      }, {
        "text" : "Oakland",
        "indices" : [ 83, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/zFglqdowSS",
        "expanded_url" : "http:\/\/www.talkoakland.org\/blog",
        "display_url" : "talkoakland.org\/blog"
      } ]
    },
    "geo" : { },
    "id_str" : "669268408110739456",
    "text" : "Identity: https:\/\/t.co\/zFglqdowSS #BlackLivesMatter #ThanksgivingWithBlackFamilies #Oakland",
    "id" : 669268408110739456,
    "created_at" : "2015-11-24 21:36:37 +0000",
    "user" : {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "protected" : false,
      "id_str" : "3280343994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682306358234976265\/CSBy-srW_normal.jpg",
      "id" : 3280343994,
      "verified" : false
    }
  },
  "id" : 669287223490035712,
  "created_at" : "2015-11-24 22:51:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#Asians4BlackLives",
      "screen_name" : "Asians4BlkLives",
      "indices" : [ 3, 19 ],
      "id_str" : "3067215570",
      "id" : 3067215570
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Asians4BlkLives\/status\/668952249700392960\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/aMMWt5Vsj9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUiYgXUUkAAklyu.jpg",
      "id_str" : "668952226447003648",
      "id" : 668952226447003648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUiYgXUUkAAklyu.jpg",
      "sizes" : [ {
        "h" : 937,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 937,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 549,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/aMMWt5Vsj9"
    } ],
    "hashtags" : [ {
      "text" : "3rdWorld4BlackPower",
      "indices" : [ 82, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669010390139801600",
  "text" : "RT @Asians4BlkLives: 1000+ Evictions a month in Oakland. We demand tenant rights! #3rdWorld4BlackPower https:\/\/t.co\/aMMWt5Vsj9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Asians4BlkLives\/status\/668952249700392960\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/aMMWt5Vsj9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUiYgXUUkAAklyu.jpg",
        "id_str" : "668952226447003648",
        "id" : 668952226447003648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUiYgXUUkAAklyu.jpg",
        "sizes" : [ {
          "h" : 937,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 937,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/aMMWt5Vsj9"
      } ],
      "hashtags" : [ {
        "text" : "3rdWorld4BlackPower",
        "indices" : [ 61, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668952249700392960",
    "text" : "1000+ Evictions a month in Oakland. We demand tenant rights! #3rdWorld4BlackPower https:\/\/t.co\/aMMWt5Vsj9",
    "id" : 668952249700392960,
    "created_at" : "2015-11-24 00:40:19 +0000",
    "user" : {
      "name" : "#Asians4BlackLives",
      "screen_name" : "Asians4BlkLives",
      "protected" : false,
      "id_str" : "3067215570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574364433650057216\/h1JhQ_fX_normal.jpeg",
      "id" : 3067215570,
      "verified" : false
    }
  },
  "id" : 669010390139801600,
  "created_at" : "2015-11-24 04:31:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "no",
      "screen_name" : "the_N0",
      "indices" : [ 3, 10 ],
      "id_str" : "42699163",
      "id" : 42699163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668746914616074240",
  "text" : "RT @the_N0: You all are doing a lot of moralizing and bickering on twitter when you should be wiping devices and figuring out contingency p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668584706653360128",
    "text" : "You all are doing a lot of moralizing and bickering on twitter when you should be wiping devices and figuring out contingency plans.",
    "id" : 668584706653360128,
    "created_at" : "2015-11-23 00:19:50 +0000",
    "user" : {
      "name" : "no",
      "screen_name" : "the_N0",
      "protected" : false,
      "id_str" : "42699163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728259978042085376\/NvWyFg0v_normal.jpg",
      "id" : 42699163,
      "verified" : false
    }
  },
  "id" : 668746914616074240,
  "created_at" : "2015-11-23 11:04:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668741847850680320",
  "text" : "Oakland is ready to explode\nThat's my word from the street",
  "id" : 668741847850680320,
  "created_at" : "2015-11-23 10:44:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667942900374765569",
  "text" : "i aint got time to wait for you to get me\ni gotta laugh at myself",
  "id" : 667942900374765569,
  "created_at" : "2015-11-21 05:49:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#FreeJalilMuntaqim",
      "screen_name" : "BlakeDontCrack",
      "indices" : [ 3, 18 ],
      "id_str" : "205531045",
      "id" : 205531045
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BlakeDontCrack\/status\/667873746762371072\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Bu7uYLXBd9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUTDoJ7UcAA3Giv.jpg",
      "id_str" : "667873739384582144",
      "id" : 667873739384582144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUTDoJ7UcAA3Giv.jpg",
      "sizes" : [ {
        "h" : 472,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 737
      }, {
        "h" : 834,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 737
      } ],
      "display_url" : "pic.twitter.com\/Bu7uYLXBd9"
    } ],
    "hashtags" : [ {
      "text" : "RichardPerkins",
      "indices" : [ 20, 35 ]
    }, {
      "text" : "Oakland",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667894663878041600",
  "text" : "RT @BlakeDontCrack: #RichardPerkins is the Black man that #Oakland Police executed on Sunday. https:\/\/t.co\/Bu7uYLXBd9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BlakeDontCrack\/status\/667873746762371072\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/Bu7uYLXBd9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUTDoJ7UcAA3Giv.jpg",
        "id_str" : "667873739384582144",
        "id" : 667873739384582144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUTDoJ7UcAA3Giv.jpg",
        "sizes" : [ {
          "h" : 472,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 737
        }, {
          "h" : 834,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 737
        } ],
        "display_url" : "pic.twitter.com\/Bu7uYLXBd9"
      } ],
      "hashtags" : [ {
        "text" : "RichardPerkins",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "Oakland",
        "indices" : [ 38, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667873746762371072",
    "text" : "#RichardPerkins is the Black man that #Oakland Police executed on Sunday. https:\/\/t.co\/Bu7uYLXBd9",
    "id" : 667873746762371072,
    "created_at" : "2015-11-21 01:14:44 +0000",
    "user" : {
      "name" : "#FreeJalilMuntaqim",
      "screen_name" : "BlakeDontCrack",
      "protected" : false,
      "id_str" : "205531045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726576575743856641\/b7se2zix_normal.jpg",
      "id" : 205531045,
      "verified" : false
    }
  },
  "id" : 667894663878041600,
  "created_at" : "2015-11-21 02:37:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667493847602065409",
  "text" : "ima forgive you in a minute, but...",
  "id" : 667493847602065409,
  "created_at" : "2015-11-20 00:05:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Carboni",
      "screen_name" : "acarboni",
      "indices" : [ 3, 12 ],
      "id_str" : "14137737",
      "id" : 14137737
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/acarboni\/status\/667388121315737602\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Q82kEXyfq4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMJ9dFWEAEVN0b.jpg",
      "id_str" : "667388121164681217",
      "id" : 667388121164681217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMJ9dFWEAEVN0b.jpg",
      "sizes" : [ {
        "h" : 985,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 985,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q82kEXyfq4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667477794142580736",
  "text" : "RT @acarboni: This is a poster for 1950s children. Maybe we could all look at it now, though? https:\/\/t.co\/Q82kEXyfq4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/acarboni\/status\/667388121315737602\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/Q82kEXyfq4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMJ9dFWEAEVN0b.jpg",
        "id_str" : "667388121164681217",
        "id" : 667388121164681217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMJ9dFWEAEVN0b.jpg",
        "sizes" : [ {
          "h" : 985,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 985,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Q82kEXyfq4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667388121315737602",
    "text" : "This is a poster for 1950s children. Maybe we could all look at it now, though? https:\/\/t.co\/Q82kEXyfq4",
    "id" : 667388121315737602,
    "created_at" : "2015-11-19 17:05:02 +0000",
    "user" : {
      "name" : "Anthony Carboni",
      "screen_name" : "acarboni",
      "protected" : false,
      "id_str" : "14137737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693980633656270851\/lrWUxsht_normal.jpg",
      "id" : 14137737,
      "verified" : false
    }
  },
  "id" : 667477794142580736,
  "created_at" : "2015-11-19 23:01:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Willis",
      "screen_name" : "owillis",
      "indices" : [ 3, 11 ],
      "id_str" : "3497941",
      "id" : 3497941
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/owillis\/status\/667452723583959041\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/YsSIGU31LY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNEtx7UAAAbkZA.jpg",
      "id_str" : "667452723067879424",
      "id" : 667452723067879424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNEtx7UAAAbkZA.jpg",
      "sizes" : [ {
        "h" : 472,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/YsSIGU31LY"
    } ],
    "hashtags" : [ {
      "text" : "SyrianRefugees",
      "indices" : [ 34, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667477754728747009",
  "text" : "RT @owillis: Superman on refugees #SyrianRefugees https:\/\/t.co\/YsSIGU31LY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/owillis\/status\/667452723583959041\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/YsSIGU31LY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNEtx7UAAAbkZA.jpg",
        "id_str" : "667452723067879424",
        "id" : 667452723067879424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNEtx7UAAAbkZA.jpg",
        "sizes" : [ {
          "h" : 472,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/YsSIGU31LY"
      } ],
      "hashtags" : [ {
        "text" : "SyrianRefugees",
        "indices" : [ 21, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667452723583959041",
    "text" : "Superman on refugees #SyrianRefugees https:\/\/t.co\/YsSIGU31LY",
    "id" : 667452723583959041,
    "created_at" : "2015-11-19 21:21:44 +0000",
    "user" : {
      "name" : "Oliver Willis",
      "screen_name" : "owillis",
      "protected" : false,
      "id_str" : "3497941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689647005598089216\/ZrrU8PFG_normal.jpg",
      "id" : 3497941,
      "verified" : false
    }
  },
  "id" : 667477754728747009,
  "created_at" : "2015-11-19 23:01:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667455781445308416",
  "text" : "I am grateful for my family, none of whom are blood-related to me, tho we are all 99.9999 copies of the same data.",
  "id" : 667455781445308416,
  "created_at" : "2015-11-19 21:33:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667212073659568128",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  o_o",
  "id" : 667212073659568128,
  "created_at" : "2015-11-19 05:25:29 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667117477260750848",
  "text" : "BIGG BABY KITTEHS",
  "id" : 667117477260750848,
  "created_at" : "2015-11-18 23:09:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/38tY9poHhu",
      "expanded_url" : "http:\/\/www.thefront.com\/",
      "display_url" : "thefront.com"
    } ]
  },
  "geo" : { },
  "id_str" : "667116639024889856",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  https:\/\/t.co\/38tY9poHhu",
  "id" : 667116639024889856,
  "created_at" : "2015-11-18 23:06:15 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667113055180816388",
  "text" : "Doges alwehs forgive",
  "id" : 667113055180816388,
  "created_at" : "2015-11-18 22:52:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666980469574123523",
  "geo" : { },
  "id_str" : "667112716096548864",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  f6  Forgiveness is radical.",
  "id" : 667112716096548864,
  "in_reply_to_status_id" : 666980469574123523,
  "created_at" : "2015-11-18 22:50:40 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mc.fly",
      "screen_name" : "mcflyhh",
      "indices" : [ 3, 11 ],
      "id_str" : "37400546",
      "id" : 37400546
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mcflyhh\/status\/667002351920746498\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/pIIpZV8vIG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUGrGp5VAAAjH7M.jpg",
      "id_str" : "667002350641414144",
      "id" : 667002350641414144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUGrGp5VAAAjH7M.jpg",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 799
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 799
      } ],
      "display_url" : "pic.twitter.com\/pIIpZV8vIG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667072734791249920",
  "text" : "RT @mcflyhh: solidarity.... https:\/\/t.co\/pIIpZV8vIG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mcflyhh\/status\/667002351920746498\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/pIIpZV8vIG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUGrGp5VAAAjH7M.jpg",
        "id_str" : "667002350641414144",
        "id" : 667002350641414144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUGrGp5VAAAjH7M.jpg",
        "sizes" : [ {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 799
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 799
        } ],
        "display_url" : "pic.twitter.com\/pIIpZV8vIG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667002351920746498",
    "text" : "solidarity.... https:\/\/t.co\/pIIpZV8vIG",
    "id" : 667002351920746498,
    "created_at" : "2015-11-18 15:32:07 +0000",
    "user" : {
      "name" : "mc.fly",
      "screen_name" : "mcflyhh",
      "protected" : false,
      "id_str" : "37400546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/815333917\/elmar-bildvontimfsmall_normal.jpg",
      "id" : 37400546,
      "verified" : false
    }
  },
  "id" : 667072734791249920,
  "created_at" : "2015-11-18 20:11:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Leroux",
      "screen_name" : "marcusleroux",
      "indices" : [ 3, 16 ],
      "id_str" : "89920433",
      "id" : 89920433
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/marcusleroux\/status\/666625869054615552\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/llgPodRHQJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUBUsfoWEAA_L3f.png",
      "id_str" : "666625868232527872",
      "id" : 666625868232527872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUBUsfoWEAA_L3f.png",
      "sizes" : [ {
        "h" : 439,
        "resize" : "fit",
        "w" : 713
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 713
      } ],
      "display_url" : "pic.twitter.com\/llgPodRHQJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666646632201478144",
  "text" : "RT @marcusleroux: Millennials' \"gender fluidity\" will make it harder to sell washing detergent and baked beans, says market researcher http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/marcusleroux\/status\/666625869054615552\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/llgPodRHQJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUBUsfoWEAA_L3f.png",
        "id_str" : "666625868232527872",
        "id" : 666625868232527872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUBUsfoWEAA_L3f.png",
        "sizes" : [ {
          "h" : 439,
          "resize" : "fit",
          "w" : 713
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 713
        } ],
        "display_url" : "pic.twitter.com\/llgPodRHQJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666625869054615552",
    "text" : "Millennials' \"gender fluidity\" will make it harder to sell washing detergent and baked beans, says market researcher https:\/\/t.co\/llgPodRHQJ",
    "id" : 666625869054615552,
    "created_at" : "2015-11-17 14:36:07 +0000",
    "user" : {
      "name" : "Marcus Leroux",
      "screen_name" : "marcusleroux",
      "protected" : false,
      "id_str" : "89920433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2221266469\/me_normal.jpg",
      "id" : 89920433,
      "verified" : true
    }
  },
  "id" : 666646632201478144,
  "created_at" : "2015-11-17 15:58:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FriendlyMatch",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666634384204656641",
  "geo" : { },
  "id_str" : "666634451057668096",
  "in_reply_to_user_id" : 46961216,
  "text" : "@TalkOakland  #FriendlyMatch",
  "id" : 666634451057668096,
  "in_reply_to_status_id" : 666634384204656641,
  "created_at" : "2015-11-17 15:10:13 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666484668930220032",
  "geo" : { },
  "id_str" : "666634384204656641",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  okay, make that last move Kxd7",
  "id" : 666634384204656641,
  "in_reply_to_status_id" : 666484668930220032,
  "created_at" : "2015-11-17 15:09:57 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666484668930220032",
  "geo" : { },
  "id_str" : "666634197277143041",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  RECOUNT!",
  "id" : 666634197277143041,
  "in_reply_to_status_id" : 666484668930220032,
  "created_at" : "2015-11-17 15:09:12 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666471916715114497",
  "geo" : { },
  "id_str" : "666474210567540736",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  your move",
  "id" : 666474210567540736,
  "in_reply_to_status_id" : 666471916715114497,
  "created_at" : "2015-11-17 04:33:28 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666441519579004928",
  "geo" : { },
  "id_str" : "666470828129697792",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  What is selective grief?",
  "id" : 666470828129697792,
  "in_reply_to_status_id" : 666441519579004928,
  "created_at" : "2015-11-17 04:20:02 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Counted",
      "screen_name" : "thecounted",
      "indices" : [ 3, 14 ],
      "id_str" : "3144928678",
      "id" : 3144928678
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/thecounted\/status\/666291690127380480\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/nDsb3vuh6n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT8kwu3UwAE2PqC.png",
      "id_str" : "666291689506521089",
      "id" : 666291689506521089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT8kwu3UwAE2PqC.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/nDsb3vuh6n"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/DMPd9jw8vY",
      "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2015\/nov\/16\/the-counted-killed-by-police-1000?CMP=twt_tc",
      "display_url" : "theguardian.com\/us-news\/2015\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666431779306213376",
  "text" : "RT @thecounted: Number of people killed by US police in 2015 now at 1,000 after Oakland shooting https:\/\/t.co\/DMPd9jw8vY https:\/\/t.co\/nDsb3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/thecounted\/status\/666291690127380480\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/nDsb3vuh6n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT8kwu3UwAE2PqC.png",
        "id_str" : "666291689506521089",
        "id" : 666291689506521089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT8kwu3UwAE2PqC.png",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/nDsb3vuh6n"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/DMPd9jw8vY",
        "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2015\/nov\/16\/the-counted-killed-by-police-1000?CMP=twt_tc",
        "display_url" : "theguardian.com\/us-news\/2015\/n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666291690127380480",
    "text" : "Number of people killed by US police in 2015 now at 1,000 after Oakland shooting https:\/\/t.co\/DMPd9jw8vY https:\/\/t.co\/nDsb3vuh6n",
    "id" : 666291690127380480,
    "created_at" : "2015-11-16 16:28:12 +0000",
    "user" : {
      "name" : "The Counted",
      "screen_name" : "thecounted",
      "protected" : false,
      "id_str" : "3144928678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729410127770624006\/OVF-CRhJ_normal.jpg",
      "id" : 3144928678,
      "verified" : true
    }
  },
  "id" : 666431779306213376,
  "created_at" : "2015-11-17 01:44:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666182881652269056",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland Qxd7",
  "id" : 666182881652269056,
  "created_at" : "2015-11-16 09:15:50 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665429981405847554",
  "text" : "do \u007B\n  diddy.dumb()\n  diddy.do()\n\u007D while (diddy)",
  "id" : 665429981405847554,
  "created_at" : "2015-11-14 07:24:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665428835211599872",
  "text" : "current status: rasta wiring",
  "id" : 665428835211599872,
  "created_at" : "2015-11-14 07:19:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/nx8iSMN7M6",
      "expanded_url" : "https:\/\/twitter.com\/DogSolutions\/status\/651900168007196672",
      "display_url" : "twitter.com\/DogSolutions\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "665059647179616256",
  "text" : "pictured: the impossible goal of catching laser in mouth https:\/\/t.co\/nx8iSMN7M6",
  "id" : 665059647179616256,
  "created_at" : "2015-11-13 06:52:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664832708032331776",
  "geo" : { },
  "id_str" : "664881977963577344",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  Qb6",
  "id" : 664881977963577344,
  "in_reply_to_status_id" : 664832708032331776,
  "created_at" : "2015-11-12 19:06:31 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664752614978928640",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  c5",
  "id" : 664752614978928640,
  "created_at" : "2015-11-12 10:32:28 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664584707347054592",
  "geo" : { },
  "id_str" : "664593052422545408",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  \n\nin view of this mea culpa, this plea of guilt\n\nI vote she only be evicted, and not banished or killed\n\nso it shall be so -_-",
  "id" : 664593052422545408,
  "in_reply_to_status_id" : 664584707347054592,
  "created_at" : "2015-11-11 23:58:25 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664549504570388482",
  "geo" : { },
  "id_str" : "664558624149147648",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  Using your queen like a pawn?\n\nNe7",
  "id" : 664558624149147648,
  "in_reply_to_status_id" : 664549504570388482,
  "created_at" : "2015-11-11 21:41:37 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664378320071495680",
  "geo" : { },
  "id_str" : "664540061271126017",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland Bd7",
  "id" : 664540061271126017,
  "in_reply_to_status_id" : 664378320071495680,
  "created_at" : "2015-11-11 20:27:51 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664327433827414018",
  "geo" : { },
  "id_str" : "664327976482279424",
  "in_reply_to_user_id" : 46961216,
  "text" : "@TalkOakland  then sleeeeeeeeep",
  "id" : 664327976482279424,
  "in_reply_to_status_id" : 664327433827414018,
  "created_at" : "2015-11-11 06:25:06 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664318084732162048",
  "geo" : { },
  "id_str" : "664327433827414018",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  d6",
  "id" : 664327433827414018,
  "in_reply_to_status_id" : 664318084732162048,
  "created_at" : "2015-11-11 06:22:57 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664316641904164864",
  "text" : "IM LITERALLY DEAD",
  "id" : 664316641904164864,
  "created_at" : "2015-11-11 05:40:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664313039638761472",
  "geo" : { },
  "id_str" : "664316063178342400",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland \n\nNb4\n\nNb4 you tap out!",
  "id" : 664316063178342400,
  "in_reply_to_status_id" : 664313039638761472,
  "created_at" : "2015-11-11 05:37:46 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664313309785513984",
  "text" : "currently listening to Slave",
  "id" : 664313309785513984,
  "created_at" : "2015-11-11 05:26:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anonymous",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664312872810319872",
  "geo" : { },
  "id_str" : "664313167560896512",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  #anonymous will be there you can count on that",
  "id" : 664313167560896512,
  "in_reply_to_status_id" : 664312872810319872,
  "created_at" : "2015-11-11 05:26:16 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664310360728453120",
  "geo" : { },
  "id_str" : "664312149624229888",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland exd5 \n\nblowin smoke already",
  "id" : 664312149624229888,
  "in_reply_to_status_id" : 664310360728453120,
  "created_at" : "2015-11-11 05:22:13 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ANONYMOUS",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664310360728453120",
  "geo" : { },
  "id_str" : "664311429755895808",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  #ANONYMOUS\n\nYOU THINK I KNOW YOU?\nYOU DONT KNOW ME!",
  "id" : 664311429755895808,
  "in_reply_to_status_id" : 664310360728453120,
  "created_at" : "2015-11-11 05:19:21 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664304053942284289",
  "geo" : { },
  "id_str" : "664308903610454016",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland e6",
  "id" : 664308903610454016,
  "in_reply_to_status_id" : 664304053942284289,
  "created_at" : "2015-11-11 05:09:19 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/xrOOBb8X30",
      "expanded_url" : "https:\/\/twitter.com\/biggbabybubba\/status\/540922893887344640",
      "display_url" : "twitter.com\/biggbabybubba\/\u2026"
    }, {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/F02q6ouWU8",
      "expanded_url" : "https:\/\/twitter.com\/biggbabybubba\/status\/540344786188660736",
      "display_url" : "twitter.com\/biggbabybubba\/\u2026"
    }, {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/6YJ9YSNsdD",
      "expanded_url" : "https:\/\/twitter.com\/biggbabybubba\/status\/537074990898614275",
      "display_url" : "twitter.com\/biggbabybubba\/\u2026"
    }, {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/G2Sy1mOX2E",
      "expanded_url" : "https:\/\/twitter.com\/biggbabybubba\/status\/537070842140561408",
      "display_url" : "twitter.com\/biggbabybubba\/\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/S7Dj7P1CGZ",
      "expanded_url" : "https:\/\/twitter.com\/biggbabybubba\/status\/536993988314542080",
      "display_url" : "twitter.com\/biggbabybubba\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "664138024788234240",
  "geo" : { },
  "id_str" : "664307775812407297",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  \nfound\nhttps:\/\/t.co\/xrOOBb8X30\nhttps:\/\/t.co\/F02q6ouWU8\nhttps:\/\/t.co\/6YJ9YSNsdD\nhttps:\/\/t.co\/G2Sy1mOX2E\nhttps:\/\/t.co\/S7Dj7P1CGZ",
  "id" : 664307775812407297,
  "in_reply_to_status_id" : 664138024788234240,
  "created_at" : "2015-11-11 05:04:50 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664300664751714304",
  "geo" : { },
  "id_str" : "664303102967676929",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  Nc6",
  "id" : 664303102967676929,
  "in_reply_to_status_id" : 664300664751714304,
  "created_at" : "2015-11-11 04:46:16 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664298852074192896",
  "text" : "u cant phase me\n\nnot much u change my phase\n\nmy synchronicity with real time\n\nwow did I just say that\n\nheheh no, I type it, d\n\n-bigbabybubba",
  "id" : 664298852074192896,
  "created_at" : "2015-11-11 04:29:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 0, 12 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664296889093718016",
  "in_reply_to_user_id" : 3280343994,
  "text" : "@TalkOakland  YOUR MOVE",
  "id" : 664296889093718016,
  "created_at" : "2015-11-11 04:21:35 +0000",
  "in_reply_to_screen_name" : "TalkOakland",
  "in_reply_to_user_id_str" : "3280343994",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "indices" : [ 3, 18 ],
      "id_str" : "620142261",
      "id" : 620142261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664291516689440768",
  "text" : "RT @KimKierkegaard: If my contemporaries could understand how I suffer, I am sure they would be so profoundly shaken that they would buy me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664225536332419073",
    "text" : "If my contemporaries could understand how I suffer, I am sure they would be so profoundly shaken that they would buy me churros.",
    "id" : 664225536332419073,
    "created_at" : "2015-11-10 23:38:03 +0000",
    "user" : {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "protected" : false,
      "id_str" : "620142261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2346161730\/images-2_normal.jpg",
      "id" : 620142261,
      "verified" : false
    }
  },
  "id" : 664291516689440768,
  "created_at" : "2015-11-11 04:00:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/HK1NFHYqQA",
      "expanded_url" : "https:\/\/twitter.com\/postcrunk\/status\/664287051223842816",
      "display_url" : "twitter.com\/postcrunk\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664290994066624512",
  "text" : "all mouth https:\/\/t.co\/HK1NFHYqQA",
  "id" : 664290994066624512,
  "created_at" : "2015-11-11 03:58:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662916240239779840",
  "text" : "I desire to be more free than you.  I do remorse of that.  It's been a privilege, folks.  You've been a terrible audience.",
  "id" : 662916240239779840,
  "created_at" : "2015-11-07 08:55:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/38SbLpBZ2K",
      "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/661635653105532928",
      "display_url" : "twitter.com\/ShaunKing\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661660302644150272",
  "text" : "heh the same thing happened to me at same age with a D.A.R.E. cop https:\/\/t.co\/38SbLpBZ2K",
  "id" : 661660302644150272,
  "created_at" : "2015-11-03 21:44:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661609358099222528",
  "text" : "a heart called like?",
  "id" : 661609358099222528,
  "created_at" : "2015-11-03 18:22:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/5q0IK02OWl",
      "expanded_url" : "https:\/\/twitter.com\/the_intercept\/status\/661548049282519040",
      "display_url" : "twitter.com\/the_intercept\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661608261771112448",
  "text" : "Nazis https:\/\/t.co\/5q0IK02OWl",
  "id" : 661608261771112448,
  "created_at" : "2015-11-03 18:17:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Intercept FLM",
      "screen_name" : "the_intercept",
      "indices" : [ 3, 17 ],
      "id_str" : "719972682322853888",
      "id" : 719972682322853888
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/the_intercept\/status\/661219799306002432\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Ob6Inf1exN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0f2V-WUAAn3Mv.jpg",
      "id_str" : "661219738765381632",
      "id" : 661219738765381632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0f2V-WUAAn3Mv.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ob6Inf1exN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/eNtn0z5jc8",
      "expanded_url" : "http:\/\/interc.pt\/1LGM3OV",
      "display_url" : "interc.pt\/1LGM3OV"
    } ]
  },
  "geo" : { },
  "id_str" : "661268927792742401",
  "text" : "RT @the_intercept: In past year, U.S. special ops forces were deployed to a record-breaking 147 countries. https:\/\/t.co\/eNtn0z5jc8 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/the_intercept\/status\/661219799306002432\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/Ob6Inf1exN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0f2V-WUAAn3Mv.jpg",
        "id_str" : "661219738765381632",
        "id" : 661219738765381632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0f2V-WUAAn3Mv.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ob6Inf1exN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/eNtn0z5jc8",
        "expanded_url" : "http:\/\/interc.pt\/1LGM3OV",
        "display_url" : "interc.pt\/1LGM3OV"
      } ]
    },
    "geo" : { },
    "id_str" : "661219799306002432",
    "text" : "In past year, U.S. special ops forces were deployed to a record-breaking 147 countries. https:\/\/t.co\/eNtn0z5jc8 https:\/\/t.co\/Ob6Inf1exN",
    "id" : 661219799306002432,
    "created_at" : "2015-11-02 16:34:19 +0000",
    "user" : {
      "name" : "The Intercept",
      "screen_name" : "theintercept",
      "protected" : false,
      "id_str" : "2329066872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621138310585409536\/mSJHNbO6_normal.png",
      "id" : 2329066872,
      "verified" : true
    }
  },
  "id" : 661268927792742401,
  "created_at" : "2015-11-02 19:49:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]