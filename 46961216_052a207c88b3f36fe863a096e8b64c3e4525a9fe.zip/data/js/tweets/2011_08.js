Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aurich Lawson",
      "screen_name" : "aurich",
      "indices" : [ 3, 10 ],
      "id_str" : "14535172",
      "id" : 14535172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/qw3hom3",
      "expanded_url" : "http:\/\/vimeo.com\/28304264",
      "display_url" : "vimeo.com\/28304264"
    } ]
  },
  "geo" : { },
  "id_str" : "108442115759013888",
  "text" : "RT @aurich: And the Best Video Use of Exotic Ferrofluid goes to \u2026 http:\/\/t.co\/qw3hom3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 73 ],
        "url" : "http:\/\/t.co\/qw3hom3",
        "expanded_url" : "http:\/\/vimeo.com\/28304264",
        "display_url" : "vimeo.com\/28304264"
      } ]
    },
    "geo" : { },
    "id_str" : "108390544778080257",
    "text" : "And the Best Video Use of Exotic Ferrofluid goes to \u2026 http:\/\/t.co\/qw3hom3",
    "id" : 108390544778080257,
    "created_at" : "2011-08-30 04:08:14 +0000",
    "user" : {
      "name" : "Aurich Lawson",
      "screen_name" : "aurich",
      "protected" : false,
      "id_str" : "14535172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656888669437952000\/QF2-knmB_normal.png",
      "id" : 14535172,
      "verified" : false
    }
  },
  "id" : 108442115759013888,
  "created_at" : "2011-08-30 07:33:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107706732322627584",
  "geo" : { },
  "id_str" : "108437692265668608",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin that was a good one, brightness o mine.",
  "id" : 108437692265668608,
  "in_reply_to_status_id" : 107706732322627584,
  "created_at" : "2011-08-30 07:15:35 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107330480910774272",
  "geo" : { },
  "id_str" : "107332800700624898",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin thanks bby! we're crusin'!",
  "id" : 107332800700624898,
  "in_reply_to_status_id" : 107330480910774272,
  "created_at" : "2011-08-27 06:05:08 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 36, 50 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/KarvSxM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=095iyCeJSbs",
      "display_url" : "youtube.com\/watch?v=095iyC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "107329634374393856",
  "text" : "KRAFTWERK BREAK http:\/\/t.co\/KarvSxM @node_knockout",
  "id" : 107329634374393856,
  "created_at" : "2011-08-27 05:52:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 4, 11 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107236503352131584",
  "text" : "WTF @google docs. If you can't fucking connect to google's teets, local save and let me keep TYPING you retarding POS",
  "id" : 107236503352131584,
  "created_at" : "2011-08-26 23:42:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 13, 27 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 70 ],
      "url" : "http:\/\/t.co\/bUtpHyo",
      "expanded_url" : "http:\/\/imgur.com\/3sopm",
      "display_url" : "imgur.com\/3sopm"
    } ]
  },
  "geo" : { },
  "id_str" : "107206436198686720",
  "text" : "this is what @node_knockout preparation looks like http:\/\/t.co\/bUtpHyo",
  "id" : 107206436198686720,
  "created_at" : "2011-08-26 21:43:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bradford cross",
      "screen_name" : "bradfordcross",
      "indices" : [ 3, 17 ],
      "id_str" : "36153601",
      "id" : 36153601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107010568380096513",
  "text" : "RT @bradfordcross: there is no late night hackathon...just keeping the game at the same level...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106994482666414080",
    "text" : "there is no late night hackathon...just keeping the game at the same level...",
    "id" : 106994482666414080,
    "created_at" : "2011-08-26 07:40:47 +0000",
    "user" : {
      "name" : "bradford cross",
      "screen_name" : "bradfordcross",
      "protected" : false,
      "id_str" : "36153601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711267766636908544\/dR3wP6YF_normal.jpg",
      "id" : 36153601,
      "verified" : false
    }
  },
  "id" : 107010568380096513,
  "created_at" : "2011-08-26 08:44:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 0, 7 ],
      "id_str" : "15540222",
      "id" : 15540222
    }, {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 8, 22 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106839800023232513",
  "in_reply_to_user_id" : 15540222,
  "text" : "@rauchg @node_knockout pls advise, re socket.io: many tiny msgs, few larger msgs, medium\/medium? #nodejs #411",
  "id" : 106839800023232513,
  "created_at" : "2011-08-25 21:26:07 +0000",
  "in_reply_to_screen_name" : "rauchg",
  "in_reply_to_user_id_str" : "15540222",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 0, 7 ],
      "id_str" : "15540222",
      "id" : 15540222
    }, {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 8, 22 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106824412682141696",
  "geo" : { },
  "id_str" : "106839478383022080",
  "in_reply_to_user_id" : 15540222,
  "text" : "@rauchg @node_knockout pls advise: many tiny msgs, few larger msgs, medium\/medium? #nodejs #411",
  "id" : 106839478383022080,
  "in_reply_to_status_id" : 106824412682141696,
  "created_at" : "2011-08-25 21:24:51 +0000",
  "in_reply_to_screen_name" : "rauchg",
  "in_reply_to_user_id_str" : "15540222",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 3, 17 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http:\/\/t.co\/26F3ZU1",
      "expanded_url" : "http:\/\/nodeknockout.com\/teams\/fortnight-labs",
      "display_url" : "nodeknockout.com\/teams\/fortnigh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "106825650928762880",
  "text" : "RT @node_knockout: @hymnhummer it'll be on your team page (e.g. http:\/\/t.co\/26F3ZU1). we're also working on a nice voting widget.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 64 ],
        "url" : "http:\/\/t.co\/26F3ZU1",
        "expanded_url" : "http:\/\/nodeknockout.com\/teams\/fortnight-labs",
        "display_url" : "nodeknockout.com\/teams\/fortnigh\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "106823393696952320",
    "geo" : { },
    "id_str" : "106824098969174016",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer it'll be on your team page (e.g. http:\/\/t.co\/26F3ZU1). we're also working on a nice voting widget.",
    "id" : 106824098969174016,
    "in_reply_to_status_id" : 106823393696952320,
    "created_at" : "2011-08-25 20:23:44 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Node Knockout",
      "screen_name" : "nodeknockout",
      "protected" : false,
      "id_str" : "148922824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623570379437510656\/b0gi4XDH_normal.png",
      "id" : 148922824,
      "verified" : false
    }
  },
  "id" : 106825650928762880,
  "created_at" : "2011-08-25 20:29:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 0, 14 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106823393696952320",
  "in_reply_to_user_id" : 148922824,
  "text" : "@node_knockout What will the url to a team's voting page be?",
  "id" : 106823393696952320,
  "created_at" : "2011-08-25 20:20:56 +0000",
  "in_reply_to_screen_name" : "nodeknockout",
  "in_reply_to_user_id_str" : "148922824",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 18, 32 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106176399005593600",
  "text" : "is it cheating at @node_knockout to turn parts of your entry into modules before the competition, then use them in your entry? #nodejs",
  "id" : 106176399005593600,
  "created_at" : "2011-08-24 01:30:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 3, 17 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106084987069145088",
  "text" : "RT @TheTweetOfGod: There was just a 5.8 earthquake in Washington. Obama wanted it to be 3.4, but the Republicans wanted 5.8, so he compr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106067968005382144",
    "text" : "There was just a 5.8 earthquake in Washington. Obama wanted it to be 3.4, but the Republicans wanted 5.8, so he compromised.",
    "id" : 106067968005382144,
    "created_at" : "2011-08-23 18:19:08 +0000",
    "user" : {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "protected" : false,
      "id_str" : "204832963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577952058680070144\/6hlNZ0_Y_normal.jpeg",
      "id" : 204832963,
      "verified" : false
    }
  },
  "id" : 106084987069145088,
  "created_at" : "2011-08-23 19:26:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "105846495688933376",
  "geo" : { },
  "id_str" : "106082607929901056",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin heard of it yeah, not heard yet",
  "id" : 106082607929901056,
  "in_reply_to_status_id" : 105846495688933376,
  "created_at" : "2011-08-23 19:17:19 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 53 ],
      "url" : "http:\/\/t.co\/sWJNagP",
      "expanded_url" : "http:\/\/angelinegragasin.com\/blog\/2011\/08\/chapter-31-no-bullshitting\/",
      "display_url" : "angelinegragasin.com\/blog\/2011\/08\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "105813882894946305",
  "text" : "RT @AngelineGragzin: HIGH ROLLERS http:\/\/t.co\/sWJNagP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 32 ],
        "url" : "http:\/\/t.co\/sWJNagP",
        "expanded_url" : "http:\/\/angelinegragasin.com\/blog\/2011\/08\/chapter-31-no-bullshitting\/",
        "display_url" : "angelinegragasin.com\/blog\/2011\/08\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "105778990207336450",
    "text" : "HIGH ROLLERS http:\/\/t.co\/sWJNagP",
    "id" : 105778990207336450,
    "created_at" : "2011-08-22 23:10:51 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703307803574865921\/ZpTWouST_normal.jpg",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 105813882894946305,
  "created_at" : "2011-08-23 01:29:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupywallst",
      "indices" : [ 3, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105104607579095040",
  "text" : "Go #occupywallst !!!",
  "id" : 105104607579095040,
  "created_at" : "2011-08-21 02:31:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Sullivan",
      "screen_name" : "colinsullivan",
      "indices" : [ 0, 14 ],
      "id_str" : "12126302",
      "id" : 12126302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102212367299002368",
  "geo" : { },
  "id_str" : "104763712027635712",
  "in_reply_to_user_id" : 12126302,
  "text" : "@colinsullivan what's ya'll status on team mates? Care to merge? We could use a sound maker! We have a good concept, smart pre-game strategy",
  "id" : 104763712027635712,
  "in_reply_to_status_id" : 102212367299002368,
  "created_at" : "2011-08-20 03:56:30 +0000",
  "in_reply_to_screen_name" : "colinsullivan",
  "in_reply_to_user_id_str" : "12126302",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ju Hae Lee",
      "screen_name" : "juhaelee",
      "indices" : [ 0, 9 ],
      "id_str" : "83207497",
      "id" : 83207497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102560400477925376",
  "geo" : { },
  "id_str" : "104762976711606273",
  "in_reply_to_user_id" : 83207497,
  "text" : "@juhaelee I got one more nodester on board, gamplay designed, schematics laid out. We're meeting monday. hollr!",
  "id" : 104762976711606273,
  "in_reply_to_status_id" : 102560400477925376,
  "created_at" : "2011-08-20 03:53:34 +0000",
  "in_reply_to_screen_name" : "juhaelee",
  "in_reply_to_user_id_str" : "83207497",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Caswell",
      "screen_name" : "creationix",
      "indices" : [ 3, 14 ],
      "id_str" : "70596949",
      "id" : 70596949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104760244202258433",
  "text" : "YO @creationix what can I do to convince you to join my team? We're making a game, too. nodeknockout.com\/teams\/4e261f99d2f97c0100003720",
  "id" : 104760244202258433,
  "created_at" : "2011-08-20 03:42:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 91, 105 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/VBpcMfD",
      "expanded_url" : "http:\/\/nodeknockout.com\/teams\/4e261f99d2f97c0100003720",
      "display_url" : "nodeknockout.com\/teams\/4e261f99\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104757144838090752",
  "text" : "throwing this out there. Team Nogrammars looking for sound FX and Graphics (sprite FX) for @node_knockout competition http:\/\/t.co\/VBpcMfD",
  "id" : 104757144838090752,
  "created_at" : "2011-08-20 03:30:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Stewart",
      "screen_name" : "MrFaulty",
      "indices" : [ 0, 9 ],
      "id_str" : "721751109132554242",
      "id" : 721751109132554242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104756559501983744",
  "text" : "@mrfaulty because putting your hands in the air FEELS GOOD. That's why spiritual leaders instruct same.",
  "id" : 104756559501983744,
  "created_at" : "2011-08-20 03:28:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lourens Naud\u00E9",
      "screen_name" : "methodmissing",
      "indices" : [ 3, 17 ],
      "id_str" : "808485",
      "id" : 808485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102967764137943040",
  "text" : "RT @methodmissing: \"Use what talents you possess: the woods would be very silent if no birds sang there except those that sang best.\" -  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102753927040217090",
    "text" : "\"Use what talents you possess: the woods would be very silent if no birds sang there except those that sang best.\" - Henry Van Dyke",
    "id" : 102753927040217090,
    "created_at" : "2011-08-14 14:50:19 +0000",
    "user" : {
      "name" : "Lourens Naud\u00E9",
      "screen_name" : "methodmissing",
      "protected" : false,
      "id_str" : "808485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53402026\/n569949045_4287_normal.jpg",
      "id" : 808485,
      "verified" : false
    }
  },
  "id" : 102967764137943040,
  "created_at" : "2011-08-15 05:00:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 3, 14 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102966986526560256",
  "text" : "RT @uptownherd: on a web site, just misread \"content generation\"  as a demographic description of everybody with a smartphone",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "102816498967515137",
    "text" : "on a web site, just misread \"content generation\"  as a demographic description of everybody with a smartphone",
    "id" : 102816498967515137,
    "created_at" : "2011-08-14 18:58:58 +0000",
    "user" : {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "protected" : false,
      "id_str" : "122112121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518645860863709184\/iHz-222r_normal.jpeg",
      "id" : 122112121,
      "verified" : false
    }
  },
  "id" : 102966986526560256,
  "created_at" : "2011-08-15 04:56:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea Verou",
      "screen_name" : "LeaVerou",
      "indices" : [ 0, 9 ],
      "id_str" : "22199970",
      "id" : 22199970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsmissingfromthesimpsons",
      "indices" : [ 46, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102905628363735040",
  "geo" : { },
  "id_str" : "102953871508385792",
  "in_reply_to_user_id" : 22199970,
  "text" : "@LeaVerou also there is no farts of any kind. #thingsmissingfromthesimpsons",
  "id" : 102953871508385792,
  "in_reply_to_status_id" : 102905628363735040,
  "created_at" : "2011-08-15 04:04:50 +0000",
  "in_reply_to_screen_name" : "LeaVerou",
  "in_reply_to_user_id_str" : "22199970",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ju Hae Lee",
      "screen_name" : "juhaelee",
      "indices" : [ 0, 9 ],
      "id_str" : "83207497",
      "id" : 83207497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102470027491540992",
  "geo" : { },
  "id_str" : "102486046993940480",
  "in_reply_to_user_id" : 83207497,
  "text" : "@juhaelee I have a lot of basics covered, but want to have meetings & design the whole thing ahead of time like architects. Have offices.",
  "id" : 102486046993940480,
  "in_reply_to_status_id" : 102470027491540992,
  "created_at" : "2011-08-13 21:05:52 +0000",
  "in_reply_to_screen_name" : "juhaelee",
  "in_reply_to_user_id_str" : "83207497",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Sullivan",
      "screen_name" : "colinsullivan",
      "indices" : [ 0, 14 ],
      "id_str" : "12126302",
      "id" : 12126302
    }, {
      "name" : "Ju Hae Lee",
      "screen_name" : "juhaelee",
      "indices" : [ 15, 24 ],
      "id_str" : "83207497",
      "id" : 83207497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102470027491540992",
  "geo" : { },
  "id_str" : "102474181584756737",
  "in_reply_to_user_id" : 83207497,
  "text" : "@colinsullivan @juhaelee would like to make a capture the flag style RTS, but am open to ideas.",
  "id" : 102474181584756737,
  "in_reply_to_status_id" : 102470027491540992,
  "created_at" : "2011-08-13 20:18:43 +0000",
  "in_reply_to_screen_name" : "juhaelee",
  "in_reply_to_user_id_str" : "83207497",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ju Hae Lee",
      "screen_name" : "juhaelee",
      "indices" : [ 0, 9 ],
      "id_str" : "83207497",
      "id" : 83207497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102173369386008576",
  "geo" : { },
  "id_str" : "102202878587977729",
  "in_reply_to_user_id" : 83207497,
  "text" : "@juhaelee all right! are you in L.A. now or any time thru to the competition dates?",
  "id" : 102202878587977729,
  "in_reply_to_status_id" : 102173369386008576,
  "created_at" : "2011-08-13 02:20:39 +0000",
  "in_reply_to_screen_name" : "juhaelee",
  "in_reply_to_user_id_str" : "83207497",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 0, 14 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102086682878291969",
  "in_reply_to_user_id" : 148922824,
  "text" : "@node_knockout  LA based team looking for mates. Canvas \/ front-end hot shots welcome. Let's talk games. #nodejs",
  "id" : 102086682878291969,
  "created_at" : "2011-08-12 18:38:56 +0000",
  "in_reply_to_screen_name" : "nodeknockout",
  "in_reply_to_user_id_str" : "148922824",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 51, 58 ]
    }, {
      "text" : "brucelee",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101747176358686720",
  "text" : "I use Continuation-Passing Style to be like water. #nodejs #brucelee",
  "id" : 101747176358686720,
  "created_at" : "2011-08-11 20:09:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reggie watts",
      "screen_name" : "reggiewatts",
      "indices" : [ 3, 15 ],
      "id_str" : "14133970",
      "id" : 14133970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/sRXuige",
      "expanded_url" : "http:\/\/bit.ly\/pLTYEz",
      "display_url" : "bit.ly\/pLTYEz"
    } ]
  },
  "geo" : { },
  "id_str" : "101742879160025090",
  "text" : "RT @reggiewatts: Chicago heads...come to my chi town shows starting tomorrow!! You might not hate it:) http:\/\/t.co\/sRXuige",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 105 ],
        "url" : "http:\/\/t.co\/sRXuige",
        "expanded_url" : "http:\/\/bit.ly\/pLTYEz",
        "display_url" : "bit.ly\/pLTYEz"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 47.48287828, -111.35814335 ]
    },
    "id_str" : "101738059627905024",
    "text" : "Chicago heads...come to my chi town shows starting tomorrow!! You might not hate it:) http:\/\/t.co\/sRXuige",
    "id" : 101738059627905024,
    "created_at" : "2011-08-11 19:33:38 +0000",
    "user" : {
      "name" : "reggie watts",
      "screen_name" : "reggiewatts",
      "protected" : false,
      "id_str" : "14133970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/62510295\/ReggieWatts__mg_4207b_normal.jpg",
      "id" : 14133970,
      "verified" : true
    }
  },
  "id" : 101742879160025090,
  "created_at" : "2011-08-11 19:52:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xno\u0279\u01DD\u0283 u\u0250\u0131\u0279q",
      "screen_name" : "brianleroux",
      "indices" : [ 9, 21 ],
      "id_str" : "676363",
      "id" : 676363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 60 ],
      "url" : "http:\/\/t.co\/OWuWuoW",
      "expanded_url" : "https:\/\/github.com\/paulirish\/html5-boilerplate\/issues\/28#issuecomment-1778290",
      "display_url" : "github.com\/paulirish\/html\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "101534005459034112",
  "text" : "BOOSH RT @brianleroux Shit just got real http:\/\/t.co\/OWuWuoW #nodejs",
  "id" : 101534005459034112,
  "created_at" : "2011-08-11 06:02:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cloud9",
      "screen_name" : "Cloud9",
      "indices" : [ 84, 91 ],
      "id_str" : "1452520626",
      "id" : 1452520626
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 132, 136 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/wqRdOWC",
      "expanded_url" : "http:\/\/bit.ly\/qapNYP",
      "display_url" : "bit.ly\/qapNYP"
    } ]
  },
  "geo" : { },
  "id_str" : "101529389212254208",
  "text" : "this is not what I was searching for, yet it was the only google search result. w2g @cloud9 i am a user http:\/\/t.co\/wqRdOWC #nodejs @izs",
  "id" : 101529389212254208,
  "created_at" : "2011-08-11 05:44:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 5, 12 ],
      "id_str" : "15540222",
      "id" : 15540222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nodejs",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101528524774572032",
  "text" : "nice @rauchg $ npm find socket.io #Nodejs",
  "id" : 101528524774572032,
  "created_at" : "2011-08-11 05:41:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Barley",
      "screen_name" : "richardbarley",
      "indices" : [ 0, 14 ],
      "id_str" : "1209971",
      "id" : 1209971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99663977738534912",
  "in_reply_to_user_id" : 1209971,
  "text" : "@richardbarley hello, can you tell me the name of the 3rd party company tweetdeck uses for the directory filter? Thanks!",
  "id" : 99663977738534912,
  "created_at" : "2011-08-06 02:11:58 +0000",
  "in_reply_to_screen_name" : "richardbarley",
  "in_reply_to_user_id_str" : "1209971",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99482345660362752",
  "geo" : { },
  "id_str" : "99525383409512448",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk stride()",
  "id" : 99525383409512448,
  "in_reply_to_status_id" : 99482345660362752,
  "created_at" : "2011-08-05 17:01:15 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mana",
      "screen_name" : "damana",
      "indices" : [ 3, 10 ],
      "id_str" : "5820182",
      "id" : 5820182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99524881980465152",
  "text" : "RT @damana: If Tetris has taught me anything, it's that errors pile up and accomplishments disappear.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99125285345181696",
    "text" : "If Tetris has taught me anything, it's that errors pile up and accomplishments disappear.",
    "id" : 99125285345181696,
    "created_at" : "2011-08-04 14:31:24 +0000",
    "user" : {
      "name" : "Mana",
      "screen_name" : "damana",
      "protected" : false,
      "id_str" : "5820182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682081138655940610\/HTvaOb-a_normal.jpg",
      "id" : 5820182,
      "verified" : false
    }
  },
  "id" : 99524881980465152,
  "created_at" : "2011-08-05 16:59:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Park",
      "screen_name" : "donpark",
      "indices" : [ 0, 8 ],
      "id_str" : "892821",
      "id" : 892821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99201865660645376",
  "geo" : { },
  "id_str" : "99207830053208064",
  "in_reply_to_user_id" : 892821,
  "text" : "@donpark It is my opinion that a little deflation would also be good for this country.",
  "id" : 99207830053208064,
  "in_reply_to_status_id" : 99201865660645376,
  "created_at" : "2011-08-04 19:59:24 +0000",
  "in_reply_to_screen_name" : "donpark",
  "in_reply_to_user_id_str" : "892821",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 0, 7 ],
      "id_str" : "15540222",
      "id" : 15540222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "99179643726336000",
  "geo" : { },
  "id_str" : "99185058497306624",
  "in_reply_to_user_id" : 15540222,
  "text" : "@rauchg see you tonight! &gt;&gt; LA #nodejs",
  "id" : 99185058497306624,
  "in_reply_to_status_id" : 99179643726336000,
  "created_at" : "2011-08-04 18:28:55 +0000",
  "in_reply_to_screen_name" : "rauchg",
  "in_reply_to_user_id_str" : "15540222",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crotches",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 47 ],
      "url" : "http:\/\/t.co\/Debm3wL",
      "expanded_url" : "http:\/\/goo.gl\/28eRG",
      "display_url" : "goo.gl\/28eRG"
    } ]
  },
  "geo" : { },
  "id_str" : "99184320417234944",
  "text" : "New OK GO HTML5 music video http:\/\/t.co\/Debm3wL #crotches",
  "id" : 99184320417234944,
  "created_at" : "2011-08-04 18:25:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "indices" : [ 0, 10 ],
      "id_str" : "13696102",
      "id" : 13696102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98834375524876289",
  "in_reply_to_user_id" : 13696102,
  "text" : "@indexzero can forever be used to keep a mongo server running? My test = script running, but mongo not actually running.  #nodejs",
  "id" : 98834375524876289,
  "created_at" : "2011-08-03 19:15:26 +0000",
  "in_reply_to_screen_name" : "indexzero",
  "in_reply_to_user_id_str" : "13696102",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98563672883990528",
  "text" : "git yr bizness on, or load it up, saddle it with somethin, welcome to data rica, the fog of porn, try rolling your eyes harder, tax corpus",
  "id" : 98563672883990528,
  "created_at" : "2011-08-03 01:19:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98562406279688193",
  "text" : "future people will need to be marketed @ in the following manner: like entrepreneurs running they livelihood on interest",
  "id" : 98562406279688193,
  "created_at" : "2011-08-03 01:14:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98496485825585152",
  "text" : "#whchat how much was our debt limit increased this time?",
  "id" : 98496485825585152,
  "created_at" : "2011-08-02 20:52:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Niklas",
      "screen_name" : "mrflix",
      "indices" : [ 0, 7 ],
      "id_str" : "15217750",
      "id" : 15217750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98490223389970432",
  "geo" : { },
  "id_str" : "98495484091568129",
  "in_reply_to_user_id" : 15217750,
  "text" : "@mrflix many thx, keep up the good work. BTW, do you node.js?",
  "id" : 98495484091568129,
  "in_reply_to_status_id" : 98490223389970432,
  "created_at" : "2011-08-02 20:48:48 +0000",
  "in_reply_to_screen_name" : "mrflix",
  "in_reply_to_user_id_str" : "15217750",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Niklas",
      "screen_name" : "mrflix",
      "indices" : [ 0, 7 ],
      "id_str" : "15217750",
      "id" : 15217750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98484159584014337",
  "geo" : { },
  "id_str" : "98485763804626944",
  "in_reply_to_user_id" : 15217750,
  "text" : "@mrflix I see that, I mean if I want to intercept that string programmatically, so I can write it directly to the css file ;)",
  "id" : 98485763804626944,
  "in_reply_to_status_id" : 98484159584014337,
  "created_at" : "2011-08-02 20:10:10 +0000",
  "in_reply_to_screen_name" : "mrflix",
  "in_reply_to_user_id_str" : "15217750",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Niklas",
      "screen_name" : "mrflix",
      "indices" : [ 7, 14 ],
      "id_str" : "15217750",
      "id" : 15217750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98482289415176192",
  "text" : "hollar @mrflix where do I intercept the css output of layerstyles?",
  "id" : 98482289415176192,
  "created_at" : "2011-08-02 19:56:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "USdaydor",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/R8yPXPw",
      "expanded_url" : "http:\/\/tpmdc.talkingpointsmemo.com\/2011\/08\/koch-group-mails-suspicious-absentee-ballot-letters-in-wisconsin.php",
      "display_url" : "tpmdc.talkingpointsmemo.com\/2011\/08\/koch-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98135371099025409",
  "text" : "the \"businessmen dressed up as indians party\" trying to hack the ballot in WI, cough cough koch http:\/\/t.co\/R8yPXPw #tcot #USdaydor",
  "id" : 98135371099025409,
  "created_at" : "2011-08-01 20:57:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/ueCnCbM",
      "expanded_url" : "http:\/\/www.columnal.com\/",
      "display_url" : "columnal.com"
    } ]
  },
  "geo" : { },
  "id_str" : "98107200836345856",
  "text" : "i'm liking this fluid css grid so im tweeting the link http:\/\/t.co\/ueCnCbM",
  "id" : 98107200836345856,
  "created_at" : "2011-08-01 19:05:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]