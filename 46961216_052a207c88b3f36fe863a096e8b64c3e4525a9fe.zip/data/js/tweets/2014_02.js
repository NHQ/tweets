Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/A1OCeuo0aZ",
      "expanded_url" : "https:\/\/github.com\/NHQ\/sesame-stream.git",
      "display_url" : "github.com\/NHQ\/sesame-str\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439474639358529536",
  "text" : "\/\/plug in ur midi controller\ngit clone https:\/\/t.co\/A1OCeuo0aZ\ncd sesame-stream\nnpm install\nnode midi.js | node server.js\n\/\/localhost:11010",
  "id" : 439474639358529536,
  "created_at" : "2014-02-28 18:58:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/5rwe2KCgKl",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/level-party",
      "display_url" : "npmjs.org\/package\/level-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439307867414200320",
  "geo" : { },
  "id_str" : "439314499963584512",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  love the new art!  https:\/\/t.co\/5rwe2KCgKl",
  "id" : 439314499963584512,
  "in_reply_to_status_id" : 439307867414200320,
  "created_at" : "2014-02-28 08:21:53 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439246466788229120",
  "text" : "Error: Cannot switch to old mode now.  Nope, not any more.  Old mode's out.  This is err.",
  "id" : 439246466788229120,
  "created_at" : "2014-02-28 03:51:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/0WtAZ3sEqd",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=oblbLHYu6uY",
      "display_url" : "youtube.com\/watch?v=oblbLH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439177086440181761",
  "text" : "You are what you is\nhttps:\/\/t.co\/0WtAZ3sEqd",
  "id" : 439177086440181761,
  "created_at" : "2014-02-27 23:15:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shruti Ravindran",
      "screen_name" : "s_ravindran",
      "indices" : [ 96, 108 ],
      "id_str" : "924046771",
      "id" : 924046771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/F0zgVObRrm",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/living-together\/what-solitary-confinement-does-to-the-brain\/",
      "display_url" : "aeon.co\/magazine\/livin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439137572095156224",
  "text" : "Research + journalism on the effects of SOLITARY CONFINEMENT, persuasive information + story by @s_ravindran \n\nhttp:\/\/t.co\/F0zgVObRrm",
  "id" : 439137572095156224,
  "created_at" : "2014-02-27 20:38:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438985792883412992",
  "text" : "it's a metabolic thing",
  "id" : 438985792883412992,
  "created_at" : "2014-02-27 10:35:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438963970632720384",
  "text" : "the if n till",
  "id" : 438963970632720384,
  "created_at" : "2014-02-27 09:09:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438956161572687872",
  "text" : "Time In The Zeeth Dimension",
  "id" : 438956161572687872,
  "created_at" : "2014-02-27 08:37:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438948678372306944",
  "text" : "let's you and me go propagate around the internet for a while",
  "id" : 438948678372306944,
  "created_at" : "2014-02-27 08:08:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438942082267246594",
  "text" : "The Man From Is Not isNaN",
  "id" : 438942082267246594,
  "created_at" : "2014-02-27 07:42:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438877761667489792",
  "text" : "Well I didn't have to become an MMA competition fighter yet after all.  About which I am melancholy.",
  "id" : 438877761667489792,
  "created_at" : "2014-02-27 03:26:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438869514877272064",
  "text" : "When there is chocolate and rye in the house at the same time, Johnny celebrating.",
  "id" : 438869514877272064,
  "created_at" : "2014-02-27 02:53:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438863720827998208",
  "text" : "Why didn't anybody ask me?",
  "id" : 438863720827998208,
  "created_at" : "2014-02-27 02:30:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438470268315377665",
  "geo" : { },
  "id_str" : "438474796741844992",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack a bunch of nonce sense",
  "id" : 438474796741844992,
  "in_reply_to_status_id" : 438470268315377665,
  "created_at" : "2014-02-26 00:45:12 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438277097367171073",
  "text" : "Cooking with software.",
  "id" : 438277097367171073,
  "created_at" : "2014-02-25 11:39:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438277080535408640",
  "text" : "Cuddling with computers.",
  "id" : 438277080535408640,
  "created_at" : "2014-02-25 11:39:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Verbaten",
      "screen_name" : "Raynos",
      "indices" : [ 0, 7 ],
      "id_str" : "304682840",
      "id" : 304682840
    }, {
      "name" : "hij1nx",
      "screen_name" : "hij1nx",
      "indices" : [ 8, 15 ],
      "id_str" : "3781380935",
      "id" : 3781380935
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 16, 25 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438083322112008192",
  "geo" : { },
  "id_str" : "438178082474573825",
  "in_reply_to_user_id" : 304682840,
  "text" : "@Raynos @hij1nx @substack Don't be shy.  Ask the user for the time.",
  "id" : 438178082474573825,
  "in_reply_to_status_id" : 438083322112008192,
  "created_at" : "2014-02-25 05:06:10 +0000",
  "in_reply_to_screen_name" : "Raynos",
  "in_reply_to_user_id_str" : "304682840",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/GlVksOzPNU",
      "expanded_url" : "https:\/\/github.com\/NHQ\/jsynth-mic",
      "display_url" : "github.com\/NHQ\/jsynth-mic"
    } ]
  },
  "geo" : { },
  "id_str" : "437867274796408832",
  "text" : "web audio mic node\nhttps:\/\/t.co\/GlVksOzPNU",
  "id" : 437867274796408832,
  "created_at" : "2014-02-24 08:31:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437430460436582400",
  "text" : "wearing masks &amp; colors &amp; shades &amp;\nin the union of anonymity, strength\ngive to thy harm n y doses o'monious\n&amp;&amp;\nbreak, dance, I prithee, break",
  "id" : 437430460436582400,
  "created_at" : "2014-02-23 03:35:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437314630369959937",
  "geo" : { },
  "id_str" : "437414158590423040",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey What happens if you run one of those in reverse?",
  "id" : 437414158590423040,
  "in_reply_to_status_id" : 437314630369959937,
  "created_at" : "2014-02-23 02:30:36 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436674979912892416",
  "geo" : { },
  "id_str" : "436685512938504193",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  The most commonly known Planck Unit is the CSS pixel.",
  "id" : 436685512938504193,
  "in_reply_to_status_id" : 436674979912892416,
  "created_at" : "2014-02-21 02:15:14 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OK Council",
      "screen_name" : "OKcouncil",
      "indices" : [ 3, 13 ],
      "id_str" : "414106728",
      "id" : 414106728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DAC",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436024261161926656",
  "text" : "RT @OKcouncil: CM Kernighan says she is inclined to vote \"No\" on #DAC, but will change her vote if people heckle. That's how to make big po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DAC",
        "indices" : [ 50, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436023357725622272",
    "text" : "CM Kernighan says she is inclined to vote \"No\" on #DAC, but will change her vote if people heckle. That's how to make big policy decisions!",
    "id" : 436023357725622272,
    "created_at" : "2014-02-19 06:24:04 +0000",
    "user" : {
      "name" : "OK Council",
      "screen_name" : "OKcouncil",
      "protected" : false,
      "id_str" : "414106728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660952431610630144\/KETEYrzx_normal.jpg",
      "id" : 414106728,
      "verified" : false
    }
  },
  "id" : 436024261161926656,
  "created_at" : "2014-02-19 06:27:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DAC",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "DAC",
      "indices" : [ 6, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436023090762358786",
  "text" : "#DAC \n#DAC\nGIVE THE FEDS THEY MONEY BACK",
  "id" : 436023090762358786,
  "created_at" : "2014-02-19 06:23:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435972603333722113",
  "geo" : { },
  "id_str" : "435974880828207104",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar On The Performance Benefits of Carefully Deleting 90% of the DOM.  Discuss.",
  "id" : 435974880828207104,
  "in_reply_to_status_id" : 435972603333722113,
  "created_at" : "2014-02-19 03:11:26 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435970516805881856",
  "text" : "To each your node.",
  "id" : 435970516805881856,
  "created_at" : "2014-02-19 02:54:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435970212475580416",
  "text" : "Reaches up into its parent and commands for the child itself to be removed.  The one true DOM grants this.",
  "id" : 435970212475580416,
  "created_at" : "2014-02-19 02:52:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435877508341194754",
  "text" : "v.Soon Node.js  + NPM + Browserify will become the world's first 16-bit creation complex.",
  "id" : 435877508341194754,
  "created_at" : "2014-02-18 20:44:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/FLD3vzzsFJ",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/groove-n-is-the-heart",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435315992277696513",
  "text" : "if ( for ( then or else ( ( if else if else ) ) ) )\ndo \nhttps:\/\/t.co\/FLD3vzzsFJ \u2026 Expand",
  "id" : 435315992277696513,
  "created_at" : "2014-02-17 07:33:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/gsonj7mhGd",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/27028d3a1caebc4cdec4",
      "display_url" : "gist.github.com\/NHQ\/27028d3a1c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435307656933146624",
  "text" : "typed 'is'\nthen almost typed 'greater than'\nthen I broke my program ftw and fixed it with this nice anti-pattern https:\/\/t.co\/gsonj7mhGd",
  "id" : 435307656933146624,
  "created_at" : "2014-02-17 07:00:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435238413541720064",
  "text" : "had to tab 16 times to get to thiz box",
  "id" : 435238413541720064,
  "created_at" : "2014-02-17 02:24:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435205698016645120",
  "text" : "I threw a chicken over a fence.",
  "id" : 435205698016645120,
  "created_at" : "2014-02-17 00:14:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 0, 6 ],
      "id_str" : "15453",
      "id" : 15453
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 7, 11 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434861975516901376",
  "geo" : { },
  "id_str" : "434964047339876352",
  "in_reply_to_user_id" : 15453,
  "text" : "@seldo @izs there are very few weird and happy people in Kansas.",
  "id" : 434964047339876352,
  "in_reply_to_status_id" : 434861975516901376,
  "created_at" : "2014-02-16 08:14:44 +0000",
  "in_reply_to_screen_name" : "seldo",
  "in_reply_to_user_id_str" : "15453",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434959204248334336",
  "text" : "its on the house tonight everyone\nits everyone on the house tonight",
  "id" : 434959204248334336,
  "created_at" : "2014-02-16 07:55:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/5z8dQLHB9f",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=k_N_FQuSeuo",
      "display_url" : "youtube.com\/watch?v=k_N_FQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434836236998422528",
  "text" : "de Cara A la Pared \nhttp:\/\/t.co\/5z8dQLHB9f",
  "id" : 434836236998422528,
  "created_at" : "2014-02-15 23:46:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434733994517622785",
  "text" : "I should probably commit this facial hair",
  "id" : 434733994517622785,
  "created_at" : "2014-02-15 17:00:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434386811691872256",
  "text" : "Happy February Fool's Day!",
  "id" : 434386811691872256,
  "created_at" : "2014-02-14 18:01:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/2QIYHoueWl",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/canvas",
      "display_url" : "npmjs.org\/package\/canvas"
    } ]
  },
  "geo" : { },
  "id_str" : "434227993955692544",
  "text" : "Who has used the 'canvas' module?  I'm trying to write png streams to file, but they come out with bunk headers.  https:\/\/t.co\/2QIYHoueWl",
  "id" : 434227993955692544,
  "created_at" : "2014-02-14 07:29:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/cO3ffS1azQ",
      "expanded_url" : "https:\/\/feedopensource.com\/",
      "display_url" : "feedopensource.com"
    } ]
  },
  "geo" : { },
  "id_str" : "434144057988628480",
  "text" : "https:\/\/t.co\/cO3ffS1azQ  needs you",
  "id" : 434144057988628480,
  "created_at" : "2014-02-14 01:56:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/swPXOD07xB",
      "expanded_url" : "https:\/\/github.com\/NHQ\/jsynth-midi",
      "display_url" : "github.com\/NHQ\/jsynth-midi"
    }, {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/UhGhrDJyLS",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/midi",
      "display_url" : "npmjs.org\/package\/midi"
    }, {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/RAer3yVSwD",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/dragon-noodle",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434108708692320256",
  "text" : "https:\/\/t.co\/swPXOD07xB + https:\/\/t.co\/UhGhrDJyLS =\nhttps:\/\/t.co\/RAer3yVSwD",
  "id" : 434108708692320256,
  "created_at" : "2014-02-13 23:35:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434054040922505216",
  "text" : "Whea yo ghost at, whea yo dead man?",
  "id" : 434054040922505216,
  "created_at" : "2014-02-13 19:58:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433776880726966272",
  "text" : "link me to your fave midi track and I'll remix it",
  "id" : 433776880726966272,
  "created_at" : "2014-02-13 01:37:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/JHPScVeKv9",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/burgertime",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433775243904024576",
  "text" : "I cut a new cut: Burger Time The Remix https:\/\/t.co\/JHPScVeKv9",
  "id" : 433775243904024576,
  "created_at" : "2014-02-13 01:30:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433659034051166208",
  "text" : "Get me $20,000 this week, or the internet doesn't get it.",
  "id" : 433659034051166208,
  "created_at" : "2014-02-12 17:49:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/m1VX0a2nhp",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/8951052",
      "display_url" : "gist.github.com\/NHQ\/8951052"
    } ]
  },
  "geo" : { },
  "id_str" : "433493816033542144",
  "text" : "send midi messages for every note of every scale of every key in every mode\nhttps:\/\/t.co\/m1VX0a2nhp",
  "id" : 433493816033542144,
  "created_at" : "2014-02-12 06:52:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Lord",
      "screen_name" : "jllord",
      "indices" : [ 0, 7 ],
      "id_str" : "126718519",
      "id" : 126718519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433467972099665920",
  "geo" : { },
  "id_str" : "433468190836809728",
  "in_reply_to_user_id" : 126718519,
  "text" : "@jllord CLICK THE LINKS LIKE EVERYONE ELSE",
  "id" : 433468190836809728,
  "in_reply_to_status_id" : 433467972099665920,
  "created_at" : "2014-02-12 05:10:44 +0000",
  "in_reply_to_screen_name" : "jllord",
  "in_reply_to_user_id_str" : "126718519",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433340010889089024",
  "text" : "THE SUN IS BACK\nGOODBYE PANTS",
  "id" : 433340010889089024,
  "created_at" : "2014-02-11 20:41:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433303566103506944",
  "text" : "I expect tiny things from NPM",
  "id" : 433303566103506944,
  "created_at" : "2014-02-11 18:16:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/kqGp6jibmb",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/sortof",
      "display_url" : "npmjs.org\/package\/sortof"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/9V1ldmTZkA",
      "expanded_url" : "https:\/\/ci.testling.com\/NHQ\/sortof",
      "display_url" : "ci.testling.com\/NHQ\/sortof"
    } ]
  },
  "geo" : { },
  "id_str" : "433284430438735873",
  "text" : "Filter lists of objects by date strings. Today, tomorrow, this week, this month, range... https:\/\/t.co\/kqGp6jibmb  https:\/\/t.co\/9V1ldmTZkA",
  "id" : 433284430438735873,
  "created_at" : "2014-02-11 17:00:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 3, 11 ],
      "id_str" : "16893912",
      "id" : 16893912
    }, {
      "name" : "Pinoccio",
      "screen_name" : "goPinoccio",
      "indices" : [ 40, 51 ],
      "id_str" : "805853400",
      "id" : 805853400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/wniWXhyGkB",
      "expanded_url" : "http:\/\/pinocc.io",
      "display_url" : "pinocc.io"
    } ]
  },
  "geo" : { },
  "id_str" : "433017198026575872",
  "text" : "RT @soldair: I'm so excited to join the @goPinoccio team! http:\/\/t.co\/wniWXhyGkB open hardware. nodejs. nodebases. robots! and a super awes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pinoccio",
        "screen_name" : "goPinoccio",
        "indices" : [ 27, 38 ],
        "id_str" : "805853400",
        "id" : 805853400
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/wniWXhyGkB",
        "expanded_url" : "http:\/\/pinocc.io",
        "display_url" : "pinocc.io"
      } ]
    },
    "geo" : { },
    "id_str" : "432976374496653312",
    "text" : "I'm so excited to join the @goPinoccio team! http:\/\/t.co\/wniWXhyGkB open hardware. nodejs. nodebases. robots! and a super awesome team!",
    "id" : 432976374496653312,
    "created_at" : "2014-02-10 20:36:26 +0000",
    "user" : {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "protected" : false,
      "id_str" : "16893912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654320052162924549\/DjQ_KPJy_normal.png",
      "id" : 16893912,
      "verified" : false
    }
  },
  "id" : 433017198026575872,
  "created_at" : "2014-02-10 23:18:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432767088327786497",
  "text" : "Your mouth would like to remind you that giving is receiving.",
  "id" : 432767088327786497,
  "created_at" : "2014-02-10 06:44:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432735176934703104",
  "text" : "draw n schema on the walls",
  "id" : 432735176934703104,
  "created_at" : "2014-02-10 04:38:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432731589034786816",
  "text" : "\"Free will\" is super-fragilistic, in theory and practice.",
  "id" : 432731589034786816,
  "created_at" : "2014-02-10 04:23:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432635092737859585",
  "text" : "It's, like literally, a transition to a metaphor from a simile.",
  "id" : 432635092737859585,
  "created_at" : "2014-02-09 22:00:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432630322669158400",
  "text" : "element.depecheChild(node)",
  "id" : 432630322669158400,
  "created_at" : "2014-02-09 21:41:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Trejo",
      "screen_name" : "ddtrejo",
      "indices" : [ 0, 8 ],
      "id_str" : "58248334",
      "id" : 58248334
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 57, 66 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432350757652672513",
  "geo" : { },
  "id_str" : "432377826830864385",
  "in_reply_to_user_id" : 58248334,
  "text" : "@ddtrejo  o\/  thx\nI signed up to be an Air Pair tutor on @substack's recommendation",
  "id" : 432377826830864385,
  "in_reply_to_status_id" : 432350757652672513,
  "created_at" : "2014-02-09 04:58:01 +0000",
  "in_reply_to_screen_name" : "ddtrejo",
  "in_reply_to_user_id_str" : "58248334",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432317014787362816",
  "text" : "cooking with software",
  "id" : 432317014787362816,
  "created_at" : "2014-02-09 00:56:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432306745507991553",
  "text" : "distributed vultron",
  "id" : 432306745507991553,
  "created_at" : "2014-02-09 00:15:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432067664643518464",
  "text" : "i'm gonna practice blogging now",
  "id" : 432067664643518464,
  "created_at" : "2014-02-08 08:25:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432067195728711680",
  "text" : "energy forms",
  "id" : 432067195728711680,
  "created_at" : "2014-02-08 08:23:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/sQS4k33qhi",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/dirt-muh-gurk",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432044123957112834",
  "text" : "if you have deep bass capabilities then https:\/\/t.co\/sQS4k33qhi",
  "id" : 432044123957112834,
  "created_at" : "2014-02-08 06:52:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432010928817586176",
  "geo" : { },
  "id_str" : "432028466926469120",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey  neuce!",
  "id" : 432028466926469120,
  "in_reply_to_status_id" : 432010928817586176,
  "created_at" : "2014-02-08 05:49:47 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431953926402097152",
  "geo" : { },
  "id_str" : "431963564350255104",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey are you doing things in the BA?",
  "id" : 431963564350255104,
  "in_reply_to_status_id" : 431953926402097152,
  "created_at" : "2014-02-08 01:31:53 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bradley Farias",
      "screen_name" : "bradleymeck",
      "indices" : [ 0, 12 ],
      "id_str" : "15338477",
      "id" : 15338477
    }, {
      "name" : "Charlie McConnell",
      "screen_name" : "Av1anFlu",
      "indices" : [ 13, 22 ],
      "id_str" : "47735209",
      "id" : 47735209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431864133391114240",
  "geo" : { },
  "id_str" : "431884761984802816",
  "in_reply_to_user_id" : 15338477,
  "text" : "@bradleymeck @Av1anFlu a mundane one, ++complexityScope.  Rules + endgame assessment are essential to strategy.  TTT is not a button masher.",
  "id" : 431884761984802816,
  "in_reply_to_status_id" : 431864133391114240,
  "created_at" : "2014-02-07 20:18:45 +0000",
  "in_reply_to_screen_name" : "bradleymeck",
  "in_reply_to_user_id_str" : "15338477",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bradley Farias",
      "screen_name" : "bradleymeck",
      "indices" : [ 0, 12 ],
      "id_str" : "15338477",
      "id" : 15338477
    }, {
      "name" : "Charlie McConnell",
      "screen_name" : "Av1anFlu",
      "indices" : [ 13, 22 ],
      "id_str" : "47735209",
      "id" : 47735209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/2qNf5nA0Fc",
      "expanded_url" : "http:\/\/jsfiddle.net\/Tq93p\/",
      "display_url" : "jsfiddle.net\/Tq93p\/"
    } ]
  },
  "in_reply_to_status_id_str" : "431844711062437888",
  "geo" : { },
  "id_str" : "431853655428321280",
  "in_reply_to_user_id" : 15338477,
  "text" : "@bradleymeck @Av1anFlu \nyour impressions plz http:\/\/t.co\/2qNf5nA0Fc",
  "id" : 431853655428321280,
  "in_reply_to_status_id" : 431844711062437888,
  "created_at" : "2014-02-07 18:15:09 +0000",
  "in_reply_to_screen_name" : "bradleymeck",
  "in_reply_to_user_id_str" : "15338477",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431845204622970880",
  "text" : "cleaning cast iron cookware\nit's probably like writing software in some way",
  "id" : 431845204622970880,
  "created_at" : "2014-02-07 17:41:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431377306825666560",
  "text" : "hash little robot\ndon't say my words",
  "id" : 431377306825666560,
  "created_at" : "2014-02-06 10:42:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431373400397725697",
  "text" : "your wish\nmy command",
  "id" : 431373400397725697,
  "created_at" : "2014-02-06 10:26:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431349617205059584",
  "text" : "I have broken some hyperlinks out there",
  "id" : 431349617205059584,
  "created_at" : "2014-02-06 08:52:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431328409705144320",
  "text" : "oriri\nnoriri\nn everything bewteen",
  "id" : 431328409705144320,
  "created_at" : "2014-02-06 07:28:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/tezn8dYmtB",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=cKx7v-uHDRQ",
      "display_url" : "youtube.com\/watch?v=cKx7v-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431221481503088640",
  "text" : "~$ run cmd\n&gt; *program barfs everywhere*\n&gt; \"see barf bucket for the rest\"\nPeer into bucket\nSame barf, two places\nbut http:\/\/t.co\/tezn8dYmtB",
  "id" : 431221481503088640,
  "created_at" : "2014-02-06 00:23:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430942741279690752",
  "text" : "push on\npush fwd\npush up\npush ahead\nnever give up\nuntil yr dead",
  "id" : 430942741279690752,
  "created_at" : "2014-02-05 05:55:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430939559661035520",
  "text" : "I'm a six year old coder.",
  "id" : 430939559661035520,
  "created_at" : "2014-02-05 05:42:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430515351109922816",
  "text" : "Join me in calling a system a system, and a complex a complex.",
  "id" : 430515351109922816,
  "created_at" : "2014-02-04 01:37:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430169051843678209",
  "text" : "US Holidays always make me feel lonely\nI feel lonely today",
  "id" : 430169051843678209,
  "created_at" : "2014-02-03 02:41:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430166810344693760",
  "text" : "interception",
  "id" : 430166810344693760,
  "created_at" : "2014-02-03 02:32:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430089636203864065",
  "text" : "The cost of living.  Why should I bear it?",
  "id" : 430089636203864065,
  "created_at" : "2014-02-02 21:25:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430086085989773312",
  "text" : "it's all on providence",
  "id" : 430086085989773312,
  "created_at" : "2014-02-02 21:11:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429823497620455424",
  "text" : "Absubtraction!  The new exercise pill that's guaranteed to take the fat off yr framework!",
  "id" : 429823497620455424,
  "created_at" : "2014-02-02 03:48:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429677976725118976",
  "text" : "If you can't beat them, join them at the lowest level.",
  "id" : 429677976725118976,
  "created_at" : "2014-02-01 18:09:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429676635600613376",
  "text" : "priority is the consideration of two points: importance, TTL",
  "id" : 429676635600613376,
  "created_at" : "2014-02-01 18:04:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]