Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450836776693673984",
  "text" : "We are living the theater of ideas.  Startup idea:  a traveling show.",
  "id" : 450836776693673984,
  "created_at" : "2014-04-01 03:27:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450833365764022272",
  "text" : "shut up and talk about the weather",
  "id" : 450833365764022272,
  "created_at" : "2014-04-01 03:13:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450751612386934784",
  "geo" : { },
  "id_str" : "450752032043827201",
  "in_reply_to_user_id" : 46961216,
  "text" : "Then we can all make components, host them, and share them.  We can then build apps out of these components.  The web as package manager.",
  "id" : 450752032043827201,
  "in_reply_to_status_id" : 450751612386934784,
  "created_at" : "2014-03-31 21:50:33 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450751612386934784",
  "text" : "I think the answer to web components is to make every component its own HTML page, use iframes, &amp; let them talk to each other w\/postMessage.",
  "id" : 450751612386934784,
  "created_at" : "2014-03-31 21:48:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450736449097199616",
  "text" : "For my next act, I'd like to give up processing.",
  "id" : 450736449097199616,
  "created_at" : "2014-03-31 20:48:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450733214877769728",
  "text" : "The Configuration of Remembrains",
  "id" : 450733214877769728,
  "created_at" : "2014-03-31 20:35:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450732764996710401",
  "text" : "You can rent giant remembrains.  They're in the cloud.  They said that's where my head was, too!",
  "id" : 450732764996710401,
  "created_at" : "2014-03-31 20:34:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450730825596690432",
  "text" : "Learn it, or forget it.  Somebody else, or a machine, will learn it, and you'll always be able to find it.",
  "id" : 450730825596690432,
  "created_at" : "2014-03-31 20:26:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450729472119955456",
  "text" : "What I do not know is the Universe unto the Earth of what I do.",
  "id" : 450729472119955456,
  "created_at" : "2014-03-31 20:20:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450729180477411328",
  "text" : "What I can't remember I don't know.",
  "id" : 450729180477411328,
  "created_at" : "2014-03-31 20:19:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450728799055802368",
  "text" : "I have chosen a way of not remembering as much as possible.",
  "id" : 450728799055802368,
  "created_at" : "2014-03-31 20:18:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450728047969185792",
  "text" : "The hardest thing about CSS is remembering CSS.",
  "id" : 450728047969185792,
  "created_at" : "2014-03-31 20:15:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "Horizontal",
      "screen_name" : "horizontal",
      "indices" : [ 60, 71 ],
      "id_str" : "1090147200",
      "id" : 1090147200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450706560247799808",
  "geo" : { },
  "id_str" : "450726911820308481",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar is that a joke webpage?  \nlet me ask that in \"VFL\"  @horizontal |-is-that-a-joke-webpage-| in(allSeriousness) gap(inMyUnderstanding)",
  "id" : 450726911820308481,
  "in_reply_to_status_id" : 450706560247799808,
  "created_at" : "2014-03-31 20:10:44 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450591560585838592",
  "geo" : { },
  "id_str" : "450689395763331072",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr a punk ass yak that",
  "id" : 450689395763331072,
  "in_reply_to_status_id" : 450591560585838592,
  "created_at" : "2014-03-31 17:41:40 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450382953693331456",
  "geo" : { },
  "id_str" : "450398295966220288",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah  I got u",
  "id" : 450398295966220288,
  "in_reply_to_status_id" : 450382953693331456,
  "created_at" : "2014-03-30 22:24:56 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450164316650475521",
  "text" : "that is a Purdie fine function",
  "id" : 450164316650475521,
  "created_at" : "2014-03-30 06:55:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/sgDmwOSJpi",
      "expanded_url" : "http:\/\/studio.substack.net\/workDiff?time=1396161270773",
      "display_url" : "studio.substack.net\/workDiff?time=\u2026"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/aPTIk9km34",
      "expanded_url" : "http:\/\/studio.substack.net\/workDiff?time=1396161262706",
      "display_url" : "studio.substack.net\/workDiff?time=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450160118022164482",
  "text" : "javascript puzzle: \nWHATS THE DIFF AND WHY\nthese two scrips:\nhttp:\/\/t.co\/sgDmwOSJpi\nand\nhttp:\/\/t.co\/aPTIk9km34\nline 1 of function pluck",
  "id" : 450160118022164482,
  "created_at" : "2014-03-30 06:38:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/zRaHaT3e1F",
      "expanded_url" : "http:\/\/studio.substack.net\/worknworknwork",
      "display_url" : "studio.substack.net\/worknworknwork"
    } ]
  },
  "in_reply_to_status_id_str" : "450142759496601600",
  "geo" : { },
  "id_str" : "450149932519788545",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack http:\/\/t.co\/zRaHaT3e1F",
  "id" : 450149932519788545,
  "in_reply_to_status_id" : 450142759496601600,
  "created_at" : "2014-03-30 05:58:01 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449996014082985984",
  "text" : "Use the infinite realm of randomness, of chaos, of the unknown, to rationalize only creation.  Destruct what ya heard.",
  "id" : 449996014082985984,
  "created_at" : "2014-03-29 19:46:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/Xi5XIsfKXO",
      "expanded_url" : "http:\/\/opinionator.blogs.nytimes.com\/2014\/03\/25\/the-certainty-of-donald-rumsfeld-part-1\/?_php=true&_type=blogs&_r=0#more-152408",
      "display_url" : "opinionator.blogs.nytimes.com\/2014\/03\/25\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449993695853428736",
  "text" : "these \"journalists\" reports &amp; professed \"objectivity\", media wearing invisible clothes &amp; hubris a the capitol zoo : http:\/\/t.co\/Xi5XIsfKXO",
  "id" : 449993695853428736,
  "created_at" : "2014-03-29 19:37:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 97, 105 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/JqHzKHRFp3",
      "expanded_url" : "http:\/\/jessemoynihan.com\/?p=11",
      "display_url" : "jessemoynihan.com\/?p=11"
    } ]
  },
  "geo" : { },
  "id_str" : "449976629268189184",
  "text" : "Gotta give context where it is do.  This graphic story is brilliant:  http:\/\/t.co\/JqHzKHRFp3\n\ncc\/@soldair",
  "id" : 449976629268189184,
  "created_at" : "2014-03-29 18:29:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449797694383345664",
  "text" : "There is evidence that all documentation of my existence will be lost or corrupt.",
  "id" : 449797694383345664,
  "created_at" : "2014-03-29 06:38:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449765615700414464",
  "geo" : { },
  "id_str" : "449770656125571072",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack FOOAK THIS S GROOV N",
  "id" : 449770656125571072,
  "in_reply_to_status_id" : 449765615700414464,
  "created_at" : "2014-03-29 04:50:55 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449763060446539776",
  "text" : "turnt up",
  "id" : 449763060446539776,
  "created_at" : "2014-03-29 04:20:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449662088148172800",
  "geo" : { },
  "id_str" : "449673811512680448",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight EL CHUBALIBRE",
  "id" : 449673811512680448,
  "in_reply_to_status_id" : 449662088148172800,
  "created_at" : "2014-03-28 22:26:05 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "recommended",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/886Hz6GW12",
      "expanded_url" : "http:\/\/jessemoynihan.com\/images\/forming+82.jpg",
      "display_url" : "jessemoynihan.com\/images\/forming\u2026"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0hDqt3eMiW",
      "expanded_url" : "http:\/\/jessemoynihan.com\/wp\/wp-content\/uploads\/2010\/12\/forming83.jpg",
      "display_url" : "jessemoynihan.com\/wp\/wp-content\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449664424798744576",
  "geo" : { },
  "id_str" : "449672715578798081",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair LOL is that Native American wisdom?\nIt is v nice to sun yr genitals #recommended\nalso\nhttp:\/\/t.co\/886Hz6GW12 http:\/\/t.co\/0hDqt3eMiW",
  "id" : 449672715578798081,
  "in_reply_to_status_id" : 449664424798744576,
  "created_at" : "2014-03-28 22:21:44 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 3, 14 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449663306861527040",
  "text" : "RT @whichlight: @johnnyscript cuz your mind is full of MAGIC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "449660009710768128",
    "geo" : { },
    "id_str" : "449660245191970816",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript cuz your mind is full of MAGIC",
    "id" : 449660245191970816,
    "in_reply_to_status_id" : 449660009710768128,
    "created_at" : "2014-03-28 21:32:11 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "protected" : false,
      "id_str" : "17092251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582894470452133888\/uBlV4V8-_normal.jpg",
      "id" : 17092251,
      "verified" : false
    }
  },
  "id" : 449663306861527040,
  "created_at" : "2014-03-28 21:44:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/449660009710768128\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/ewmYbqhIvd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj2DZX0CUAAZSrn.jpg",
      "id_str" : "449660009719156736",
      "id" : 449660009719156736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj2DZX0CUAAZSrn.jpg",
      "sizes" : [ {
        "h" : 753,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/ewmYbqhIvd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449657086725853184",
  "geo" : { },
  "id_str" : "449660009710768128",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  Im sayin!  I was like ouhmmmm http:\/\/t.co\/ewmYbqhIvd",
  "id" : 449660009710768128,
  "in_reply_to_status_id" : 449657086725853184,
  "created_at" : "2014-03-28 21:31:15 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449656074216300545",
  "geo" : { },
  "id_str" : "449656906504626176",
  "in_reply_to_user_id" : 46961216,
  "text" : "A complete, circular rainbow halo appeared on the ground, radius ~1meter, centered around the shadow of my head.  It followed me as I walked",
  "id" : 449656906504626176,
  "in_reply_to_status_id" : 449656074216300545,
  "created_at" : "2014-03-28 21:18:55 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449656074216300545",
  "text" : "I experienced a better-than-double-rainbow phenomenon on my lunch walk moments ago.",
  "id" : 449656074216300545,
  "created_at" : "2014-03-28 21:15:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Justin Stephenson",
      "screen_name" : "datatat",
      "indices" : [ 31, 39 ],
      "id_str" : "16929696",
      "id" : 16929696
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheHatGhost\/status\/449548478382080000\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/kJqUXyIvjC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj0d9UHIgAAfZG6.jpg",
      "id_str" : "449548477014769664",
      "id" : 449548477014769664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj0d9UHIgAAfZG6.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/kJqUXyIvjC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449567690215014400",
  "text" : "RT @TheHatGhost: @johnnyscript @datatat http:\/\/t.co\/kJqUXyIvjC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "Justin Stephenson",
        "screen_name" : "datatat",
        "indices" : [ 14, 22 ],
        "id_str" : "16929696",
        "id" : 16929696
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheHatGhost\/status\/449548478382080000\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/kJqUXyIvjC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj0d9UHIgAAfZG6.jpg",
        "id_str" : "449548477014769664",
        "id" : 449548477014769664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj0d9UHIgAAfZG6.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        } ],
        "display_url" : "pic.twitter.com\/kJqUXyIvjC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449548478382080000",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript @datatat http:\/\/t.co\/kJqUXyIvjC",
    "id" : 449548478382080000,
    "created_at" : "2014-03-28 14:08:04 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606927351168036864\/lzGOA4HX_normal.jpg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 449567690215014400,
  "created_at" : "2014-03-28 15:24:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449529430881230848",
  "geo" : { },
  "id_str" : "449567195463303168",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey heap allocation &amp;&amp; garbage collection?",
  "id" : 449567195463303168,
  "in_reply_to_status_id" : 449529430881230848,
  "created_at" : "2014-03-28 15:22:26 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "Justin Stephenson",
      "screen_name" : "datatat",
      "indices" : [ 13, 21 ],
      "id_str" : "16929696",
      "id" : 16929696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/nb8je9Ks83",
      "expanded_url" : "http:\/\/studio.substack.net\/johnny04",
      "display_url" : "studio.substack.net\/johnny04"
    } ]
  },
  "in_reply_to_status_id_str" : "449562000046055427",
  "geo" : { },
  "id_str" : "449567137934225408",
  "in_reply_to_user_id" : 46961216,
  "text" : "@TheHatGhost @datatat \nhttp:\/\/t.co\/nb8je9Ks83",
  "id" : 449567137934225408,
  "in_reply_to_status_id" : 449562000046055427,
  "created_at" : "2014-03-28 15:22:12 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "Justin Stephenson",
      "screen_name" : "datatat",
      "indices" : [ 13, 21 ],
      "id_str" : "16929696",
      "id" : 16929696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449548478382080000",
  "geo" : { },
  "id_str" : "449562000046055427",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost @datatat  :O",
  "id" : 449562000046055427,
  "in_reply_to_status_id" : 449548478382080000,
  "created_at" : "2014-03-28 15:01:47 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449373714682245120",
  "geo" : { },
  "id_str" : "449394090375774208",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey  I had the biggest crush on camp gay!",
  "id" : 449394090375774208,
  "in_reply_to_status_id" : 449373714682245120,
  "created_at" : "2014-03-28 03:54:35 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thorsten Lorenz",
      "screen_name" : "thlorenz",
      "indices" : [ 0, 9 ],
      "id_str" : "174726123",
      "id" : 174726123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449342167975493632",
  "geo" : { },
  "id_str" : "449352133431656448",
  "in_reply_to_user_id" : 174726123,
  "text" : "@thlorenz uhm by confusion++ what diz u mean?",
  "id" : 449352133431656448,
  "in_reply_to_status_id" : 449342167975493632,
  "created_at" : "2014-03-28 01:07:51 +0000",
  "in_reply_to_screen_name" : "thlorenz",
  "in_reply_to_user_id_str" : "174726123",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pcmI4eLcxo",
      "expanded_url" : "http:\/\/feedopensource.com",
      "display_url" : "feedopensource.com"
    } ]
  },
  "geo" : { },
  "id_str" : "449328894852620289",
  "text" : "http:\/\/t.co\/pcmI4eLcxo iteration 2 fully funded.  \n\nMr. Body Massage Machine GO!",
  "id" : 449328894852620289,
  "created_at" : "2014-03-27 23:35:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 15, 24 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "eran blade hammer",
      "screen_name" : "eranhammer",
      "indices" : [ 25, 36 ],
      "id_str" : "346026614",
      "id" : 346026614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449293558529269760",
  "geo" : { },
  "id_str" : "449300077882781697",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah @substack @eranhammer an indictor or warning perhaps that you shouldn't use it",
  "id" : 449300077882781697,
  "in_reply_to_status_id" : 449293558529269760,
  "created_at" : "2014-03-27 21:41:00 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/449241263208812544\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/8eNYqBo6ml",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjwGjHiCUAAeAxq.jpg",
      "id_str" : "449241263217201152",
      "id" : 449241263217201152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjwGjHiCUAAeAxq.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/8eNYqBo6ml"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449241263208812544",
  "text" : "lol good 1 found this on stackoverflow http:\/\/t.co\/8eNYqBo6ml",
  "id" : 449241263208812544,
  "created_at" : "2014-03-27 17:47:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449210812838588416",
  "text" : "Soon ads will capture you, analyze, clone, and display your happier, more beautiful avatar behind a screen enjoying the product of machines.",
  "id" : 449210812838588416,
  "created_at" : "2014-03-27 15:46:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449208849384230914",
  "geo" : { },
  "id_str" : "449209357327011841",
  "in_reply_to_user_id" : 46961216,
  "text" : "THIS IS YOUR BRAIN ON CLASSIFICATION",
  "id" : 449209357327011841,
  "in_reply_to_status_id" : 449208849384230914,
  "created_at" : "2014-03-27 15:40:31 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/J4Z9PSe62l",
      "expanded_url" : "http:\/\/docomputersdream.org\/#lVH8FVyEQOzwrLkQCkDvTCR_R-c",
      "display_url" : "docomputersdream.org\/#lVH8FVyEQOzwr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449208849384230914",
  "text" : "lol \n\nhttp:\/\/t.co\/J4Z9PSe62l\n\nwait for it...",
  "id" : 449208849384230914,
  "created_at" : "2014-03-27 15:38:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 13, 22 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449078624600080384",
  "geo" : { },
  "id_str" : "449084162444492800",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @substack DOWNSAMPLE REALITY",
  "id" : 449084162444492800,
  "in_reply_to_status_id" : 449078624600080384,
  "created_at" : "2014-03-27 07:23:02 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449067314734845952",
  "geo" : { },
  "id_str" : "449073958441062401",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript but shift-arrows and delete don't work now, is this a mac thing?",
  "id" : 449073958441062401,
  "in_reply_to_status_id" : 449067314734845952,
  "created_at" : "2014-03-27 06:42:29 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449068788667785216",
  "text" : "I no longer support quotes around html attributes",
  "id" : 449068788667785216,
  "created_at" : "2014-03-27 06:21:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smells",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449067314734845952",
  "text" : "finally got vim syntaxing JS right and using mango color scheme.  so much nicer than red strings on a black bg, i mean rilly tho.  #smells",
  "id" : 449067314734845952,
  "created_at" : "2014-03-27 06:16:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/449063478095912960\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/So6k5GdCYE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjtk2qYCIAAVriB.jpg",
      "id_str" : "449063478104301568",
      "id" : 449063478104301568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjtk2qYCIAAVriB.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/So6k5GdCYE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448936304974131200",
  "geo" : { },
  "id_str" : "449063478095912960",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack I have one like that too, made while debugging my own app.  We should start a band or something. http:\/\/t.co\/So6k5GdCYE",
  "id" : 449063478095912960,
  "in_reply_to_status_id" : 448936304974131200,
  "created_at" : "2014-03-27 06:00:51 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449056400225091584",
  "geo" : { },
  "id_str" : "449060816562577409",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah the kitchen tool or the musical instrument?",
  "id" : 449060816562577409,
  "in_reply_to_status_id" : 449056400225091584,
  "created_at" : "2014-03-27 05:50:16 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449037748406464512",
  "text" : "watch this space cadet watch this space",
  "id" : 449037748406464512,
  "created_at" : "2014-03-27 04:18:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449030568835940353",
  "text" : "dance dance program",
  "id" : 449030568835940353,
  "created_at" : "2014-03-27 03:50:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448855510033260544",
  "text" : "l8vers gonna l8ve",
  "id" : 448855510033260544,
  "created_at" : "2014-03-26 16:14:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/vL9Ucs68Yj",
      "expanded_url" : "http:\/\/studio.substack.net\/johnny_plucky0",
      "display_url" : "studio.substack.net\/johnny_plucky0"
    } ]
  },
  "geo" : { },
  "id_str" : "448662292352090112",
  "text" : "code music doodle http:\/\/t.co\/vL9Ucs68Yj",
  "id" : 448662292352090112,
  "created_at" : "2014-03-26 03:26:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/uTLPw5Zesy",
      "expanded_url" : "https:\/\/www.newschallenge.org\/challenge\/2014\/feedback-review\/toward-a-network-commons-building-an-internet-for-and-by-the-people",
      "display_url" : "newschallenge.org\/challenge\/2014\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448589775654486017",
  "text" : "hey this is real make, sure it gets awarded grant $$$ - wifi mesh networking for free community internets   https:\/\/t.co\/uTLPw5Zesy",
  "id" : 448589775654486017,
  "created_at" : "2014-03-25 22:38:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448324915138011136",
  "geo" : { },
  "id_str" : "448362511859851265",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar haha you called your personal web framework with built-in sockets \"skateboard\"  :^P",
  "id" : 448362511859851265,
  "in_reply_to_status_id" : 448324915138011136,
  "created_at" : "2014-03-25 07:35:27 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448360610690912256",
  "text" : "when I say x\nyou mean y\nx\ny\nx\ny",
  "id" : 448360610690912256,
  "created_at" : "2014-03-25 07:27:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448359576312619008",
  "text" : "pineapple so fine you eat the core",
  "id" : 448359576312619008,
  "created_at" : "2014-03-25 07:23:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448251188463427584",
  "text" : "I opened google drive, now how do I get a ride?",
  "id" : 448251188463427584,
  "created_at" : "2014-03-25 00:13:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448234859551391745",
  "text" : "ctrl-click, you know, opens the link in a new tab without switching your view to that tab.",
  "id" : 448234859551391745,
  "created_at" : "2014-03-24 23:08:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448234194078945281",
  "text" : "The fact that ads open in a new tab makes redistributing wealth from international manufactures to bespoke publishers not very distracting.",
  "id" : 448234194078945281,
  "created_at" : "2014-03-24 23:05:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448232568412835840",
  "text" : "screwgle: app that googles random BS so the advertisers loose track of yr demographic.  See also: cookie-club: swap cookies w\/strangers!",
  "id" : 448232568412835840,
  "created_at" : "2014-03-24 22:59:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447896163035774976",
  "text" : "axii",
  "id" : 447896163035774976,
  "created_at" : "2014-03-24 00:42:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447881770843639808",
  "text" : "forgotten accounts inside forgotten accounts",
  "id" : 447881770843639808,
  "created_at" : "2014-03-23 23:45:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447874323143864320",
  "text" : "abre tu mundo y la puerta tambien",
  "id" : 447874323143864320,
  "created_at" : "2014-03-23 23:15:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447856003728416768",
  "text" : "talk to my agent @node_modulhaus",
  "id" : 447856003728416768,
  "created_at" : "2014-03-23 22:02:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447855925185888256",
  "text" : "im not doing your hackathon or conference or contest or naked marketing ploy, but if u give me cash I can promise u something expensive.",
  "id" : 447855925185888256,
  "created_at" : "2014-03-23 22:02:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447855281729310720",
  "text" : "open call for web companies:  give me money directly and I will make something freaky with your API.  Money in hand or gtfo.",
  "id" : 447855281729310720,
  "created_at" : "2014-03-23 21:59:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447854515048296449",
  "text" : "Who else is being targeted with googlies lame dev art campaign?  Can I put that in my resume?",
  "id" : 447854515048296449,
  "created_at" : "2014-03-23 21:56:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "disasteradio",
      "screen_name" : "disasteradio",
      "indices" : [ 0, 13 ],
      "id_str" : "90604368",
      "id" : 90604368
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 42, 51 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/rZIoGglJtD",
      "expanded_url" : "http:\/\/files.ilictronix.com\/staff\/claude\/images\/software-digital-dance.jpg",
      "display_url" : "files.ilictronix.com\/staff\/claude\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "447832464757518336",
  "geo" : { },
  "id_str" : "447852881618546688",
  "in_reply_to_user_id" : 90604368,
  "text" : "@disasteradio check that album gen art cc\/@substack http:\/\/t.co\/rZIoGglJtD",
  "id" : 447852881618546688,
  "in_reply_to_status_id" : 447832464757518336,
  "created_at" : "2014-03-23 21:50:22 +0000",
  "in_reply_to_screen_name" : "disasteradio",
  "in_reply_to_user_id_str" : "90604368",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/od7kAw6j1P",
      "expanded_url" : "https:\/\/medium.com\/philosophy-logic\/ab75335fe268",
      "display_url" : "medium.com\/philosophy-log\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "447775441932546048",
  "geo" : { },
  "id_str" : "447809285452345345",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah welcome to your new home https:\/\/t.co\/od7kAw6j1P",
  "id" : 447809285452345345,
  "in_reply_to_status_id" : 447775441932546048,
  "created_at" : "2014-03-23 18:57:08 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/f5fQYuidgu",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=NHQ\/9711493",
      "display_url" : "requirebin.com\/?gist=NHQ\/9711\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447432297420058624",
  "text" : "messaging between window and iframe http:\/\/t.co\/f5fQYuidgu",
  "id" : 447432297420058624,
  "created_at" : "2014-03-22 17:59:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447418787474591744",
  "text" : "I am the anti-programmer.  I haven't made my own blog CMS, I don't write tests, and I spend too much time standing at a computer.",
  "id" : 447418787474591744,
  "created_at" : "2014-03-22 17:05:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447273044604502016",
  "text" : "reinventing machine education",
  "id" : 447273044604502016,
  "created_at" : "2014-03-22 07:26:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/447203491555995648\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ocrCW8KGcs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjTJNL7CQAAH01o.jpg",
      "id_str" : "447203491392405504",
      "id" : 447203491392405504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjTJNL7CQAAH01o.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 860,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ocrCW8KGcs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447203491555995648",
  "text" : "Check out my new git up. http:\/\/t.co\/ocrCW8KGcs",
  "id" : 447203491555995648,
  "created_at" : "2014-03-22 02:49:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m. hokanson",
      "screen_name" : "h0ke",
      "indices" : [ 0, 5 ],
      "id_str" : "16802242",
      "id" : 16802242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447191457007284224",
  "geo" : { },
  "id_str" : "447196445179789312",
  "in_reply_to_user_id" : 16802242,
  "text" : "@h0ke \nNaturally, you would appreciate it almost touching the ground",
  "id" : 447196445179789312,
  "in_reply_to_status_id" : 447191457007284224,
  "created_at" : "2014-03-22 02:21:55 +0000",
  "in_reply_to_screen_name" : "h0ke",
  "in_reply_to_user_id_str" : "16802242",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/447189853617135616\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/DyMLxRXzMy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjS8zWjCUAA8tGf.jpg",
      "id_str" : "447189853428404224",
      "id" : 447189853428404224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjS8zWjCUAA8tGf.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/DyMLxRXzMy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446911859933736960",
  "geo" : { },
  "id_str" : "447189853617135616",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript home http:\/\/t.co\/DyMLxRXzMy",
  "id" : 447189853617135616,
  "in_reply_to_status_id" : 446911859933736960,
  "created_at" : "2014-03-22 01:55:44 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knuckle Tat",
      "screen_name" : "knuckle_tat",
      "indices" : [ 0, 12 ],
      "id_str" : "2287798746",
      "id" : 2287798746
    }, {
      "name" : "m. hokanson",
      "screen_name" : "h0ke",
      "indices" : [ 13, 18 ],
      "id_str" : "16802242",
      "id" : 16802242
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 53, 65 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "disasteradio",
      "screen_name" : "disasteradio",
      "indices" : [ 66, 79 ],
      "id_str" : "90604368",
      "id" : 90604368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/OA9ri4ZmcS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=s0S-HOOp_VY&feature=youtu.be&t=30s",
      "display_url" : "youtube.com\/watch?v=s0S-HO\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "447151808842985472",
  "geo" : { },
  "id_str" : "447159493235703808",
  "in_reply_to_user_id" : 2287798746,
  "text" : "@knuckle_tat @h0ke \nFREE WIFI\nhttp:\/\/t.co\/OA9ri4ZmcS\n@dominictarr @disasteradio",
  "id" : 447159493235703808,
  "in_reply_to_status_id" : 447151808842985472,
  "created_at" : "2014-03-21 23:55:05 +0000",
  "in_reply_to_screen_name" : "knuckle_tat",
  "in_reply_to_user_id_str" : "2287798746",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446914685489537024",
  "geo" : { },
  "id_str" : "446916790199656448",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia  Poop on a leash",
  "id" : 446916790199656448,
  "in_reply_to_status_id" : 446914685489537024,
  "created_at" : "2014-03-21 07:50:40 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446911859933736960",
  "text" : "Rode bike from North Berkeley to Middle-East Oakland.  Got a pie in the face of flowers &amp; scents entering Stanza,  garden of Hackistan.",
  "id" : 446911859933736960,
  "created_at" : "2014-03-21 07:31:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoskop",
      "screen_name" : "monoskop",
      "indices" : [ 0, 9 ],
      "id_str" : "50769684",
      "id" : 50769684
    }, {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 14, 26 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446701351586656257",
  "geo" : { },
  "id_str" : "446734622647279616",
  "in_reply_to_user_id" : 50769684,
  "text" : "@monoskop cc\/ @TheHatGhost",
  "id" : 446734622647279616,
  "in_reply_to_status_id" : 446701351586656257,
  "created_at" : "2014-03-20 19:46:48 +0000",
  "in_reply_to_screen_name" : "monoskop",
  "in_reply_to_user_id_str" : "50769684",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoskop",
      "screen_name" : "monoskop",
      "indices" : [ 3, 12 ],
      "id_str" : "50769684",
      "id" : 50769684
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/monoskop\/status\/446615095548719105\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/oRnCx7juiU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjKyECoCMAAyfBY.jpg",
      "id_str" : "446615095557107712",
      "id" : 446615095557107712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjKyECoCMAAyfBY.jpg",
      "sizes" : [ {
        "h" : 1527,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1563,
        "resize" : "fit",
        "w" : 1048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 895,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oRnCx7juiU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/0V28WQ2Bhq",
      "expanded_url" : "http:\/\/monoskop.org\/log\/?p=11083",
      "display_url" : "monoskop.org\/log\/?p=11083"
    } ]
  },
  "geo" : { },
  "id_str" : "446688059094884352",
  "text" : "RT @monoskop: Walter Gropius: The New Architecture and the Bauhaus (1935\/1965) http:\/\/t.co\/0V28WQ2Bhq http:\/\/t.co\/oRnCx7juiU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/monoskop\/status\/446615095548719105\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/oRnCx7juiU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjKyECoCMAAyfBY.jpg",
        "id_str" : "446615095557107712",
        "id" : 446615095557107712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjKyECoCMAAyfBY.jpg",
        "sizes" : [ {
          "h" : 1527,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1563,
          "resize" : "fit",
          "w" : 1048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 895,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oRnCx7juiU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/0V28WQ2Bhq",
        "expanded_url" : "http:\/\/monoskop.org\/log\/?p=11083",
        "display_url" : "monoskop.org\/log\/?p=11083"
      } ]
    },
    "geo" : { },
    "id_str" : "446615095548719105",
    "text" : "Walter Gropius: The New Architecture and the Bauhaus (1935\/1965) http:\/\/t.co\/0V28WQ2Bhq http:\/\/t.co\/oRnCx7juiU",
    "id" : 446615095548719105,
    "created_at" : "2014-03-20 11:51:51 +0000",
    "user" : {
      "name" : "monoskop",
      "screen_name" : "monoskop",
      "protected" : false,
      "id_str" : "50769684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476272053469728768\/j8wk6ibH_normal.png",
      "id" : 50769684,
      "verified" : false
    }
  },
  "id" : 446688059094884352,
  "created_at" : "2014-03-20 16:41:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Evan You",
      "screen_name" : "youyuxi",
      "indices" : [ 8, 16 ],
      "id_str" : "182821975",
      "id" : 182821975
    }, {
      "name" : "unspecified.jpg",
      "screen_name" : "fivetanley",
      "indices" : [ 17, 28 ],
      "id_str" : "306497372",
      "id" : 306497372
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 29, 38 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ALERT",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446520058848624640",
  "geo" : { },
  "id_str" : "446577813613580288",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @youyuxi @fivetanley @substack \nYour lil module is not the topic here\nBut this is a perfect RED FLAG for core concerns.\nWTF?\n#ALERT",
  "id" : 446577813613580288,
  "in_reply_to_status_id" : 446520058848624640,
  "created_at" : "2014-03-20 09:23:42 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 8, 17 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Nicole Sullivan",
      "screen_name" : "stubbornella",
      "indices" : [ 18, 31 ],
      "id_str" : "15629200",
      "id" : 15629200
    }, {
      "name" : "Jake Verbaten",
      "screen_name" : "Raynos",
      "indices" : [ 32, 39 ],
      "id_str" : "304682840",
      "id" : 304682840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446499112536387585",
  "geo" : { },
  "id_str" : "446574644875636736",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @substack @stubbornella @raynos\nSounds like you are being critically ignorant.\nListen: disagreement surrounds every ES6 \"feature\".",
  "id" : 446574644875636736,
  "in_reply_to_status_id" : 446499112536387585,
  "created_at" : "2014-03-20 09:11:06 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 0, 7 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Nicole Sullivan",
      "screen_name" : "stubbornella",
      "indices" : [ 8, 21 ],
      "id_str" : "15629200",
      "id" : 15629200
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 129, 138 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446495604579921920",
  "geo" : { },
  "id_str" : "446572696650776576",
  "in_reply_to_user_id" : 8526432,
  "text" : "@wycats @stubbornella \nThe Node community is not trying to force idioms into the language over a background of disagreement.  cc\/@substack",
  "id" : 446572696650776576,
  "in_reply_to_status_id" : 446495604579921920,
  "created_at" : "2014-03-20 09:03:22 +0000",
  "in_reply_to_screen_name" : "wycats",
  "in_reply_to_user_id_str" : "8526432",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 14, 21 ],
      "id_str" : "8526432",
      "id" : 8526432
    }, {
      "name" : "Nicole Sullivan",
      "screen_name" : "stubbornella",
      "indices" : [ 22, 35 ],
      "id_str" : "15629200",
      "id" : 15629200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446562692254277633",
  "text" : "RT @substack: @wycats @stubbornella Ad-hominem. The \"batteries included\" ideology that underlies this inclusion sucks the air out of ecosys\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yehuda Katz",
        "screen_name" : "wycats",
        "indices" : [ 0, 7 ],
        "id_str" : "8526432",
        "id" : 8526432
      }, {
        "name" : "Nicole Sullivan",
        "screen_name" : "stubbornella",
        "indices" : [ 8, 21 ],
        "id_str" : "15629200",
        "id" : 15629200
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "446499112536387585",
    "geo" : { },
    "id_str" : "446501501720985600",
    "in_reply_to_user_id" : 8526432,
    "text" : "@wycats @stubbornella Ad-hominem. The \"batteries included\" ideology that underlies this inclusion sucks the air out of ecosystems.",
    "id" : 446501501720985600,
    "in_reply_to_status_id" : 446499112536387585,
    "created_at" : "2014-03-20 04:20:28 +0000",
    "in_reply_to_screen_name" : "wycats",
    "in_reply_to_user_id_str" : "8526432",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 446562692254277633,
  "created_at" : "2014-03-20 08:23:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446487572139634689",
  "text" : "aint lyin I write code on a pedestal",
  "id" : 446487572139634689,
  "created_at" : "2014-03-20 03:25:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 0, 4 ],
      "id_str" : "4816",
      "id" : 4816
    }, {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 45, 53 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446304956404867072",
  "geo" : { },
  "id_str" : "446413173348773888",
  "in_reply_to_user_id" : 4816,
  "text" : "@EFF avatar looks like a bag of potato chips @soldair",
  "id" : 446413173348773888,
  "in_reply_to_status_id" : 446304956404867072,
  "created_at" : "2014-03-19 22:29:29 +0000",
  "in_reply_to_screen_name" : "EFF",
  "in_reply_to_user_id_str" : "4816",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446359346696310784",
  "text" : "name:\nmanual people\nemail:\n99:99:24:df:37\npassword:\nvar1@ions04@Kind3000\nprove yr human on this robocaptcha:\n\\\\\/\/\\\\\/\/\/Ants!#&amp;\/&gt;*[*]\/\\outout\\",
  "id" : 446359346696310784,
  "created_at" : "2014-03-19 18:55:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446353867429539840",
  "text" : "Theory:  One should be offered some ratio of one's proven market rate to apply that market skill how one chooses.  Another ratio to teach...",
  "id" : 446353867429539840,
  "created_at" : "2014-03-19 18:33:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446130007098658816",
  "text" : "hilarious bug found",
  "id" : 446130007098658816,
  "created_at" : "2014-03-19 03:44:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446129204682182656",
  "text" : "Rome wasn't written in 3 months for $18,000.",
  "id" : 446129204682182656,
  "created_at" : "2014-03-19 03:41:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446125689167568896",
  "text" : "say it with me\nvar data\nvar\ndata\nvarrrrr\nda\ntuh",
  "id" : 446125689167568896,
  "created_at" : "2014-03-19 03:27:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446015441601695744",
  "text" : "feels good to be off the cell networks.  now I must needs build my personal communication device.",
  "id" : 446015441601695744,
  "created_at" : "2014-03-18 20:09:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446011820138967040",
  "text" : "I'm pivoting, like LEBRON.",
  "id" : 446011820138967040,
  "created_at" : "2014-03-18 19:54:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446001198827466753",
  "geo" : { },
  "id_str" : "446011689809346560",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso millions? one?",
  "id" : 446011689809346560,
  "in_reply_to_status_id" : 446001198827466753,
  "created_at" : "2014-03-18 19:54:08 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445993267554172930",
  "text" : "It should not surprise you that an individual does not like being blamed for the system.",
  "id" : 445993267554172930,
  "created_at" : "2014-03-18 18:40:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sartaj",
      "screen_name" : "sartaj",
      "indices" : [ 0, 7 ],
      "id_str" : "24467334",
      "id" : 24467334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445865173765476352",
  "geo" : { },
  "id_str" : "445990513540595712",
  "in_reply_to_user_id" : 24467334,
  "text" : "@sartaj \nI mean is \"translateX(100px)\" a function, like in JS, or is it a declaration, like most of CSS, only written in function style?",
  "id" : 445990513540595712,
  "in_reply_to_status_id" : 445865173765476352,
  "created_at" : "2014-03-18 18:29:59 +0000",
  "in_reply_to_screen_name" : "sartaj",
  "in_reply_to_user_id_str" : "24467334",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445815165569622016",
  "text" : "This beard, she's been good to me.",
  "id" : 445815165569622016,
  "created_at" : "2014-03-18 06:53:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445769838573535233",
  "text" : "Folk Stack Artist and Web Spinner",
  "id" : 445769838573535233,
  "created_at" : "2014-03-18 03:53:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Kempf",
      "screen_name" : "takempf",
      "indices" : [ 0, 8 ],
      "id_str" : "17734862",
      "id" : 17734862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445767862230056960",
  "geo" : { },
  "id_str" : "445769749872398336",
  "in_reply_to_user_id" : 17734862,
  "text" : "@takempf \ntrust me\nur gonna want yr own",
  "id" : 445769749872398336,
  "in_reply_to_status_id" : 445767862230056960,
  "created_at" : "2014-03-18 03:52:45 +0000",
  "in_reply_to_screen_name" : "takempf",
  "in_reply_to_user_id_str" : "17734862",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445767745745862656",
  "text" : "Soon my personal framework will grant auto generated parametric user interfaces, for remote, multi-modal control.  Give up!",
  "id" : 445767745745862656,
  "created_at" : "2014-03-18 03:44:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445767102859726848",
  "text" : "Como?  My personal web framework now includes API configurable websocket behaviours for games and other scenarios.  Is what I meant.",
  "id" : 445767102859726848,
  "created_at" : "2014-03-18 03:42:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445765767317835778",
  "text" : "My person web framework now includes API configurable stream behaviours for single, double and multi passes.",
  "id" : 445765767317835778,
  "created_at" : "2014-03-18 03:36:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445746807117586433",
  "text" : "i'm often off one in the abstraction",
  "id" : 445746807117586433,
  "created_at" : "2014-03-18 02:21:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445679971655106560",
  "text" : "With CSS, is like translateX(100px) an actual function?  Or did they really turn functional syntax into a semantic style?",
  "id" : 445679971655106560,
  "created_at" : "2014-03-17 21:56:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445643843799502848",
  "geo" : { },
  "id_str" : "445668201217536000",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar airbnb began as a novelty cereal iirc",
  "id" : 445668201217536000,
  "in_reply_to_status_id" : 445643843799502848,
  "created_at" : "2014-03-17 21:09:13 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445664929631047680",
  "text" : "I'm back on the Jack \nbut got the major arcana with me all so",
  "id" : 445664929631047680,
  "created_at" : "2014-03-17 20:56:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445657466890510337",
  "geo" : { },
  "id_str" : "445664529825812480",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah CRANK UP YR IMAGINATION",
  "id" : 445664529825812480,
  "in_reply_to_status_id" : 445657466890510337,
  "created_at" : "2014-03-17 20:54:38 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0432\u0435\u0442\u043A\u0430 \u0410\u043D\u043E\u0448\u043A\u043E",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "429007315",
      "id" : 429007315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445580476233678849",
  "geo" : { },
  "id_str" : "445590912156962816",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah software is a translation of robotic consciousness what are you talking about crazy man?",
  "id" : 445590912156962816,
  "in_reply_to_status_id" : 445580476233678849,
  "created_at" : "2014-03-17 16:02:06 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445404452816551937",
  "text" : "u wont find me binding functions",
  "id" : 445404452816551937,
  "created_at" : "2014-03-17 03:41:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445404290966765568",
  "text" : "i've got buttons to grind",
  "id" : 445404290966765568,
  "created_at" : "2014-03-17 03:40:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445403990923038720",
  "text" : "here's where I leave some ideas behind.",
  "id" : 445403990923038720,
  "created_at" : "2014-03-17 03:39:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445403858949242880",
  "text" : "im outside inside my mind",
  "id" : 445403858949242880,
  "created_at" : "2014-03-17 03:38:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445383213393780736",
  "text" : "Eat the change you want to be.",
  "id" : 445383213393780736,
  "created_at" : "2014-03-17 02:16:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445105400258387968",
  "text" : "tasks = tasks.filter.sort.reduce.map.rereduceduce",
  "id" : 445105400258387968,
  "created_at" : "2014-03-16 07:52:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "M Heuberger",
      "screen_name" : "binarykitchen",
      "indices" : [ 13, 27 ],
      "id_str" : "115861122",
      "id" : 115861122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444722410055405568",
  "geo" : { },
  "id_str" : "444722733725650944",
  "in_reply_to_user_id" : 46961216,
  "text" : "@dominictarr @binarykitchen 'course if it plays in a video tag u can record audio with webAudio (mediaStreamNode) &amp; video with canvas 2 pngs",
  "id" : 444722733725650944,
  "in_reply_to_status_id" : 444722410055405568,
  "created_at" : "2014-03-15 06:32:16 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "M Heuberger",
      "screen_name" : "binarykitchen",
      "indices" : [ 13, 27 ],
      "id_str" : "115861122",
      "id" : 115861122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441382227843108866",
  "geo" : { },
  "id_str" : "444722410055405568",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @binarykitchen I ran the demo on their site.  seemed to work.",
  "id" : 444722410055405568,
  "in_reply_to_status_id" : 441382227843108866,
  "created_at" : "2014-03-15 06:30:59 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/444684691937849344\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/5fFHEAj5t5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BivWXwxCcAAQp0L.jpg",
      "id_str" : "444684691942043648",
      "id" : 444684691942043648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BivWXwxCcAAQp0L.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5fFHEAj5t5"
    } ],
    "hashtags" : [ {
      "text" : "piDay",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444684691937849344",
  "text" : "I drew this with my finger on an app I wrote using a stroke I mathified #piDay http:\/\/t.co\/5fFHEAj5t5",
  "id" : 444684691937849344,
  "created_at" : "2014-03-15 04:01:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444675351126364160",
  "text" : "Is a laptop your vanishing point?",
  "id" : 444675351126364160,
  "created_at" : "2014-03-15 03:24:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444603450920169472",
  "text" : "the full moon will be Sunday, if you were wondering.  You could have been wondering anything, but you read this.",
  "id" : 444603450920169472,
  "created_at" : "2014-03-14 22:38:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444589335870857216",
  "geo" : { },
  "id_str" : "444603128369778688",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr major refactor!",
  "id" : 444603128369778688,
  "in_reply_to_status_id" : 444589335870857216,
  "created_at" : "2014-03-14 22:37:00 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444548846123642880",
  "text" : "Edification is when the feedback reinforces the pattern.",
  "id" : 444548846123642880,
  "created_at" : "2014-03-14 19:01:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444547195212009472",
  "text" : "What countries they pay people like me to teach kids things like \"this\"?",
  "id" : 444547195212009472,
  "created_at" : "2014-03-14 18:54:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 5, 12 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "literal brujer\u00EDa",
      "screen_name" : "nrrrdcore",
      "indices" : [ 13, 23 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444520098603089920",
  "geo" : { },
  "id_str" : "444521823904870400",
  "in_reply_to_user_id" : 46961216,
  "text" : "@izs @github @nrrrdcore\nwhile stay == cease \/\/ i.e. the execution &amp;! the continuation\nif classy == adj. bad or outmoded behavior\nreturn true",
  "id" : 444521823904870400,
  "in_reply_to_status_id" : 444520098603089920,
  "created_at" : "2014-03-14 17:13:56 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 5, 12 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "literal brujer\u00EDa",
      "screen_name" : "nrrrdcore",
      "indices" : [ 13, 23 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444301912314097665",
  "geo" : { },
  "id_str" : "444520098603089920",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs @github @nrrrdcore \nwhile stay == continue\nif classy == \"[high || upper] class\" \nreturn sarcasm\nif classy == Classical\nreturn irony",
  "id" : 444520098603089920,
  "in_reply_to_status_id" : 444301912314097665,
  "created_at" : "2014-03-14 17:07:04 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443498623477616640",
  "text" : "Gotta stop handshaking.",
  "id" : 443498623477616640,
  "created_at" : "2014-03-11 21:28:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443478903655383041",
  "text" : "I'm a child for simplicity.",
  "id" : 443478903655383041,
  "created_at" : "2014-03-11 20:09:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443428593469624320",
  "text" : "Bring it life!",
  "id" : 443428593469624320,
  "created_at" : "2014-03-11 16:49:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443174939877572608",
  "text" : "The Three of Ruby \nThe Three of Python\nThe Six of ECMASCRIPT",
  "id" : 443174939877572608,
  "created_at" : "2014-03-11 00:01:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/BGXA9Zhoqk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zBft8qY6caE&feature=share&list=RD9bvKiISdcjk&index=2",
      "display_url" : "youtube.com\/watch?v=zBft8q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443080629601570817",
  "text" : "watch http:\/\/t.co\/BGXA9Zhoqk",
  "id" : 443080629601570817,
  "created_at" : "2014-03-10 17:47:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aNVuca0qVv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=K5_Fusasy2s&list=RD9AiL6e0KpXU&feature=share&index=4",
      "display_url" : "youtube.com\/watch?v=K5_Fus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442790083909791745",
  "text" : "http:\/\/t.co\/aNVuca0qVv",
  "id" : 442790083909791745,
  "created_at" : "2014-03-09 22:32:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442091502445948928",
  "text" : "SAVE THE TREES\n\nIN YR DATABASE\n\n#",
  "id" : 442091502445948928,
  "created_at" : "2014-03-08 00:16:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442083655796531200",
  "text" : "Call me Palos Billz",
  "id" : 442083655796531200,
  "created_at" : "2014-03-07 23:45:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442068566347509761",
  "text" : "Wierdo in yr Paradise",
  "id" : 442068566347509761,
  "created_at" : "2014-03-07 22:45:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/dmPoJmhIhA",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9AiL6e0KpXU",
      "display_url" : "youtube.com\/watch?v=9AiL6e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441843747504922624",
  "text" : "uh love this jam http:\/\/t.co\/dmPoJmhIhA",
  "id" : 441843747504922624,
  "created_at" : "2014-03-07 07:52:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441417748485128192",
  "text" : "I got two ratatouille going.",
  "id" : 441417748485128192,
  "created_at" : "2014-03-06 03:39:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/m8tYKQd4rY",
      "expanded_url" : "http:\/\/bgrins.github.io\/videoconverter.js\/",
      "display_url" : "bgrins.github.io\/videoconverter\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441331920954068993",
  "geo" : { },
  "id_str" : "441347103231467520",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  Supposedly this is an emscripten port of ffmpeg  http:\/\/t.co\/m8tYKQd4rY",
  "id" : 441347103231467520,
  "in_reply_to_status_id" : 441331920954068993,
  "created_at" : "2014-03-05 22:58:43 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440982789672820736",
  "text" : "the pendulum of it all",
  "id" : 440982789672820736,
  "created_at" : "2014-03-04 22:51:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 0, 7 ],
      "id_str" : "15540222",
      "id" : 15540222
    }, {
      "name" : "David Trejo",
      "screen_name" : "ddtrejo",
      "indices" : [ 8, 16 ],
      "id_str" : "58248334",
      "id" : 58248334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440898629146923011",
  "geo" : { },
  "id_str" : "440916756576473088",
  "in_reply_to_user_id" : 15540222,
  "text" : "@rauchg @ddtrejo \nThis bananas is shit.",
  "id" : 440916756576473088,
  "in_reply_to_status_id" : 440898629146923011,
  "created_at" : "2014-03-04 18:28:41 +0000",
  "in_reply_to_screen_name" : "rauchg",
  "in_reply_to_user_id_str" : "15540222",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440909859525902336",
  "text" : "super user doooooooooo",
  "id" : 440909859525902336,
  "created_at" : "2014-03-04 18:01:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Whittemore",
      "screen_name" : "mcwhittemore",
      "indices" : [ 0, 13 ],
      "id_str" : "13319802",
      "id" : 13319802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440554754775601152",
  "in_reply_to_user_id" : 13319802,
  "text" : "@mcwhittemore  I could really use git clean on a repo, pls advise!",
  "id" : 440554754775601152,
  "created_at" : "2014-03-03 18:30:13 +0000",
  "in_reply_to_screen_name" : "mcwhittemore",
  "in_reply_to_user_id_str" : "13319802",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440426869968478208",
  "text" : "Johnny Go Hard",
  "id" : 440426869968478208,
  "created_at" : "2014-03-03 10:02:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440058830760579072",
  "text" : "git add index.js entry.js bindex.js bentry.js\ngit commit -am \"git night\"",
  "id" : 440058830760579072,
  "created_at" : "2014-03-02 09:39:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 0, 14 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439851685406453760",
  "geo" : { },
  "id_str" : "439874529670619136",
  "in_reply_to_user_id" : 379919160,
  "text" : "@MikolaLysenko \nis this big enough?\n[[0,0], [1e9, 0], [1e9, 1e9], [0. 1e9]]",
  "id" : 439874529670619136,
  "in_reply_to_status_id" : 439851685406453760,
  "created_at" : "2014-03-01 21:27:15 +0000",
  "in_reply_to_screen_name" : "MikolaLysenko",
  "in_reply_to_user_id_str" : "379919160",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]