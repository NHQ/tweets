Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhammapada",
      "screen_name" : "dhammapada_es",
      "indices" : [ 3, 17 ],
      "id_str" : "212375376",
      "id" : 212375376
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/dhammapada_es\/status\/704349306833260544\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/hYGuTLfHra",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcZZ9SCWoAAfZw1.jpg",
      "id_str" : "704349301078663168",
      "id" : 704349301078663168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcZZ9SCWoAAfZw1.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/hYGuTLfHra"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704350969182617600",
  "text" : "RT @dhammapada_es: Todo el universo en el que vives est\u00E1 en tu mente. https:\/\/t.co\/hYGuTLfHra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/dhammapada_es\/status\/704349306833260544\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/hYGuTLfHra",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcZZ9SCWoAAfZw1.jpg",
        "id_str" : "704349301078663168",
        "id" : 704349301078663168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcZZ9SCWoAAfZw1.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/hYGuTLfHra"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704349306833260544",
    "text" : "Todo el universo en el que vives est\u00E1 en tu mente. https:\/\/t.co\/hYGuTLfHra",
    "id" : 704349306833260544,
    "created_at" : "2016-02-29 16:55:35 +0000",
    "user" : {
      "name" : "Dhammapada",
      "screen_name" : "dhammapada_es",
      "protected" : false,
      "id_str" : "212375376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570314912312750080\/0ZZXqCfL_normal.jpeg",
      "id" : 212375376,
      "verified" : false
    }
  },
  "id" : 704350969182617600,
  "created_at" : "2016-02-29 17:02:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704190151161851906",
  "text" : "you have distracted me from my creative processeeeeez",
  "id" : 704190151161851906,
  "created_at" : "2016-02-29 06:23:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703728249168220161",
  "text" : "who wants to take a babe to the dance tonight?",
  "id" : 703728249168220161,
  "created_at" : "2016-02-27 23:47:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/57SmGtUXd9",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=yFzJf4IrjYA&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=yFzJf4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703261525952233472",
  "text" : "autosynth + algogenerated interface\n\nhttps:\/\/t.co\/57SmGtUXd9",
  "id" : 703261525952233472,
  "created_at" : "2016-02-26 16:53:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702960597365723136",
  "text" : "what if we demand equality for all labor?",
  "id" : 702960597365723136,
  "created_at" : "2016-02-25 20:57:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702959868785758208",
  "text" : "minimum wage should be $50\/hr",
  "id" : 702959868785758208,
  "created_at" : "2016-02-25 20:54:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702898503194775555",
  "text" : "An open letter to my peers:  C",
  "id" : 702898503194775555,
  "created_at" : "2016-02-25 16:50:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702672136951824384",
  "text" : "inininterternetternetnet",
  "id" : 702672136951824384,
  "created_at" : "2016-02-25 01:51:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702671912728547328",
  "text" : "interinternetnet",
  "id" : 702671912728547328,
  "created_at" : "2016-02-25 01:50:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 100, 114 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PrHcns30Jl",
      "expanded_url" : "http:\/\/qz.com\/622452\/tech-bros-and-their-sense-of-entitlement-will-be-silicon-valleys-undoing\/",
      "display_url" : "qz.com\/622452\/tech-br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702202103704358912",
  "text" : "\"who would want to be reminded of market failure on his way to work at a redundant tech startup\"? - @girlziplocked \n\nhttps:\/\/t.co\/PrHcns30Jl",
  "id" : 702202103704358912,
  "created_at" : "2016-02-23 18:43:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Keys",
      "screen_name" : "MatthewKeysLive",
      "indices" : [ 3, 19 ],
      "id_str" : "754485",
      "id" : 754485
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MatthewKeysLive\/status\/700903255392460801\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/HB8jYvmytM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cboby7DUYAAtgNs.jpg",
      "id_str" : "700903253668552704",
      "id" : 700903253668552704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cboby7DUYAAtgNs.jpg",
      "sizes" : [ {
        "h" : 1204,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1204,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/HB8jYvmytM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701550344224972800",
  "text" : "RT @MatthewKeysLive: OMG https:\/\/t.co\/HB8jYvmytM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MatthewKeysLive\/status\/700903255392460801\/photo\/1",
        "indices" : [ 4, 27 ],
        "url" : "https:\/\/t.co\/HB8jYvmytM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cboby7DUYAAtgNs.jpg",
        "id_str" : "700903253668552704",
        "id" : 700903253668552704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cboby7DUYAAtgNs.jpg",
        "sizes" : [ {
          "h" : 1204,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1204,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 705,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/HB8jYvmytM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700903255392460801",
    "text" : "OMG https:\/\/t.co\/HB8jYvmytM",
    "id" : 700903255392460801,
    "created_at" : "2016-02-20 04:42:12 +0000",
    "user" : {
      "name" : "Matthew Keys",
      "screen_name" : "MatthewKeysLive",
      "protected" : false,
      "id_str" : "754485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726922892806483968\/7b6kuZ5n_normal.jpg",
      "id" : 754485,
      "verified" : false
    }
  },
  "id" : 701550344224972800,
  "created_at" : "2016-02-21 23:33:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/701164148265132032\/photo\/1",
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/NyBGjhtSmv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbsJE9lUAAET4i8.jpg",
      "id_str" : "701164147841433601",
      "id" : 701164147841433601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbsJE9lUAAET4i8.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 655
      } ],
      "display_url" : "pic.twitter.com\/NyBGjhtSmv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701164148265132032",
  "text" : "interface https:\/\/t.co\/NyBGjhtSmv",
  "id" : 701164148265132032,
  "created_at" : "2016-02-20 21:58:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701148757249818625",
  "text" : "what are your favorite music related twibber accounts?",
  "id" : 701148757249818625,
  "created_at" : "2016-02-20 20:57:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/700919953604513792\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/STz6H4i3mq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cboq-9lUAAAaObQ.jpg",
      "id_str" : "700919953180852224",
      "id" : 700919953180852224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cboq-9lUAAAaObQ.jpg",
      "sizes" : [ {
        "h" : 364,
        "resize" : "fit",
        "w" : 602
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 602
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 602
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 602
      } ],
      "display_url" : "pic.twitter.com\/STz6H4i3mq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700919953604513792",
  "text" : "beezy to the nth mag\nnth mag\nnth mag\nnth mag\nbeezy to the nth mag https:\/\/t.co\/STz6H4i3mq",
  "id" : 700919953604513792,
  "created_at" : "2016-02-20 05:48:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Rogers",
      "screen_name" : "polotek",
      "indices" : [ 3, 11 ],
      "id_str" : "20079975",
      "id" : 20079975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700893074432524290",
  "text" : "RT @polotek: We keep going over this in different ways, but the message is the same. White culture must actively divest from anti-blackness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "700862000771919872",
    "geo" : { },
    "id_str" : "700864349397618688",
    "in_reply_to_user_id" : 20079975,
    "text" : "We keep going over this in different ways, but the message is the same. White culture must actively divest from anti-blackness.",
    "id" : 700864349397618688,
    "in_reply_to_status_id" : 700862000771919872,
    "created_at" : "2016-02-20 02:07:36 +0000",
    "in_reply_to_screen_name" : "polotek",
    "in_reply_to_user_id_str" : "20079975",
    "user" : {
      "name" : "Marco Rogers",
      "screen_name" : "polotek",
      "protected" : false,
      "id_str" : "20079975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3603780451\/4775e8c65a9f6f70c824a5b689e6295c_normal.jpeg",
      "id" : 20079975,
      "verified" : false
    }
  },
  "id" : 700893074432524290,
  "created_at" : "2016-02-20 04:01:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700727959875813376",
  "geo" : { },
  "id_str" : "700728399807942656",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost  \"this is going on your permanent record\" - FBI",
  "id" : 700728399807942656,
  "in_reply_to_status_id" : 700727959875813376,
  "created_at" : "2016-02-19 17:07:24 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 0, 8 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "699928918946516996",
  "geo" : { },
  "id_str" : "700721210401779712",
  "in_reply_to_user_id" : 433715578,
  "text" : "@Gyselie this avatar does not identify as a man  -_-",
  "id" : 700721210401779712,
  "in_reply_to_status_id" : 699928918946516996,
  "created_at" : "2016-02-19 16:38:49 +0000",
  "in_reply_to_screen_name" : "Gyselie",
  "in_reply_to_user_id_str" : "433715578",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700690873554612224",
  "geo" : { },
  "id_str" : "700720297217908736",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost vaguely...?",
  "id" : 700720297217908736,
  "in_reply_to_status_id" : 700690873554612224,
  "created_at" : "2016-02-19 16:35:12 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700441646068936704",
  "geo" : { },
  "id_str" : "700442958210867200",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost i set self on fire",
  "id" : 700442958210867200,
  "in_reply_to_status_id" : 700441646068936704,
  "created_at" : "2016-02-18 22:13:09 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indiedev",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/YQoCZ7nEWb",
      "expanded_url" : "https:\/\/twitter.com\/ToddBailey\/status\/700389185946054656",
      "display_url" : "twitter.com\/ToddBailey\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700406465610145793",
  "text" : "multiplayer russian roulette game for NES zapper on a bespoke reprogrammable cartridge? pull the trigger!\n#indiedev https:\/\/t.co\/YQoCZ7nEWb",
  "id" : 700406465610145793,
  "created_at" : "2016-02-18 19:48:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/RKfOqr44eY",
      "expanded_url" : "http:\/\/nymag.com\/daily\/intelligencer\/2016\/02\/us-marshals-forcibly-collecting-student-debt.html",
      "display_url" : "nymag.com\/daily\/intellig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699810068477267968",
  "text" : "\/!\\ Gov contracts private debt collectors who use court orders to have federal marshalls arrest student loan debtors https:\/\/t.co\/RKfOqr44eY",
  "id" : 699810068477267968,
  "created_at" : "2016-02-17 04:18:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/HG5zVRmERG",
      "expanded_url" : "https:\/\/twitter.com\/soldair\/status\/699660299725631489",
      "display_url" : "twitter.com\/soldair\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699662207454326788",
  "text" : "It's a crime against nature, ergo humanity, to package jellied tomato paste in billions of baby brontosaurus scrota. https:\/\/t.co\/HG5zVRmERG",
  "id" : 699662207454326788,
  "created_at" : "2016-02-16 18:30:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699483954655526912",
  "text" : "mainstream american culture really is 1989 tho, even grammy knows shit ain't changed",
  "id" : 699483954655526912,
  "created_at" : "2016-02-16 06:42:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/699403664704679936\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/x9NIo4KmBR",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbTH6gtUEAAAT1T.jpg",
      "id_str" : "699403650175602688",
      "id" : 699403650175602688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbTH6gtUEAAAT1T.jpg",
      "sizes" : [ {
        "h" : 54,
        "resize" : "fit",
        "w" : 72
      }, {
        "h" : 54,
        "resize" : "fit",
        "w" : 72
      }, {
        "h" : 54,
        "resize" : "crop",
        "w" : 54
      }, {
        "h" : 54,
        "resize" : "fit",
        "w" : 72
      }, {
        "h" : 54,
        "resize" : "fit",
        "w" : 72
      } ],
      "display_url" : "pic.twitter.com\/x9NIo4KmBR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699403664704679936",
  "text" : "https:\/\/t.co\/x9NIo4KmBR",
  "id" : 699403664704679936,
  "created_at" : "2016-02-16 01:23:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GRAMMYs",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/1gU4Qi09tK",
      "expanded_url" : "https:\/\/folkstack.bandcamp.com\/track\/warp-01",
      "display_url" : "folkstack.bandcamp.com\/track\/warp-01"
    } ]
  },
  "geo" : { },
  "id_str" : "699402954088972290",
  "text" : "RT @folkstack: best psych fusion drive song of the year right here #GRAMMYs https:\/\/t.co\/1gU4Qi09tK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GRAMMYs",
        "indices" : [ 52, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/1gU4Qi09tK",
        "expanded_url" : "https:\/\/folkstack.bandcamp.com\/track\/warp-01",
        "display_url" : "folkstack.bandcamp.com\/track\/warp-01"
      } ]
    },
    "geo" : { },
    "id_str" : "699402851034857472",
    "text" : "best psych fusion drive song of the year right here #GRAMMYs https:\/\/t.co\/1gU4Qi09tK",
    "id" : 699402851034857472,
    "created_at" : "2016-02-16 01:20:08 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 699402954088972290,
  "created_at" : "2016-02-16 01:20:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/qzbjGlgOyu",
      "expanded_url" : "https:\/\/twitter.com\/TheHatGhost\/status\/699350442329780224",
      "display_url" : "twitter.com\/TheHatGhost\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699365432403230720",
  "text" : "better start writing hopeful hymnals to the music https:\/\/t.co\/qzbjGlgOyu",
  "id" : 699365432403230720,
  "created_at" : "2016-02-15 22:51:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/fx6uyfMQA3",
      "expanded_url" : "https:\/\/twitter.com\/BernieSanders\/status\/699232335531786240",
      "display_url" : "twitter.com\/BernieSanders\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699337657415917568",
  "text" : "And spends it on the oppression and enslavement of you and the world!  https:\/\/t.co\/fx6uyfMQA3",
  "id" : 699337657415917568,
  "created_at" : "2016-02-15 21:01:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/F30g7kQFqI",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/audio-recording-on-sunday-evening",
      "display_url" : "soundcloud.com\/johnnyscript\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699310035625598976",
  "text" : "am i playing the game or is the game playing me? https:\/\/t.co\/F30g7kQFqI",
  "id" : 699310035625598976,
  "created_at" : "2016-02-15 19:11:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698988949360881664",
  "text" : "NYT not even writing news re: post-Scalia, only stating the obvious in advance and waiting for parties to fill in the blanks.",
  "id" : 698988949360881664,
  "created_at" : "2016-02-14 21:55:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698916402397249536",
  "text" : "pretend it's not a thing",
  "id" : 698916402397249536,
  "created_at" : "2016-02-14 17:07:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/G4kjrpy4hg",
      "expanded_url" : "https:\/\/www.jacobinmag.com\/2016\/02\/bill-hillary-clinton-labor-union-yale-law\/",
      "display_url" : "jacobinmag.com\/2016\/02\/bill-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698713007736508416",
  "text" : "HA the clinton dynasty began \"with the crossing of a picket line.\"\n\nhttps:\/\/t.co\/G4kjrpy4hg",
  "id" : 698713007736508416,
  "created_at" : "2016-02-14 03:38:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698653212107145216",
  "text" : "Obama can nominate anybody to SCOTUS, should he nominate:",
  "id" : 698653212107145216,
  "created_at" : "2016-02-13 23:41:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "petition",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698652802784989184",
  "text" : "Johnny Honestly 4 Justice #petition",
  "id" : 698652802784989184,
  "created_at" : "2016-02-13 23:39:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698652703002460160",
  "text" : "Obama 4 Justice",
  "id" : 698652703002460160,
  "created_at" : "2016-02-13 23:39:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697974407197650944",
  "text" : "Live the your others best life.",
  "id" : 697974407197650944,
  "created_at" : "2016-02-12 02:44:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697495173618491393",
  "text" : "&lt;3 if you follow me on mute",
  "id" : 697495173618491393,
  "created_at" : "2016-02-10 18:59:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697493690575486976",
  "geo" : { },
  "id_str" : "697494894173007872",
  "in_reply_to_user_id" : 46961216,
  "text" : "Parties are weaker in smaller governments, at the city level.  That is the level to target, to choke out your totalitarian overlords.",
  "id" : 697494894173007872,
  "in_reply_to_status_id" : 697493690575486976,
  "created_at" : "2016-02-10 18:58:36 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "697493690575486976",
  "geo" : { },
  "id_str" : "697494160048148480",
  "in_reply_to_user_id" : 46961216,
  "text" : "Ever notice that candidates in US politics are mostly self-annointed, and self aggrandizing?  People don't choose who runs.  Game rigged.",
  "id" : 697494160048148480,
  "in_reply_to_status_id" : 697493690575486976,
  "created_at" : "2016-02-10 18:55:41 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697493690575486976",
  "text" : "US democracy is owned at the party level.  That is the crux, and that is what the powerful control.",
  "id" : 697493690575486976,
  "created_at" : "2016-02-10 18:53:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/697493302250065920\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/LkZNkEJ2Kr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3-dmzUEAECC3K.jpg",
      "id_str" : "697493301897728001",
      "id" : 697493301897728001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3-dmzUEAECC3K.jpg",
      "sizes" : [ {
        "h" : 75,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 43,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 1805
      } ],
      "display_url" : "pic.twitter.com\/LkZNkEJ2Kr"
    } ],
    "hashtags" : [ {
      "text" : "HEILCLINTON",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697493302250065920",
  "text" : "\"party officials\" hijacking US democracy\nis that some nazi shit?\n#HEILCLINTON https:\/\/t.co\/LkZNkEJ2Kr",
  "id" : 697493302250065920,
  "created_at" : "2016-02-10 18:52:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696884652598923265",
  "text" : "i narrative everything",
  "id" : 696884652598923265,
  "created_at" : "2016-02-09 02:33:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/uxCSPdSneY",
      "expanded_url" : "https:\/\/folkstack.bandcamp.com\/track\/hunger-joy-3",
      "display_url" : "folkstack.bandcamp.com\/track\/hunger-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696884625134596096",
  "text" : "that sound when you're fasting, and taking it slow, enduring the reward, pro rogue\n\nhttps:\/\/t.co\/uxCSPdSneY",
  "id" : 696884625134596096,
  "created_at" : "2016-02-09 02:33:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696868091632848896",
  "text" : "BORED JOHNNY MUST",
  "id" : 696868091632848896,
  "created_at" : "2016-02-09 01:27:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696868002487148545",
  "text" : "IS THERE A SPORTS DEFICIT BALL?",
  "id" : 696868002487148545,
  "created_at" : "2016-02-09 01:27:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/dH0cCQtvwd",
      "expanded_url" : "https:\/\/twitter.com\/folkstack\/status\/696865920841416704",
      "display_url" : "twitter.com\/folkstack\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696867265250091008",
  "text" : "HONEY https:\/\/t.co\/dH0cCQtvwd",
  "id" : 696867265250091008,
  "created_at" : "2016-02-09 01:24:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/Nt3m6bRRRS",
      "expanded_url" : "https:\/\/twitter.com\/folkstack\/status\/696866693730013184",
      "display_url" : "twitter.com\/folkstack\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696867224917827586",
  "text" : "POT https:\/\/t.co\/Nt3m6bRRRS",
  "id" : 696867224917827586,
  "created_at" : "2016-02-09 01:24:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/HBzaXLR6Lu",
      "expanded_url" : "https:\/\/twitter.com\/soldair\/status\/696396286577213440",
      "display_url" : "twitter.com\/soldair\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696413840699822080",
  "text" : "Klein-Bottling a RoggenBier and creating a Weltschmerzenspiel Elixer  https:\/\/t.co\/HBzaXLR6Lu",
  "id" : 696413840699822080,
  "created_at" : "2016-02-07 19:22:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/696394622025609216\/photo\/1",
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/9G9kr6ehvR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaoXN_qUAAA_MeK.jpg",
      "id_str" : "696394621576806400",
      "id" : 696394621576806400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaoXN_qUAAA_MeK.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9G9kr6ehvR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696394622025609216",
  "text" : "every hollywood ever https:\/\/t.co\/9G9kr6ehvR",
  "id" : 696394622025609216,
  "created_at" : "2016-02-07 18:06:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dey Cross",
      "screen_name" : "Deycrossis",
      "indices" : [ 3, 14 ],
      "id_str" : "4213440313",
      "id" : 4213440313
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Deycrossis\/status\/696240104809975808\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/DV3TuKNp7G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CamKrgNUcAAj8y1.png",
      "id_str" : "696240097390260224",
      "id" : 696240097390260224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CamKrgNUcAAj8y1.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 672
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 672
      } ],
      "display_url" : "pic.twitter.com\/DV3TuKNp7G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696371346234744832",
  "text" : "RT @Deycrossis: https:\/\/t.co\/DV3TuKNp7G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Deycrossis\/status\/696240104809975808\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/DV3TuKNp7G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CamKrgNUcAAj8y1.png",
        "id_str" : "696240097390260224",
        "id" : 696240097390260224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CamKrgNUcAAj8y1.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 672
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 672
        } ],
        "display_url" : "pic.twitter.com\/DV3TuKNp7G"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696240104809975808",
    "text" : "https:\/\/t.co\/DV3TuKNp7G",
    "id" : 696240104809975808,
    "created_at" : "2016-02-07 07:52:31 +0000",
    "user" : {
      "name" : "Dey Cross",
      "screen_name" : "Deycrossis",
      "protected" : false,
      "id_str" : "4213440313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664817156559798272\/O43Oeo_5_normal.jpg",
      "id" : 4213440313,
      "verified" : false
    }
  },
  "id" : 696371346234744832,
  "created_at" : "2016-02-07 16:34:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whisky Yogi",
      "screen_name" : "LewisCowper",
      "indices" : [ 0, 12 ],
      "id_str" : "433729178",
      "id" : 433729178
    }, {
      "name" : "Suz Hinton",
      "screen_name" : "noopkat",
      "indices" : [ 13, 21 ],
      "id_str" : "8942382",
      "id" : 8942382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696364986004803584",
  "geo" : { },
  "id_str" : "696370443180122112",
  "in_reply_to_user_id" : 433729178,
  "text" : "@LewisCowper @noopkat GP, let's flip it on \"management\"",
  "id" : 696370443180122112,
  "in_reply_to_status_id" : 696364986004803584,
  "created_at" : "2016-02-07 16:30:26 +0000",
  "in_reply_to_screen_name" : "LewisCowper",
  "in_reply_to_user_id_str" : "433729178",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696357127640653824",
  "geo" : { },
  "id_str" : "696369972885360640",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost find my tweet \"THE END\" and retweet it, adding what happened previously.  then I (or others) will rt yours with what happened",
  "id" : 696369972885360640,
  "in_reply_to_status_id" : 696357127640653824,
  "created_at" : "2016-02-07 16:28:34 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der Noffle",
      "screen_name" : "noffle",
      "indices" : [ 0, 7 ],
      "id_str" : "157503599",
      "id" : 157503599
    }, {
      "name" : "\u271E",
      "screen_name" : "Marina",
      "indices" : [ 8, 15 ],
      "id_str" : "34743057",
      "id" : 34743057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696099195124514816",
  "geo" : { },
  "id_str" : "696210951079489536",
  "in_reply_to_user_id" : 157503599,
  "text" : "@noffle @Marina  THE END",
  "id" : 696210951079489536,
  "in_reply_to_status_id" : 696099195124514816,
  "created_at" : "2016-02-07 05:56:40 +0000",
  "in_reply_to_screen_name" : "noffle",
  "in_reply_to_user_id_str" : "157503599",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696182784633647104",
  "geo" : { },
  "id_str" : "696210850101665792",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost lol... but it only works with retweeting, not replying",
  "id" : 696210850101665792,
  "in_reply_to_status_id" : 696182784633647104,
  "created_at" : "2016-02-07 05:56:16 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Noffle",
      "screen_name" : "noffle",
      "indices" : [ 0, 7 ],
      "id_str" : "157503599",
      "id" : 157503599
    }, {
      "name" : "\u271E",
      "screen_name" : "Marina",
      "indices" : [ 8, 15 ],
      "id_str" : "34743057",
      "id" : 34743057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696098775513718784",
  "in_reply_to_user_id" : 157503599,
  "text" : "@noffle @marina YOU DIDN'T DO IT RIGHT YOU WERE SUPPOSED TO RT THE END NOT REPLY, RTFM",
  "id" : 696098775513718784,
  "created_at" : "2016-02-06 22:30:55 +0000",
  "in_reply_to_screen_name" : "noffle",
  "in_reply_to_user_id_str" : "157503599",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/29mSu792nu",
      "expanded_url" : "https:\/\/twitter.com\/noffle\/status\/696094523873632256",
      "display_url" : "twitter.com\/noffle\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696098314069024768",
  "text" : "\"WHAT PROVIDENCE THESE SHIPS?  THEY COME, THEY OFFLOAD, THEY LEAVE WITH OUR AIR, AND RETURN SO FULL OF SHIT.\" https:\/\/t.co\/29mSu792nu",
  "id" : 696098314069024768,
  "created_at" : "2016-02-06 22:29:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Noffle",
      "screen_name" : "noffle",
      "indices" : [ 3, 10 ],
      "id_str" : "157503599",
      "id" : 157503599
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 12, 25 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696097016242278400",
  "text" : "RT @noffle: @johnnyscript AND IT TURNED OUT IT WAS EARTH ALL ALONG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "696086058337849344",
    "geo" : { },
    "id_str" : "696090050816159744",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript AND IT TURNED OUT IT WAS EARTH ALL ALONG",
    "id" : 696090050816159744,
    "in_reply_to_status_id" : 696086058337849344,
    "created_at" : "2016-02-06 21:56:15 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Der Noffle",
      "screen_name" : "noffle",
      "protected" : false,
      "id_str" : "157503599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604703830891102208\/Xfkg9Wlp_normal.png",
      "id" : 157503599,
      "verified" : false
    }
  },
  "id" : 696097016242278400,
  "created_at" : "2016-02-06 22:23:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696096970960539649",
  "text" : "RT @marinakukso: @johnnyscript she died",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "696086058337849344",
    "geo" : { },
    "id_str" : "696090611183546368",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript she died",
    "id" : 696090611183546368,
    "in_reply_to_status_id" : 696086058337849344,
    "created_at" : "2016-02-06 21:58:29 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 696096970960539649,
  "created_at" : "2016-02-06 22:23:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/IHRMwIQ7QU",
      "expanded_url" : "https:\/\/twitter.com\/marinakukso\/status\/696090611183546368",
      "display_url" : "twitter.com\/marinakukso\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696096949137616896",
  "text" : "Enemies vanquished, rule overturned. \nPeace finally.\nShe breathed and just breathed, unaware of an unlit gas burner. https:\/\/t.co\/IHRMwIQ7QU",
  "id" : 696096949137616896,
  "created_at" : "2016-02-06 22:23:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/gfazwC7nIU",
      "expanded_url" : "https:\/\/twitter.com\/noffle\/status\/696090050816159744",
      "display_url" : "twitter.com\/noffle\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696092032918376448",
  "text" : "THE LAST HOMO-GIGANTOIDS SAT THERE, STILL, SURROUNDED BY FECES, PONDERING THAT THEY HAD NOWHERE \"ELSE\" TO SHIT. https:\/\/t.co\/gfazwC7nIU",
  "id" : 696092032918376448,
  "created_at" : "2016-02-06 22:04:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696077204426350596",
  "geo" : { },
  "id_str" : "696086458495414272",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski  see, you know exactly what I mean. Let us not spread the tyranny that controls us, but build locally up and out of tyranny.",
  "id" : 696086458495414272,
  "in_reply_to_status_id" : 696077204426350596,
  "created_at" : "2016-02-06 21:41:59 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696086058337849344",
  "text" : "THE END",
  "id" : 696086058337849344,
  "created_at" : "2016-02-06 21:40:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696086014524141568",
  "text" : "I FINALLY REALIZED WHAT TWITTER IS FOR.  \n\nI WILL TWEET THE END OF A STORY, YOU RETWEET WITH WHAT HAPPENED PREVIOUSLY.",
  "id" : 696086014524141568,
  "created_at" : "2016-02-06 21:40:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696071956102164480",
  "geo" : { },
  "id_str" : "696073182529204224",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski  which, to get back to the point, is definitely not the kind of thinking we want in our local politics",
  "id" : 696073182529204224,
  "in_reply_to_status_id" : 696071956102164480,
  "created_at" : "2016-02-06 20:49:13 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696071956102164480",
  "geo" : { },
  "id_str" : "696072383732408320",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski exactly, a person identifying with the totalitarian control of state backed capitalist hegemony, hypothesized just as such",
  "id" : 696072383732408320,
  "in_reply_to_status_id" : 696071956102164480,
  "created_at" : "2016-02-06 20:46:03 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696071247092797440",
  "geo" : { },
  "id_str" : "696071987710431232",
  "in_reply_to_user_id" : 46961216,
  "text" : "@michalmigurski  it is ironic, and patronizing because really what people want is resources and the liberty to use them, not our data plans.",
  "id" : 696071987710431232,
  "in_reply_to_status_id" : 696071247092797440,
  "created_at" : "2016-02-06 20:44:28 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696069810950549504",
  "geo" : { },
  "id_str" : "696071247092797440",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski  it says \"they\" want what \"we\" have. we have is ability to control with conditions what they can get, if only they join us.",
  "id" : 696071247092797440,
  "in_reply_to_status_id" : 696069810950549504,
  "created_at" : "2016-02-06 20:41:32 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696063576176349184",
  "text" : "you shouldn't the need the police to starting killing people you identify with before you start acting directly against your military police",
  "id" : 696063576176349184,
  "created_at" : "2016-02-06 20:11:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    }, {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 16, 22 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696058038055141376",
  "geo" : { },
  "id_str" : "696063025581682688",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski @ixley uuhhhhh that Barnett and his core gap smell like totalitarian shit breh",
  "id" : 696063025581682688,
  "in_reply_to_status_id" : 696058038055141376,
  "created_at" : "2016-02-06 20:08:52 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696059934367059969",
  "text" : "equality is not mainstream",
  "id" : 696059934367059969,
  "created_at" : "2016-02-06 19:56:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    }, {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 16, 22 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696058038055141376",
  "geo" : { },
  "id_str" : "696059734848241664",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski @ixley  Plus we know that equality is not mainstream, so poof goes any argument about actual bridges that integrate society.",
  "id" : 696059734848241664,
  "in_reply_to_status_id" : 696058038055141376,
  "created_at" : "2016-02-06 19:55:47 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    }, {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 16, 22 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696058038055141376",
  "geo" : { },
  "id_str" : "696059273575424000",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski @ixley  This is a trick of exclusivity, and a con of deciding what is mainstream.",
  "id" : 696059273575424000,
  "in_reply_to_status_id" : 696058038055141376,
  "created_at" : "2016-02-06 19:53:57 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    }, {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 16, 22 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696056649212149760",
  "geo" : { },
  "id_str" : "696058225976692736",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski @ixley  the real point is that platitudes in rhetoric is the sign of skewed interested or lack of capability, take yr pick",
  "id" : 696058225976692736,
  "in_reply_to_status_id" : 696056649212149760,
  "created_at" : "2016-02-06 19:49:47 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    }, {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 16, 22 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696056649212149760",
  "geo" : { },
  "id_str" : "696057882408660992",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski @ixley how about that school to prison pipeline!  that digital divide is education, and we know public ed's grade is an F...",
  "id" : 696057882408660992,
  "in_reply_to_status_id" : 696056649212149760,
  "created_at" : "2016-02-06 19:48:25 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    }, {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 16, 22 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696056649212149760",
  "geo" : { },
  "id_str" : "696057358372343808",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski @ixley  the conditions of doing it like the people who make these decisions, a weekly elected group of capitalists?",
  "id" : 696057358372343808,
  "in_reply_to_status_id" : 696056649212149760,
  "created_at" : "2016-02-06 19:46:21 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    }, {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 16, 22 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696055734899863552",
  "geo" : { },
  "id_str" : "696056515849900033",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski @ixley  the metaphor of the bridge to people who can't travel says come be with us. But that contract is full of conditions.",
  "id" : 696056515849900033,
  "in_reply_to_status_id" : 696055734899863552,
  "created_at" : "2016-02-06 19:43:00 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/Ll8SnZiHAZ",
      "expanded_url" : "https:\/\/twitter.com\/grayamelia\/status\/696054711770677248",
      "display_url" : "twitter.com\/grayamelia\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696056012390817792",
  "text" : "*reveals tentacles by pulling off paw print mittens* https:\/\/t.co\/Ll8SnZiHAZ",
  "id" : 696056012390817792,
  "created_at" : "2016-02-06 19:41:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michal Migurski",
      "screen_name" : "michalmigurski",
      "indices" : [ 0, 15 ],
      "id_str" : "93046641",
      "id" : 93046641
    }, {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 16, 22 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696053988798496768",
  "geo" : { },
  "id_str" : "696055401104568320",
  "in_reply_to_user_id" : 93046641,
  "text" : "@michalmigurski @ixley precisely, which is weak, patronizing, political engineering, the same that created the digital divide; ergo bridge.",
  "id" : 696055401104568320,
  "in_reply_to_status_id" : 696053988798496768,
  "created_at" : "2016-02-06 19:38:34 +0000",
  "in_reply_to_screen_name" : "michalmigurski",
  "in_reply_to_user_id_str" : "93046641",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696053835907792896",
  "geo" : { },
  "id_str" : "696053941671370753",
  "in_reply_to_user_id" : 46961216,
  "text" : "who specs these things anyway?",
  "id" : 696053941671370753,
  "in_reply_to_status_id" : 696053835907792896,
  "created_at" : "2016-02-06 19:32:46 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696053835907792896",
  "text" : "the big browsers force us to use big tech backends for our data by not giving developers good client side file storage options",
  "id" : 696053835907792896,
  "created_at" : "2016-02-06 19:32:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696050226184892416",
  "text" : "troll your local government, even when they are trying to do good, cuz none of our govs are trying hard enough to not be patsy with the rich",
  "id" : 696050226184892416,
  "created_at" : "2016-02-06 19:18:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff French",
      "screen_name" : "ixley",
      "indices" : [ 0, 6 ],
      "id_str" : "15760117",
      "id" : 15760117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "citycampoak",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "696035191836413952",
  "geo" : { },
  "id_str" : "696048946670497793",
  "in_reply_to_user_id" : 15760117,
  "text" : "@ixley It's rhetoric when you twist logic w\/ language. \"acting upon\" twisted logic is to build a bridge that can't hold weight. #citycampoak",
  "id" : 696048946670497793,
  "in_reply_to_status_id" : 696035191836413952,
  "created_at" : "2016-02-06 19:12:55 +0000",
  "in_reply_to_screen_name" : "ixley",
  "in_reply_to_user_id_str" : "15760117",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/vKtXc6xzRo",
      "expanded_url" : "https:\/\/twitter.com\/ixley\/status\/696022289129689088",
      "display_url" : "twitter.com\/ixley\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696032110444871680",
  "text" : "this is some dumb rhetoric\n\nit is like saying, let's build a highway to the land where people can't afford cars. https:\/\/t.co\/vKtXc6xzRo",
  "id" : 696032110444871680,
  "created_at" : "2016-02-06 18:06:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0455ynd\u03B9cal\u03B9\u0455\u0442",
      "screen_name" : "syndicalisms",
      "indices" : [ 3, 16 ],
      "id_str" : "974735124",
      "id" : 974735124
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/7eQua0XMMu",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/10da555e-ab0a-4a01-8fb5-cc31f895bc34",
      "display_url" : "amp.twimg.com\/v\/10da555e-ab0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695738630774484993",
  "text" : "RT @syndicalisms: Yesterday protesters in Peru &amp; Chile took to the streets against the Trans-Pacific Partnership (#TPP) trade deal https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 100, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/7eQua0XMMu",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/10da555e-ab0a-4a01-8fb5-cc31f895bc34",
        "display_url" : "amp.twimg.com\/v\/10da555e-ab0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695733818267979776",
    "text" : "Yesterday protesters in Peru &amp; Chile took to the streets against the Trans-Pacific Partnership (#TPP) trade deal https:\/\/t.co\/7eQua0XMMu",
    "id" : 695733818267979776,
    "created_at" : "2016-02-05 22:20:43 +0000",
    "user" : {
      "name" : "\u0455ynd\u03B9cal\u03B9\u0455\u0442",
      "screen_name" : "syndicalisms",
      "protected" : false,
      "id_str" : "974735124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261575308709\/c9c1971afbf7db1f9016fb6f89db8213_normal.jpeg",
      "id" : 974735124,
      "verified" : false
    }
  },
  "id" : 695738630774484993,
  "created_at" : "2016-02-05 22:39:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695736283201560576",
  "text" : "please stop saying \"nice\" and \"looking forward\"",
  "id" : 695736283201560576,
  "created_at" : "2016-02-05 22:30:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695736218990936064",
  "text" : "I'm Looking Forward To That dot trademark",
  "id" : 695736218990936064,
  "created_at" : "2016-02-05 22:30:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695688299713683456",
  "text" : "when we say capitalism sucks, we mean the government",
  "id" : 695688299713683456,
  "created_at" : "2016-02-05 19:19:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695684826582528001",
  "text" : "I define anarchy as \"desperate survival in [whatever you want to call our current totalitarian regime]\"\n\nNow you're all anarchists!",
  "id" : 695684826582528001,
  "created_at" : "2016-02-05 19:06:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CTU",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695454243180797952",
  "text" : "Whenever teachers protest all I can think is about how they only march for their paychecks, never the gross failure of public schools.  #CTU",
  "id" : 695454243180797952,
  "created_at" : "2016-02-05 03:49:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anarchitecture",
      "indices" : [ 10, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695438531859083265",
  "geo" : { },
  "id_str" : "695447780173574146",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack #anarchitecture",
  "id" : 695447780173574146,
  "in_reply_to_status_id" : 695438531859083265,
  "created_at" : "2016-02-05 03:24:06 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/tSuRHshWXa",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/611226383054843904",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695419960386912257",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross on formal shorthands in standard https:\/\/t.co\/tSuRHshWXa",
  "id" : 695419960386912257,
  "created_at" : "2016-02-05 01:33:33 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/695341491271528449\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/YCDLZVF0NO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZZZt8VAAASdoG.jpg",
      "id_str" : "695341490839552000",
      "id" : 695341490839552000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZZZt8VAAASdoG.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 173
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 173
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 173
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 173
      } ],
      "display_url" : "pic.twitter.com\/YCDLZVF0NO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695341491271528449",
  "text" : "\"logarithms\"; pixels on canvas; $100 https:\/\/t.co\/YCDLZVF0NO",
  "id" : 695341491271528449,
  "created_at" : "2016-02-04 20:21:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/695340179863662593\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Iq6iCtTKk0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZYNX8VAAE1aWa.jpg",
      "id_str" : "695340179263913985",
      "id" : 695340179263913985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZYNX8VAAE1aWa.jpg",
      "sizes" : [ {
        "h" : 308,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 1904
      } ],
      "display_url" : "pic.twitter.com\/Iq6iCtTKk0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695340179863662593",
  "text" : "https:\/\/t.co\/Iq6iCtTKk0",
  "id" : 695340179863662593,
  "created_at" : "2016-02-04 20:16:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "695124309023391744",
  "geo" : { },
  "id_str" : "695128198741241856",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha doods doo doh don't doods?",
  "id" : 695128198741241856,
  "in_reply_to_status_id" : 695124309023391744,
  "created_at" : "2016-02-04 06:14:12 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695095278253137921",
  "text" : "May China own all my debts.",
  "id" : 695095278253137921,
  "created_at" : "2016-02-04 04:03:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/OwPNQ3UDb7",
      "expanded_url" : "https:\/\/twitter.com\/rgb_alpha\/status\/694708232325976064",
      "display_url" : "twitter.com\/rgb_alpha\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695060313952034821",
  "text" : "lol acting https:\/\/t.co\/OwPNQ3UDb7",
  "id" : 695060313952034821,
  "created_at" : "2016-02-04 01:44:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/oTIwiUnOTn",
      "expanded_url" : "http:\/\/studio.substack.net\/wave_pond_a_pond_of_waves_",
      "display_url" : "studio.substack.net\/wave_pond_a_po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695055050100445184",
  "text" : "have a lil sum n before the storm https:\/\/t.co\/oTIwiUnOTn",
  "id" : 695055050100445184,
  "created_at" : "2016-02-04 01:23:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 28, 38 ],
      "id_str" : "224828427",
      "id" : 224828427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/hsnPaReXoY",
      "expanded_url" : "https:\/\/github.com\/substack\/music-for-hire",
      "display_url" : "github.com\/substack\/music\u2026"
    }, {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/2JiFnf8WtU",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/694982892204589056",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695008185908748288",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack represents me and @folkstack https:\/\/t.co\/hsnPaReXoY https:\/\/t.co\/2JiFnf8WtU",
  "id" : 695008185908748288,
  "created_at" : "2016-02-03 22:17:18 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694981329683771392",
  "text" : "OUTSIDERS START YOUR FIRES",
  "id" : 694981329683771392,
  "created_at" : "2016-02-03 20:30:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694980269980266497",
  "text" : "should I post all 20 minutes of this live code remux or a sample?",
  "id" : 694980269980266497,
  "created_at" : "2016-02-03 20:26:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    }, {
      "name" : "mask magazine",
      "screen_name" : "mask_mag",
      "indices" : [ 49, 58 ],
      "id_str" : "1680362934",
      "id" : 1680362934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "matchmaking",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694979006320373760",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked imo you should get political with @mask_mag  #matchmaking",
  "id" : 694979006320373760,
  "created_at" : "2016-02-03 20:21:21 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694977588154888192",
  "text" : "p sure soundcloud hires fake twitter accounts",
  "id" : 694977588154888192,
  "created_at" : "2016-02-03 20:15:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/F30g7kQFqI",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/audio-recording-on-sunday-evening",
      "display_url" : "soundcloud.com\/johnnyscript\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694977289356865538",
  "text" : "I post mere tidbits to soundcloud, here's anoder https:\/\/t.co\/F30g7kQFqI",
  "id" : 694977289356865538,
  "created_at" : "2016-02-03 20:14:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694976784358506500",
  "text" : "watch thisp face",
  "id" : 694976784358506500,
  "created_at" : "2016-02-03 20:12:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 26, 35 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/dXT7xcBDc7",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/live-code-session",
      "display_url" : "soundcloud.com\/folkstack\/live\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694976190130434049",
  "text" : "live coding for days with @substack this lofi recording was yesterday's chilled out nightcap https:\/\/t.co\/dXT7xcBDc7",
  "id" : 694976190130434049,
  "created_at" : "2016-02-03 20:10:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 7, 16 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694974596269735936",
  "text" : "me and @substack are launching a fleet of ships",
  "id" : 694974596269735936,
  "created_at" : "2016-02-03 20:03:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 0, 8 ],
      "id_str" : "185744472",
      "id" : 185744472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694419502126096384",
  "geo" : { },
  "id_str" : "694578141310750720",
  "in_reply_to_user_id" : 185744472,
  "text" : "@Cabbibo  you make dat???",
  "id" : 694578141310750720,
  "in_reply_to_status_id" : 694419502126096384,
  "created_at" : "2016-02-02 17:48:28 +0000",
  "in_reply_to_screen_name" : "Cabbibo",
  "in_reply_to_user_id_str" : "185744472",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694565811764068352",
  "geo" : { },
  "id_str" : "694577868764884992",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  please depart academia asap",
  "id" : 694577868764884992,
  "in_reply_to_status_id" : 694565811764068352,
  "created_at" : "2016-02-02 17:47:23 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cyberwizard",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/y4f6IEcetT",
      "expanded_url" : "https:\/\/twitter.com\/girlziplocked\/status\/694252702478524417",
      "display_url" : "twitter.com\/girlziplocked\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694278734992556033",
  "text" : "#cyberwizard https:\/\/t.co\/y4f6IEcetT",
  "id" : 694278734992556033,
  "created_at" : "2016-02-01 21:58:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 3, 17 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694278646580686848",
  "text" : "RT @girlziplocked: The government is just a tool. Under democratic control, poor geniuses would have all the power and that horrifies rich \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694253615792459776",
    "text" : "The government is just a tool. Under democratic control, poor geniuses would have all the power and that horrifies rich idiots.",
    "id" : 694253615792459776,
    "created_at" : "2016-02-01 20:18:55 +0000",
    "user" : {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "protected" : false,
      "id_str" : "20221325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497445169797414913\/rvn1M8zY_normal.jpeg",
      "id" : 20221325,
      "verified" : false
    }
  },
  "id" : 694278646580686848,
  "created_at" : "2016-02-01 21:58:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/o7oInHR4rS",
      "expanded_url" : "https:\/\/twitter.com\/dick_nixon\/status\/693985347047399424",
      "display_url" : "twitter.com\/dick_nixon\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694213221092208642",
  "text" : "tricky dicky https:\/\/t.co\/o7oInHR4rS",
  "id" : 694213221092208642,
  "created_at" : "2016-02-01 17:38:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick",
      "screen_name" : "Vectorpark",
      "indices" : [ 0, 11 ],
      "id_str" : "35604279",
      "id" : 35604279
    }, {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 12, 20 ],
      "id_str" : "185744472",
      "id" : 185744472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "694066946338332672",
  "geo" : { },
  "id_str" : "694207254069817344",
  "in_reply_to_user_id" : 35604279,
  "text" : "@Vectorpark @Cabbibo from the movie \"The Canadian Matrix\"",
  "id" : 694207254069817344,
  "in_reply_to_status_id" : 694066946338332672,
  "created_at" : "2016-02-01 17:14:41 +0000",
  "in_reply_to_screen_name" : "Vectorpark",
  "in_reply_to_user_id_str" : "35604279",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]