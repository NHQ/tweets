Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494886490015416320",
  "text" : "F'sha 256",
  "id" : 494886490015416320,
  "created_at" : "2014-07-31 16:45:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494886233487581185",
  "text" : "SELL CORN!!!\nBUY 592e56f1cf4c106b9c1b92dcc9179e69b2b132012d0df4797c363d3144bf4f07!!!",
  "id" : 494886233487581185,
  "created_at" : "2014-07-31 16:44:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Tweetserve",
      "screen_name" : "TheTweetserve",
      "indices" : [ 1, 15 ],
      "id_str" : "2300627557",
      "id" : 2300627557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492850318707679232",
  "geo" : { },
  "id_str" : "494881102520016897",
  "in_reply_to_user_id" : 46961216,
  "text" : ".@TheTweetserve RTd this.  Me n the bots be bottomless.",
  "id" : 494881102520016897,
  "in_reply_to_status_id" : 492850318707679232,
  "created_at" : "2014-07-31 16:23:43 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494880132419428352",
  "text" : "I'm currently between computers.",
  "id" : 494880132419428352,
  "created_at" : "2014-07-31 16:19:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 13, 25 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 26, 38 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 39, 48 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/zEup37uWnF",
      "expanded_url" : "http:\/\/rhizome.org\/editorial\/2013\/sep\/23\/impossible-music-black-midi\/",
      "display_url" : "rhizome.org\/editorial\/2013\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "494295355823886336",
  "geo" : { },
  "id_str" : "494322234622627840",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost @dominictarr @marinakukso @sudoroom \n\nThe black midi of player piano rolls?\n\nhttp:\/\/t.co\/zEup37uWnF",
  "id" : 494322234622627840,
  "in_reply_to_status_id" : 494295355823886336,
  "created_at" : "2014-07-30 03:22:59 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494305940707876864",
  "geo" : { },
  "id_str" : "494321229336035329",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  that's where the mothership gonna land?",
  "id" : 494321229336035329,
  "in_reply_to_status_id" : 494305940707876864,
  "created_at" : "2014-07-30 03:18:59 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 17, 29 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 30, 43 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 44, 53 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/6uVZkTRr6Q",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_sUeGC-8dyk",
      "display_url" : "youtube.com\/watch?v=_sUeGC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494291897494405120",
  "text" : "RT @marinakukso: @dominictarr @johnnyscript @sudoroom https:\/\/t.co\/6uVZkTRr6Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dominic Tarr",
        "screen_name" : "dominictarr",
        "indices" : [ 0, 12 ],
        "id_str" : "136933779",
        "id" : 136933779
      }, {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 13, 26 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "Sudo Room",
        "screen_name" : "sudoroom",
        "indices" : [ 27, 36 ],
        "id_str" : "411733308",
        "id" : 411733308
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/6uVZkTRr6Q",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_sUeGC-8dyk",
        "display_url" : "youtube.com\/watch?v=_sUeGC\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "494275499489632257",
    "geo" : { },
    "id_str" : "494279098626088960",
    "in_reply_to_user_id" : 136933779,
    "text" : "@dominictarr @johnnyscript @sudoroom https:\/\/t.co\/6uVZkTRr6Q",
    "id" : 494279098626088960,
    "in_reply_to_status_id" : 494275499489632257,
    "created_at" : "2014-07-30 00:31:35 +0000",
    "in_reply_to_screen_name" : "dominictarr",
    "in_reply_to_user_id_str" : "136933779",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 494291897494405120,
  "created_at" : "2014-07-30 01:22:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 17, 29 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 30, 43 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 44, 53 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/9n4qTAfjAR",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=c2JChnwv2Ws",
      "display_url" : "youtube.com\/watch?v=c2JChn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494288743482667008",
  "text" : "RT @dominictarr: @marinakukso @johnnyscript @sudoroom https:\/\/t.co\/9n4qTAfjAR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marina Kukso",
        "screen_name" : "marinakukso",
        "indices" : [ 0, 12 ],
        "id_str" : "1484011428",
        "id" : 1484011428
      }, {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 13, 26 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "Sudo Room",
        "screen_name" : "sudoroom",
        "indices" : [ 27, 36 ],
        "id_str" : "411733308",
        "id" : 411733308
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/9n4qTAfjAR",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=c2JChnwv2Ws",
        "display_url" : "youtube.com\/watch?v=c2JChn\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "494249495362691074",
    "geo" : { },
    "id_str" : "494272407834595328",
    "in_reply_to_user_id" : 1484011428,
    "text" : "@marinakukso @johnnyscript @sudoroom https:\/\/t.co\/9n4qTAfjAR",
    "id" : 494272407834595328,
    "in_reply_to_status_id" : 494249495362691074,
    "created_at" : "2014-07-30 00:04:59 +0000",
    "in_reply_to_screen_name" : "marinakukso",
    "in_reply_to_user_id_str" : "1484011428",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712569197126160384\/nvnXBzt-_normal.jpg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 494288743482667008,
  "created_at" : "2014-07-30 01:09:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 31, 43 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 44, 53 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/jtqX9cvo7q",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=X1jsU1lBZMc",
      "display_url" : "youtube.com\/watch?v=X1jsU1\u2026"
    }, {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/kuWmXwtvqz",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Ht96HJ01SE4&list=PL1C9D69FB4157393B",
      "display_url" : "youtube.com\/watch?v=Ht96HJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494288670027837440",
  "text" : "RT @marinakukso: @johnnyscript @dominictarr @sudoroom https:\/\/t.co\/jtqX9cvo7q &amp; https:\/\/t.co\/kuWmXwtvqz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "Dominic Tarr",
        "screen_name" : "dominictarr",
        "indices" : [ 14, 26 ],
        "id_str" : "136933779",
        "id" : 136933779
      }, {
        "name" : "Sudo Room",
        "screen_name" : "sudoroom",
        "indices" : [ 27, 36 ],
        "id_str" : "411733308",
        "id" : 411733308
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/jtqX9cvo7q",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=X1jsU1lBZMc",
        "display_url" : "youtube.com\/watch?v=X1jsU1\u2026"
      }, {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/kuWmXwtvqz",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Ht96HJ01SE4&list=PL1C9D69FB4157393B",
        "display_url" : "youtube.com\/watch?v=Ht96HJ\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "494247653002076161",
    "geo" : { },
    "id_str" : "494249495362691074",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript @dominictarr @sudoroom https:\/\/t.co\/jtqX9cvo7q &amp; https:\/\/t.co\/kuWmXwtvqz",
    "id" : 494249495362691074,
    "in_reply_to_status_id" : 494247653002076161,
    "created_at" : "2014-07-29 22:33:57 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 494288670027837440,
  "created_at" : "2014-07-30 01:09:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 1, 13 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 15, 27 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 28, 41 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 42, 51 ],
      "id_str" : "411733308",
      "id" : 411733308
    }, {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 78, 90 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/g6pCVkkNv0",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=lQRnH02FPE0",
      "display_url" : "youtube.com\/watch?v=lQRnH0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494284952708460545",
  "text" : "\"@dominictarr: @marinakukso @johnnyscript @sudoroom https:\/\/t.co\/g6pCVkkNv0\". @TheHatGhost",
  "id" : 494284952708460545,
  "created_at" : "2014-07-30 00:54:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/al2Myxx5Q6",
      "expanded_url" : "http:\/\/youtu.be\/_RyodnisVvU",
      "display_url" : "youtu.be\/_RyodnisVvU"
    } ]
  },
  "geo" : { },
  "id_str" : "494248769437704192",
  "text" : "This is the cutest robot \n\nhttp:\/\/t.co\/al2Myxx5Q6",
  "id" : 494248769437704192,
  "created_at" : "2014-07-29 22:31:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 13, 25 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 26, 35 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/al2Myxx5Q6",
      "expanded_url" : "http:\/\/youtu.be\/_RyodnisVvU",
      "display_url" : "youtu.be\/_RyodnisVvU"
    } ]
  },
  "in_reply_to_status_id_str" : "494236460979978240",
  "geo" : { },
  "id_str" : "494247653002076161",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @marinakukso @sudoroom \n\nhttp:\/\/t.co\/al2Myxx5Q6",
  "id" : 494247653002076161,
  "in_reply_to_status_id" : 494236460979978240,
  "created_at" : "2014-07-29 22:26:37 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 33, 42 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/494205463336988672\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/Wd4yGoGLzE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtvFPE_CQAAUGz0.jpg",
      "id_str" : "494205446954041344",
      "id" : 494205446954041344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtvFPE_CQAAUGz0.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Wd4yGoGLzE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494205463336988672",
  "text" : "Another view of the Robot Arm of @sudoroom a perfect mount for muh bass gong http:\/\/t.co\/Wd4yGoGLzE",
  "id" : 494205463336988672,
  "created_at" : "2014-07-29 19:38:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/494204140038287360\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/C1U8LmgbdP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtvECUJCMAAop4B.jpg",
      "id_str" : "494204128172584960",
      "id" : 494204128172584960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtvECUJCMAAop4B.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C1U8LmgbdP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494204140038287360",
  "text" : "DO NOT ENTER ROBOT WORK AREA!!!  U AM TOO CLOSE FOR YOUR OWN COMFORTS!!! http:\/\/t.co\/C1U8LmgbdP",
  "id" : 494204140038287360,
  "created_at" : "2014-07-29 19:33:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/494203707228049410\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/NBFzsipViJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtvDpENCcAEdRPx.jpg",
      "id_str" : "494203694397681665",
      "id" : 494203694397681665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtvDpENCcAEdRPx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/NBFzsipViJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494203707228049410",
  "text" : "The new robot arm at sudoroom!  Pictured here hoisting your god monkey hand's bass drum. http:\/\/t.co\/NBFzsipViJ",
  "id" : 494203707228049410,
  "created_at" : "2014-07-29 19:32:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 1, 10 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493913224966701059",
  "text" : "\"@substack: a burrito is neither a liquid nor a gel\". Plasma",
  "id" : 493913224966701059,
  "created_at" : "2014-07-29 00:17:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493912505089921024",
  "text" : "I PROVED NP IS NOT DIFFICULT\nITS EASY\nNP BRUH",
  "id" : 493912505089921024,
  "created_at" : "2014-07-29 00:14:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492911091194687488",
  "text" : "SELL FIAT CORN!!!\nBUY CRYPTO CORN!!!",
  "id" : 492911091194687488,
  "created_at" : "2014-07-26 05:55:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492850318707679232",
  "text" : "RT if u ain't been wearing pants",
  "id" : 492850318707679232,
  "created_at" : "2014-07-26 01:54:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492718325231652864",
  "text" : "The whereabouts of my sunglasses is extremely debugging.",
  "id" : 492718325231652864,
  "created_at" : "2014-07-25 17:09:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RATCHETT TRAXXX",
      "screen_name" : "TTTRAXXX",
      "indices" : [ 0, 9 ],
      "id_str" : "2194426460",
      "id" : 2194426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492701408299204608",
  "geo" : { },
  "id_str" : "492703741770866688",
  "in_reply_to_user_id" : 2194426460,
  "text" : "@TTTRAXXX like as if house wasn't borun in the Chi",
  "id" : 492703741770866688,
  "in_reply_to_status_id" : 492701408299204608,
  "created_at" : "2014-07-25 16:11:40 +0000",
  "in_reply_to_screen_name" : "TTTRAXXX",
  "in_reply_to_user_id_str" : "2194426460",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492702593173311488",
  "text" : "You n me is both kinds of geniuses\nWhere n is everyone &amp;&amp;",
  "id" : 492702593173311488,
  "created_at" : "2014-07-25 16:07:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RATCHETT TRAXXX",
      "screen_name" : "TTTRAXXX",
      "indices" : [ 10, 19 ],
      "id_str" : "2194426460",
      "id" : 2194426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492700696550993920",
  "text" : "PREACH IT @TTTRAXXX",
  "id" : 492700696550993920,
  "created_at" : "2014-07-25 15:59:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492699738056048640",
  "text" : "Wutwut  \"@JohnnySackRaps: Tom Hardy is the next Mad Max... So I guess it's gunna be called Miffed Maximillion.\"",
  "id" : 492699738056048640,
  "created_at" : "2014-07-25 15:55:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bear",
      "screen_name" : "TheoryBear",
      "indices" : [ 3, 14 ],
      "id_str" : "2432520866",
      "id" : 2432520866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492682108859469825",
  "text" : "RT @TheoryBear: I have not tweeted in a while. Does my tweet silence mean I am not a bear?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "490308441898893312",
    "text" : "I have not tweeted in a while. Does my tweet silence mean I am not a bear?",
    "id" : 490308441898893312,
    "created_at" : "2014-07-19 01:33:36 +0000",
    "user" : {
      "name" : "Bear",
      "screen_name" : "TheoryBear",
      "protected" : false,
      "id_str" : "2432520866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453260623925637120\/qmkoDfx-_normal.jpeg",
      "id" : 2432520866,
      "verified" : false
    }
  },
  "id" : 492682108859469825,
  "created_at" : "2014-07-25 14:45:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 1, 15 ],
      "id_str" : "379919160",
      "id" : 379919160
    }, {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 17, 24 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 25, 38 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492681168165154816",
  "text" : "\"@MikolaLysenko: @tmpvar @johnnyscript ?\"  Hahaha",
  "id" : 492681168165154816,
  "created_at" : "2014-07-25 14:41:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLT HULK",
      "screen_name" : "PLT_Hulk",
      "indices" : [ 1, 10 ],
      "id_str" : "484936561",
      "id" : 484936561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492515779456151552",
  "text" : "\"@PLT_Hulk: JJJOHNNY AM ENGINEER IN RESUME ONLY!!!!\".",
  "id" : 492515779456151552,
  "created_at" : "2014-07-25 03:44:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492511941529583616",
  "geo" : { },
  "id_str" : "492514847171420160",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar What do they offer in gases?",
  "id" : 492514847171420160,
  "in_reply_to_status_id" : 492511941529583616,
  "created_at" : "2014-07-25 03:41:04 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "indices" : [ 1, 9 ],
      "id_str" : "15665323",
      "id" : 15665323
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/afrobot\/status\/492493703802400768\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/XCTYolEQTL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtWwagDCIAEMBXa.jpg",
      "id_str" : "492493703592681473",
      "id" : 492493703592681473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtWwagDCIAEMBXa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XCTYolEQTL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492514192973234177",
  "text" : "\"@afrobot: Mission street artist lashes out at the gentrifiers http:\/\/t.co\/XCTYolEQTL\". Hahaha no u can't",
  "id" : 492514192973234177,
  "created_at" : "2014-07-25 03:38:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490215165556555776",
  "text" : "owww i bumped my head",
  "id" : 490215165556555776,
  "created_at" : "2014-07-18 19:22:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486413859763138561",
  "text" : "Gradient pie charts",
  "id" : 486413859763138561,
  "created_at" : "2014-07-08 07:37:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK LOVE",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 3, 15 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JUNGLEPUSSY\/status\/486338180803997696\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/mpZB0iN50B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br_R_6MIMAA2UJL.jpg",
      "id_str" : "486338180661391360",
      "id" : 486338180661391360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br_R_6MIMAA2UJL.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/mpZB0iN50B"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486362390838005760",
  "text" : "RT @JUNGLEPUSSY: MY FRIENDS http:\/\/t.co\/mpZB0iN50B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JUNGLEPUSSY\/status\/486338180803997696\/photo\/1",
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/mpZB0iN50B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Br_R_6MIMAA2UJL.jpg",
        "id_str" : "486338180661391360",
        "id" : 486338180661391360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br_R_6MIMAA2UJL.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/mpZB0iN50B"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486338180803997696",
    "text" : "MY FRIENDS http:\/\/t.co\/mpZB0iN50B",
    "id" : 486338180803997696,
    "created_at" : "2014-07-08 02:37:12 +0000",
    "user" : {
      "name" : "BLACK LOVE",
      "screen_name" : "JUNGLEPUSSY",
      "protected" : false,
      "id_str" : "15819295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669258125707493376\/F7rYnkx3_normal.jpg",
      "id" : 15819295,
      "verified" : false
    }
  },
  "id" : 486362390838005760,
  "created_at" : "2014-07-08 04:13:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486308441607000064",
  "text" : "i must try several tries to put on real pants or shorts.  And by try, I mean locate, pick up, set down, and repeat.  bucuz pants.",
  "id" : 486308441607000064,
  "created_at" : "2014-07-08 00:39:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486298338866642944",
  "geo" : { },
  "id_str" : "486300055175823360",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha \"You will have advanced to level iii Twitter if you can tell the troll accounts from the real accounts.\" - Edna Piranha",
  "id" : 486300055175823360,
  "in_reply_to_status_id" : 486298338866642944,
  "created_at" : "2014-07-08 00:05:42 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/kGhQzQuO5g",
      "expanded_url" : "http:\/\/butt.systems\/",
      "display_url" : "butt.systems"
    } ]
  },
  "geo" : { },
  "id_str" : "486247719560695808",
  "text" : "http:\/\/t.co\/kGhQzQuO5g",
  "id" : 486247719560695808,
  "created_at" : "2014-07-07 20:37:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natasha Lee",
      "screen_name" : "Teh_Natasha",
      "indices" : [ 0, 12 ],
      "id_str" : "251489343",
      "id" : 251489343
    }, {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 13, 23 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486005868811407360",
  "geo" : { },
  "id_str" : "486202189291876352",
  "in_reply_to_user_id" : 251489343,
  "text" : "@Teh_Natasha @nexxylove  &lt;3 &lt;3 &lt;3",
  "id" : 486202189291876352,
  "in_reply_to_status_id" : 486005868811407360,
  "created_at" : "2014-07-07 17:36:49 +0000",
  "in_reply_to_screen_name" : "Teh_Natasha",
  "in_reply_to_user_id_str" : "251489343",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikael",
      "screen_name" : "Mikael",
      "indices" : [ 15, 22 ],
      "id_str" : "1492171",
      "id" : 1492171
    }, {
      "name" : "nodeconf",
      "screen_name" : "nodeconf",
      "indices" : [ 27, 36 ],
      "id_str" : "186697923",
      "id" : 186697923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486200954392301568",
  "text" : "Many thanks to @mikael and @nodeconf for making me an honorary significant other.",
  "id" : 486200954392301568,
  "created_at" : "2014-07-07 17:31:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodeconf",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486199693643223040",
  "text" : "What I did at #nodeconf \n\nI summoned the courage to do back flips off the dock.  I had not back flipped in a decade!",
  "id" : 486199693643223040,
  "created_at" : "2014-07-07 17:26:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodeConf",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486197656192958465",
  "text" : "the \"significant other track\" is the only way to conference.  Kids, games, hiking, swimming. I didn't touch a computer all of #nodeConf",
  "id" : 486197656192958465,
  "created_at" : "2014-07-07 17:18:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodeConf",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486197152922599425",
  "text" : "I went to #nodeConf and got way more than a t-shirt.  I slept on a pile of them from isaac loud.",
  "id" : 486197152922599425,
  "created_at" : "2014-07-07 17:16:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom  \u2692 Croucher",
      "screen_name" : "sh1mmer",
      "indices" : [ 0, 8 ],
      "id_str" : "63803",
      "id" : 63803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485739000292843522",
  "geo" : { },
  "id_str" : "485943532209721344",
  "in_reply_to_user_id" : 63803,
  "text" : "@sh1mmer  pic pls",
  "id" : 485943532209721344,
  "in_reply_to_status_id" : 485739000292843522,
  "created_at" : "2014-07-07 00:29:01 +0000",
  "in_reply_to_screen_name" : "sh1mmer",
  "in_reply_to_user_id_str" : "63803",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484833708130586625",
  "text" : "does the new twitter have not a logout button?",
  "id" : 484833708130586625,
  "created_at" : "2014-07-03 22:58:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Gruber",
      "screen_name" : "juliangruber",
      "indices" : [ 0, 13 ],
      "id_str" : "324544130",
      "id" : 324544130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484806685203390464",
  "geo" : { },
  "id_str" : "484808771365904384",
  "in_reply_to_user_id" : 324544130,
  "text" : "@juliangruber  structure it absolutely \"vertical\" so that everybody has one boss and one subordinate.  Then connect the two ends.",
  "id" : 484808771365904384,
  "in_reply_to_status_id" : 484806685203390464,
  "created_at" : "2014-07-03 21:19:53 +0000",
  "in_reply_to_screen_name" : "juliangruber",
  "in_reply_to_user_id_str" : "324544130",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/BYotz1pVkl",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Glacial_erratics",
      "display_url" : "en.wikipedia.org\/wiki\/Glacial_e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484519013335056385",
  "text" : "there are many picture examples of glacial erratics  http:\/\/t.co\/BYotz1pVkl",
  "id" : 484519013335056385,
  "created_at" : "2014-07-03 02:08:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484463073986506752",
  "text" : "dating",
  "id" : 484463073986506752,
  "created_at" : "2014-07-02 22:26:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484463057494474752",
  "text" : "what if the animal tooth they found at the excavation site of early humans was an animal tooth those people found at an excavation site?",
  "id" : 484463057494474752,
  "created_at" : "2014-07-02 22:26:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484181496765243392",
  "geo" : { },
  "id_str" : "484190695733723136",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar where yat?",
  "id" : 484190695733723136,
  "in_reply_to_status_id" : 484181496765243392,
  "created_at" : "2014-07-02 04:23:52 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JacquieMinter",
      "screen_name" : "JacquieMinter",
      "indices" : [ 0, 14 ],
      "id_str" : "2365374830",
      "id" : 2365374830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483942429611937792",
  "geo" : { },
  "id_str" : "484107381387702273",
  "in_reply_to_user_id" : 2365374830,
  "text" : "@JacquieMinter tu",
  "id" : 484107381387702273,
  "in_reply_to_status_id" : 483942429611937792,
  "created_at" : "2014-07-01 22:52:48 +0000",
  "in_reply_to_screen_name" : "JacquieMinter",
  "in_reply_to_user_id_str" : "2365374830",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/6lP8rQ21xt",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/adaptive",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483924684178604032",
  "text" : "one of my first live recordings \nhttps:\/\/t.co\/6lP8rQ21xt\n\navaillable for a limited time until i change my soundcloud handle again",
  "id" : 483924684178604032,
  "created_at" : "2014-07-01 10:46:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "indices" : [ 3, 13 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483918786798419968",
  "text" : "RT @LouMinoti: violence reflects inequality",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483915706439061505",
    "text" : "violence reflects inequality",
    "id" : 483915706439061505,
    "created_at" : "2014-07-01 10:11:09 +0000",
    "user" : {
      "name" : "Scurge Ibaka",
      "screen_name" : "LouMinoti",
      "protected" : false,
      "id_str" : "262151877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725638787720712192\/IT5u9RUF_normal.jpg",
      "id" : 262151877,
      "verified" : false
    }
  },
  "id" : 483918786798419968,
  "created_at" : "2014-07-01 10:23:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483918658725363712",
  "text" : "YOU ADVANCE WHEN YOU RECOGNIZE ADANCEMENT",
  "id" : 483918658725363712,
  "created_at" : "2014-07-01 10:22:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]