Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Westin",
      "screen_name" : "marcuswestin",
      "indices" : [ 3, 16 ],
      "id_str" : "8904922",
      "id" : 8904922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/v9yusPDW",
      "expanded_url" : "http:\/\/sir-realism.com\/pages\/soulsearchinld.php",
      "display_url" : "sir-realism.com\/pages\/soulsear\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206186294810906624",
  "text" : "RT @marcuswestin: An amazing game! Take a couple of minutes of your friday and play this. It's so worth it! http:\/\/t.co\/v9yusPDW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/v9yusPDW",
        "expanded_url" : "http:\/\/sir-realism.com\/pages\/soulsearchinld.php",
        "display_url" : "sir-realism.com\/pages\/soulsear\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206171279286468610",
    "text" : "An amazing game! Take a couple of minutes of your friday and play this. It's so worth it! http:\/\/t.co\/v9yusPDW",
    "id" : 206171279286468610,
    "created_at" : "2012-05-25 23:53:58 +0000",
    "user" : {
      "name" : "Marcus Westin",
      "screen_name" : "marcuswestin",
      "protected" : false,
      "id_str" : "8904922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/379382059\/n2904387_30962178_8468_normal.jpg",
      "id" : 8904922,
      "verified" : false
    }
  },
  "id" : 206186294810906624,
  "created_at" : "2012-05-26 00:53:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 0, 7 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205866208824786944",
  "in_reply_to_user_id" : 13334762,
  "text" : "@github fork network graphs are very useful",
  "id" : 205866208824786944,
  "created_at" : "2012-05-25 03:41:43 +0000",
  "in_reply_to_screen_name" : "github",
  "in_reply_to_user_id_str" : "13334762",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T-Mobile",
      "screen_name" : "TMobile",
      "indices" : [ 0, 8 ],
      "id_str" : "17338082",
      "id" : 17338082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204305723088318464",
  "in_reply_to_user_id" : 17338082,
  "text" : "@tmobile you are starting a battle that will bring you down, one overpriced data plan at a time",
  "id" : 204305723088318464,
  "created_at" : "2012-05-20 20:20:54 +0000",
  "in_reply_to_screen_name" : "TMobile",
  "in_reply_to_user_id_str" : "17338082",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T-Mobile",
      "screen_name" : "TMobile",
      "indices" : [ 0, 8 ],
      "id_str" : "17338082",
      "id" : 17338082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204305367243558912",
  "in_reply_to_user_id" : 17338082,
  "text" : "@Tmobile just started blocking tethering. This must be a violation of my privacy, knowing whats up in my computer phone.",
  "id" : 204305367243558912,
  "created_at" : "2012-05-20 20:19:30 +0000",
  "in_reply_to_screen_name" : "TMobile",
  "in_reply_to_user_id_str" : "17338082",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayson Musson",
      "screen_name" : "therealhennessy",
      "indices" : [ 0, 16 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "econ101",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Ltz6qq7n",
      "expanded_url" : "http:\/\/hennessyyoungman.com\/gradschool.html",
      "display_url" : "hennessyyoungman.com\/gradschool.html"
    } ]
  },
  "geo" : { },
  "id_str" : "204298619057213444",
  "in_reply_to_user_id" : 137090436,
  "text" : "@therealhennessy \"MFA on DVD\" is fit to pop the .edu bubble. Better ditch investments in children futures! #econ101 http:\/\/t.co\/Ltz6qq7n",
  "id" : 204298619057213444,
  "created_at" : "2012-05-20 19:52:41 +0000",
  "in_reply_to_screen_name" : "therealhennessy",
  "in_reply_to_user_id_str" : "137090436",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204287986723074048",
  "text" : "or, How I learned to Stop Caring About legacy browsers and love simpler html5 media libraries",
  "id" : 204287986723074048,
  "created_at" : "2012-05-20 19:10:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CRAP",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203310312127082496",
  "text" : "Cashflow Ruins Around Me Everything #CRAP",
  "id" : 203310312127082496,
  "created_at" : "2012-05-18 02:25:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Anderson",
      "screen_name" : "TEDchris",
      "indices" : [ 37, 46 ],
      "id_str" : "14761795",
      "id" : 14761795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203216403023671296",
  "text" : "I apologize for my last remark about @TEDchris's head. I don't know why I write it. He might just have tiny hands.",
  "id" : 203216403023671296,
  "created_at" : "2012-05-17 20:12:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Anderson",
      "screen_name" : "TEDchris",
      "indices" : [ 4, 13 ],
      "id_str" : "14761795",
      "id" : 14761795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/gCsLgrUw",
      "expanded_url" : "http:\/\/roundtable.nationaljournal.com\/2012\/05\/the-inequality-speech-that-ted-wont-show-you.php",
      "display_url" : "roundtable.nationaljournal.com\/2012\/05\/the-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203215819021352960",
  "text" : "Boo @TEDchris &amp; His Giant Head for cowing to partisanship, like a partisan. A talk you can't see, will have to read: http:\/\/t.co\/gCsLgrUw",
  "id" : 203215819021352960,
  "created_at" : "2012-05-17 20:10:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unions",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202873883353825280",
  "text" : "demand an direct Internet IPv6 address for your connected devices, solve lots of problems for developers &amp; society! #unions",
  "id" : 202873883353825280,
  "created_at" : "2012-05-16 21:31:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "getify",
      "screen_name" : "getify",
      "indices" : [ 56, 63 ],
      "id_str" : "16686076",
      "id" : 16686076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202211673543684096",
  "geo" : { },
  "id_str" : "202220603510505472",
  "in_reply_to_user_id" : 16686076,
  "text" : "that would ruin a lot of my \"magic bar\" google searches @getify",
  "id" : 202220603510505472,
  "in_reply_to_status_id" : 202211673543684096,
  "created_at" : "2012-05-15 02:15:23 +0000",
  "in_reply_to_screen_name" : "getify",
  "in_reply_to_user_id_str" : "16686076",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 24, 33 ],
      "id_str" : "141834186",
      "id" : 141834186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201749728076107776",
  "geo" : { },
  "id_str" : "201761049114968064",
  "in_reply_to_user_id" : 141834186,
  "text" : "In drrivatives we trust @FearDept",
  "id" : 201761049114968064,
  "in_reply_to_status_id" : 201749728076107776,
  "created_at" : "2012-05-13 19:49:17 +0000",
  "in_reply_to_screen_name" : "FearDept",
  "in_reply_to_user_id_str" : "141834186",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz McArthur",
      "screen_name" : "liz217",
      "indices" : [ 33, 40 ],
      "id_str" : "15219721",
      "id" : 15219721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201530113567891458",
  "geo" : { },
  "id_str" : "201530782920081408",
  "in_reply_to_user_id" : 15219721,
  "text" : "shoot for the web instead, dummy @liz217",
  "id" : 201530782920081408,
  "in_reply_to_status_id" : 201530113567891458,
  "created_at" : "2012-05-13 04:34:17 +0000",
  "in_reply_to_screen_name" : "liz217",
  "in_reply_to_user_id_str" : "15219721",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201528661810225155",
  "text" : "we are the monkeys on the typewriters",
  "id" : 201528661810225155,
  "created_at" : "2012-05-13 04:25:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 74, 81 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/lgg6Z4FN",
      "expanded_url" : "http:\/\/soundcloud.com\/prollabilly",
      "display_url" : "soundcloud.com\/prollabilly"
    } ]
  },
  "in_reply_to_status_id_str" : "201525879879385089",
  "geo" : { },
  "id_str" : "201527291354943488",
  "in_reply_to_user_id" : 14690653,
  "text" : "i just got done thinking up goofy names for raw, repetitious poly rhythms @regisl if you like such things http:\/\/t.co\/lgg6Z4FN",
  "id" : 201527291354943488,
  "in_reply_to_status_id" : 201525879879385089,
  "created_at" : "2012-05-13 04:20:25 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201525540128161793",
  "text" : "I dare twitter to tell a user how many of her followers are tuned in",
  "id" : 201525540128161793,
  "created_at" : "2012-05-13 04:13:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201095625692037120",
  "text" : "twitter should just become a place for calling out bitches",
  "id" : 201095625692037120,
  "created_at" : "2012-05-11 23:45:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "setTheory",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "thx",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 127 ],
      "url" : "https:\/\/t.co\/YnOXhmim",
      "expanded_url" : "https:\/\/gist.github.com\/2663091",
      "display_url" : "gist.github.com\/2663091"
    } ]
  },
  "geo" : { },
  "id_str" : "201093308322283521",
  "text" : "#setTheory will a learned hacker please inform me which language best to implement this short pseudo code https:\/\/t.co\/YnOXhmim #thx",
  "id" : 201093308322283521,
  "created_at" : "2012-05-11 23:35:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 89, 96 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201062037311340545",
  "text" : "are some dualities *real*? Is the duality of Man \/ Woman real, an abstraction of nature? @regisl",
  "id" : 201062037311340545,
  "created_at" : "2012-05-11 21:31:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 91, 98 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201059901940842496",
  "text" : "i desire to have more on the subject of the nondualistic universe if it please the pyramid @regisl",
  "id" : 201059901940842496,
  "created_at" : "2012-05-11 21:23:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 18, 25 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201052649381044224",
  "geo" : { },
  "id_str" : "201058458403995651",
  "in_reply_to_user_id" : 14690653,
  "text" : "BY LOVING, PEOPLE @regisl",
  "id" : 201058458403995651,
  "in_reply_to_status_id" : 201052649381044224,
  "created_at" : "2012-05-11 21:17:26 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/0g8yXEvb",
      "expanded_url" : "http:\/\/www.healthline.com\/human-body-maps\/",
      "display_url" : "healthline.com\/human-body-map\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201025773237313537",
  "text" : "Dive in for true self knowledge. Better bring God with you. http:\/\/t.co\/0g8yXEvb",
  "id" : 201025773237313537,
  "created_at" : "2012-05-11 19:07:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Friday",
      "screen_name" : "scifri",
      "indices" : [ 123, 130 ],
      "id_str" : "16817883",
      "id" : 16817883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201014546532540417",
  "text" : "Why don't you lazy dweebs invent a survey that unconsciously induces the participant to think, write, reason abt the topic @scifri",
  "id" : 201014546532540417,
  "created_at" : "2012-05-11 18:22:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Friday",
      "screen_name" : "scifri",
      "indices" : [ 99, 106 ],
      "id_str" : "16817883",
      "id" : 16817883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201012879074394112",
  "geo" : { },
  "id_str" : "201014087986057217",
  "in_reply_to_user_id" : 16817883,
  "text" : "I strongly disagree with X tier agree \/ disagree surveys like I was applying to work at Bennigan's @scifri",
  "id" : 201014087986057217,
  "in_reply_to_status_id" : 201012879074394112,
  "created_at" : "2012-05-11 18:21:07 +0000",
  "in_reply_to_screen_name" : "scifri",
  "in_reply_to_user_id_str" : "16817883",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corinthiano Sofredor",
      "screen_name" : "corinthino",
      "indices" : [ 18, 29 ],
      "id_str" : "2231991757",
      "id" : 2231991757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201008750608396288",
  "text" : "You don't gno me! @corinthino",
  "id" : 201008750608396288,
  "created_at" : "2012-05-11 17:59:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201007182341353472",
  "text" : "Do either of the two real people who might see this tweet live in NYC? RSVP!",
  "id" : 201007182341353472,
  "created_at" : "2012-05-11 17:53:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 42, 49 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200991194279460866",
  "text" : "hint: it's not an eye actually @_shrine_  @regisl",
  "id" : 200991194279460866,
  "created_at" : "2012-05-11 16:50:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Hank Johnson",
      "screen_name" : "RepHankJohnson",
      "indices" : [ 10, 25 ],
      "id_str" : "24745957",
      "id" : 24745957
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "disturbing",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/vyemNsDE",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0EtcutxLtc4&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=0Etcut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200791268429799424",
  "text" : "Thank you @RepHankJohnson of Georgia for this http:\/\/t.co\/vyemNsDE #disturbing",
  "id" : 200791268429799424,
  "created_at" : "2012-05-11 03:35:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200767473010737152",
  "text" : "If you don't know, I don't like CoffeeScript, now you know.",
  "id" : 200767473010737152,
  "created_at" : "2012-05-11 02:01:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200764039192772608",
  "text" : "sometimes i just practice typing here but don't press the button",
  "id" : 200764039192772608,
  "created_at" : "2012-05-11 01:47:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200760056042627072",
  "text" : "it's too bad this is an illegal invocation (for any event) element.onclick = console.log",
  "id" : 200760056042627072,
  "created_at" : "2012-05-11 01:31:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iola",
      "screen_name" : "iola",
      "indices" : [ 5, 10 ],
      "id_str" : "1551349417",
      "id" : 1551349417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200755158559363072",
  "text" : "heya @ioLA Me and my cutting edge developer crew would like to come hit you with some ideas.",
  "id" : 200755158559363072,
  "created_at" : "2012-05-11 01:12:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE ILLUMINATI",
      "screen_name" : "ThelIluminati",
      "indices" : [ 3, 17 ],
      "id_str" : "143257853",
      "id" : 143257853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaForgot",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200751911090135040",
  "text" : "RT @ThelIluminati: #ObamaForgot nothing. He's doing his best just as past Presidents. Most of you complaining can't even run your lives  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaForgot",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200734241699532802",
    "text" : "#ObamaForgot nothing. He's doing his best just as past Presidents. Most of you complaining can't even run your lives let alone this country.",
    "id" : 200734241699532802,
    "created_at" : "2012-05-10 23:49:07 +0000",
    "user" : {
      "name" : "THE ILLUMINATI",
      "screen_name" : "ThelIluminati",
      "protected" : false,
      "id_str" : "143257853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000843245240\/428857c8f1abcff5780ebf1424c57523_normal.jpeg",
      "id" : 143257853,
      "verified" : false
    }
  },
  "id" : 200751911090135040,
  "created_at" : "2012-05-11 00:59:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 63, 73 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200741615365660673",
  "geo" : { },
  "id_str" : "200751410340577280",
  "in_reply_to_user_id" : 19725644,
  "text" : "The world transcended borders using the internet in the 1960s? @neiltyson",
  "id" : 200751410340577280,
  "in_reply_to_status_id" : 200741615365660673,
  "created_at" : "2012-05-11 00:57:20 +0000",
  "in_reply_to_screen_name" : "neiltyson",
  "in_reply_to_user_id_str" : "19725644",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOL",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200750853181808640",
  "text" : "#LOL \"We already have 5 Fortune 500 customers interested, and will grow faster than Facebook, and we will add 2% to worldwide GDP\u2019s\"",
  "id" : 200750853181808640,
  "created_at" : "2012-05-11 00:55:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Stewart",
      "screen_name" : "ryanstewart",
      "indices" : [ 21, 33 ],
      "id_str" : "11414",
      "id" : 11414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/lbMsYpyJ",
      "expanded_url" : "http:\/\/musicforprogramming.net\/",
      "display_url" : "musicforprogramming.net"
    } ]
  },
  "in_reply_to_status_id_str" : "200343484698337281",
  "geo" : { },
  "id_str" : "200345774796713986",
  "in_reply_to_user_id" : 11414,
  "text" : "http:\/\/t.co\/lbMsYpyJ @ryanstewart",
  "id" : 200345774796713986,
  "in_reply_to_status_id" : 200343484698337281,
  "created_at" : "2012-05-09 22:05:29 +0000",
  "in_reply_to_screen_name" : "ryanstewart",
  "in_reply_to_user_id_str" : "11414",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Hu",
      "screen_name" : "andyhu",
      "indices" : [ 35, 42 ],
      "id_str" : "27852883",
      "id" : 27852883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200045365951594498",
  "text" : "Nice work with the mongo interface @andyhu I'm running it now.",
  "id" : 200045365951594498,
  "created_at" : "2012-05-09 02:11:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200024879666442241",
  "text" : "All these serious, tea-drinking product reviewers had me by the clickballs about choosing an electric kettle. Capitalist revolution FTW.",
  "id" : 200024879666442241,
  "created_at" : "2012-05-09 00:50:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirill Sheynkman",
      "screen_name" : "sheynkman",
      "indices" : [ 3, 13 ],
      "id_str" : "20889975",
      "id" : 20889975
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 55, 66 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/O2xMSHW6",
      "expanded_url" : "http:\/\/4sq.com\/Iwlo62",
      "display_url" : "4sq.com\/Iwlo62"
    } ]
  },
  "geo" : { },
  "id_str" : "199226283375345664",
  "text" : "RT @sheynkman: I just unlocked the \u201CMall Rat\u201D badge on @foursquare for checking in at malls! Time for a fancy pretzel. http:\/\/t.co\/O2xMSHW6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Foursquare",
        "screen_name" : "foursquare",
        "indices" : [ 40, 51 ],
        "id_str" : "14120151",
        "id" : 14120151
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/O2xMSHW6",
        "expanded_url" : "http:\/\/4sq.com\/Iwlo62",
        "display_url" : "4sq.com\/Iwlo62"
      } ]
    },
    "geo" : { },
    "id_str" : "199225184291520512",
    "text" : "I just unlocked the \u201CMall Rat\u201D badge on @foursquare for checking in at malls! Time for a fancy pretzel. http:\/\/t.co\/O2xMSHW6",
    "id" : 199225184291520512,
    "created_at" : "2012-05-06 19:52:40 +0000",
    "user" : {
      "name" : "Kirill Sheynkman",
      "screen_name" : "sheynkman",
      "protected" : false,
      "id_str" : "20889975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1826751334\/ksheadright-web_normal.jpg",
      "id" : 20889975,
      "verified" : false
    }
  },
  "id" : 199226283375345664,
  "created_at" : "2012-05-06 19:57:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 32, 39 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/RSlKaP0P",
      "expanded_url" : "http:\/\/ga.water.usgs.gov\/edu\/2010\/gallery\/global-water-volume.html",
      "display_url" : "ga.water.usgs.gov\/edu\/2010\/galle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199225965988159488",
  "text" : "of planets &amp; dogs @Norondor @regisl http:\/\/t.co\/RSlKaP0P",
  "id" : 199225965988159488,
  "created_at" : "2012-05-06 19:55:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/RSlKaP0P",
      "expanded_url" : "http:\/\/ga.water.usgs.gov\/edu\/2010\/gallery\/global-water-volume.html",
      "display_url" : "ga.water.usgs.gov\/edu\/2010\/galle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199224506928214016",
  "text" : "I have a dog, and tomato plants, and this is thrilling and terrifying  http:\/\/t.co\/RSlKaP0P",
  "id" : 199224506928214016,
  "created_at" : "2012-05-06 19:49:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198485231555198976",
  "text" : "FOUR is now more poignant than THREE which factored into my decision to switch from THREE to TWO",
  "id" : 198485231555198976,
  "created_at" : "2012-05-04 18:52:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198125063411744768",
  "text" : "damn you suck so weak twitter, damn",
  "id" : 198125063411744768,
  "created_at" : "2012-05-03 19:01:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197839532178149380",
  "text" : "CSS is an acronym. It stands for HyperText Makeup Language.",
  "id" : 197839532178149380,
  "created_at" : "2012-05-03 00:06:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Hilowitz",
      "screen_name" : "dhilowitz",
      "indices" : [ 54, 64 ],
      "id_str" : "24695909",
      "id" : 24695909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 87 ],
      "url" : "https:\/\/t.co\/tsyu3ONg",
      "expanded_url" : "https:\/\/developer.mozilla.org\/en-US\/demos\/detail\/tito",
      "display_url" : "developer.mozilla.org\/en-US\/demos\/de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197512849084514305",
  "text" : "I dig this 'gravity controlled' musical instrument by @dhilowitz. https:\/\/t.co\/tsyu3ONg funny tho it seems to be anti-gravitational!",
  "id" : 197512849084514305,
  "created_at" : "2012-05-02 02:28:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corinthiano Sofredor",
      "screen_name" : "corinthino",
      "indices" : [ 24, 35 ],
      "id_str" : "2231991757",
      "id" : 2231991757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197423993345687552",
  "text" : "What is a pseudo-ideal? @corinthino @RedNaylor",
  "id" : 197423993345687552,
  "created_at" : "2012-05-01 20:35:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corinthiano Sofredor",
      "screen_name" : "corinthino",
      "indices" : [ 112, 123 ],
      "id_str" : "2231991757",
      "id" : 2231991757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197422676514578433",
  "text" : "So if it's not perfect and worldwide \/ universal ... ? You'll be pleased to be disappointed I guess! @RedNaylor @corinthino",
  "id" : 197422676514578433,
  "created_at" : "2012-05-01 20:30:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 139, 140 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/i8OFDIRI",
      "expanded_url" : "https:\/\/developer.mozilla.org\/en-US\/demos\/detail\/simon-scats",
      "display_url" : "developer.mozilla.org\/en-US\/demos\/de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197421334127579136",
  "text" : "RT @AngelineGragzin: Remember the memory game SIMON? It's like that, but with Ella Fitzgerald! Give a like if you like: https:\/\/t.co\/i8O ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 124, 136 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 120 ],
        "url" : "https:\/\/t.co\/i8OFDIRI",
        "expanded_url" : "https:\/\/developer.mozilla.org\/en-US\/demos\/detail\/simon-scats",
        "display_url" : "developer.mozilla.org\/en-US\/demos\/de\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "197417472993923073",
    "text" : "Remember the memory game SIMON? It's like that, but with Ella Fitzgerald! Give a like if you like: https:\/\/t.co\/i8OFDIRI by @astromanies \u2665",
    "id" : 197417472993923073,
    "created_at" : "2012-05-01 20:09:28 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703307803574865921\/ZpTWouST_normal.jpg",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 197421334127579136,
  "created_at" : "2012-05-01 20:24:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corinthiano Sofredor",
      "screen_name" : "corinthino",
      "indices" : [ 47, 58 ],
      "id_str" : "2231991757",
      "id" : 2231991757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197421113314246658",
  "text" : "Those are the words of disaffection @RedNaylor @corinthino You squelch the potential by worrying about the possible failure.",
  "id" : 197421113314246658,
  "created_at" : "2012-05-01 20:23:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 119 ],
      "url" : "https:\/\/t.co\/MO1q9H8k",
      "expanded_url" : "https:\/\/developer.mozilla.org\/en-US\/demos\/detail\/simon-scats\/launch",
      "display_url" : "developer.mozilla.org\/en-US\/demos\/de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197408422310842369",
  "text" : "You may not want to play it in Chrome. My Chrome scratches the .wavs like a dusted record needle. https:\/\/t.co\/MO1q9H8k",
  "id" : 197408422310842369,
  "created_at" : "2012-05-01 19:33:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Hacks",
      "screen_name" : "mozhacks",
      "indices" : [ 36, 45 ],
      "id_str" : "45496942",
      "id" : 45496942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JIT",
      "indices" : [ 73, 77 ]
    }, {
      "text" : "html5",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 136 ],
      "url" : "https:\/\/t.co\/ijDkGaLc",
      "expanded_url" : "https:\/\/developer.mozilla.org\/en-US\/demos\/detail\/simon-scats",
      "display_url" : "developer.mozilla.org\/en-US\/demos\/de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197406712897085440",
  "text" : "I managed to squeeze out a demo for @mozhacks April dev derby last night #JIT. \"Simon Scats\" game \/ sampler #html5 https:\/\/t.co\/ijDkGaLc",
  "id" : 197406712897085440,
  "created_at" : "2012-05-01 19:26:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]