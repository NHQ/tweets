Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/cad6xvu",
      "expanded_url" : "http:\/\/www.npr.org\/2011\/07\/30\/138855279\/convicted-suburban-mom-has-city-planners-nervous?ft=1&f=1001",
      "display_url" : "npr.org\/2011\/07\/30\/138\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97416591385436160",
  "text" : "LOL \"If they were to go out and fix the problem, it would be a tacit acknowledgment that the problem existed.\" Ahahaha! http:\/\/t.co\/cad6xvu",
  "id" : 97416591385436160,
  "created_at" : "2011-07-30 21:21:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 40 ],
      "url" : "http:\/\/t.co\/RSWTaXr",
      "expanded_url" : "http:\/\/beta.msgboy.com\/rvzs1",
      "display_url" : "beta.msgboy.com\/rvzs1"
    } ]
  },
  "geo" : { },
  "id_str" : "97069997926526976",
  "text" : "hey ppl try this out http:\/\/t.co\/RSWTaXr",
  "id" : 97069997926526976,
  "created_at" : "2011-07-29 22:24:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wager",
      "indices" : [ 46, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97066342032744448",
  "text" : "I bet you don't secrete honeydew out yr anus. #wager",
  "id" : 97066342032744448,
  "created_at" : "2011-07-29 22:09:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 35 ],
      "url" : "http:\/\/t.co\/GosIGeL",
      "expanded_url" : "http:\/\/www.ted.com\/talks\/deborah_gordon_digs_ants.html",
      "display_url" : "ted.com\/talks\/deborah_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97065858131705856",
  "text" : "it's ant friday http:\/\/t.co\/GosIGeL can u dig it?",
  "id" : 97065858131705856,
  "created_at" : "2011-07-29 22:07:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97059121441935360",
  "text" : "Aphids secrete honeydew and amino acids through their anus.",
  "id" : 97059121441935360,
  "created_at" : "2011-07-29 21:41:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 0, 11 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96738091578048512",
  "geo" : { },
  "id_str" : "96738848184348672",
  "in_reply_to_user_id" : 47951511,
  "text" : "@zunguzungu the Air Force! That's Ivy League Military.",
  "id" : 96738848184348672,
  "in_reply_to_status_id" : 96738091578048512,
  "created_at" : "2011-07-29 00:28:33 +0000",
  "in_reply_to_screen_name" : "zunguzungu",
  "in_reply_to_user_id_str" : "47951511",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 8, 19 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96730161218719745",
  "geo" : { },
  "id_str" : "96736803675058177",
  "in_reply_to_user_id" : 47951511,
  "text" : "correct @zunguzungu going to war has long been one of the fairer options presented to the poor, minorities, immigrants",
  "id" : 96736803675058177,
  "in_reply_to_status_id" : 96730161218719745,
  "created_at" : "2011-07-29 00:20:25 +0000",
  "in_reply_to_screen_name" : "zunguzungu",
  "in_reply_to_user_id_str" : "47951511",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 27, 41 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tia",
      "indices" : [ 83, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96718931405967360",
  "geo" : { },
  "id_str" : "96726100910157824",
  "in_reply_to_user_id" : 749863,
  "text" : "Would somebody please give @hotdogsladies an invitation to hashtag patentrollcall. #tia",
  "id" : 96726100910157824,
  "in_reply_to_status_id" : 96718931405967360,
  "created_at" : "2011-07-28 23:37:54 +0000",
  "in_reply_to_screen_name" : "hotdogsladies",
  "in_reply_to_user_id_str" : "749863",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "patentrollcall",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96724334881681410",
  "text" : "Patent for technical obfuscation: A system which the gizmo pings a widget and gets response type doodad. Claim 1: WEEEEE!!! #patentrollcall",
  "id" : 96724334881681410,
  "created_at" : "2011-07-28 23:30:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "patentrollcall",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96720745836724224",
  "text" : "Patent for Righteousness: A system by which other systems are ignored. Claim 1: Righteousness. #patentrollcall",
  "id" : 96720745836724224,
  "created_at" : "2011-07-28 23:16:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "patentrollcall",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96719651349872641",
  "text" : "Patent for solving mazes: A system by which If you run into a dead-end, you turn around and try another route. #patentrollcall",
  "id" : 96719651349872641,
  "created_at" : "2011-07-28 23:12:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 13, 20 ],
      "id_str" : "15540222",
      "id" : 15540222
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 95, 111 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/i2q85Fp",
      "expanded_url" : "http:\/\/www.meetup.com\/SoCal-Node-JS\/events\/20602651\/",
      "display_url" : "meetup.com\/SoCal-Node-JS\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "96304511446024192",
  "geo" : { },
  "id_str" : "96310599142735872",
  "in_reply_to_user_id" : 15540222,
  "text" : "@socalnodejs @rauchg its about time soCal connects the nodes! #nodejs confirmed attendance 1 + @angelinegragzin http:\/\/t.co\/i2q85Fp",
  "id" : 96310599142735872,
  "in_reply_to_status_id" : 96304511446024192,
  "created_at" : "2011-07-27 20:06:50 +0000",
  "in_reply_to_screen_name" : "rauchg",
  "in_reply_to_user_id_str" : "15540222",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyouwashington",
      "indices" : [ 67, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95019631873507328",
  "text" : "leave my soul out of your necessary evil dealings! Bitchizzzzzz!!! #fuckyouwashington",
  "id" : 95019631873507328,
  "created_at" : "2011-07-24 06:37:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyouwashington",
      "indices" : [ 68, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95018463185219584",
  "text" : "is that loose change you're shaking in the pocket of that lobbyist? #fuckyouwashington",
  "id" : 95018463185219584,
  "created_at" : "2011-07-24 06:32:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyouwashington",
      "indices" : [ 40, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95017164813250560",
  "text" : "who the hell elected washington anyway? #fuckyouwashington",
  "id" : 95017164813250560,
  "created_at" : "2011-07-24 06:27:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyouwashington",
      "indices" : [ 94, 112 ]
    }, {
      "text" : "mastercard",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95016854707372033",
  "text" : "fool us once, shame on you. fool us twice shame on us. the other trillion times... priceless. #fuckyouwashington #mastercard",
  "id" : 95016854707372033,
  "created_at" : "2011-07-24 06:25:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95015367998574594",
  "text" : "RT @postcrunk: taking a self-portrait brandishing a wad of money is an example of one of many small deaths you can experience in a lifetime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94996547611275265",
    "text" : "taking a self-portrait brandishing a wad of money is an example of one of many small deaths you can experience in a lifetime",
    "id" : 94996547611275265,
    "created_at" : "2011-07-24 05:05:16 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 95015367998574594,
  "created_at" : "2011-07-24 06:20:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freeAccess",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/uevSvba",
      "expanded_url" : "http:\/\/fcc.us\/pJGpto",
      "display_url" : "fcc.us\/pJGpto"
    } ]
  },
  "geo" : { },
  "id_str" : "94486935917166592",
  "text" : "I commented on the FCC's blog about auctioning off our public broadband spectrum: read it here http:\/\/t.co\/uevSvba #freeAccess",
  "id" : 94486935917166592,
  "created_at" : "2011-07-22 19:20:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wager",
      "indices" : [ 48, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94259381541146624",
  "text" : "Future people are never on the computer, I bet. #wager",
  "id" : 94259381541146624,
  "created_at" : "2011-07-22 04:16:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faruk Ate\u015F",
      "screen_name" : "KuraFire",
      "indices" : [ 3, 12 ],
      "id_str" : "22253",
      "id" : 22253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94183363958669313",
  "text" : "RT @KuraFire: I can\u2019t wait for OS X Nyan.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94151841654374400",
    "text" : "I can\u2019t wait for OS X Nyan.",
    "id" : 94151841654374400,
    "created_at" : "2011-07-21 21:08:42 +0000",
    "user" : {
      "name" : "Faruk Ate\u015F",
      "screen_name" : "KuraFire",
      "protected" : false,
      "id_str" : "22253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624710140537753600\/UaYZfDvu_normal.jpg",
      "id" : 22253,
      "verified" : false
    }
  },
  "id" : 94183363958669313,
  "created_at" : "2011-07-21 23:13:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 24 ],
      "url" : "http:\/\/t.co\/jv23GJA",
      "expanded_url" : "http:\/\/visual.ly\/history-science-fiction-v1",
      "display_url" : "visual.ly\/history-scienc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94132982553657344",
  "text" : "whoa http:\/\/t.co\/jv23GJA",
  "id" : 94132982553657344,
  "created_at" : "2011-07-21 19:53:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyent",
      "screen_name" : "joyent",
      "indices" : [ 0, 7 ],
      "id_str" : "666523",
      "id" : 666523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94087252925362176",
  "geo" : { },
  "id_str" : "94131539234926592",
  "in_reply_to_user_id" : 666523,
  "text" : "@joyent re: cloud9 (the open source project) doesn't have support for Solaris yet. Is that coming soon? = very helpful for Node SM users.",
  "id" : 94131539234926592,
  "in_reply_to_status_id" : 94087252925362176,
  "created_at" : "2011-07-21 19:48:02 +0000",
  "in_reply_to_screen_name" : "joyent",
  "in_reply_to_user_id_str" : "666523",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 36 ],
      "url" : "http:\/\/t.co\/SSOygan",
      "expanded_url" : "http:\/\/www.awesomefood.net\/2011\/07\/awesome-food-now-accepting-applications-for-1000-microgrants\/",
      "display_url" : "awesomefood.net\/2011\/07\/awesom\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "93855853769261056",
  "geo" : { },
  "id_str" : "93856816420753408",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin http:\/\/t.co\/SSOygan",
  "id" : 93856816420753408,
  "in_reply_to_status_id" : 93855853769261056,
  "created_at" : "2011-07-21 01:36:23 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93478389830266880",
  "geo" : { },
  "id_str" : "93479604404236288",
  "in_reply_to_user_id" : 232439599,
  "text" : "@mkrecny i'm not so swift on the command line, and I know all of 3 vim commands i, :wq, :q!",
  "id" : 93479604404236288,
  "in_reply_to_status_id" : 93478389830266880,
  "created_at" : "2011-07-20 00:37:29 +0000",
  "in_reply_to_screen_name" : "recborg",
  "in_reply_to_user_id_str" : "232439599",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93471246074912768",
  "geo" : { },
  "id_str" : "93477880192974848",
  "in_reply_to_user_id" : 232439599,
  "text" : "@mkrecny ur kidding right?",
  "id" : 93477880192974848,
  "in_reply_to_status_id" : 93471246074912768,
  "created_at" : "2011-07-20 00:30:38 +0000",
  "in_reply_to_screen_name" : "recborg",
  "in_reply_to_user_id_str" : "232439599",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 0, 14 ],
      "id_str" : "180919472",
      "id" : 180919472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93470191555592193",
  "geo" : { },
  "id_str" : "93476837765812224",
  "in_reply_to_user_id" : 148922824,
  "text" : "@node_knockout - I GOT A KNOCKOUT SPOT - LA nodesters or others git in touch. This the misfit squad. Team Nogrammers. #nodejs it's easy.",
  "id" : 93476837765812224,
  "in_reply_to_status_id" : 93470191555592193,
  "created_at" : "2011-07-20 00:26:29 +0000",
  "in_reply_to_screen_name" : "nodeknockout",
  "in_reply_to_user_id_str" : "148922824",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 130, 137 ]
    }, {
      "text" : "mf",
      "indices" : [ 138, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93468214742351872",
  "text" : "YAHAAA! I am using cloud9 to edit my code on the server. no more local git push &gt;&gt; server git pull every 2 fucking minutes. #nodejs #mf",
  "id" : 93468214742351872,
  "created_at" : "2011-07-19 23:52:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "OpMonsanto",
      "indices" : [ 0, 11 ],
      "id_str" : "294447837",
      "id" : 294447837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91725257282568192",
  "geo" : { },
  "id_str" : "91729420158640128",
  "in_reply_to_user_id" : 294447837,
  "text" : "@OpMonsanto are those investors or employees?",
  "id" : 91729420158640128,
  "in_reply_to_status_id" : 91725257282568192,
  "created_at" : "2011-07-15 04:42:52 +0000",
  "in_reply_to_screen_name" : "OpMonsanto",
  "in_reply_to_user_id_str" : "294447837",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex MacCaw",
      "screen_name" : "maccman",
      "indices" : [ 3, 11 ],
      "id_str" : "1345494948",
      "id" : 1345494948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http:\/\/t.co\/VPXJlFI",
      "expanded_url" : "http:\/\/appft1.uspto.gov\/netacgi\/nph-Parser?Sect1=PTO1&Sect2=HITOFF&d=PG01&p=1&u=%2Fnetahtml%2FPTO%2Fsrchnum.html&r=1&f=G&l=50&s1=%2220070244837%22.PGNR.&OS=DN\/20070244837&RS=DN\/20070244837",
      "display_url" : "appft1.uspto.gov\/netacgi\/nph-Pa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91209806039367680",
  "text" : "RT @maccman: You couldn't make it up - IBM have patented Patent Trolling - http:\/\/t.co\/VPXJlFI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 81 ],
        "url" : "http:\/\/t.co\/VPXJlFI",
        "expanded_url" : "http:\/\/appft1.uspto.gov\/netacgi\/nph-Parser?Sect1=PTO1&Sect2=HITOFF&d=PG01&p=1&u=%2Fnetahtml%2FPTO%2Fsrchnum.html&r=1&f=G&l=50&s1=%2220070244837%22.PGNR.&OS=DN\/20070244837&RS=DN\/20070244837",
        "display_url" : "appft1.uspto.gov\/netacgi\/nph-Pa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "91174810763276289",
    "text" : "You couldn't make it up - IBM have patented Patent Trolling - http:\/\/t.co\/VPXJlFI",
    "id" : 91174810763276289,
    "created_at" : "2011-07-13 15:59:03 +0000",
    "user" : {
      "name" : "Alex MacCaw",
      "screen_name" : "maccaw",
      "protected" : false,
      "id_str" : "2006261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658880981017882629\/nlXSOJnc_normal.jpg",
      "id" : 2006261,
      "verified" : false
    }
  },
  "id" : 91209806039367680,
  "created_at" : "2011-07-13 18:18:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyent",
      "screen_name" : "joyent",
      "indices" : [ 0, 7 ],
      "id_str" : "666523",
      "id" : 666523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 36 ],
      "url" : "http:\/\/t.co\/f1rD3pE",
      "expanded_url" : "http:\/\/groups.google.com\/group\/nodejs\/browse_thread\/thread\/ce3f6fd3cf5e0857\/f796972824e9637c?lnk=gst&q=solaris#f796972824e9637c",
      "display_url" : "groups.google.com\/group\/nodejs\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91206188045316096",
  "in_reply_to_user_id" : 666523,
  "text" : "@joyent see also http:\/\/t.co\/f1rD3pE",
  "id" : 91206188045316096,
  "created_at" : "2011-07-13 18:03:44 +0000",
  "in_reply_to_screen_name" : "joyent",
  "in_reply_to_user_id_str" : "666523",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyent",
      "screen_name" : "joyent",
      "indices" : [ 0, 7 ],
      "id_str" : "666523",
      "id" : 666523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 27 ],
      "url" : "http:\/\/t.co\/uPxQ3tb",
      "expanded_url" : "http:\/\/discuss.joyent.com\/viewtopic.php?id=29965",
      "display_url" : "discuss.joyent.com\/viewtopic.php?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91205972827193344",
  "in_reply_to_user_id" : 666523,
  "text" : "@joyent http:\/\/t.co\/uPxQ3tb",
  "id" : 91205972827193344,
  "created_at" : "2011-07-13 18:02:53 +0000",
  "in_reply_to_screen_name" : "joyent",
  "in_reply_to_user_id_str" : "666523",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91204643530604544",
  "geo" : { },
  "id_str" : "91205725296132096",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk I ask cuz I am currently using solaris but it is a pain in the ass",
  "id" : 91205725296132096,
  "in_reply_to_status_id" : 91204643530604544,
  "created_at" : "2011-07-13 18:01:54 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91204643530604544",
  "geo" : { },
  "id_str" : "91205076890288128",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk which linux distro?",
  "id" : 91205076890288128,
  "in_reply_to_status_id" : 91204643530604544,
  "created_at" : "2011-07-13 17:59:19 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91204345458200576",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk Q: what is the learnboost node stack? Where do you host?",
  "id" : 91204345458200576,
  "created_at" : "2011-07-13 17:56:25 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nodejitsu",
      "screen_name" : "nodejitsu",
      "indices" : [ 0, 10 ],
      "id_str" : "157442008",
      "id" : 157442008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81524416772718592",
  "geo" : { },
  "id_str" : "90917240010051584",
  "in_reply_to_user_id" : 157442008,
  "text" : "@nodejitsu yo when do I get to try your platform already",
  "id" : 90917240010051584,
  "in_reply_to_status_id" : 81524416772718592,
  "created_at" : "2011-07-12 22:55:33 +0000",
  "in_reply_to_screen_name" : "nodejitsu",
  "in_reply_to_user_id_str" : "157442008",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LearnBoost",
      "screen_name" : "LearnBoost",
      "indices" : [ 0, 11 ],
      "id_str" : "91498731",
      "id" : 91498731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89793949014835200",
  "in_reply_to_user_id" : 91498731,
  "text" : "@learnboost what is your nodejs operating environment in 140 chars pls? #nodejs",
  "id" : 89793949014835200,
  "created_at" : "2011-07-09 20:32:00 +0000",
  "in_reply_to_screen_name" : "LearnBoost",
  "in_reply_to_user_id_str" : "91498731",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Geisend\u00F6rfer",
      "screen_name" : "felixge",
      "indices" : [ 0, 8 ],
      "id_str" : "9599342",
      "id" : 9599342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89204528020332544",
  "geo" : { },
  "id_str" : "89790829073416193",
  "in_reply_to_user_id" : 9599342,
  "text" : "@felixge can you stream itunes through nodejs?",
  "id" : 89790829073416193,
  "in_reply_to_status_id" : 89204528020332544,
  "created_at" : "2011-07-09 20:19:36 +0000",
  "in_reply_to_screen_name" : "felixge",
  "in_reply_to_user_id_str" : "9599342",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nodejitsu",
      "screen_name" : "nodejitsu",
      "indices" : [ 3, 13 ],
      "id_str" : "157442008",
      "id" : 157442008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89788665919836160",
  "text" : "yo @nodejitsu when am I ever gonna git to try yr platform?",
  "id" : 89788665919836160,
  "created_at" : "2011-07-09 20:11:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamar",
      "screen_name" : "stoplookingup",
      "indices" : [ 3, 17 ],
      "id_str" : "20112568",
      "id" : 20112568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89537529082150912",
  "text" : "RT @stoplookingup: Retweet if you still want to be an astronaut.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89362886740283392",
    "text" : "Retweet if you still want to be an astronaut.",
    "id" : 89362886740283392,
    "created_at" : "2011-07-08 15:59:07 +0000",
    "user" : {
      "name" : "Tamar",
      "screen_name" : "stoplookingup",
      "protected" : false,
      "id_str" : "20112568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2998646215\/08e39175020b9cb078fe757774001d8f_normal.jpeg",
      "id" : 20112568,
      "verified" : false
    }
  },
  "id" : 89537529082150912,
  "created_at" : "2011-07-09 03:33:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caroline McCarthy",
      "screen_name" : "caro",
      "indices" : [ 0, 5 ],
      "id_str" : "818155",
      "id" : 818155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "google",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http:\/\/t.co\/IPuuTO1",
      "expanded_url" : "http:\/\/manvcandymachine.com\/#man_v_candy_machine_script",
      "display_url" : "manvcandymachine.com\/#man_v_candy_m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89049188465250304",
  "in_reply_to_user_id" : 818155,
  "text" : "@caro #google http:\/\/t.co\/IPuuTO1",
  "id" : 89049188465250304,
  "created_at" : "2011-07-07 19:12:35 +0000",
  "in_reply_to_screen_name" : "caro",
  "in_reply_to_user_id_str" : "818155",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89038519821008896",
  "text" : "Die Roboter!",
  "id" : 89038519821008896,
  "created_at" : "2011-07-07 18:30:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89038436505354240",
  "text" : "finally kraftwerk time",
  "id" : 89038436505354240,
  "created_at" : "2011-07-07 18:29:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phoebe Gillim",
      "screen_name" : "usdayofrage",
      "indices" : [ 3, 15 ],
      "id_str" : "4377025355",
      "id" : 4377025355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usdor",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86886148542173184",
  "text" : "RT @USDayofRage: Corporations are the vampire squids of  our elections. #usdor - http:\/\/ow.ly\/5v14m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "usdor",
        "indices" : [ 55, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86871863871025152",
    "text" : "Corporations are the vampire squids of  our elections. #usdor - http:\/\/ow.ly\/5v14m",
    "id" : 86871863871025152,
    "created_at" : "2011-07-01 19:00:41 +0000",
    "user" : {
      "name" : "The Great Unwashed",
      "screen_name" : "_GreatUnwashed",
      "protected" : false,
      "id_str" : "263466153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677200566724853760\/sMleis2S_normal.jpg",
      "id" : 263466153,
      "verified" : false
    }
  },
  "id" : 86886148542173184,
  "created_at" : "2011-07-01 19:57:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]