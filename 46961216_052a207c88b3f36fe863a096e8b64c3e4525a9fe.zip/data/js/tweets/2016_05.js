Grailbird.data.tweets_2016_05 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729451177755082753",
  "text" : "I am truly glorious.",
  "id" : 729451177755082753,
  "created_at" : "2016-05-08 23:21:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/FIlpREwiBv",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/729422741317681152",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729437556006248449",
  "text" : "ima repeat this signal a few times\n\nhttps:\/\/t.co\/FIlpREwiBv",
  "id" : 729437556006248449,
  "created_at" : "2016-05-08 22:27:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lady fav-a-lot",
      "screen_name" : "rubybrunton",
      "indices" : [ 0, 12 ],
      "id_str" : "330311639",
      "id" : 330311639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729435977509416960",
  "geo" : { },
  "id_str" : "729436824993570816",
  "in_reply_to_user_id" : 330311639,
  "text" : "@rubybrunton  that is the answer then (if not block them), thank you lady genius",
  "id" : 729436824993570816,
  "in_reply_to_status_id" : 729435977509416960,
  "created_at" : "2016-05-08 22:24:26 +0000",
  "in_reply_to_screen_name" : "rubybrunton",
  "in_reply_to_user_id_str" : "330311639",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lady fav-a-lot",
      "screen_name" : "rubybrunton",
      "indices" : [ 0, 12 ],
      "id_str" : "330311639",
      "id" : 330311639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729434613513396225",
  "geo" : { },
  "id_str" : "729435336288309248",
  "in_reply_to_user_id" : 330311639,
  "text" : "@rubybrunton  clarification:  I mean to keep the crush from reading of one's inspired public venue blubbering",
  "id" : 729435336288309248,
  "in_reply_to_status_id" : 729434613513396225,
  "created_at" : "2016-05-08 22:18:31 +0000",
  "in_reply_to_screen_name" : "rubybrunton",
  "in_reply_to_user_id_str" : "330311639",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729434732799221761",
  "text" : "oh maya maya",
  "id" : 729434732799221761,
  "created_at" : "2016-05-08 22:16:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/UWh13GwoHQ",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/729433789085016064",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729434127351447552",
  "text" : "i mean die\n\nhttps:\/\/t.co\/UWh13GwoHQ",
  "id" : 729434127351447552,
  "created_at" : "2016-05-08 22:13:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/EX6FkVujG1",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/729433442169937920",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729433789085016064",
  "text" : "my life goal is to live in the finest people purgatories\n\nhttps:\/\/t.co\/EX6FkVujG1",
  "id" : 729433789085016064,
  "created_at" : "2016-05-08 22:12:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729433442169937920",
  "text" : "here's some social network graffology, you should be able to block without forcing unfollow, call it a purgatory ban",
  "id" : 729433442169937920,
  "created_at" : "2016-05-08 22:10:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729432923720458243",
  "text" : "I ADVISE U GET WITH JOHNNY MIND AND BODY",
  "id" : 729432923720458243,
  "created_at" : "2016-05-08 22:08:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lady fav-a-lot",
      "screen_name" : "rubybrunton",
      "indices" : [ 0, 12 ],
      "id_str" : "330311639",
      "id" : 330311639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729432252778569728",
  "geo" : { },
  "id_str" : "729432315311489028",
  "in_reply_to_user_id" : 46961216,
  "text" : "@rubybrunton pls + thx",
  "id" : 729432315311489028,
  "in_reply_to_status_id" : 729432252778569728,
  "created_at" : "2016-05-08 22:06:30 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lady fav-a-lot",
      "screen_name" : "rubybrunton",
      "indices" : [ 0, 12 ],
      "id_str" : "330311639",
      "id" : 330311639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729432252778569728",
  "in_reply_to_user_id" : 330311639,
  "text" : "@rubybrunton hlo pls advise what one a do if the main crush follows you but maybe doesn't use tw much (but who knows)?  im thinkin block...?",
  "id" : 729432252778569728,
  "created_at" : "2016-05-08 22:06:15 +0000",
  "in_reply_to_screen_name" : "rubybrunton",
  "in_reply_to_user_id_str" : "330311639",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729431387229454336",
  "text" : "johnny errbodt",
  "id" : 729431387229454336,
  "created_at" : "2016-05-08 22:02:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729431028897484800",
  "text" : "^_^\n\n~^_^~\n\n ,^_^,",
  "id" : 729431028897484800,
  "created_at" : "2016-05-08 22:01:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729430828619440128",
  "text" : "transmuting energy back into inspo",
  "id" : 729430828619440128,
  "created_at" : "2016-05-08 22:00:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729422741317681152",
  "text" : "yo holler at me if you are in san diego or los angeles areas and can host me, assist me, jam w me, or wish to come visit me this week\/end",
  "id" : 729422741317681152,
  "created_at" : "2016-05-08 21:28:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729421554908467201",
  "text" : "decentralize your sensual selfie",
  "id" : 729421554908467201,
  "created_at" : "2016-05-08 21:23:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knowdat",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729421078922039296",
  "text" : "DEX is short for decentralized, because X marks the center, and we seek to de-X  #knowdat",
  "id" : 729421078922039296,
  "created_at" : "2016-05-08 21:21:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729412410746888192",
  "text" : "tears brast from johnny eyen",
  "id" : 729412410746888192,
  "created_at" : "2016-05-08 20:47:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729410808975757312",
  "text" : "so part\nvery sweet\nmuch sorrow",
  "id" : 729410808975757312,
  "created_at" : "2016-05-08 20:41:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729393526862061568",
  "text" : "I need to see a hater out of my notifications tab so like some of my tweets already",
  "id" : 729393526862061568,
  "created_at" : "2016-05-08 19:32:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729393282648694784",
  "text" : "\"the apps are all made out of icky techy\nand have the same shitty interfaaaace\"",
  "id" : 729393282648694784,
  "created_at" : "2016-05-08 19:31:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729200822756593665",
  "text" : "you've got sharp hot pokers",
  "id" : 729200822756593665,
  "created_at" : "2016-05-08 06:46:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729172445135933440",
  "geo" : { },
  "id_str" : "729200660361580545",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  that's too Rumsfeldian for them",
  "id" : 729200660361580545,
  "in_reply_to_status_id" : 729172445135933440,
  "created_at" : "2016-05-08 06:45:59 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729199122415165440",
  "text" : "this algorithm gets its own fold",
  "id" : 729199122415165440,
  "created_at" : "2016-05-08 06:39:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729197927982243841",
  "text" : "if it is easy to confuse the means with ends\nit is also easy to confuse recursing with arguing in circles",
  "id" : 729197927982243841,
  "created_at" : "2016-05-08 06:35:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/729171748147486720\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/zAmgifLM13",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch6J1yvUkAAGINi.jpg",
      "id_str" : "729171746926923776",
      "id" : 729171746926923776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch6J1yvUkAAGINi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zAmgifLM13"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729171748147486720",
  "text" : "OMG I FOUND THIS SELFIE OMG https:\/\/t.co\/zAmgifLM13",
  "id" : 729171748147486720,
  "created_at" : "2016-05-08 04:51:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729167935395090433",
  "text" : "first I want you to be free\nand then espy you dancing",
  "id" : 729167935395090433,
  "created_at" : "2016-05-08 04:35:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/729149747856965636\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/cCbnwpLCWl",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ch51xpYUgAEoV9K.jpg",
      "id_str" : "729149685462499329",
      "id" : 729149685462499329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ch51xpYUgAEoV9K.jpg",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/cCbnwpLCWl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729149747856965636",
  "text" : "https:\/\/t.co\/cCbnwpLCWl",
  "id" : 729149747856965636,
  "created_at" : "2016-05-08 03:23:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729058026955505664",
  "geo" : { },
  "id_str" : "729058127627214848",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz don't hate the messenger mang",
  "id" : 729058127627214848,
  "in_reply_to_status_id" : 729058026955505664,
  "created_at" : "2016-05-07 21:19:37 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729045631851999232",
  "geo" : { },
  "id_str" : "729057828149690368",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz maybe nature needed to catch up with Perception, which broke the determinism, and was engendered by consciousness",
  "id" : 729057828149690368,
  "in_reply_to_status_id" : 729045631851999232,
  "created_at" : "2016-05-07 21:18:26 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/KurvnhklWs",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Guard_(grappling)",
      "display_url" : "en.wikipedia.org\/wiki\/Guard_(gr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728742730147364864",
  "text" : "why is there a pic of US army dudes here instead of a couple people doing jujitsu  https:\/\/t.co\/KurvnhklWs",
  "id" : 728742730147364864,
  "created_at" : "2016-05-07 00:26:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728634984165048320",
  "geo" : { },
  "id_str" : "728642365410271232",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove never forget, the middle finger is protected free speech",
  "id" : 728642365410271232,
  "in_reply_to_status_id" : 728634984165048320,
  "created_at" : "2016-05-06 17:47:32 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 20, 32 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 33, 42 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 43, 51 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/728380047015321601\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/Wn1kfEboda",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chu5yvmUgAAFE3R.jpg",
      "id_str" : "728380046172258304",
      "id" : 728380046172258304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chu5yvmUgAAFE3R.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Wn1kfEboda"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728380047015321601",
  "text" : "To whom it concerns @marinakukso @substack @soldair https:\/\/t.co\/Wn1kfEboda",
  "id" : 728380047015321601,
  "created_at" : "2016-05-06 00:25:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/yGIJDwcjJ5",
      "expanded_url" : "https:\/\/twitter.com\/Cabbibo\/status\/728274507354406912",
      "display_url" : "twitter.com\/Cabbibo\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728330206914617344",
  "text" : "hey me https:\/\/t.co\/yGIJDwcjJ5",
  "id" : 728330206914617344,
  "created_at" : "2016-05-05 21:07:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hologram Reagan",
      "screen_name" : "HologramReagan",
      "indices" : [ 3, 18 ],
      "id_str" : "555066637",
      "id" : 555066637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/3gWjVvg5kS",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/706606468045344768",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728077391390638080",
  "text" : "RT @HologramReagan: Done and Done. https:\/\/t.co\/3gWjVvg5kS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/3gWjVvg5kS",
        "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/706606468045344768",
        "display_url" : "twitter.com\/johnnyscript\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728076951865319427",
    "text" : "Done and Done. https:\/\/t.co\/3gWjVvg5kS",
    "id" : 728076951865319427,
    "created_at" : "2016-05-05 04:20:46 +0000",
    "user" : {
      "name" : "Hologram Reagan",
      "screen_name" : "HologramReagan",
      "protected" : false,
      "id_str" : "555066637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2139721116\/rgnthumbs_normal.jpg",
      "id" : 555066637,
      "verified" : false
    }
  },
  "id" : 728077391390638080,
  "created_at" : "2016-05-05 04:22:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727337615876218880",
  "geo" : { },
  "id_str" : "727518549514682368",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  crowdfund protest army!",
  "id" : 727518549514682368,
  "in_reply_to_status_id" : 727337615876218880,
  "created_at" : "2016-05-03 15:21:53 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "blprnt",
      "screen_name" : "blprnt",
      "indices" : [ 0, 7 ],
      "id_str" : "17013577",
      "id" : 17013577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727497755405361155",
  "geo" : { },
  "id_str" : "727518254038548480",
  "in_reply_to_user_id" : 17013577,
  "text" : "@blprnt  protesters",
  "id" : 727518254038548480,
  "in_reply_to_status_id" : 727497755405361155,
  "created_at" : "2016-05-03 15:20:43 +0000",
  "in_reply_to_screen_name" : "blprnt",
  "in_reply_to_user_id_str" : "17013577",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727263609852563456",
  "geo" : { },
  "id_str" : "727264017912225792",
  "in_reply_to_user_id" : 46961216,
  "text" : "featuring the single Lop-Sided",
  "id" : 727264017912225792,
  "in_reply_to_status_id" : 727263609852563456,
  "created_at" : "2016-05-02 22:30:28 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/727263609852563456\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/uugzQV2JrW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChfCZP0U8AAc-Qt.jpg",
      "id_str" : "727263603842150400",
      "id" : 727263603842150400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChfCZP0U8AAc-Qt.jpg",
      "sizes" : [ {
        "h" : 140,
        "resize" : "fit",
        "w" : 128
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 128
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 128
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 128
      }, {
        "h" : 128,
        "resize" : "crop",
        "w" : 128
      } ],
      "display_url" : "pic.twitter.com\/uugzQV2JrW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727263609852563456",
  "text" : "cop my new album on vinyl \"Picture Me Spin(n)\" https:\/\/t.co\/uugzQV2JrW",
  "id" : 727263609852563456,
  "created_at" : "2016-05-02 22:28:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "thealphanerd",
      "indices" : [ 0, 13 ],
      "id_str" : "150664007",
      "id" : 150664007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727258011257827328",
  "in_reply_to_user_id" : 150664007,
  "text" : "@thealphanerd  do also auto-unretweet after n period, for scrollback crush control",
  "id" : 727258011257827328,
  "created_at" : "2016-05-02 22:06:36 +0000",
  "in_reply_to_screen_name" : "thealphanerd",
  "in_reply_to_user_id_str" : "150664007",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727253880073940992",
  "text" : "tfw when a great thrift store steal finna set your wardrobe off forever (cuz you wear the same thing every day)",
  "id" : 727253880073940992,
  "created_at" : "2016-05-02 21:50:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 0, 11 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    }, {
      "name" : "Joe Bel Bruno",
      "screen_name" : "JoeBelBruno",
      "indices" : [ 12, 24 ],
      "id_str" : "49325537",
      "id" : 49325537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727248264970522627",
  "geo" : { },
  "id_str" : "727249066636140544",
  "in_reply_to_user_id" : 2375721396,
  "text" : "@Satoshi_N_ @JoeBelBruno  when is bitcoin's jubilee?  I want to throw out old these blocks.",
  "id" : 727249066636140544,
  "in_reply_to_status_id" : 727248264970522627,
  "created_at" : "2016-05-02 21:31:03 +0000",
  "in_reply_to_screen_name" : "Satoshi_N_",
  "in_reply_to_user_id_str" : "2375721396",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727198464036098048",
  "text" : "what's all the nakamoto about anyway?",
  "id" : 727198464036098048,
  "created_at" : "2016-05-02 18:09:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727198356594782209",
  "text" : "SATOSHI BLAGABLAGABLAGA",
  "id" : 727198356594782209,
  "created_at" : "2016-05-02 18:09:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726876837012340736",
  "text" : "IM ON A MISSION \n\nFROM GODT",
  "id" : 726876837012340736,
  "created_at" : "2016-05-01 20:51:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abs",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726875963204628480",
  "text" : "algorithmic beauty salon #abs",
  "id" : 726875963204628480,
  "created_at" : "2016-05-01 20:48:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/4Wbm9F5DJ3",
      "expanded_url" : "https:\/\/youtu.be\/oJkGsl0chrM",
      "display_url" : "youtu.be\/oJkGsl0chrM"
    } ]
  },
  "geo" : { },
  "id_str" : "726875376236908544",
  "text" : "check out my latest abs clip\n\nhttps:\/\/t.co\/4Wbm9F5DJ3",
  "id" : 726875376236908544,
  "created_at" : "2016-05-01 20:46:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/oT3W6pxXS8",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/726860921629351936",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726862551804342274",
  "text" : "i actually have to not keep mirrors around work areas because of this (unless the work dancing)\n\nhttps:\/\/t.co\/oT3W6pxXS8",
  "id" : 726862551804342274,
  "created_at" : "2016-05-01 19:55:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726860921629351936",
  "text" : "every time I walk by a reflective surface I am greeted by beauty",
  "id" : 726860921629351936,
  "created_at" : "2016-05-01 19:48:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726860623124959233",
  "text" : "u don't know me you know",
  "id" : 726860623124959233,
  "created_at" : "2016-05-01 19:47:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726860559912570880",
  "text" : "we don't know shit about one another",
  "id" : 726860559912570880,
  "created_at" : "2016-05-01 19:47:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726858147009155073",
  "text" : "sexy model selfie for hire: me",
  "id" : 726858147009155073,
  "created_at" : "2016-05-01 19:37:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]