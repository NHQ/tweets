Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627312028978294784",
  "text" : "Failed to kill daemon: Success, folks.\n\nFailed to kill daemon: Success",
  "id" : 627312028978294784,
  "created_at" : "2015-08-01 02:56:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627209820144144384",
  "text" : "\"We needed more electricity, so we gathered everyone from the village together and rolled the boulder up the hill once more.\"",
  "id" : 627209820144144384,
  "created_at" : "2015-07-31 20:10:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/ea5GfDDQSd",
      "expanded_url" : "https:\/\/medium.com\/tag\/cli-fi",
      "display_url" : "medium.com\/tag\/cli-fi"
    } ]
  },
  "geo" : { },
  "id_str" : "627150385149407232",
  "text" : "CLI-FI IS NOT COMMAND LINE INTERFACE FICTION \n\nhttps:\/\/t.co\/ea5GfDDQSd",
  "id" : 627150385149407232,
  "created_at" : "2015-07-31 16:14:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627141784586489856",
  "text" : "CA needs to raise property taxes.",
  "id" : 627141784586489856,
  "created_at" : "2015-07-31 15:40:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Palmer",
      "screen_name" : "Caged",
      "indices" : [ 3, 9 ],
      "id_str" : "779169",
      "id" : 779169
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Caged\/status\/626909569055195136\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/JoAvsUb4DY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLM67kOUEAEA3ae.jpg",
      "id_str" : "626909568145035265",
      "id" : 626909568145035265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLM67kOUEAEA3ae.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 867,
        "resize" : "fit",
        "w" : 1300
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/JoAvsUb4DY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626924234565005312",
  "text" : "RT @Caged: Not the Onion.  That\u2019s Portland\u2019s Mayor and the police talking to the Greenpeace folks through a traffic cone. http:\/\/t.co\/JoAvs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Caged\/status\/626909569055195136\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/JoAvsUb4DY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLM67kOUEAEA3ae.jpg",
        "id_str" : "626909568145035265",
        "id" : 626909568145035265,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLM67kOUEAEA3ae.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 867,
          "resize" : "fit",
          "w" : 1300
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/JoAvsUb4DY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626909569055195136",
    "text" : "Not the Onion.  That\u2019s Portland\u2019s Mayor and the police talking to the Greenpeace folks through a traffic cone. http:\/\/t.co\/JoAvsUb4DY",
    "id" : 626909569055195136,
    "created_at" : "2015-07-31 00:17:43 +0000",
    "user" : {
      "name" : "Justin Palmer",
      "screen_name" : "Caged",
      "protected" : false,
      "id_str" : "779169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580792039899435008\/EI0FMeTs_normal.jpg",
      "id" : 779169,
      "verified" : false
    }
  },
  "id" : 626924234565005312,
  "created_at" : "2015-07-31 01:15:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jethro",
      "screen_name" : "jethrolarson",
      "indices" : [ 0, 13 ],
      "id_str" : "6244912",
      "id" : 6244912
    }, {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 14, 25 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626912651851886592",
  "geo" : { },
  "id_str" : "626923913503584256",
  "in_reply_to_user_id" : 6244912,
  "text" : "@jethrolarson @whichlight  those were pretty good experiences!",
  "id" : 626923913503584256,
  "in_reply_to_status_id" : 626912651851886592,
  "created_at" : "2015-07-31 01:14:43 +0000",
  "in_reply_to_screen_name" : "jethrolarson",
  "in_reply_to_user_id_str" : "6244912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/F2yJ32zpXW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=9AiL6e0KpXU",
      "display_url" : "youtube.com\/watch?v=9AiL6e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626921655617466368",
  "text" : "always dig this song on a hot naps kind of summer day  https:\/\/t.co\/F2yJ32zpXW",
  "id" : 626921655617466368,
  "created_at" : "2015-07-31 01:05:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626891758077652992",
  "geo" : { },
  "id_str" : "626896725278470145",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  \"isometric user experiences\"",
  "id" : 626896725278470145,
  "in_reply_to_status_id" : 626891758077652992,
  "created_at" : "2015-07-30 23:26:41 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "no",
      "screen_name" : "the_N0",
      "indices" : [ 0, 7 ],
      "id_str" : "42699163",
      "id" : 42699163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626741655639494656",
  "geo" : { },
  "id_str" : "626791373937766400",
  "in_reply_to_user_id" : 42699163,
  "text" : "@the_N0  all the world's men on a continuous, 24 hour, cock-a-doodle-do cycle WHO'S CRAZY NOW BITCH",
  "id" : 626791373937766400,
  "in_reply_to_status_id" : 626741655639494656,
  "created_at" : "2015-07-30 16:28:03 +0000",
  "in_reply_to_screen_name" : "the_N0",
  "in_reply_to_user_id_str" : "42699163",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626575123487690753",
  "text" : "give up\ngive in\ngive",
  "id" : 626575123487690753,
  "created_at" : "2015-07-30 02:08:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/aLFqtTIsK5",
      "expanded_url" : "https:\/\/soundcloud.com\/neilcic\/crocodile-chop",
      "display_url" : "soundcloud.com\/neilcic\/crocod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626571324824031232",
  "text" : "this is existential pop brilliance https:\/\/t.co\/aLFqtTIsK5",
  "id" : 626571324824031232,
  "created_at" : "2015-07-30 01:53:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/AuCMWfbuZy",
      "expanded_url" : "https:\/\/soundcloud.com\/neilcic\/no-credit-card",
      "display_url" : "soundcloud.com\/neilcic\/no-cre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626567376323002368",
  "text" : "listening to this was most cathartic\n\nhttps:\/\/t.co\/AuCMWfbuZy",
  "id" : 626567376323002368,
  "created_at" : "2015-07-30 01:37:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/fEHe7WlZ3J",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/stand-by",
      "display_url" : "soundcloud.com\/folkstack\/stan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626553836912578560",
  "text" : "STANDBY  https:\/\/t.co\/fEHe7WlZ3J",
  "id" : 626553836912578560,
  "created_at" : "2015-07-30 00:44:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626547730953846784",
  "text" : "and now beer",
  "id" : 626547730953846784,
  "created_at" : "2015-07-30 00:19:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626547599164637184",
  "text" : "my tribe needs a business finance minister",
  "id" : 626547599164637184,
  "created_at" : "2015-07-30 00:19:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626546995373584384",
  "text" : "something I think about:  tribal corporate co-operative communities, existing in the framework of granted laws and property.  I regret this.",
  "id" : 626546995373584384,
  "created_at" : "2015-07-30 00:16:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626545160751464448",
  "geo" : { },
  "id_str" : "626545454990278656",
  "in_reply_to_user_id" : 46961216,
  "text" : "This is for real life, and is the opposite of what you do to create believable fiction.",
  "id" : 626545454990278656,
  "in_reply_to_status_id" : 626545160751464448,
  "created_at" : "2015-07-30 00:10:51 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626545160751464448",
  "text" : "fake it until they no longer suspect you",
  "id" : 626545160751464448,
  "created_at" : "2015-07-30 00:09:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/OPgIdSwhRQ",
      "expanded_url" : "https:\/\/twitter.com\/modulhaus3000\/status\/626543872873664512",
      "display_url" : "twitter.com\/modulhaus3000\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626544511120834560",
  "text" : "patriarchy is object oriented https:\/\/t.co\/OPgIdSwhRQ",
  "id" : 626544511120834560,
  "created_at" : "2015-07-30 00:07:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626541702421938176",
  "text" : "devops is for fuccbois",
  "id" : 626541702421938176,
  "created_at" : "2015-07-29 23:55:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "april glaser",
      "screen_name" : "aprilaser",
      "indices" : [ 3, 13 ],
      "id_str" : "210056653",
      "id" : 210056653
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aprilaser\/status\/626451181905145856\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2fyr8Hoow8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLGaBe4UYAAXDBX.jpg",
      "id_str" : "626451173441036288",
      "id" : 626451173441036288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLGaBe4UYAAXDBX.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2fyr8Hoow8"
    } ],
    "hashtags" : [ {
      "text" : "ShellNo",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626507106590588928",
  "text" : "RT @aprilaser: They deployed at 1am last night and are hanging low enough to stop Shell's damaged oil ship from passing #ShellNo http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aprilaser\/status\/626451181905145856\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/2fyr8Hoow8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLGaBe4UYAAXDBX.jpg",
        "id_str" : "626451173441036288",
        "id" : 626451173441036288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLGaBe4UYAAXDBX.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 574,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 574,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2fyr8Hoow8"
      } ],
      "hashtags" : [ {
        "text" : "ShellNo",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626451181905145856",
    "text" : "They deployed at 1am last night and are hanging low enough to stop Shell's damaged oil ship from passing #ShellNo http:\/\/t.co\/2fyr8Hoow8",
    "id" : 626451181905145856,
    "created_at" : "2015-07-29 17:56:15 +0000",
    "user" : {
      "name" : "april glaser",
      "screen_name" : "aprilaser",
      "protected" : false,
      "id_str" : "210056653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712477337531449344\/H6j-FPul_normal.jpg",
      "id" : 210056653,
      "verified" : false
    }
  },
  "id" : 626507106590588928,
  "created_at" : "2015-07-29 21:38:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/KgGjs9zVdG",
      "expanded_url" : "https:\/\/www.jacobinmag.com\/2015\/07\/incarceration-capitalism-black-lives-matter\/",
      "display_url" : "jacobinmag.com\/2015\/07\/incarc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626432012291694592",
  "text" : "https:\/\/t.co\/KgGjs9zVdG",
  "id" : 626432012291694592,
  "created_at" : "2015-07-29 16:40:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625725185056972800",
  "text" : "sell your cars, sell your house, join some tribes, drop out of the packaged life",
  "id" : 625725185056972800,
  "created_at" : "2015-07-27 17:51:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sartaj",
      "screen_name" : "sartaj",
      "indices" : [ 42, 49 ],
      "id_str" : "24467334",
      "id" : 24467334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625723064484003840",
  "text" : "\"This looks like the revolution to me.\" - @sartaj in Hackistan.",
  "id" : 625723064484003840,
  "created_at" : "2015-07-27 17:42:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "indices" : [ 3, 19 ],
      "id_str" : "87320284",
      "id" : 87320284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625487741300535296",
  "text" : "RT @veeveeveeveevee: Meek &gt; Drake but more importantly was Sandra Bland already dead in her mugshot?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625470681489108993",
    "text" : "Meek &gt; Drake but more importantly was Sandra Bland already dead in her mugshot?",
    "id" : 625470681489108993,
    "created_at" : "2015-07-27 01:00:05 +0000",
    "user" : {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "protected" : false,
      "id_str" : "87320284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3290278496\/63e6e6ef113610b95961f0a5436adf5d_normal.jpeg",
      "id" : 87320284,
      "verified" : true
    }
  },
  "id" : 625487741300535296,
  "created_at" : "2015-07-27 02:07:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 3, 11 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Alaska",
      "indices" : [ 29, 36 ]
    }, {
      "text" : "Denali",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "K2aviation",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "mountains",
      "indices" : [ 57, 67 ]
    }, {
      "text" : "glacier",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/DvfePujscq",
      "expanded_url" : "https:\/\/instagram.com\/p\/5ljuExgfOM\/",
      "display_url" : "instagram.com\/p\/5ljuExgfOM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "625184608821194753",
  "text" : "RT @Gyselie: Just beautiful. #Alaska #Denali #K2aviation #mountains #glacier @ Denali National Park\/Mt. McKinley https:\/\/t.co\/DvfePujscq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Alaska",
        "indices" : [ 16, 23 ]
      }, {
        "text" : "Denali",
        "indices" : [ 24, 31 ]
      }, {
        "text" : "K2aviation",
        "indices" : [ 32, 43 ]
      }, {
        "text" : "mountains",
        "indices" : [ 44, 54 ]
      }, {
        "text" : "glacier",
        "indices" : [ 55, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/DvfePujscq",
        "expanded_url" : "https:\/\/instagram.com\/p\/5ljuExgfOM\/",
        "display_url" : "instagram.com\/p\/5ljuExgfOM\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 62.604411952, -150.228779315 ]
    },
    "id_str" : "625168799969472512",
    "text" : "Just beautiful. #Alaska #Denali #K2aviation #mountains #glacier @ Denali National Park\/Mt. McKinley https:\/\/t.co\/DvfePujscq",
    "id" : 625168799969472512,
    "created_at" : "2015-07-26 05:00:31 +0000",
    "user" : {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "protected" : false,
      "id_str" : "433715578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469656620155154432\/1XOA8tYu_normal.jpeg",
      "id" : 433715578,
      "verified" : false
    }
  },
  "id" : 625184608821194753,
  "created_at" : "2015-07-26 06:03:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 3, 11 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Alaska",
      "indices" : [ 51, 58 ]
    }, {
      "text" : "mountains",
      "indices" : [ 59, 69 ]
    }, {
      "text" : "glacier",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/U5dSx93GLu",
      "expanded_url" : "https:\/\/instagram.com\/p\/5ljQUzgfNf\/",
      "display_url" : "instagram.com\/p\/5ljQUzgfNf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "625184547475329025",
  "text" : "RT @Gyselie: Ruth Glacier in Denali National Park. #Alaska #mountains #glacier @ Denali National Park\/Mt. McKinley https:\/\/t.co\/U5dSx93GLu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Alaska",
        "indices" : [ 38, 45 ]
      }, {
        "text" : "mountains",
        "indices" : [ 46, 56 ]
      }, {
        "text" : "glacier",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/U5dSx93GLu",
        "expanded_url" : "https:\/\/instagram.com\/p\/5ljQUzgfNf\/",
        "display_url" : "instagram.com\/p\/5ljQUzgfNf\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 62.604411952, -150.228779315 ]
    },
    "id_str" : "625167777905668097",
    "text" : "Ruth Glacier in Denali National Park. #Alaska #mountains #glacier @ Denali National Park\/Mt. McKinley https:\/\/t.co\/U5dSx93GLu",
    "id" : 625167777905668097,
    "created_at" : "2015-07-26 04:56:27 +0000",
    "user" : {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "protected" : false,
      "id_str" : "433715578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469656620155154432\/1XOA8tYu_normal.jpeg",
      "id" : 433715578,
      "verified" : false
    }
  },
  "id" : 625184547475329025,
  "created_at" : "2015-07-26 06:03:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/K4xGdSp3y6",
      "expanded_url" : "https:\/\/twitter.com\/Appleguysnake\/status\/624256991838511104",
      "display_url" : "twitter.com\/Appleguysnake\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624365855888031744",
  "text" : "The wheel's traction proves to be !equal to realistic, but that is often where great entertainment can be found. https:\/\/t.co\/K4xGdSp3y6",
  "id" : 624365855888031744,
  "created_at" : "2015-07-23 23:49:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandraBland",
      "indices" : [ 35, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624243741226721281",
  "text" : "Women found dead in her mug shot.  #SandraBland",
  "id" : 624243741226721281,
  "created_at" : "2015-07-23 15:44:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623903905789796353",
  "text" : "going crazy staying sane",
  "id" : 623903905789796353,
  "created_at" : "2015-07-22 17:14:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 9, 21 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623858957811998720",
  "geo" : { },
  "id_str" : "623900242065293312",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee @dominictarr DID SOMEBODY SAY BITCOIN?",
  "id" : 623900242065293312,
  "in_reply_to_status_id" : 623858957811998720,
  "created_at" : "2015-07-22 16:59:43 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623202057705488384",
  "text" : "MAMA MESIS",
  "id" : 623202057705488384,
  "created_at" : "2015-07-20 18:45:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622226541028585474",
  "text" : "One order of magnitude, coming right up.",
  "id" : 622226541028585474,
  "created_at" : "2015-07-18 02:09:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622153785796771840",
  "geo" : { },
  "id_str" : "622155106591490049",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  see you where!",
  "id" : 622155106591490049,
  "in_reply_to_status_id" : 622153785796771840,
  "created_at" : "2015-07-17 21:25:11 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622118470201683968",
  "geo" : { },
  "id_str" : "622153439154274304",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  you have chosen the only good reason to move to the east coast, although that reasoning could take you anywhere.",
  "id" : 622153439154274304,
  "in_reply_to_status_id" : 622118470201683968,
  "created_at" : "2015-07-17 21:18:33 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621841587954323458",
  "geo" : { },
  "id_str" : "621910401769320449",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  the last comment",
  "id" : 621910401769320449,
  "in_reply_to_status_id" : 621841587954323458,
  "created_at" : "2015-07-17 05:12:48 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 3, 14 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621707793733562369",
  "text" : "RT @Satoshi_N_: You're only free to say anything when no one truly knows who you are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621533249198686209",
    "text" : "You're only free to say anything when no one truly knows who you are.",
    "id" : 621533249198686209,
    "created_at" : "2015-07-16 04:14:08 +0000",
    "user" : {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "protected" : false,
      "id_str" : "2375721396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727448034024525825\/nxaF8tNf_normal.jpg",
      "id" : 2375721396,
      "verified" : false
    }
  },
  "id" : 621707793733562369,
  "created_at" : "2015-07-16 15:47:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621527459897307137",
  "text" : "THE DUALITY OF STEREO vs THE OUINESS OF MONO",
  "id" : 621527459897307137,
  "created_at" : "2015-07-16 03:51:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621526741853433856",
  "text" : "ZOMBIES WIN",
  "id" : 621526741853433856,
  "created_at" : "2015-07-16 03:48:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621524405680615425",
  "text" : "ERRBODY TOO BUSY WORKING TO FIGURE OUT HOW TO MAKE THIS LIFE BETTER.  LUCKILY, I BEEN EMPLOYED IN THAT BUSINESS SINCE FOREVER N I AINT QUIT,",
  "id" : 621524405680615425,
  "created_at" : "2015-07-16 03:39:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621377180241559553",
  "geo" : { },
  "id_str" : "621377801929625600",
  "in_reply_to_user_id" : 46961216,
  "text" : "ask me how",
  "id" : 621377801929625600,
  "in_reply_to_status_id" : 621377180241559553,
  "created_at" : "2015-07-15 17:56:27 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621377180241559553",
  "text" : "grotesquewmorphism",
  "id" : 621377180241559553,
  "created_at" : "2015-07-15 17:53:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621199674230177792",
  "text" : "who can hack, can fight back",
  "id" : 621199674230177792,
  "created_at" : "2015-07-15 06:08:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621155158118961152",
  "geo" : { },
  "id_str" : "621158619657015296",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  now I understand what xargs does",
  "id" : 621158619657015296,
  "in_reply_to_status_id" : 621155158118961152,
  "created_at" : "2015-07-15 03:25:30 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 0, 11 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620726203570388992",
  "geo" : { },
  "id_str" : "620729222546362368",
  "in_reply_to_user_id" : 2375721396,
  "text" : "@Satoshi_N_  great now they can trace you",
  "id" : 620729222546362368,
  "in_reply_to_status_id" : 620726203570388992,
  "created_at" : "2015-07-13 22:59:13 +0000",
  "in_reply_to_screen_name" : "Satoshi_N_",
  "in_reply_to_user_id_str" : "2375721396",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620678971538018304",
  "geo" : { },
  "id_str" : "620704058425249792",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  drop out!",
  "id" : 620704058425249792,
  "in_reply_to_status_id" : 620678971538018304,
  "created_at" : "2015-07-13 21:19:14 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620702164327903232",
  "geo" : { },
  "id_str" : "620703664672407552",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs  I will help produce \"yoga ball\".  We need more dances.   There are not enough dances.",
  "id" : 620703664672407552,
  "in_reply_to_status_id" : 620702164327903232,
  "created_at" : "2015-07-13 21:17:40 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620499515607379969",
  "text" : "How does one teach a computer that it already possesses all knowledge?",
  "id" : 620499515607379969,
  "created_at" : "2015-07-13 07:46:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620497996375941120",
  "text" : "i want machines to learn how to plot graphs for me data idgaf",
  "id" : 620497996375941120,
  "created_at" : "2015-07-13 07:40:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620348095511986181",
  "text" : "Tests are where abstractions go to calcify.",
  "id" : 620348095511986181,
  "created_at" : "2015-07-12 21:44:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Zivarts",
      "screen_name" : "annabikes",
      "indices" : [ 3, 13 ],
      "id_str" : "44379664",
      "id" : 44379664
    }, {
      "name" : "Michael Farrell",
      "screen_name" : "mikefarrell",
      "indices" : [ 99, 111 ],
      "id_str" : "359524790",
      "id" : 359524790
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mikefarrell\/status\/532324242444922880\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/2fE0GNWlwK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2MyE9SCIAAaYZ1.jpg",
      "id_str" : "532324241710915584",
      "id" : 532324241710915584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2MyE9SCIAAaYZ1.jpg",
      "sizes" : [ {
        "h" : 462,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 586
      } ],
      "display_url" : "pic.twitter.com\/2fE0GNWlwK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620093616363433985",
  "text" : "RT @annabikes: Brilliant visual of how much public space we cede to cars http:\/\/t.co\/2fE0GNWlwK ht @mikefarrell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Farrell",
        "screen_name" : "mikefarrell",
        "indices" : [ 84, 96 ],
        "id_str" : "359524790",
        "id" : 359524790
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mikefarrell\/status\/532324242444922880\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/2fE0GNWlwK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2MyE9SCIAAaYZ1.jpg",
        "id_str" : "532324241710915584",
        "id" : 532324241710915584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2MyE9SCIAAaYZ1.jpg",
        "sizes" : [ {
          "h" : 462,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 586
        } ],
        "display_url" : "pic.twitter.com\/2fE0GNWlwK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532583894252806144",
    "text" : "Brilliant visual of how much public space we cede to cars http:\/\/t.co\/2fE0GNWlwK ht @mikefarrell",
    "id" : 532583894252806144,
    "created_at" : "2014-11-12 17:21:09 +0000",
    "user" : {
      "name" : "Anna Zivarts",
      "screen_name" : "annabikes",
      "protected" : false,
      "id_str" : "44379664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658269153648885760\/RzWjBihi_normal.jpg",
      "id" : 44379664,
      "verified" : false
    }
  },
  "id" : 620093616363433985,
  "created_at" : "2015-07-12 04:53:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619776456520896512",
  "text" : "a boogly boogly boop boo yeah",
  "id" : 619776456520896512,
  "created_at" : "2015-07-11 07:53:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619693776391401472",
  "text" : "I want to dance tonight",
  "id" : 619693776391401472,
  "created_at" : "2015-07-11 02:24:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 0, 11 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619245100330168321",
  "in_reply_to_user_id" : 2375721396,
  "text" : "@Satoshi_N_  should I use counterparty?  Is there another way to do BTC asset stuff?  domo arigato.",
  "id" : 619245100330168321,
  "created_at" : "2015-07-09 20:41:51 +0000",
  "in_reply_to_screen_name" : "Satoshi_N_",
  "in_reply_to_user_id_str" : "2375721396",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/619209374549037057\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/bPjXdSJQPI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJffpQ_WoAMIw7Z.png",
      "id_str" : "619209373815054339",
      "id" : 619209373815054339,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJffpQ_WoAMIw7Z.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 101,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 795
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 795
      } ],
      "display_url" : "pic.twitter.com\/bPjXdSJQPI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619209374549037057",
  "text" : "This is what a gal puts up with.  Just want to keep my hands clean of neurotoxin, but get treated like a drug addict. http:\/\/t.co\/bPjXdSJQPI",
  "id" : 619209374549037057,
  "created_at" : "2015-07-09 18:19:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "no",
      "screen_name" : "the_N0",
      "indices" : [ 3, 10 ],
      "id_str" : "42699163",
      "id" : 42699163
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/the_N0\/status\/618953993033682944\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/X26pXLEcrn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJb3XjhUkAA0WZT.jpg",
      "id_str" : "618953982854074368",
      "id" : 618953982854074368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJb3XjhUkAA0WZT.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/X26pXLEcrn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619038418316627968",
  "text" : "RT @the_N0: http:\/\/t.co\/X26pXLEcrn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/the_N0\/status\/618953993033682944\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/X26pXLEcrn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJb3XjhUkAA0WZT.jpg",
        "id_str" : "618953982854074368",
        "id" : 618953982854074368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJb3XjhUkAA0WZT.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/X26pXLEcrn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618953993033682944",
    "text" : "http:\/\/t.co\/X26pXLEcrn",
    "id" : 618953993033682944,
    "created_at" : "2015-07-09 01:25:06 +0000",
    "user" : {
      "name" : "no",
      "screen_name" : "the_N0",
      "protected" : false,
      "id_str" : "42699163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728259978042085376\/NvWyFg0v_normal.jpg",
      "id" : 42699163,
      "verified" : false
    }
  },
  "id" : 619038418316627968,
  "created_at" : "2015-07-09 07:00:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 3, 14 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618901255126016000",
  "text" : "RT @whichlight: @johnnyscript woooooaaahahhhhhhhhhhhhh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "618894871848300545",
    "geo" : { },
    "id_str" : "618895454269390848",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript woooooaaahahhhhhhhhhhhhh",
    "id" : 618895454269390848,
    "in_reply_to_status_id" : 618894871848300545,
    "created_at" : "2015-07-08 21:32:29 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "protected" : false,
      "id_str" : "17092251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582894470452133888\/uBlV4V8-_normal.jpg",
      "id" : 17092251,
      "verified" : false
    }
  },
  "id" : 618901255126016000,
  "created_at" : "2015-07-08 21:55:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "syncrelodeon",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/3Lg1GmIduz",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/whistle-claps",
      "display_url" : "soundcloud.com\/folkstack\/whis\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "618891543936503808",
  "geo" : { },
  "id_str" : "618894871848300545",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  meanwhile I had jus finished clapping my hands and whistling into an algorithm #syncrelodeon https:\/\/t.co\/3Lg1GmIduz",
  "id" : 618894871848300545,
  "in_reply_to_status_id" : 618891543936503808,
  "created_at" : "2015-07-08 21:30:10 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618872265791418368",
  "geo" : { },
  "id_str" : "618890694568968192",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  dp deep dp deepy, duh deep d' deep",
  "id" : 618890694568968192,
  "in_reply_to_status_id" : 618872265791418368,
  "created_at" : "2015-07-08 21:13:34 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618860063390859264",
  "geo" : { },
  "id_str" : "618871761770278912",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  MC KA-1 Deep Verde",
  "id" : 618871761770278912,
  "in_reply_to_status_id" : 618860063390859264,
  "created_at" : "2015-07-08 19:58:20 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618674098386788356",
  "geo" : { },
  "id_str" : "618680837249216512",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso metamorphosis",
  "id" : 618680837249216512,
  "in_reply_to_status_id" : 618674098386788356,
  "created_at" : "2015-07-08 07:19:40 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/xc7hJup4AW",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/stand-by",
      "display_url" : "soundcloud.com\/folkstack\/stan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618678664079650816",
  "text" : "RT @folkstack: CASTING PEARLS BEFORE SWINE https:\/\/t.co\/xc7hJup4AW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/xc7hJup4AW",
        "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/stand-by",
        "display_url" : "soundcloud.com\/folkstack\/stan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618252158408900608",
    "text" : "CASTING PEARLS BEFORE SWINE https:\/\/t.co\/xc7hJup4AW",
    "id" : 618252158408900608,
    "created_at" : "2015-07-07 02:56:15 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 618678664079650816,
  "created_at" : "2015-07-08 07:11:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30CF\u30E8\u30CA\u30AA",
      "screen_name" : "mohayonao",
      "indices" : [ 3, 13 ],
      "id_str" : "27622871",
      "id" : 27622871
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mohayonao\/status\/618591433327382528\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/vddDBVnoDV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJWtoVcUMAAcf3b.png",
      "id_str" : "618591432295591936",
      "id" : 618591432295591936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJWtoVcUMAAcf3b.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1001,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1001,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vddDBVnoDV"
    } ],
    "hashtags" : [ {
      "text" : "\u306F\u3066\u306A\u30D6\u30ED\u30B0",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/vGUqDL1BQA",
      "expanded_url" : "http:\/\/mohayonao.hatenablog.com\/entry\/2015\/07\/08\/102401",
      "display_url" : "mohayonao.hatenablog.com\/entry\/2015\/07\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618596201785655296",
  "text" : "RT @mohayonao: \u306F\u3066\u306A\u30D6\u30ED\u30B0\u306B\u6295\u7A3F\u3057\u307E\u3057\u305F #\u306F\u3066\u306A\u30D6\u30ED\u30B0\nWebMusic\u30CF\u30C3\u30AB\u30BD\u30F3\u3067\u4F7F\u3048\u305D\u3046\u306A\u4FFA\u4FFA\u30E9\u30A4\u30D6\u30E9\u30EA 5\u9078 - \u97F3\u306E\u9CF4\u308B\u30D6\u30ED\u30B0\nhttp:\/\/t.co\/vGUqDL1BQA http:\/\/t.co\/vddDBVnoDV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hatena.ne.jp\/guide\/twitter\" rel=\"nofollow\"\u003EHatena\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mohayonao\/status\/618591433327382528\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/vddDBVnoDV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJWtoVcUMAAcf3b.png",
        "id_str" : "618591432295591936",
        "id" : 618591432295591936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJWtoVcUMAAcf3b.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1001,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1001,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/vddDBVnoDV"
      } ],
      "hashtags" : [ {
        "text" : "\u306F\u3066\u306A\u30D6\u30ED\u30B0",
        "indices" : [ 14, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/vGUqDL1BQA",
        "expanded_url" : "http:\/\/mohayonao.hatenablog.com\/entry\/2015\/07\/08\/102401",
        "display_url" : "mohayonao.hatenablog.com\/entry\/2015\/07\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618591433327382528",
    "text" : "\u306F\u3066\u306A\u30D6\u30ED\u30B0\u306B\u6295\u7A3F\u3057\u307E\u3057\u305F #\u306F\u3066\u306A\u30D6\u30ED\u30B0\nWebMusic\u30CF\u30C3\u30AB\u30BD\u30F3\u3067\u4F7F\u3048\u305D\u3046\u306A\u4FFA\u4FFA\u30E9\u30A4\u30D6\u30E9\u30EA 5\u9078 - \u97F3\u306E\u9CF4\u308B\u30D6\u30ED\u30B0\nhttp:\/\/t.co\/vGUqDL1BQA http:\/\/t.co\/vddDBVnoDV",
    "id" : 618591433327382528,
    "created_at" : "2015-07-08 01:24:25 +0000",
    "user" : {
      "name" : "\u30E2\u30CF\u30E8\u30CA\u30AA",
      "screen_name" : "mohayonao",
      "protected" : false,
      "id_str" : "27622871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1203144390\/mohayonao180x180hand_normal.png",
      "id" : 27622871,
      "verified" : false
    }
  },
  "id" : 618596201785655296,
  "created_at" : "2015-07-08 01:43:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 3, 11 ],
      "id_str" : "19417999",
      "id" : 19417999
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PROBLEM354\/status\/617890914694860800\/video\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/i5lE8PIqjU",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/617885582631436288\/pu\/img\/lOu73SFinRgsvAZL.jpg",
      "id_str" : "617885582631436288",
      "id" : 617885582631436288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/617885582631436288\/pu\/img\/lOu73SFinRgsvAZL.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/i5lE8PIqjU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618594949341315076",
  "text" : "RT @DaMFunK: From A G perspective: https:\/\/t.co\/i5lE8PIqjU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PROBLEM354\/status\/617890914694860800\/video\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/i5lE8PIqjU",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/617885582631436288\/pu\/img\/lOu73SFinRgsvAZL.jpg",
        "id_str" : "617885582631436288",
        "id" : 617885582631436288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/617885582631436288\/pu\/img\/lOu73SFinRgsvAZL.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/i5lE8PIqjU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618561837496320000",
    "text" : "From A G perspective: https:\/\/t.co\/i5lE8PIqjU",
    "id" : 618561837496320000,
    "created_at" : "2015-07-07 23:26:49 +0000",
    "user" : {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "protected" : false,
      "id_str" : "19417999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727729991186825216\/fKFPEbre_normal.jpg",
      "id" : 19417999,
      "verified" : true
    }
  },
  "id" : 618594949341315076,
  "created_at" : "2015-07-08 01:38:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618505239155511296",
  "text" : "When you phrase your ask \"do you mind...\" you force others to respond with a negative **to answer positively**, depriving them of pleasure.",
  "id" : 618505239155511296,
  "created_at" : "2015-07-07 19:41:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618499711482224640",
  "text" : "\"social security\" was such a linguistic terror plot.  It is anti-social, disintegrating, to rely on money and market services to survive.",
  "id" : 618499711482224640,
  "created_at" : "2015-07-07 19:19:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/qxbdl1AL7r",
      "expanded_url" : "https:\/\/archive.org\/details\/elementsofacoust00olso",
      "display_url" : "archive.org\/details\/elemen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618079433862180864",
  "text" : "\"elements of acoustical engineering\"\n\nhttps:\/\/t.co\/qxbdl1AL7r",
  "id" : 618079433862180864,
  "created_at" : "2015-07-06 15:29:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617769786722811904",
  "text" : "GREEK SOLIDARITY.  THE PLYMOUTH ROCK OF WESTERN CIV IS GIVING THE FINGER.  MY GREEKS, I WAVE THY FLAG FOR THEE.",
  "id" : 617769786722811904,
  "created_at" : "2015-07-05 18:59:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617769156931227648",
  "text" : "the new patriotism allows you to wave other people's flags only.  nobody waving your flag?  don't talk to me!",
  "id" : 617769156931227648,
  "created_at" : "2015-07-05 18:56:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/2jdVXTS2e2",
      "expanded_url" : "http:\/\/www.nakedcapitalism.com\/2015\/07\/why-dont-americans-take-more-vacations-blame-it-on-independence-day-2.html",
      "display_url" : "nakedcapitalism.com\/2015\/07\/why-do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617412279290589184",
  "text" : "Haha you dumb muffhuckers.  The 4th of July, as a holiday, is a creation of CIA propaganda at the behest of BIGBIZ. \n\nhttp:\/\/t.co\/2jdVXTS2e2",
  "id" : 617412279290589184,
  "created_at" : "2015-07-04 19:18:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617034629443227648",
  "text" : "Expunge \"allow\" from your lexicon, banish it forever.",
  "id" : 617034629443227648,
  "created_at" : "2015-07-03 18:18:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/nU1iewkgR1",
      "expanded_url" : "https:\/\/soundcloud.com\/dominictarr\/sets\/ladies-in-my-life",
      "display_url" : "soundcloud.com\/dominictarr\/se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616807270848958464",
  "text" : "RT @dominictarr: I just stayed up all night listening to ALL the Lady In My Life covers on soundcloud.\nHere are the best 18\nhttps:\/\/t.co\/nU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/nU1iewkgR1",
        "expanded_url" : "https:\/\/soundcloud.com\/dominictarr\/sets\/ladies-in-my-life",
        "display_url" : "soundcloud.com\/dominictarr\/se\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616799220138385412",
    "text" : "I just stayed up all night listening to ALL the Lady In My Life covers on soundcloud.\nHere are the best 18\nhttps:\/\/t.co\/nU1iewkgR1",
    "id" : 616799220138385412,
    "created_at" : "2015-07-03 02:42:48 +0000",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712569197126160384\/nvnXBzt-_normal.jpg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 616807270848958464,
  "created_at" : "2015-07-03 03:14:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616339998854361088",
  "text" : "hackistani house show tonight fruitvale w\/ lovely singers, artists, musicians.  psyche outs, deep bass, and endless edifying grooves.",
  "id" : 616339998854361088,
  "created_at" : "2015-07-01 20:18:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616156452839780352",
  "text" : "The Underground Superhighway",
  "id" : 616156452839780352,
  "created_at" : "2015-07-01 08:08:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616132495206002688",
  "text" : "change\ndon't ever change",
  "id" : 616132495206002688,
  "created_at" : "2015-07-01 06:33:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]