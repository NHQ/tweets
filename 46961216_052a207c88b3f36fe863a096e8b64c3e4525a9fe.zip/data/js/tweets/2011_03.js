Grailbird.data.tweets_2011_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 0, 10 ],
      "id_str" : "15865878",
      "id" : 15865878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51764763448971264",
  "in_reply_to_user_id" : 15865878,
  "text" : "@NiemanLab i like to go to the multiperspectival with my friends, ride mechanical toys like a kid, and eat funnel cakes 3-ways",
  "id" : 51764763448971264,
  "created_at" : "2011-03-26 21:57:36 +0000",
  "in_reply_to_screen_name" : "NiemanLab",
  "in_reply_to_user_id_str" : "15865878",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 0, 10 ],
      "id_str" : "15865878",
      "id" : 15865878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "51689979763634176",
  "geo" : { },
  "id_str" : "51762966210691072",
  "in_reply_to_user_id" : 15865878,
  "text" : "@NiemanLab \"multiperspectival\"",
  "id" : 51762966210691072,
  "in_reply_to_status_id" : 51689979763634176,
  "created_at" : "2011-03-26 21:50:27 +0000",
  "in_reply_to_screen_name" : "NiemanLab",
  "in_reply_to_user_id_str" : "15865878",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "51430243256385536",
  "text" : "and described a chemical kinetic model of point-like charges obeying the Onsager\u2013Wien mechanism of carrier dissociation and recombination.",
  "id" : 51430243256385536,
  "created_at" : "2011-03-25 23:48:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47474926759837696",
  "text" : "alien EM goose pimples",
  "id" : 47474926759837696,
  "created_at" : "2011-03-15 01:51:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "47105059024142336",
  "text" : "There are boats in parking lots in japan.",
  "id" : 47105059024142336,
  "created_at" : "2011-03-14 01:21:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Zamora",
      "screen_name" : "jczamora",
      "indices" : [ 0, 9 ],
      "id_str" : "14305753",
      "id" : 14305753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46036252205662210",
  "geo" : { },
  "id_str" : "46348169688260608",
  "in_reply_to_user_id" : 14305753,
  "text" : "@jczamora did you get the follow up from Maria with the details?",
  "id" : 46348169688260608,
  "in_reply_to_status_id" : 46036252205662210,
  "created_at" : "2011-03-11 23:13:59 +0000",
  "in_reply_to_screen_name" : "jczamora",
  "in_reply_to_user_id_str" : "14305753",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Zamora",
      "screen_name" : "jczamora",
      "indices" : [ 0, 9 ],
      "id_str" : "14305753",
      "id" : 14305753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "46036252205662210",
  "geo" : { },
  "id_str" : "46055522855686144",
  "in_reply_to_user_id" : 14305753,
  "text" : "@jczamora thx. should be coming to you via Maria Thomas.",
  "id" : 46055522855686144,
  "in_reply_to_status_id" : 46036252205662210,
  "created_at" : "2011-03-11 03:51:06 +0000",
  "in_reply_to_screen_name" : "jczamora",
  "in_reply_to_user_id_str" : "14305753",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. SunWolf",
      "screen_name" : "TheSocialBrain",
      "indices" : [ 3, 18 ],
      "id_str" : "43540843",
      "id" : 43540843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "46049879029596160",
  "text" : "RT @TheSocialBrain: \u007BCan pain relieve guilt?\u007D Subjecting ourselves to bodily pain might reduce guilt about immoral acts. New study: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "46043220714598400",
    "text" : "\u007BCan pain relieve guilt?\u007D Subjecting ourselves to bodily pain might reduce guilt about immoral acts. New study: http:\/\/alturl.com\/je6a6",
    "id" : 46043220714598400,
    "created_at" : "2011-03-11 03:02:13 +0000",
    "user" : {
      "name" : "Dr. SunWolf",
      "screen_name" : "TheSocialBrain",
      "protected" : false,
      "id_str" : "43540843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448478339\/langcolor_normal.jpg",
      "id" : 43540843,
      "verified" : false
    }
  },
  "id" : 46049879029596160,
  "created_at" : "2011-03-11 03:28:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Zamora",
      "screen_name" : "jczamora",
      "indices" : [ 0, 9 ],
      "id_str" : "14305753",
      "id" : 14305753
    }, {
      "name" : "Knight Foundation",
      "screen_name" : "knightfdn",
      "indices" : [ 10, 20 ],
      "id_str" : "14073364",
      "id" : 14073364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45987449087864834",
  "geo" : { },
  "id_str" : "46011762671226880",
  "in_reply_to_user_id" : 14305753,
  "text" : "@jczamora @knightfdn I sent an email thru the Knight News Challenge website contact regarding my missing application. can I get a contact?",
  "id" : 46011762671226880,
  "in_reply_to_status_id" : 45987449087864834,
  "created_at" : "2011-03-11 00:57:13 +0000",
  "in_reply_to_screen_name" : "jczamora",
  "in_reply_to_user_id_str" : "14305753",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "45744783557279744",
  "text" : "rationing apples is more than a band name",
  "id" : 45744783557279744,
  "created_at" : "2011-03-10 07:16:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "45678254702596096",
  "geo" : { },
  "id_str" : "45679191257137152",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk may you answer a quick javascript question from a fan?",
  "id" : 45679191257137152,
  "in_reply_to_status_id" : 45678254702596096,
  "created_at" : "2011-03-10 02:55:42 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u10E7\u0308n Haverbeke",
      "screen_name" : "marijnjh",
      "indices" : [ 0, 9 ],
      "id_str" : "47585779",
      "id" : 47585779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44292940406861824",
  "geo" : { },
  "id_str" : "44295732861206528",
  "in_reply_to_user_id" : 47585779,
  "text" : "@marijnjh But... what is there... besides javascript?",
  "id" : 44295732861206528,
  "in_reply_to_status_id" : 44292940406861824,
  "created_at" : "2011-03-06 07:18:20 +0000",
  "in_reply_to_screen_name" : "marijnjh",
  "in_reply_to_user_id_str" : "47585779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mar\u10E7\u0308n Haverbeke",
      "screen_name" : "marijnjh",
      "indices" : [ 3, 12 ],
      "id_str" : "47585779",
      "id" : 47585779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44295567257513984",
  "text" : "RT @marijnjh: It's official and it's public: I am joining the Rust team at Mozilla. This will be fun. https:\/\/github.com\/graydon\/rust",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "44292940406861824",
    "text" : "It's official and it's public: I am joining the Rust team at Mozilla. This will be fun. https:\/\/github.com\/graydon\/rust",
    "id" : 44292940406861824,
    "created_at" : "2011-03-06 07:07:14 +0000",
    "user" : {
      "name" : "Mar\u10E7\u0308n Haverbeke",
      "screen_name" : "marijnjh",
      "protected" : false,
      "id_str" : "47585779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2033010624\/pic_normal.jpg",
      "id" : 47585779,
      "verified" : false
    }
  },
  "id" : 44295567257513984,
  "created_at" : "2011-03-06 07:17:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44288368263184384",
  "text" : "tired of panicking when hunger strikes, alone in NYC, unable to decide where and what to eat. bought a jar of peanut butter 2 carry with me.",
  "id" : 44288368263184384,
  "created_at" : "2011-03-06 06:49:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44285159058579456",
  "geo" : { },
  "id_str" : "44286067041513472",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin taken care of course",
  "id" : 44286067041513472,
  "in_reply_to_status_id" : 44285159058579456,
  "created_at" : "2011-03-06 06:39:55 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44275284916043776",
  "geo" : { },
  "id_str" : "44284688101163008",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin but its also on a mountainside surrounded by verdure where the air smells sweet of flowers. Hippy neighborhood now.",
  "id" : 44284688101163008,
  "in_reply_to_status_id" : 44275284916043776,
  "created_at" : "2011-03-06 06:34:27 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 15, 20 ]
    }, {
      "text" : "power",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44262433451278336",
  "text" : "We've got love\n#love\nPOWER\n#power\nIt's the greatest power of them all\nPut yr hands up in the air\nrepeat",
  "id" : 44262433451278336,
  "created_at" : "2011-03-06 05:06:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44261709145321472",
  "text" : "just me and arikaa baambaataa and me. dark matter moving at the speed of light.",
  "id" : 44261709145321472,
  "created_at" : "2011-03-06 05:03:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mum1Detail",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44251371511361536",
  "geo" : { },
  "id_str" : "44261388205555712",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin his house has floor2ceiling mirrors everywhere including the bathroom\/tub\/toilet. is 70s cocaine-riche. #mum1Detail",
  "id" : 44261388205555712,
  "in_reply_to_status_id" : 44251371511361536,
  "created_at" : "2011-03-06 05:01:51 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44224524203466752",
  "geo" : { },
  "id_str" : "44226871650557954",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin I'm at office. Was here earlier. Just got back. Took mid day off. stayed last night @ jareds in laurel canyon",
  "id" : 44226871650557954,
  "in_reply_to_status_id" : 44224524203466752,
  "created_at" : "2011-03-06 02:44:42 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "44223959343968256",
  "text" : "it helps to remember that 3 million is only 1\/100th of the population of the USA, or 1 small percent",
  "id" : 44223959343968256,
  "created_at" : "2011-03-06 02:33:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "44221733485555712",
  "geo" : { },
  "id_str" : "44222583775830016",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin hola mami",
  "id" : 44222583775830016,
  "in_reply_to_status_id" : 44221733485555712,
  "created_at" : "2011-03-06 02:27:40 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43136105528307713",
  "text" : "Clever Algorithms: Nature-Inspired Programming Recipes  http:\/\/www.lulu.com\/items\/volume_69\/10078000\/10078410\/1\/print\/paperback_20110125.pdf",
  "id" : 43136105528307713,
  "created_at" : "2011-03-03 02:30:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43117097995337728",
  "geo" : { },
  "id_str" : "43118047984234497",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk that's why companies have technical writers",
  "id" : 43118047984234497,
  "in_reply_to_status_id" : 43117097995337728,
  "created_at" : "2011-03-03 01:18:38 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43114404518178816",
  "geo" : { },
  "id_str" : "43116470024151040",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin no wifi in the airport?",
  "id" : 43116470024151040,
  "in_reply_to_status_id" : 43114404518178816,
  "created_at" : "2011-03-03 01:12:22 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "43102327258873856",
  "geo" : { },
  "id_str" : "43103454390005760",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb see you got bird names on the bill chicago repn",
  "id" : 43103454390005760,
  "in_reply_to_status_id" : 43102327258873856,
  "created_at" : "2011-03-03 00:20:39 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43103082824994816",
  "text" : "brief history of USA death industry video http:\/\/vimeo.com\/20419171 see how we're done!",
  "id" : 43103082824994816,
  "created_at" : "2011-03-03 00:19:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "javascript",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "43036097617473536",
  "text" : "can we call an arrays of arrays an array-ray? #javascript #nodejs",
  "id" : 43036097617473536,
  "created_at" : "2011-03-02 19:52:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]