Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64474069101330432",
  "geo" : { },
  "id_str" : "64530241024036864",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin http:\/\/curiositycounts.com\/post\/5049135006\/jell-o-bouncing-in-ultra-slow-motion-at-6200-fps",
  "id" : 64530241024036864,
  "in_reply_to_status_id" : 64474069101330432,
  "created_at" : "2011-05-01 03:23:03 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "marak squires",
      "screen_name" : "maraksquires",
      "indices" : [ 18, 31 ],
      "id_str" : "745792987",
      "id" : 745792987
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64432215685201920",
  "in_reply_to_user_id" : 58809542,
  "text" : "@angelinegragzin \u201C@maraksquires: I need a good female voice for the hook on the next #nodejs rap. Hit me up if u can drop some remote lyrics",
  "id" : 64432215685201920,
  "created_at" : "2011-04-30 20:53:31 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http:\/\/t.co\/BMQG8fd",
      "expanded_url" : "http:\/\/mozillalabs.com\/chromeless\/2011\/04\/29\/chromeless-0-2\/",
      "display_url" : "mozillalabs.com\/chromeless\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "64066142599266305",
  "text" : "we need one of these with nodejs in it #nodejs http:\/\/t.co\/BMQG8fd",
  "id" : 64066142599266305,
  "created_at" : "2011-04-29 20:38:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 15, 31 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http:\/\/t.co\/5IPNwfH",
      "expanded_url" : "http:\/\/bit.ly\/kfNNbu",
      "display_url" : "bit.ly\/kfNNbu"
    } ]
  },
  "geo" : { },
  "id_str" : "64042843920007169",
  "text" : "werner herzog! @angelinegragzin http:\/\/t.co\/5IPNwfH",
  "id" : 64042843920007169,
  "created_at" : "2011-04-29 19:06:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64034625059684352",
  "text" : "It is good to think about what you must accomplish today. That is what I will be doing today.",
  "id" : 64034625059684352,
  "created_at" : "2011-04-29 18:33:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samy Kamkar",
      "screen_name" : "samykamkar",
      "indices" : [ 3, 14 ],
      "id_str" : "15092452",
      "id" : 15092452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63828040177827841",
  "text" : "RT @samykamkar: iPhone sends cell tower + wifi info to Apple, even with GPS off. Locate via cell http:\/\/samy.pl\/cellmap or wifi http:\/\/s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63717064241721344",
    "text" : "iPhone sends cell tower + wifi info to Apple, even with GPS off. Locate via cell http:\/\/samy.pl\/cellmap or wifi http:\/\/samy.pl\/androidmap",
    "id" : 63717064241721344,
    "created_at" : "2011-04-28 21:31:46 +0000",
    "user" : {
      "name" : "Samy Kamkar",
      "screen_name" : "samykamkar",
      "protected" : false,
      "id_str" : "15092452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427715845469392896\/AdPfbXVY_normal.png",
      "id" : 15092452,
      "verified" : false
    }
  },
  "id" : 63828040177827841,
  "created_at" : "2011-04-29 04:52:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63768069637545984",
  "text" : "sick of journalists and editors declaring how and why in titles",
  "id" : 63768069637545984,
  "created_at" : "2011-04-29 00:54:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Plait",
      "screen_name" : "BadAstronomer",
      "indices" : [ 3, 17 ],
      "id_str" : "4620451",
      "id" : 4620451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63472871812509696",
  "text" : "RT @BadAstronomer: China to build a space station by 2021? http:\/\/is.gd\/3I8bwn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63354035717152768",
    "text" : "China to build a space station by 2021? http:\/\/is.gd\/3I8bwn",
    "id" : 63354035717152768,
    "created_at" : "2011-04-27 21:29:13 +0000",
    "user" : {
      "name" : "Phil Plait",
      "screen_name" : "BadAstronomer",
      "protected" : false,
      "id_str" : "4620451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680871217516052480\/aZf1lCDR_normal.jpg",
      "id" : 4620451,
      "verified" : true
    }
  },
  "id" : 63472871812509696,
  "created_at" : "2011-04-28 05:21:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nerdist News Node",
      "screen_name" : "node",
      "indices" : [ 4, 9 ],
      "id_str" : "94228202",
      "id" : 94228202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63046438216667136",
  "text" : "hey @node I just moved away from Chicago. Who'se nodeling in LA???",
  "id" : 63046438216667136,
  "created_at" : "2011-04-27 01:06:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63038873579692032",
  "text" : "We'd need eyes the size of the sun to even begin scaling our mind to fit the universe.",
  "id" : 63038873579692032,
  "created_at" : "2011-04-27 00:36:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63037992889102336",
  "text" : "Also the big bang theory is a less believable yarn than noah and the ark.",
  "id" : 63037992889102336,
  "created_at" : "2011-04-27 00:33:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63037631960858625",
  "text" : "Dark matter is a chimera. Its creator was gravity.",
  "id" : 63037631960858625,
  "created_at" : "2011-04-27 00:31:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sony",
      "indices" : [ 114, 119 ]
    }, {
      "text" : "playstation",
      "indices" : [ 120, 132 ]
    }, {
      "text" : "anon",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62953042634477568",
  "text" : "vigilante hack attacks on big incorporated's vital internet businesses is a welcome relief, a service to humanity #sony #playstation #anon",
  "id" : 62953042634477568,
  "created_at" : "2011-04-26 18:55:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62920814244278272",
  "geo" : { },
  "id_str" : "62951121165107200",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk AWS HELL NAW!",
  "id" : 62951121165107200,
  "in_reply_to_status_id" : 62920814244278272,
  "created_at" : "2011-04-26 18:48:11 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59778424088178689",
  "text" : "Cinderella 300+ ways http:\/\/www.archive.org\/details\/cinderellathreeh00coxmuoft",
  "id" : 59778424088178689,
  "created_at" : "2011-04-18 00:41:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59723368559157248",
  "text" : "2137: The Land of the Free",
  "id" : 59723368559157248,
  "created_at" : "2011-04-17 21:02:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59710568268959744",
  "text" : "Everybody in the mostmodernist office agree",
  "id" : 59710568268959744,
  "created_at" : "2011-04-17 20:11:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59710251921969152",
  "text" : "voice is the most under-appreciated objectifyable women part, and pop-music can be squarely blamed for it, as pop-viz is for rump and thies",
  "id" : 59710251921969152,
  "created_at" : "2011-04-17 20:10:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "merrill garbus",
      "screen_name" : "tuneyards",
      "indices" : [ 36, 46 ],
      "id_str" : "63858347",
      "id" : 63858347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59707212234375168",
  "text" : "song 3 on this new album WHOKILL by @tuneyards, called \"gansgta\" receives relative media score: one order of magnitude!",
  "id" : 59707212234375168,
  "created_at" : "2011-04-17 19:58:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "merrill garbus",
      "screen_name" : "tuneyards",
      "indices" : [ 54, 64 ],
      "id_str" : "63858347",
      "id" : 63858347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59705918195113985",
  "text" : "you're not tuned in to listening to this new album by @tuneyards like I am, so you have to tune in to me. this is what we call webv0.3.0",
  "id" : 59705918195113985,
  "created_at" : "2011-04-17 19:52:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "merrill garbus",
      "screen_name" : "tuneyards",
      "indices" : [ 74, 84 ],
      "id_str" : "63858347",
      "id" : 63858347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59705494088065024",
  "text" : "still haven't heard a TV-Radio song I like. switched rip. 30 seconds into @tuneyards i'm feeling it so I turnt it up http:\/\/tune-yards.com\/",
  "id" : 59705494088065024,
  "created_at" : "2011-04-17 19:51:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59705320074788864",
  "text" : "still haven't heard a TV-Radio song I like. switched rip.  30 seconds into tUnE-yArDs i'm feeling it so I turnt it up http:\/\/tune-yards.com\/",
  "id" : 59705320074788864,
  "created_at" : "2011-04-17 19:50:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59031974970523648",
  "geo" : { },
  "id_str" : "59066834825125889",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia whorish cloth, whorish tub, whorishing machine",
  "id" : 59066834825125889,
  "in_reply_to_status_id" : 59031974970523648,
  "created_at" : "2011-04-16 01:33:25 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 3, 14 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57884579184390144",
  "text" : "RT @grayamelia: feeling like a puppy flying through lasers right now",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57880162628415488",
    "text" : "feeling like a puppy flying through lasers right now",
    "id" : 57880162628415488,
    "created_at" : "2011-04-12 18:58:00 +0000",
    "user" : {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "protected" : false,
      "id_str" : "181328570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542768392499761152\/NN148tlm_normal.png",
      "id" : 181328570,
      "verified" : false
    }
  },
  "id" : 57884579184390144,
  "created_at" : "2011-04-12 19:15:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57531307533676544",
  "text" : "var get an office = go pro. stop working in your skivvies. increase productivity. Expand network. #nodejs 2\/8 spaces remain. all pro cohabs.",
  "id" : 57531307533676544,
  "created_at" : "2011-04-11 19:51:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "rsvp",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57530882373844992",
  "text" : "LA node hackers. Want to work in a nice office? Indie web workers have v. nice $180\/mo, 10th floor, fashion district space. #nodejs #rsvp",
  "id" : 57530882373844992,
  "created_at" : "2011-04-11 19:50:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56181738937925632",
  "geo" : { },
  "id_str" : "56199507087605760",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey what are you building?",
  "id" : 56199507087605760,
  "in_reply_to_status_id" : 56181738937925632,
  "created_at" : "2011-04-08 03:39:41 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/uGlwMKb",
      "expanded_url" : "http:\/\/www.orderofthegooddeath.com\/eros-thanatos-in-the-age-of-twilight",
      "display_url" : "orderofthegooddeath.com\/eros-thanatos-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "55885248575188992",
  "text" : "http:\/\/t.co\/uGlwMKb",
  "id" : 55885248575188992,
  "created_at" : "2011-04-07 06:50:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rawrtweet",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55088504379674624",
  "text" : "#rawrtweet this sucks for NC: http:\/\/arstechnica.com\/tech-policy\/news\/2011\/04\/fcc-commish-slams-north-carolina-anti-muni-broadband-bill.ars",
  "id" : 55088504379674624,
  "created_at" : "2011-04-05 02:04:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53925484798550016",
  "text" : "I think many people are asses. Therefore many is the minimum that must think the same of me.",
  "id" : 53925484798550016,
  "created_at" : "2011-04-01 21:03:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/proxlet.com\" rel=\"nofollow\"\u003EProxlet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 3, 9 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53885842799857664",
  "text" : "yo @gmail why do I get a redirect loop only when using the chrome browser? Can't access email. Have to use FF.",
  "id" : 53885842799857664,
  "created_at" : "2011-04-01 18:26:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]