Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660650391001018368",
  "text" : "capitalism is a high energy weapon, which you use it when you participate",
  "id" : 660650391001018368,
  "created_at" : "2015-11-01 02:51:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660625084445540352",
  "text" : "in the voice of Nate Dogg RiP\n\n\"HALLOWEEN EVERYDAY\"",
  "id" : 660625084445540352,
  "created_at" : "2015-11-01 01:11:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660533393537396736",
  "text" : "You cash collecting wizards better save that coin for when the curtain falls on the current act.\n\nImma gonna wanna snack.\n\nAnd as for you...",
  "id" : 660533393537396736,
  "created_at" : "2015-10-31 19:06:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660509833272143872",
  "text" : "Justice &amp; Education reforms lack the backbone of the people who profess their life's labor to be Justice &amp; Education.  Shame unto them!",
  "id" : 660509833272143872,
  "created_at" : "2015-10-31 17:33:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "indices" : [ 3, 11 ],
      "id_str" : "15665323",
      "id" : 15665323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660130791310012416",
  "text" : "RT @afrobot: The Daddy State, conservative alternative to the Nanny State: largely absent except to protect property, enforce boundaries, a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "660108774653325313",
    "text" : "The Daddy State, conservative alternative to the Nanny State: largely absent except to protect property, enforce boundaries, and punish.",
    "id" : 660108774653325313,
    "created_at" : "2015-10-30 14:59:30 +0000",
    "user" : {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "protected" : false,
      "id_str" : "15665323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442925524835254272\/1FJx1Wzd_normal.png",
      "id" : 15665323,
      "verified" : false
    }
  },
  "id" : 660130791310012416,
  "created_at" : "2015-10-30 16:26:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 3, 12 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/PHUMpBlx1q",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/659920868546506752",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660129818084642816",
  "text" : "RT @jfhbrook: Yo can we start a collection for substack and then fix health care in this GD country? https:\/\/t.co\/PHUMpBlx1q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/PHUMpBlx1q",
        "expanded_url" : "https:\/\/twitter.com\/substack\/status\/659920868546506752",
        "display_url" : "twitter.com\/substack\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660127852084465664",
    "text" : "Yo can we start a collection for substack and then fix health care in this GD country? https:\/\/t.co\/PHUMpBlx1q",
    "id" : 660127852084465664,
    "created_at" : "2015-10-30 16:15:19 +0000",
    "user" : {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "protected" : false,
      "id_str" : "184987977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712111710094671872\/8jcHfPsI_normal.jpg",
      "id" : 184987977,
      "verified" : false
    }
  },
  "id" : 660129818084642816,
  "created_at" : "2015-10-30 16:23:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/px0PNup2w5",
      "expanded_url" : "https:\/\/twitter.com\/droosien\/status\/659439312317059074",
      "display_url" : "twitter.com\/droosien\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659445862553096192",
  "text" : "so true https:\/\/t.co\/px0PNup2w5",
  "id" : 659445862553096192,
  "created_at" : "2015-10-28 19:05:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rick waldron",
      "screen_name" : "rwaldron",
      "indices" : [ 3, 12 ],
      "id_str" : "16144669",
      "id" : 16144669
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rwaldron\/status\/659170555640356868\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/wMsSctWvy8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXYIBHUEAApDmp.jpg",
      "id_str" : "659170552729309184",
      "id" : 659170552729309184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXYIBHUEAApDmp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wMsSctWvy8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659180060172226560",
  "text" : "RT @rwaldron: https:\/\/t.co\/wMsSctWvy8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rwaldron\/status\/659170555640356868\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/wMsSctWvy8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXYIBHUEAApDmp.jpg",
        "id_str" : "659170552729309184",
        "id" : 659170552729309184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXYIBHUEAApDmp.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wMsSctWvy8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659170555640356868",
    "text" : "https:\/\/t.co\/wMsSctWvy8",
    "id" : 659170555640356868,
    "created_at" : "2015-10-28 00:51:21 +0000",
    "user" : {
      "name" : "rick waldron",
      "screen_name" : "rwaldron",
      "protected" : false,
      "id_str" : "16144669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541448981797011457\/oMLzXo_j_normal.jpeg",
      "id" : 16144669,
      "verified" : false
    }
  },
  "id" : 659180060172226560,
  "created_at" : "2015-10-28 01:29:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659161455158251520",
  "text" : "\/s\/typo\/acknowledging i am not an idiot",
  "id" : 659161455158251520,
  "created_at" : "2015-10-28 00:15:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658465872135233537",
  "text" : "HEY BIG BOY",
  "id" : 658465872135233537,
  "created_at" : "2015-10-26 02:11:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658462293857050624",
  "text" : "GET ON PATCH NOW SWEETIE!!",
  "id" : 658462293857050624,
  "created_at" : "2015-10-26 01:56:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658358339693182976",
  "text" : "my patchwork address is @Dtx\/yCinQW1zfHTqF54xPYEKaO+ju8fq6Igv\/lbMqSU=.ed25519",
  "id" : 658358339693182976,
  "created_at" : "2015-10-25 19:03:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 3, 10 ],
      "id_str" : "291901937",
      "id" : 291901937
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 12, 25 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658344616308187136",
  "text" : "RT @LB2045: @johnnyscript that email about house politics was poetry. Thank you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658155979029090304",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript that email about house politics was poetry. Thank you.",
    "id" : 658155979029090304,
    "created_at" : "2015-10-25 05:39:48 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "protected" : false,
      "id_str" : "291901937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524991844514418688\/hPkExiIp_normal.jpeg",
      "id" : 291901937,
      "verified" : false
    }
  },
  "id" : 658344616308187136,
  "created_at" : "2015-10-25 18:09:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/zAxoLwaBNp",
      "expanded_url" : "https:\/\/twitter.com\/BaltUprising\/status\/658035283728973824",
      "display_url" : "twitter.com\/BaltUprising\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658072310100848640",
  "text" : "wow https:\/\/t.co\/zAxoLwaBNp",
  "id" : 658072310100848640,
  "created_at" : "2015-10-25 00:07:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/VODabranc3",
      "expanded_url" : "https:\/\/twitter.com\/BYP_100\/status\/658036920979750912",
      "display_url" : "twitter.com\/BYP_100\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658072002855575552",
  "text" : "defund police hell yes https:\/\/t.co\/VODabranc3",
  "id" : 658072002855575552,
  "created_at" : "2015-10-25 00:06:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658071330458238976",
  "text" : "we're all shiteaters one way or several",
  "id" : 658071330458238976,
  "created_at" : "2015-10-25 00:03:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658046475411324928",
  "text" : "Chaotic neutral is awesome.  One cannot \"increase\" neutrality, so you can spend all points upping chaos.",
  "id" : 658046475411324928,
  "created_at" : "2015-10-24 22:24:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657748167199428608",
  "text" : "scripsi scrypsy",
  "id" : 657748167199428608,
  "created_at" : "2015-10-24 02:39:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657720067380113408",
  "text" : "Do you like?",
  "id" : 657720067380113408,
  "created_at" : "2015-10-24 00:47:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657708045443592193",
  "text" : "How may I love thee? as the new hey",
  "id" : 657708045443592193,
  "created_at" : "2015-10-23 23:59:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657706915242184704",
  "text" : "I don't like companies telling me they love me.  You have no idea how to love me.  Your concept of love is patronizing.",
  "id" : 657706915242184704,
  "created_at" : "2015-10-23 23:55:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "indices" : [ 3, 15 ],
      "id_str" : "3280343994",
      "id" : 3280343994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBlack",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657704988710297600",
  "text" : "RT @TalkOakland: #BeingBlack: always having to make your abusers feel safe.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBlack",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657623875186876416",
    "text" : "#BeingBlack: always having to make your abusers feel safe.",
    "id" : 657623875186876416,
    "created_at" : "2015-10-23 18:25:24 +0000",
    "user" : {
      "name" : "TalkOakland",
      "screen_name" : "TalkOakland",
      "protected" : false,
      "id_str" : "3280343994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682306358234976265\/CSBy-srW_normal.jpg",
      "id" : 3280343994,
      "verified" : false
    }
  },
  "id" : 657704988710297600,
  "created_at" : "2015-10-23 23:47:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657474138374696960",
  "text" : "Raising totalitarians.",
  "id" : 657474138374696960,
  "created_at" : "2015-10-23 08:30:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657412437411364864",
  "text" : "jettison yr executive  (sing along)",
  "id" : 657412437411364864,
  "created_at" : "2015-10-23 04:25:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656895479326769152",
  "text" : "I said, that rainbow is moving directly toward us, and we knew it was time to get off the roof.",
  "id" : 656895479326769152,
  "created_at" : "2015-10-21 18:11:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655955555882700800",
  "text" : "The first rule is\n\nfood everywhere and sleep anywhere.",
  "id" : 655955555882700800,
  "created_at" : "2015-10-19 03:56:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EL PELUCA.",
      "screen_name" : "SanPeluca",
      "indices" : [ 3, 13 ],
      "id_str" : "930217548",
      "id" : 930217548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655916429225529344",
  "text" : "RT @SanPeluca: Dato Curioso:\n\nLos humanos somos 70% de agua, pero t\u00FA eres 100%  puta.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655889403647295488",
    "text" : "Dato Curioso:\n\nLos humanos somos 70% de agua, pero t\u00FA eres 100%  puta.",
    "id" : 655889403647295488,
    "created_at" : "2015-10-18 23:33:14 +0000",
    "user" : {
      "name" : "EL PELUCA.",
      "screen_name" : "SanPeluca",
      "protected" : false,
      "id_str" : "930217548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725433648518946816\/lf14NZ2L_normal.jpg",
      "id" : 930217548,
      "verified" : false
    }
  },
  "id" : 655916429225529344,
  "created_at" : "2015-10-19 01:20:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 0, 7 ],
      "id_str" : "291901937",
      "id" : 291901937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654517034324127744",
  "geo" : { },
  "id_str" : "654934463835561984",
  "in_reply_to_user_id" : 291901937,
  "text" : "@LB2045  \nsure, you can choose to marry one\nthat's patriarchy's limit, in parallel\nbut polylove ain't a parameter\nit is immutably true",
  "id" : 654934463835561984,
  "in_reply_to_status_id" : 654517034324127744,
  "created_at" : "2015-10-16 08:18:38 +0000",
  "in_reply_to_screen_name" : "LB2045",
  "in_reply_to_user_id_str" : "291901937",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654775828216045568",
  "text" : "If I can kiss you, I can kill you.",
  "id" : 654775828216045568,
  "created_at" : "2015-10-15 21:48:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654522957075628032",
  "text" : "Giving up privilege to create equal ground may not feel fair.  That's how you know it's working.",
  "id" : 654522957075628032,
  "created_at" : "2015-10-15 05:03:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fokstack",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/tMKk3fphZE",
      "expanded_url" : "https:\/\/archive.org\/download\/hackistani_recordings_1\/Untitled%20Recording%2034.wav",
      "display_url" : "archive.org\/download\/hacki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654140267881066496",
  "text" : "psych out yr little bear with this one from the #fokstack archives https:\/\/t.co\/tMKk3fphZE",
  "id" : 654140267881066496,
  "created_at" : "2015-10-14 03:42:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "folkstack",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/PRR0Rtx2ve",
      "expanded_url" : "https:\/\/archive.org\/download\/hackistani_recordings_1\/Untitled%20Recording%2030.wav",
      "display_url" : "archive.org\/download\/hacki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654135338529517568",
  "text" : "https:\/\/t.co\/PRR0Rtx2ve  #folkstack",
  "id" : 654135338529517568,
  "created_at" : "2015-10-14 03:23:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/BQ57daxKvD",
      "expanded_url" : "https:\/\/ia601501.us.archive.org\/24\/items\/hackistani_recordings_1\/Untitled%20Recording%2029.wav",
      "display_url" : "ia601501.us.archive.org\/24\/items\/hacki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654135028411031552",
  "text" : "https:\/\/t.co\/BQ57daxKvD",
  "id" : 654135028411031552,
  "created_at" : "2015-10-14 03:21:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654012582852857856",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  I am in Oakland today yes, in hackistan now, by lake merrit later",
  "id" : 654012582852857856,
  "created_at" : "2015-10-13 19:15:25 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653573350493679616",
  "geo" : { },
  "id_str" : "654008411214884864",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  lol im a dummy",
  "id" : 654008411214884864,
  "in_reply_to_status_id" : 653573350493679616,
  "created_at" : "2015-10-13 18:58:50 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653757380811878400",
  "text" : "flawless victory jesus christ is your score from the victoreport",
  "id" : 653757380811878400,
  "created_at" : "2015-10-13 02:21:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653507309465829376",
  "text" : "all I want is for you to respond when I ping, dummy",
  "id" : 653507309465829376,
  "created_at" : "2015-10-12 09:47:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653507025901518848",
  "text" : "che dummy",
  "id" : 653507025901518848,
  "created_at" : "2015-10-12 09:46:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653506996314877952",
  "text" : "dummy",
  "id" : 653506996314877952,
  "created_at" : "2015-10-12 09:46:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653506946016743424",
  "text" : "Here's to the next time we wake.",
  "id" : 653506946016743424,
  "created_at" : "2015-10-12 09:46:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653506625345449984",
  "text" : "Here's to the next time we're awake, dummy.",
  "id" : 653506625345449984,
  "created_at" : "2015-10-12 09:44:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653469142406684676",
  "text" : "s\/incorrect\/outtacorrect",
  "id" : 653469142406684676,
  "created_at" : "2015-10-12 07:15:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newegg",
      "screen_name" : "Newegg",
      "indices" : [ 0, 7 ],
      "id_str" : "17221819",
      "id" : 17221819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653419437333155840",
  "in_reply_to_user_id" : 17221819,
  "text" : "@Newegg  do you accept bitcoin?  I see the option, but cannot choose it.  TIA",
  "id" : 653419437333155840,
  "created_at" : "2015-10-12 03:58:28 +0000",
  "in_reply_to_screen_name" : "Newegg",
  "in_reply_to_user_id_str" : "17221819",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/6C7KTNtYOr",
      "expanded_url" : "https:\/\/twitter.com\/ToddBailey\/status\/653324287395405825",
      "display_url" : "twitter.com\/ToddBailey\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653353502056386561",
  "text" : "gamified https:\/\/t.co\/6C7KTNtYOr",
  "id" : 653353502056386561,
  "created_at" : "2015-10-11 23:36:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653323288630833154",
  "text" : "*raises hand*\n\nWhat happens when this strategy of \"mutually assured destruction\" is brought home and internalized?",
  "id" : 653323288630833154,
  "created_at" : "2015-10-11 21:36:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "craigslist",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653064695369175040",
  "text" : "I will trade web development \/ programming for a van or a truck  #craigslist",
  "id" : 653064695369175040,
  "created_at" : "2015-10-11 04:28:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 10, 14 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COLO",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652713248001658880",
  "geo" : { },
  "id_str" : "652715215780384768",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack @izs #COLO",
  "id" : 652715215780384768,
  "in_reply_to_status_id" : 652713248001658880,
  "created_at" : "2015-10-10 05:20:08 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652692826434617347",
  "geo" : { },
  "id_str" : "652705239884107776",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia  talk to my agent",
  "id" : 652705239884107776,
  "in_reply_to_status_id" : 652692826434617347,
  "created_at" : "2015-10-10 04:40:30 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 3, 10 ],
      "id_str" : "291901937",
      "id" : 291901937
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openwrt",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/2eTlGfOZ5Z",
      "expanded_url" : "http:\/\/dearfcc.org",
      "display_url" : "dearfcc.org"
    } ]
  },
  "geo" : { },
  "id_str" : "652701604366299136",
  "text" : "RT @LB2045: Here's a link to tell the FCC why it can't ban open source operating systems like #openwrt http:\/\/t.co\/2eTlGfOZ5Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openwrt",
        "indices" : [ 82, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/2eTlGfOZ5Z",
        "expanded_url" : "http:\/\/dearfcc.org",
        "display_url" : "dearfcc.org"
      } ]
    },
    "geo" : { },
    "id_str" : "652638464731541504",
    "text" : "Here's a link to tell the FCC why it can't ban open source operating systems like #openwrt http:\/\/t.co\/2eTlGfOZ5Z",
    "id" : 652638464731541504,
    "created_at" : "2015-10-10 00:15:10 +0000",
    "user" : {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "protected" : false,
      "id_str" : "291901937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524991844514418688\/hPkExiIp_normal.jpeg",
      "id" : 291901937,
      "verified" : false
    }
  },
  "id" : 652701604366299136,
  "created_at" : "2015-10-10 04:26:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652609200770576384",
  "geo" : { },
  "id_str" : "652692348883759104",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia  give em what they want will ya",
  "id" : 652692348883759104,
  "in_reply_to_status_id" : 652609200770576384,
  "created_at" : "2015-10-10 03:49:17 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 3, 15 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoColumbusDay",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/pl3fTWnvOX",
      "expanded_url" : "https:\/\/twitter.com\/FNDI303\/status\/652157389974540288",
      "display_url" : "twitter.com\/FNDI303\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652370477902491648",
  "text" : "RT @vrroanhorse: Is your city on the list? #NoColumbusDay https:\/\/t.co\/pl3fTWnvOX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoColumbusDay",
        "indices" : [ 26, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/pl3fTWnvOX",
        "expanded_url" : "https:\/\/twitter.com\/FNDI303\/status\/652157389974540288",
        "display_url" : "twitter.com\/FNDI303\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652240392495063041",
    "text" : "Is your city on the list? #NoColumbusDay https:\/\/t.co\/pl3fTWnvOX",
    "id" : 652240392495063041,
    "created_at" : "2015-10-08 21:53:22 +0000",
    "user" : {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "protected" : false,
      "id_str" : "557228721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652515840194056193\/vt9WrUY__normal.jpg",
      "id" : 557228721,
      "verified" : false
    }
  },
  "id" : 652370477902491648,
  "created_at" : "2015-10-09 06:30:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/cFv1O5B75F",
      "expanded_url" : "https:\/\/twitter.com\/brunoleyval\/status\/651415145772642304",
      "display_url" : "twitter.com\/brunoleyval\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652223492323045376",
  "text" : "RT @Snowden: \"Beware of artists. They mix with all classes of society and are therefore most dangerous.\" -King Leopold https:\/\/t.co\/cFv1O5B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/cFv1O5B75F",
        "expanded_url" : "https:\/\/twitter.com\/brunoleyval\/status\/651415145772642304",
        "display_url" : "twitter.com\/brunoleyval\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652191336226013185",
    "text" : "\"Beware of artists. They mix with all classes of society and are therefore most dangerous.\" -King Leopold https:\/\/t.co\/cFv1O5B75F",
    "id" : 652191336226013185,
    "created_at" : "2015-10-08 18:38:26 +0000",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 652223492323045376,
  "created_at" : "2015-10-08 20:46:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651882357880819713",
  "text" : "congrats!\nyou found \nthe right clique\nsave as!",
  "id" : 651882357880819713,
  "created_at" : "2015-10-07 22:10:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651691497868292096",
  "text" : "I'm anonymous, but not in any these public channels.",
  "id" : 651691497868292096,
  "created_at" : "2015-10-07 09:32:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/ca25YR4W4u",
      "expanded_url" : "https:\/\/twitter.com\/blackoutcollect\/status\/651605017074335744",
      "display_url" : "twitter.com\/blackoutcollec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651677367149064192",
  "text" : "YES YES https:\/\/t.co\/ca25YR4W4u",
  "id" : 651677367149064192,
  "created_at" : "2015-10-07 08:36:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651676565986676736",
  "text" : "San Fran Cis Bro",
  "id" : 651676565986676736,
  "created_at" : "2015-10-07 08:32:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651308849270427649",
  "text" : "THE UNITED SPATES",
  "id" : 651308849270427649,
  "created_at" : "2015-10-06 08:11:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651156878290882560",
  "text" : "If everybody gets behind Bernie early perhaps we can skip the whole campaign season.  That show jumped the shark before I was born.",
  "id" : 651156878290882560,
  "created_at" : "2015-10-05 22:07:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Marquis-Boire",
      "screen_name" : "headhntr",
      "indices" : [ 3, 12 ],
      "id_str" : "22404415",
      "id" : 22404415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "heartsandminds",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/mJkJ18KHMh",
      "expanded_url" : "https:\/\/theintercept.com\/2015\/10\/05\/drone-flies-over-nsa-complex-in-germany-dropping-pamphlets\/",
      "display_url" : "theintercept.com\/2015\/10\/05\/dro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651150335998726144",
  "text" : "RT @headhntr: Drone flies over the NSA complex in Germany, dropping leaflets telling the spies they should quit https:\/\/t.co\/mJkJ18KHMh #he\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "heartsandminds",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/mJkJ18KHMh",
        "expanded_url" : "https:\/\/theintercept.com\/2015\/10\/05\/drone-flies-over-nsa-complex-in-germany-dropping-pamphlets\/",
        "display_url" : "theintercept.com\/2015\/10\/05\/dro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651121564939743232",
    "text" : "Drone flies over the NSA complex in Germany, dropping leaflets telling the spies they should quit https:\/\/t.co\/mJkJ18KHMh #heartsandminds",
    "id" : 651121564939743232,
    "created_at" : "2015-10-05 19:47:32 +0000",
    "user" : {
      "name" : "Morgan Marquis-Boire",
      "screen_name" : "headhntr",
      "protected" : false,
      "id_str" : "22404415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669307323500761088\/NyEPjfaf_normal.jpg",
      "id" : 22404415,
      "verified" : true
    }
  },
  "id" : 651150335998726144,
  "created_at" : "2015-10-05 21:41:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651123652897865729",
  "text" : "i'm really bad at arguing!\nbut I love to sing!\n&amp; destroy derivative\nindividualismo\ncapitalish\nsuperfragile\nphilistino \nego wagging\nproducts!",
  "id" : 651123652897865729,
  "created_at" : "2015-10-05 19:55:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 0, 12 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650840179670827008",
  "geo" : { },
  "id_str" : "650853371243466752",
  "in_reply_to_user_id" : 557228721,
  "text" : "@vrroanhorse  beer n boocha",
  "id" : 650853371243466752,
  "in_reply_to_status_id" : 650840179670827008,
  "created_at" : "2015-10-05 02:01:50 +0000",
  "in_reply_to_screen_name" : "vrroanhorse",
  "in_reply_to_user_id_str" : "557228721",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lord Pinky",
      "screen_name" : "HiddenPinky",
      "indices" : [ 3, 15 ],
      "id_str" : "835553228",
      "id" : 835553228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650790410453848064",
  "text" : "RT @HiddenPinky: Your password must contain at least two female characters who talk to each other about something other than a man.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "522045348731035648",
    "text" : "Your password must contain at least two female characters who talk to each other about something other than a man.",
    "id" : 522045348731035648,
    "created_at" : "2014-10-14 15:24:44 +0000",
    "user" : {
      "name" : "Lord Pinky",
      "screen_name" : "HiddenPinky",
      "protected" : false,
      "id_str" : "835553228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728559776091668480\/X5aI8Bj0_normal.jpg",
      "id" : 835553228,
      "verified" : false
    }
  },
  "id" : 650790410453848064,
  "created_at" : "2015-10-04 21:51:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650788913544458240",
  "text" : "A LIBERTARIAN IS TRYING TO TELL ME SINGLE MOMS ARE A \"GOVERNMENT PROGRAM\"\n\nPLS ADVISE",
  "id" : 650788913544458240,
  "created_at" : "2015-10-04 21:45:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/2lm6TgweGd",
      "expanded_url" : "https:\/\/twitter.com\/ghostnatal\/status\/650492632561516544",
      "display_url" : "twitter.com\/ghostnatal\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650549211197386752",
  "text" : "spotted a drop out https:\/\/t.co\/2lm6TgweGd",
  "id" : 650549211197386752,
  "created_at" : "2015-10-04 05:53:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/UANXrdB8xL",
      "expanded_url" : "https:\/\/twitter.com\/nexxylove\/status\/650500729669443584",
      "display_url" : "twitter.com\/nexxylove\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650548901414498304",
  "text" : "this is a seen as a good sign for the egonomy https:\/\/t.co\/UANXrdB8xL",
  "id" : 650548901414498304,
  "created_at" : "2015-10-04 05:51:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/678CSooI8I",
      "expanded_url" : "https:\/\/twitter.com\/grayamelia\/status\/650509876112703488",
      "display_url" : "twitter.com\/grayamelia\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650548422148161536",
  "text" : "did she see her shadow? https:\/\/t.co\/678CSooI8I",
  "id" : 650548422148161536,
  "created_at" : "2015-10-04 05:50:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 0, 12 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650538394276098049",
  "geo" : { },
  "id_str" : "650547362121707520",
  "in_reply_to_user_id" : 557228721,
  "text" : "@vrroanhorse  soon ima brew my own",
  "id" : 650547362121707520,
  "in_reply_to_status_id" : 650538394276098049,
  "created_at" : "2015-10-04 05:45:52 +0000",
  "in_reply_to_screen_name" : "vrroanhorse",
  "in_reply_to_user_id_str" : "557228721",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650478526496309252",
  "text" : "if elected president, I will change retirement age to use any calendar you choose",
  "id" : 650478526496309252,
  "created_at" : "2015-10-04 01:12:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650463714332676096",
  "text" : "noodle your way in till you make it",
  "id" : 650463714332676096,
  "created_at" : "2015-10-04 00:13:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Tatum",
      "screen_name" : "TatumCreative",
      "indices" : [ 3, 17 ],
      "id_str" : "17205841",
      "id" : 17205841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Qif2IVXEYo",
      "expanded_url" : "https:\/\/vine.co\/v\/eQtIihrJZiD",
      "display_url" : "vine.co\/v\/eQtIihrJZiD"
    } ]
  },
  "geo" : { },
  "id_str" : "649827822706360320",
  "text" : "RT @TatumCreative: Instability in the system. https:\/\/t.co\/Qif2IVXEYo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/Qif2IVXEYo",
        "expanded_url" : "https:\/\/vine.co\/v\/eQtIihrJZiD",
        "display_url" : "vine.co\/v\/eQtIihrJZiD"
      } ]
    },
    "geo" : { },
    "id_str" : "649759617464053761",
    "text" : "Instability in the system. https:\/\/t.co\/Qif2IVXEYo",
    "id" : 649759617464053761,
    "created_at" : "2015-10-02 01:35:39 +0000",
    "user" : {
      "name" : "Greg Tatum",
      "screen_name" : "TatumCreative",
      "protected" : false,
      "id_str" : "17205841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597965632181653504\/aQvCxyfk_normal.jpg",
      "id" : 17205841,
      "verified" : false
    }
  },
  "id" : 649827822706360320,
  "created_at" : "2015-10-02 06:06:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649787887014146048",
  "text" : "polyamory isn't a choice",
  "id" : 649787887014146048,
  "created_at" : "2015-10-02 03:27:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649704411854323712",
  "text" : "Did adblock jus hijack my browser and try to sell me ads?",
  "id" : 649704411854323712,
  "created_at" : "2015-10-01 21:56:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. Magnusson",
      "screen_name" : "rymagnusson",
      "indices" : [ 3, 15 ],
      "id_str" : "60252924",
      "id" : 60252924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649691256918949889",
  "text" : "RT @rymagnusson: We have to accept people dying so paranoid white dudes can fantasize that they'd be the hero in Die Hard if only the chanc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649682758244044800",
    "text" : "We have to accept people dying so paranoid white dudes can fantasize that they'd be the hero in Die Hard if only the chance would arrive.",
    "id" : 649682758244044800,
    "created_at" : "2015-10-01 20:30:14 +0000",
    "user" : {
      "name" : "R. Magnusson",
      "screen_name" : "rymagnusson",
      "protected" : false,
      "id_str" : "60252924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563636522843246592\/ycpJbx0-_normal.jpeg",
      "id" : 60252924,
      "verified" : false
    }
  },
  "id" : 649691256918949889,
  "created_at" : "2015-10-01 21:04:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]