Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/uFZpne7CIo",
      "expanded_url" : "http:\/\/utotherescue.blogspot.com\/2016\/01\/ucop-ordered-spyware-installed-on-uc.html",
      "display_url" : "utotherescue.blogspot.com\/2016\/01\/ucop-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693929690076057601",
  "text" : "former homeland sec. boss is the President of University of California?  that should be instant student protest shit https:\/\/t.co\/uFZpne7CIo",
  "id" : 693929690076057601,
  "created_at" : "2016-01-31 22:51:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/693922640038199296\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/j3gJisaMlb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaFO9szUkAAHGSI.jpg",
      "id_str" : "693922639497170944",
      "id" : 693922639497170944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaFO9szUkAAHGSI.jpg",
      "sizes" : [ {
        "h" : 867,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 797,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 867,
        "resize" : "fit",
        "w" : 653
      } ],
      "display_url" : "pic.twitter.com\/j3gJisaMlb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693922640038199296",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked well done https:\/\/t.co\/j3gJisaMlb",
  "id" : 693922640038199296,
  "created_at" : "2016-01-31 22:23:44 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693846011001880578",
  "geo" : { },
  "id_str" : "693858491090362368",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair what's that for?",
  "id" : 693858491090362368,
  "in_reply_to_status_id" : 693846011001880578,
  "created_at" : "2016-01-31 18:08:50 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693708860683464704",
  "text" : "all your code base are belong to my joke butts",
  "id" : 693708860683464704,
  "created_at" : "2016-01-31 08:14:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693663842862129152",
  "text" : "my new band's pronoun is people \/ person",
  "id" : 693663842862129152,
  "created_at" : "2016-01-31 05:15:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692774625973907456",
  "geo" : { },
  "id_str" : "692778064736964608",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross  should be free for writers whose modules are depended on by at least X modules;  that ecosystem is what powers the node community.",
  "id" : 692778064736964608,
  "in_reply_to_status_id" : 692774625973907456,
  "created_at" : "2016-01-28 18:35:36 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lady fav-a-lot",
      "screen_name" : "rubybrunton",
      "indices" : [ 3, 15 ],
      "id_str" : "330311639",
      "id" : 330311639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691821875270414340",
  "text" : "RT @rubybrunton: support your friends' projects 2k16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "644267086949302272",
    "geo" : { },
    "id_str" : "691812470026059776",
    "in_reply_to_user_id" : 330311639,
    "text" : "support your friends' projects 2k16",
    "id" : 691812470026059776,
    "in_reply_to_status_id" : 644267086949302272,
    "created_at" : "2016-01-26 02:38:40 +0000",
    "in_reply_to_screen_name" : "rubybrunton",
    "in_reply_to_user_id_str" : "330311639",
    "user" : {
      "name" : "lady fav-a-lot",
      "screen_name" : "rubybrunton",
      "protected" : false,
      "id_str" : "330311639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707061099695382528\/kSkBwCbY_normal.jpg",
      "id" : 330311639,
      "verified" : false
    }
  },
  "id" : 691821875270414340,
  "created_at" : "2016-01-26 03:16:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Hester Sr",
      "screen_name" : "paulh2167657",
      "indices" : [ 3, 16 ],
      "id_str" : "3313860960",
      "id" : 3313860960
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/paulh2167657\/status\/690913320405053443\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/gzU205nIxv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZaeAMRUMAARHzc.jpg",
      "id_str" : "690913318978990080",
      "id" : 690913318978990080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZaeAMRUMAARHzc.jpg",
      "sizes" : [ {
        "h" : 395,
        "resize" : "fit",
        "w" : 392
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 392
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 392
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gzU205nIxv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690948919862267904",
  "text" : "RT @paulh2167657: We Americans have tendacy to get upset at the wrong target. Take a look. https:\/\/t.co\/gzU205nIxv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/paulh2167657\/status\/690913320405053443\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/gzU205nIxv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZaeAMRUMAARHzc.jpg",
        "id_str" : "690913318978990080",
        "id" : 690913318978990080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZaeAMRUMAARHzc.jpg",
        "sizes" : [ {
          "h" : 395,
          "resize" : "fit",
          "w" : 392
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 392
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 392
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gzU205nIxv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690913320405053443",
    "text" : "We Americans have tendacy to get upset at the wrong target. Take a look. https:\/\/t.co\/gzU205nIxv",
    "id" : 690913320405053443,
    "created_at" : "2016-01-23 15:05:46 +0000",
    "user" : {
      "name" : "Paul Hester Sr",
      "screen_name" : "paulh2167657",
      "protected" : false,
      "id_str" : "3313860960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727471490866753536\/ET3Q5nNW_normal.jpg",
      "id" : 3313860960,
      "verified" : false
    }
  },
  "id" : 690948919862267904,
  "created_at" : "2016-01-23 17:27:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690574767179563008",
  "geo" : { },
  "id_str" : "690615614705012740",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  no-clintonian",
  "id" : 690615614705012740,
  "in_reply_to_status_id" : 690574767179563008,
  "created_at" : "2016-01-22 19:22:48 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690373788660318211",
  "geo" : { },
  "id_str" : "690374905939038209",
  "in_reply_to_user_id" : 46961216,
  "text" : "I shoulda saved that one for later, ya'll are lucky I'm hittin that green tea",
  "id" : 690374905939038209,
  "in_reply_to_status_id" : 690373788660318211,
  "created_at" : "2016-01-22 03:26:18 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690373788660318211",
  "text" : "patience divines the truth",
  "id" : 690373788660318211,
  "created_at" : "2016-01-22 03:21:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690018670987350016",
  "geo" : { },
  "id_str" : "690049897903562752",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  His life was a distress antenna.  I'm too weak to read his non-nonfiction for all its gruesome, psychic, postmodern detail.",
  "id" : 690049897903562752,
  "in_reply_to_status_id" : 690018670987350016,
  "created_at" : "2016-01-21 05:54:50 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689591578726297600",
  "text" : "gimp has a toilet paper template",
  "id" : 689591578726297600,
  "created_at" : "2016-01-19 23:33:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReclaimMLK",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689241277641064448",
  "text" : "awesome bay bridge shut down #ReclaimMLK",
  "id" : 689241277641064448,
  "created_at" : "2016-01-19 00:21:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/af4aS06NNL",
      "expanded_url" : "https:\/\/www.youtube.com\/playlist?list=PLZQOUqGiAoY0VD0gzNnjJxZdNuivMao1E",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689240210928877568",
  "text" : "I made this playlist to ytdl for #MLKDay at my community center https:\/\/t.co\/af4aS06NNL",
  "id" : 689240210928877568,
  "created_at" : "2016-01-19 00:17:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReclaimMLK",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689156192573079552",
  "text" : "If you've never been arrested or tear gassed for protesting mad injustice in the USA yet, you are practically complicit.  #ReclaimMLK",
  "id" : 689156192573079552,
  "created_at" : "2016-01-18 18:43:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Thorn Coyle",
      "screen_name" : "ThornCoyle",
      "indices" : [ 3, 14 ],
      "id_str" : "245071650",
      "id" : 245071650
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ThornCoyle\/status\/689143405746589696\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/KELkS6Clea",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZBURpqUoAI9H6K.jpg",
      "id_str" : "689143405205561346",
      "id" : 689143405205561346,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZBURpqUoAI9H6K.jpg",
      "sizes" : [ {
        "h" : 2000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KELkS6Clea"
    } ],
    "hashtags" : [ {
      "text" : "ReclaimMLK",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "96hours",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689155381860286464",
  "text" : "RT @ThornCoyle: Nonviolent direct action seeks to create such a crisis...\n\n#ReclaimMLK \n#96hours https:\/\/t.co\/KELkS6Clea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ThornCoyle\/status\/689143405746589696\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/KELkS6Clea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZBURpqUoAI9H6K.jpg",
        "id_str" : "689143405205561346",
        "id" : 689143405205561346,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZBURpqUoAI9H6K.jpg",
        "sizes" : [ {
          "h" : 2000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KELkS6Clea"
      } ],
      "hashtags" : [ {
        "text" : "ReclaimMLK",
        "indices" : [ 59, 70 ]
      }, {
        "text" : "96hours",
        "indices" : [ 72, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689143405746589696",
    "text" : "Nonviolent direct action seeks to create such a crisis...\n\n#ReclaimMLK \n#96hours https:\/\/t.co\/KELkS6Clea",
    "id" : 689143405746589696,
    "created_at" : "2016-01-18 17:52:46 +0000",
    "user" : {
      "name" : "T. Thorn Coyle",
      "screen_name" : "ThornCoyle",
      "protected" : false,
      "id_str" : "245071650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616034907656028161\/2NkaqzBv_normal.jpg",
      "id" : 245071650,
      "verified" : false
    }
  },
  "id" : 689155381860286464,
  "created_at" : "2016-01-18 18:40:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689154719076331520",
  "text" : "They killed MLK to put down a revolution.  It worked.  The life &amp; dream we're supposed to celebrate was deferred.  Stay woke.  #MLKDay",
  "id" : 689154719076331520,
  "created_at" : "2016-01-18 18:37:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 3, 17 ],
      "id_str" : "20221325",
      "id" : 20221325
    }, {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 53, 67 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/77MyhEfrFt",
      "expanded_url" : "https:\/\/medium.com\/@girlziplocked\/hillary-clinton-wasted-her-life-b1ba5aeb467b",
      "display_url" : "medium.com\/@girlziplocked\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688906958145863681",
  "text" : "RT @girlziplocked: \u201CHillary Clinton Wasted Her Life\u201D @girlziplocked https:\/\/t.co\/77MyhEfrFt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "holly wood",
        "screen_name" : "girlziplocked",
        "indices" : [ 34, 48 ],
        "id_str" : "20221325",
        "id" : 20221325
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/77MyhEfrFt",
        "expanded_url" : "https:\/\/medium.com\/@girlziplocked\/hillary-clinton-wasted-her-life-b1ba5aeb467b",
        "display_url" : "medium.com\/@girlziplocked\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688875957512306688",
    "text" : "\u201CHillary Clinton Wasted Her Life\u201D @girlziplocked https:\/\/t.co\/77MyhEfrFt",
    "id" : 688875957512306688,
    "created_at" : "2016-01-18 00:10:01 +0000",
    "user" : {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "protected" : false,
      "id_str" : "20221325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497445169797414913\/rvn1M8zY_normal.jpeg",
      "id" : 20221325,
      "verified" : false
    }
  },
  "id" : 688906958145863681,
  "created_at" : "2016-01-18 02:13:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 3, 17 ],
      "id_str" : "20221325",
      "id" : 20221325
    }, {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 66, 80 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/mF9YD1FPQl",
      "expanded_url" : "https:\/\/medium.com\/@girlziplocked\/hillary-clinton-represents-the-asshole-class-9d43ac97abcd",
      "display_url" : "medium.com\/@girlziplocked\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688906948352212992",
  "text" : "RT @girlziplocked: \u201CHillary Clinton Represents the Asshole Class\u201D @girlziplocked https:\/\/t.co\/mF9YD1FPQl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "holly wood",
        "screen_name" : "girlziplocked",
        "indices" : [ 47, 61 ],
        "id_str" : "20221325",
        "id" : 20221325
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/mF9YD1FPQl",
        "expanded_url" : "https:\/\/medium.com\/@girlziplocked\/hillary-clinton-represents-the-asshole-class-9d43ac97abcd",
        "display_url" : "medium.com\/@girlziplocked\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688876034234564608",
    "text" : "\u201CHillary Clinton Represents the Asshole Class\u201D @girlziplocked https:\/\/t.co\/mF9YD1FPQl",
    "id" : 688876034234564608,
    "created_at" : "2016-01-18 00:10:19 +0000",
    "user" : {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "protected" : false,
      "id_str" : "20221325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497445169797414913\/rvn1M8zY_normal.jpeg",
      "id" : 20221325,
      "verified" : false
    }
  },
  "id" : 688906948352212992,
  "created_at" : "2016-01-18 02:13:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/688853117610274816\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/5PED1fOFOm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY9MQqLU0AAn3bE.png",
      "id_str" : "688853117094383616",
      "id" : 688853117094383616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY9MQqLU0AAn3bE.png",
      "sizes" : [ {
        "h" : 310,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/5PED1fOFOm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688853117610274816",
  "text" : "https:\/\/t.co\/5PED1fOFOm",
  "id" : 688853117610274816,
  "created_at" : "2016-01-17 22:39:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688851763491815424",
  "text" : "Every one of you is a Narcissuses presuming yourself to be empathizing w\/ an algorithm, or other.  \n\nThat is not intended an insult, dummy.",
  "id" : 688851763491815424,
  "created_at" : "2016-01-17 22:33:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688826499932094464",
  "text" : "what do I need to sell to get some fuckin fiat around here?",
  "id" : 688826499932094464,
  "created_at" : "2016-01-17 20:53:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/AuaHNDBotu",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript",
      "display_url" : "soundcloud.com\/johnnyscript"
    }, {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/HX7pfPKMdd",
      "expanded_url" : "https:\/\/twitter.com\/Satoshi_N_\/status\/688797022934163458",
      "display_url" : "twitter.com\/Satoshi_N_\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688808038036144128",
  "text" : "your math makes money, my math makes music, let's do this: https:\/\/t.co\/AuaHNDBotu https:\/\/t.co\/HX7pfPKMdd",
  "id" : 688808038036144128,
  "created_at" : "2016-01-17 19:40:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/54WQHRjJz7",
      "expanded_url" : "https:\/\/medium.com\/@girlziplocked\/skullfuck-you-very-much-cultural-authority-and-the-dispossessed-1770fdb01dc4#.xz1hx5n2n",
      "display_url" : "medium.com\/@girlziplocked\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688470676773064704",
  "text" : "more skullfulking during political intercourse please \n\nhttps:\/\/t.co\/54WQHRjJz7",
  "id" : 688470676773064704,
  "created_at" : "2016-01-16 21:19:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688375359717310464",
  "text" : "I'm back in Oakland for a period.  Hit me up.  Take me out.  I like to dance. Help me get some cash.",
  "id" : 688375359717310464,
  "created_at" : "2016-01-16 15:00:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688207613322866688",
  "text" : "We did not have to be in the same world for most of the time.",
  "id" : 688207613322866688,
  "created_at" : "2016-01-16 03:54:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687465661837082624",
  "text" : "Artists and scientists require instruments.\n\nI am one.",
  "id" : 687465661837082624,
  "created_at" : "2016-01-14 02:46:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687434385365319680",
  "geo" : { },
  "id_str" : "687435352760545280",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked new definition: economics is the study of how people are forced to act given the economic system  :^3",
  "id" : 687435352760545280,
  "in_reply_to_status_id" : 687434385365319680,
  "created_at" : "2016-01-14 00:45:34 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687434985268088832",
  "geo" : { },
  "id_str" : "687435170161508353",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  the control mechanism, the power, the ism?",
  "id" : 687435170161508353,
  "in_reply_to_status_id" : 687434985268088832,
  "created_at" : "2016-01-14 00:44:51 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687434385365319680",
  "geo" : { },
  "id_str" : "687434849230143488",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked plural *archy",
  "id" : 687434849230143488,
  "in_reply_to_status_id" : 687434385365319680,
  "created_at" : "2016-01-14 00:43:34 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687424269693927424",
  "geo" : { },
  "id_str" : "687434281057136640",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  new definition: economics is the study of how *archies force people to act in order to survive",
  "id" : 687434281057136640,
  "in_reply_to_status_id" : 687424269693927424,
  "created_at" : "2016-01-14 00:41:19 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 0, 8 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687375325567647744",
  "geo" : { },
  "id_str" : "687389513379786752",
  "in_reply_to_user_id" : 4784511,
  "text" : "@bigeasy  I feel like sharing is responsible for that.  Thanks for sharing.",
  "id" : 687389513379786752,
  "in_reply_to_status_id" : 687375325567647744,
  "created_at" : "2016-01-13 21:43:25 +0000",
  "in_reply_to_screen_name" : "bigeasy",
  "in_reply_to_user_id_str" : "4784511",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687387910908215296",
  "text" : "the neoliberal argument for capitalism reduces to \"I can't make anything myself.\"",
  "id" : 687387910908215296,
  "created_at" : "2016-01-13 21:37:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 8, 16 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687158817688281088",
  "geo" : { },
  "id_str" : "687161328910221312",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar @soldair  yuuup cold chillin beans over fire buddha monk style",
  "id" : 687161328910221312,
  "in_reply_to_status_id" : 687158817688281088,
  "created_at" : "2016-01-13 06:36:42 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 88, 96 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687153506495676416",
  "geo" : { },
  "id_str" : "687155967700549633",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  Southern Cali, a SE of LA, elevated desert territory. off grid living courtesy @soldair who is in nyc even now",
  "id" : 687155967700549633,
  "in_reply_to_status_id" : 687153506495676416,
  "created_at" : "2016-01-13 06:15:24 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687151652395204608",
  "geo" : { },
  "id_str" : "687153282976890880",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  likewise! and now i'm in the SW desert, and you're city living.\n\nIs yours a stunted emoji drawing library too?",
  "id" : 687153282976890880,
  "in_reply_to_status_id" : 687151652395204608,
  "created_at" : "2016-01-13 06:04:44 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/687151465421389824\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/1pmMZrYbOH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYlAneAUoAAVCw-.png",
      "id_str" : "687151464964202496",
      "id" : 687151464964202496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYlAneAUoAAVCw-.png",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 580
      } ],
      "display_url" : "pic.twitter.com\/1pmMZrYbOH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687148549461700608",
  "geo" : { },
  "id_str" : "687151465421389824",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar you're quite right https:\/\/t.co\/1pmMZrYbOH",
  "id" : 687151465421389824,
  "in_reply_to_status_id" : 687148549461700608,
  "created_at" : "2016-01-13 05:57:30 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687147406052429825",
  "geo" : { },
  "id_str" : "687148271274295296",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  The first step is to admit *you* have a *problem*",
  "id" : 687148271274295296,
  "in_reply_to_status_id" : 687147406052429825,
  "created_at" : "2016-01-13 05:44:49 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    }, {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "mafintosh",
      "indices" : [ 8, 18 ],
      "id_str" : "217505532",
      "id" : 217505532
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/687146638670839808\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/CFJ1cgsq4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYk8OgyUEAIcBqs.png",
      "id_str" : "687146638167511042",
      "id" : 687146638167511042,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYk8OgyUEAIcBqs.png",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/CFJ1cgsq4h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687137068368150528",
  "geo" : { },
  "id_str" : "687146638670839808",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross @mafintosh Great work, but I think a bug this serious needs a killer logo https:\/\/t.co\/CFJ1cgsq4h",
  "id" : 687146638670839808,
  "in_reply_to_status_id" : 687137068368150528,
  "created_at" : "2016-01-13 05:38:19 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687124834220773378",
  "text" : "in 2016 let's make explain a bad word",
  "id" : 687124834220773378,
  "created_at" : "2016-01-13 04:11:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687106935238205440",
  "text" : "everybody cheers, as the lights go dim and a disco ball descends #SOTU",
  "id" : 687106935238205440,
  "created_at" : "2016-01-13 03:00:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687103149811699712",
  "text" : "*switches from state of union address to people playing with bear videos*",
  "id" : 687103149811699712,
  "created_at" : "2016-01-13 02:45:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687099553586102272",
  "text" : "i've never had health insurance and I don't have any now, i just hope if something happens to me it's somebody else's fault",
  "id" : 687099553586102272,
  "created_at" : "2016-01-13 02:31:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687098572257374209",
  "text" : "is obama talking to those other people in the chamber who effusively pretend to care what he says about citizen?",
  "id" : 687098572257374209,
  "created_at" : "2016-01-13 02:27:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 9, 18 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687093979528073216",
  "geo" : { },
  "id_str" : "687094666307616768",
  "in_reply_to_user_id" : 46961216,
  "text" : "image by @substack who I steal art from all the time",
  "id" : 687094666307616768,
  "in_reply_to_status_id" : 687093979528073216,
  "created_at" : "2016-01-13 02:11:48 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/cUDHNpRaWc",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/break-or-bust",
      "display_url" : "soundcloud.com\/johnnyscript\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687093979528073216",
  "text" : "my latest code music, also one of my favorites\n\nhttps:\/\/t.co\/cUDHNpRaWc",
  "id" : 687093979528073216,
  "created_at" : "2016-01-13 02:09:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie rose",
      "screen_name" : "onemoremermaid",
      "indices" : [ 0, 15 ],
      "id_str" : "1499868055",
      "id" : 1499868055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687058903159291904",
  "geo" : { },
  "id_str" : "687085282772959232",
  "in_reply_to_user_id" : 1499868055,
  "text" : "@onemoremermaid  I would like to attend (you showed me your cockroach film at sudo room ~month ago)",
  "id" : 687085282772959232,
  "in_reply_to_status_id" : 687058903159291904,
  "created_at" : "2016-01-13 01:34:31 +0000",
  "in_reply_to_screen_name" : "onemoremermaid",
  "in_reply_to_user_id_str" : "1499868055",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/yL4JPEmUEG",
      "expanded_url" : "https:\/\/twitter.com\/steveklabnik\/status\/687050110128250881",
      "display_url" : "twitter.com\/steveklabnik\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687053126088540160",
  "text" : "fvck https:\/\/t.co\/yL4JPEmUEG",
  "id" : 687053126088540160,
  "created_at" : "2016-01-12 23:26:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/ZvLthIYW1I",
      "expanded_url" : "https:\/\/twitter.com\/girlziplocked\/status\/687021727478501376",
      "display_url" : "twitter.com\/girlziplocked\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687024904940617729",
  "text" : "Until then, continue educating men and enlightening fools https:\/\/t.co\/ZvLthIYW1I",
  "id" : 687024904940617729,
  "created_at" : "2016-01-12 21:34:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 3, 17 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687021709682032641",
  "text" : "RT @girlziplocked: You know who is a dick about coding being the future?\n\nCEOs.\n\nYou know who recognizes we all have other things to do?\n\nC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687020963943194624",
    "text" : "You know who is a dick about coding being the future?\n\nCEOs.\n\nYou know who recognizes we all have other things to do?\n\nCoders.",
    "id" : 687020963943194624,
    "created_at" : "2016-01-12 21:18:56 +0000",
    "user" : {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "protected" : false,
      "id_str" : "20221325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497445169797414913\/rvn1M8zY_normal.jpeg",
      "id" : 20221325,
      "verified" : false
    }
  },
  "id" : 687021709682032641,
  "created_at" : "2016-01-12 21:21:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687021249147486208",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  I just want to say hold on and get ready to forget about twitter and money-run social networks. but your effort is glorious.",
  "id" : 687021249147486208,
  "created_at" : "2016-01-12 21:20:04 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687018589971476480",
  "geo" : { },
  "id_str" : "687020250534039553",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked true, decentralization is on its way for social, then people can write opens source anti-harassment algorithms instead of pro",
  "id" : 687020250534039553,
  "in_reply_to_status_id" : 687018589971476480,
  "created_at" : "2016-01-12 21:16:06 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686986463548850176",
  "text" : "twitter is \/dev\/null",
  "id" : 686986463548850176,
  "created_at" : "2016-01-12 19:01:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686984720354152448",
  "text" : "you should have to ask the person who reports an issue to close the issue, not just close it in their face.  github and beyond.",
  "id" : 686984720354152448,
  "created_at" : "2016-01-12 18:54:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maximilian Klein",
      "screen_name" : "notconfusing",
      "indices" : [ 0, 13 ],
      "id_str" : "286504285",
      "id" : 286504285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/l7GpxJFKPq",
      "expanded_url" : "https:\/\/wayback.archive.org\/web\/20120214194015\/http:\/\/www.stanford.edu\/dept\/HPS\/Haraway\/CyborgManifesto.html",
      "display_url" : "wayback.archive.org\/web\/2012021419\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "686643144939540480",
  "geo" : { },
  "id_str" : "686649100767383552",
  "in_reply_to_user_id" : 286504285,
  "text" : "@notconfusing basically that identities are the atomized units of the capitalism factory, q.v. https:\/\/t.co\/l7GpxJFKPq",
  "id" : 686649100767383552,
  "in_reply_to_status_id" : 686643144939540480,
  "created_at" : "2016-01-11 20:41:17 +0000",
  "in_reply_to_screen_name" : "notconfusing",
  "in_reply_to_user_id_str" : "286504285",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686648446686646272",
  "text" : "Meritocracy is the asexually reproduced child of Plutocracy.",
  "id" : 686648446686646272,
  "created_at" : "2016-01-11 20:38:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/ES2fKcjiCU",
      "expanded_url" : "https:\/\/twitter.com\/girlziplocked\/status\/686633618068893697",
      "display_url" : "twitter.com\/girlziplocked\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686641433139265537",
  "text" : "this could be one of the best uses of drone technology https:\/\/t.co\/ES2fKcjiCU",
  "id" : 686641433139265537,
  "created_at" : "2016-01-11 20:10:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686347290257129472",
  "text" : "How to Tech Start Up:\n1. start idea\n2. invest $100 for .0000001 stake\n3. company valuates at $100000000\n4. tell crunch tech website\n5. fail",
  "id" : 686347290257129472,
  "created_at" : "2016-01-11 00:42:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 3, 9 ],
      "id_str" : "28131948",
      "id" : 28131948
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 11, 24 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686305274928353280",
  "text" : "RT @Plinz: @johnnyscript In principle the universe can spring random cat GIFs, but it is perhaps similarly unlikely.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "686204134966480896",
    "geo" : { },
    "id_str" : "686299329288613888",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript In principle the universe can spring random cat GIFs, but it is perhaps similarly unlikely.",
    "id" : 686299329288613888,
    "in_reply_to_status_id" : 686204134966480896,
    "created_at" : "2016-01-10 21:31:25 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "protected" : false,
      "id_str" : "28131948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717902898127044608\/o6PgkZFJ_normal.jpg",
      "id" : 28131948,
      "verified" : false
    }
  },
  "id" : 686305274928353280,
  "created_at" : "2016-01-10 21:55:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686204134966480896",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz  Do you reckon that if computation leads to consciousness (there being no other way?), then the universe may spring random thoughts?",
  "id" : 686204134966480896,
  "created_at" : "2016-01-10 15:13:09 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/N8eqD4ymnM",
      "expanded_url" : "https:\/\/twitter.com\/Charlotteis\/status\/686193676033388548",
      "display_url" : "twitter.com\/Charlotteis\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686202519920328704",
  "text" : "Gender is your magic wand. https:\/\/t.co\/N8eqD4ymnM",
  "id" : 686202519920328704,
  "created_at" : "2016-01-10 15:06:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 3, 9 ],
      "id_str" : "28131948",
      "id" : 28131948
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 11, 24 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686200527101661184",
  "text" : "RT @Plinz: @johnnyscript Our consciousness seems to have evolved as a very specific set of mechanisms, in answer to the problems of social \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "686041440611241984",
    "geo" : { },
    "id_str" : "686075520799387652",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript Our consciousness seems to have evolved as a very specific set of mechanisms, in answer to the problems of social primates.",
    "id" : 686075520799387652,
    "in_reply_to_status_id" : 686041440611241984,
    "created_at" : "2016-01-10 06:42:05 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "protected" : false,
      "id_str" : "28131948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717902898127044608\/o6PgkZFJ_normal.jpg",
      "id" : 28131948,
      "verified" : false
    }
  },
  "id" : 686200527101661184,
  "created_at" : "2016-01-10 14:58:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 3, 9 ],
      "id_str" : "28131948",
      "id" : 28131948
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 11, 24 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686200355093217281",
  "text" : "RT @Plinz: @johnnyscript Not clear if the universe itself had any problems to solve.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "686075520799387652",
    "geo" : { },
    "id_str" : "686075654878662656",
    "in_reply_to_user_id" : 28131948,
    "text" : "@johnnyscript Not clear if the universe itself had any problems to solve.",
    "id" : 686075654878662656,
    "in_reply_to_status_id" : 686075520799387652,
    "created_at" : "2016-01-10 06:42:37 +0000",
    "in_reply_to_screen_name" : "Plinz",
    "in_reply_to_user_id_str" : "28131948",
    "user" : {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "protected" : false,
      "id_str" : "28131948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717902898127044608\/o6PgkZFJ_normal.jpg",
      "id" : 28131948,
      "verified" : false
    }
  },
  "id" : 686200355093217281,
  "created_at" : "2016-01-10 14:58:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686075654878662656",
  "geo" : { },
  "id_str" : "686199997398827008",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz  also very interested in your analysis of love, apropos consciousness.  You remark several times somewhat mystically  ;^)",
  "id" : 686199997398827008,
  "in_reply_to_status_id" : 686075654878662656,
  "created_at" : "2016-01-10 14:56:43 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/686199527351554048\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/dsVerTw9SX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYXe1XcUQAQn0i_.png",
      "id_str" : "686199526651084804",
      "id" : 686199526651084804,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYXe1XcUQAQn0i_.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 953,
        "resize" : "fit",
        "w" : 1796
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dsVerTw9SX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686075654878662656",
  "geo" : { },
  "id_str" : "686199527351554048",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz  ah cuz computation != consciousness?  This is where I wondered if you thought so or not: https:\/\/t.co\/dsVerTw9SX",
  "id" : 686199527351554048,
  "in_reply_to_status_id" : 686075654878662656,
  "created_at" : "2016-01-10 14:54:50 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686102390362247168",
  "geo" : { },
  "id_str" : "686197344761610240",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  TAKE ME THERE",
  "id" : 686197344761610240,
  "in_reply_to_status_id" : 686102390362247168,
  "created_at" : "2016-01-10 14:46:10 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686060602251296768",
  "text" : "Sean Penn for secretary of State",
  "id" : 686060602251296768,
  "created_at" : "2016-01-10 05:42:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dog Solution",
      "screen_name" : "DogSolutions",
      "indices" : [ 3, 16 ],
      "id_str" : "40343143",
      "id" : 40343143
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DogSolutions\/status\/686019090104856578\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/2jcgQl1tD2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYU6ujIWsAAo-PW.jpg",
      "id_str" : "686019089622544384",
      "id" : 686019089622544384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYU6ujIWsAAo-PW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 595
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 595
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 595
      } ],
      "display_url" : "pic.twitter.com\/2jcgQl1tD2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686042787825848320",
  "text" : "RT @DogSolutions: HOW2: Impress a dog? Perhap, deg have seen all universe, and only here to company us. We are to be impress, by dog. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DogSolutions\/status\/686019090104856578\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/2jcgQl1tD2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYU6ujIWsAAo-PW.jpg",
        "id_str" : "686019089622544384",
        "id" : 686019089622544384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYU6ujIWsAAo-PW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 595
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 595
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 595
        } ],
        "display_url" : "pic.twitter.com\/2jcgQl1tD2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686019090104856578",
    "text" : "HOW2: Impress a dog? Perhap, deg have seen all universe, and only here to company us. We are to be impress, by dog. https:\/\/t.co\/2jcgQl1tD2",
    "id" : 686019090104856578,
    "created_at" : "2016-01-10 02:57:51 +0000",
    "user" : {
      "name" : "Dog Solution",
      "screen_name" : "DogSolutions",
      "protected" : false,
      "id_str" : "40343143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451138333360402432\/nZ7vdu_r_normal.png",
      "id" : 40343143,
      "verified" : false
    }
  },
  "id" : 686042787825848320,
  "created_at" : "2016-01-10 04:32:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/xCVqQ94h2D",
      "expanded_url" : "https:\/\/media.ccc.de\/v\/30C3_-_5526_-_en_-_saal_2_-_201312291600_-_how_to_build_a_mind_-_joscha",
      "display_url" : "media.ccc.de\/v\/30C3_-_5526_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686041582500356098",
  "text" : "more like how to blow a mind https:\/\/t.co\/xCVqQ94h2D",
  "id" : 686041582500356098,
  "created_at" : "2016-01-10 04:27:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686041440611241984",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz  After watching your CCC presentation, I would like to know if you believe the universe is conscious.",
  "id" : 686041440611241984,
  "created_at" : "2016-01-10 04:26:40 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ResistCapitalism",
      "indices" : [ 32, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685978949260685312",
  "text" : "drop out\nget together\npower up\n\n#ResistCapitalism",
  "id" : 685978949260685312,
  "created_at" : "2016-01-10 00:18:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nessa.",
      "screen_name" : "curlyheadRED",
      "indices" : [ 3, 16 ],
      "id_str" : "39793617",
      "id" : 39793617
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/curlyheadRED\/status\/685949509558497285\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/tU9j96PETP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYT7caCVAAAMpbz.jpg",
      "id_str" : "685949508711153664",
      "id" : 685949508711153664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYT7caCVAAAMpbz.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/tU9j96PETP"
    } ],
    "hashtags" : [ {
      "text" : "ResistCapitalism",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685968311083909121",
  "text" : "RT @curlyheadRED: Folks love quoting MLK but skip right past all of his condemnation on capitalism. #ResistCapitalism https:\/\/t.co\/tU9j96PE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/curlyheadRED\/status\/685949509558497285\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/tU9j96PETP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYT7caCVAAAMpbz.jpg",
        "id_str" : "685949508711153664",
        "id" : 685949508711153664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYT7caCVAAAMpbz.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/tU9j96PETP"
      } ],
      "hashtags" : [ {
        "text" : "ResistCapitalism",
        "indices" : [ 82, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685949509558497285",
    "text" : "Folks love quoting MLK but skip right past all of his condemnation on capitalism. #ResistCapitalism https:\/\/t.co\/tU9j96PETP",
    "id" : 685949509558497285,
    "created_at" : "2016-01-09 22:21:22 +0000",
    "user" : {
      "name" : "Nessa.",
      "screen_name" : "curlyheadRED",
      "protected" : false,
      "id_str" : "39793617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727548650361098241\/DD4Q18Eu_normal.jpg",
      "id" : 39793617,
      "verified" : false
    }
  },
  "id" : 685968311083909121,
  "created_at" : "2016-01-09 23:36:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685927967093055488",
  "geo" : { },
  "id_str" : "685939089460215808",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  oh yeah, big cooking supplies++",
  "id" : 685939089460215808,
  "in_reply_to_status_id" : 685927967093055488,
  "created_at" : "2016-01-09 21:39:57 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685925432965894145",
  "geo" : { },
  "id_str" : "685926108097691649",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair yes make that a priority for sure (kettles == carboys?)",
  "id" : 685926108097691649,
  "in_reply_to_status_id" : 685925432965894145,
  "created_at" : "2016-01-09 20:48:22 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/685676691004370949\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/LXSelpKxcz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYQDUSXUEAAVDhq.jpg",
      "id_str" : "685676690329047040",
      "id" : 685676690329047040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYQDUSXUEAAVDhq.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 990
      } ],
      "display_url" : "pic.twitter.com\/LXSelpKxcz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685676691004370949",
  "text" : "When somebody I like asks me to join their polycrusherie https:\/\/t.co\/LXSelpKxcz",
  "id" : 685676691004370949,
  "created_at" : "2016-01-09 04:17:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685651651777134592",
  "geo" : { },
  "id_str" : "685654042173779968",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair hahaha",
  "id" : 685654042173779968,
  "in_reply_to_status_id" : 685651651777134592,
  "created_at" : "2016-01-09 02:47:17 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685626166602891264",
  "text" : "I try to communicate and I end up feeling more alone.",
  "id" : 685626166602891264,
  "created_at" : "2016-01-09 00:56:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685562743101898752",
  "text" : "I approve: \"Let's be l33t postgendered transhuman multiplexed identityfuckers.\"",
  "id" : 685562743101898752,
  "created_at" : "2016-01-08 20:44:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685304151740317696",
  "text" : "never watched stars war not starting now.",
  "id" : 685304151740317696,
  "created_at" : "2016-01-08 03:36:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685275606603317248",
  "text" : "I'm down to 11.6 volts",
  "id" : 685275606603317248,
  "created_at" : "2016-01-08 01:43:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685261121993879553",
  "text" : "my misery is exquisite",
  "id" : 685261121993879553,
  "created_at" : "2016-01-08 00:45:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685241538545201152",
  "text" : "lit rally",
  "id" : 685241538545201152,
  "created_at" : "2016-01-07 23:28:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rune B",
      "screen_name" : "sp00x",
      "indices" : [ 0, 6 ],
      "id_str" : "34296797",
      "id" : 34296797
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 7, 19 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "kelsey \u1555( \u141B )\u1557",
      "screen_name" : "_K_E_L_S_E_Y",
      "indices" : [ 20, 33 ],
      "id_str" : "435236587",
      "id" : 435236587
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 34, 43 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684875647685111809",
  "geo" : { },
  "id_str" : "684895387056881665",
  "in_reply_to_user_id" : 34296797,
  "text" : "@sp00x @marinakukso @_K_E_L_S_E_Y @substack  \n\nI would have but such a joke would likely create a maximum psychic stack size exceeded error.",
  "id" : 684895387056881665,
  "in_reply_to_status_id" : 684875647685111809,
  "created_at" : "2016-01-07 00:32:39 +0000",
  "in_reply_to_screen_name" : "sp00x",
  "in_reply_to_user_id_str" : "34296797",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "kelsey \u1555( \u141B )\u1557",
      "screen_name" : "_K_E_L_S_E_Y",
      "indices" : [ 13, 26 ],
      "id_str" : "435236587",
      "id" : 435236587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EELzbCpg6G",
      "expanded_url" : "http:\/\/socialistworker.org\/2015\/06\/24\/class-capitalism-and-the-tech",
      "display_url" : "socialistworker.org\/2015\/06\/24\/cla\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "684801247564546048",
  "geo" : { },
  "id_str" : "684829877791358976",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso @_K_E_L_S_E_Y \n\nYep, programmers are working class, aka Capitalism's favorite class to abuse, see also  https:\/\/t.co\/EELzbCpg6G",
  "id" : 684829877791358976,
  "in_reply_to_status_id" : 684801247564546048,
  "created_at" : "2016-01-06 20:12:21 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684501978886475776",
  "geo" : { },
  "id_str" : "684502071987453952",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  use it but wisely",
  "id" : 684502071987453952,
  "in_reply_to_status_id" : 684501978886475776,
  "created_at" : "2016-01-05 22:29:46 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684501978886475776",
  "text" : "ye'll twitter is a shitty social medium sucking up your time, talent &amp; connection-making, and in return giving you all kinda false senses.",
  "id" : 684501978886475776,
  "created_at" : "2016-01-05 22:29:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684500302267957248",
  "text" : "if you read any of my tweets and don't &lt;3 it, you are a withholding and making me sad",
  "id" : 684500302267957248,
  "created_at" : "2016-01-05 22:22:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684498878503124992",
  "text" : "If you need a quick extra dependant for your income taxes, let's talk allowance.",
  "id" : 684498878503124992,
  "created_at" : "2016-01-05 22:17:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684498591986003968",
  "text" : "My 2015 income was approximately 1.5 bitcoin and a couple hundo cash.",
  "id" : 684498591986003968,
  "created_at" : "2016-01-05 22:15:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684498006230437889",
  "text" : "I need some people to make me a books wish list, and some people to fulfill it, thanks in advance.",
  "id" : 684498006230437889,
  "created_at" : "2016-01-05 22:13:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/b579klqXGK",
      "expanded_url" : "https:\/\/twitter.com\/mask_mag\/status\/684487134124707842",
      "display_url" : "twitter.com\/mask_mag\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684495841030057984",
  "text" : "\"Where the meaning of life is to be noticed for w\/e clever and poetic disassociations you employ merely to survive.\" https:\/\/t.co\/b579klqXGK",
  "id" : 684495841030057984,
  "created_at" : "2016-01-05 22:05:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684494893134163968",
  "text" : "Calling it \"late stage capitalism\" is so very optimistic, imho.",
  "id" : 684494893134163968,
  "created_at" : "2016-01-05 22:01:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684493598419636224",
  "text" : "We should not share bad \/ ugly \/ stupid news, unless it is actionable, and action is demanded.  This is the cure for the common media.",
  "id" : 684493598419636224,
  "created_at" : "2016-01-05 21:56:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684490095332741120",
  "text" : "I am living a completely snack-less existence.  Everything I eat mus be prepared from raw.  This is not a humble brag.  Johnny &lt;3 snacks.",
  "id" : 684490095332741120,
  "created_at" : "2016-01-05 21:42:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh Kennedy",
      "screen_name" : "hughskennedy",
      "indices" : [ 0, 13 ],
      "id_str" : "338334935",
      "id" : 338334935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684323965116940288",
  "geo" : { },
  "id_str" : "684484351048851457",
  "in_reply_to_user_id" : 338334935,
  "text" : "@hughskennedy  what are buffers in this context?",
  "id" : 684484351048851457,
  "in_reply_to_status_id" : 684323965116940288,
  "created_at" : "2016-01-05 21:19:21 +0000",
  "in_reply_to_screen_name" : "hughskennedy",
  "in_reply_to_user_id_str" : "338334935",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684179045202833408",
  "text" : "cooking beans in a wok over a fire, \nsunlight, water, and internet--\nthe only things I require.",
  "id" : 684179045202833408,
  "created_at" : "2016-01-05 01:06:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683828210023284736",
  "geo" : { },
  "id_str" : "683832878870863872",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  probably a abundance of overgrown genetically modified buffalo organisms",
  "id" : 683832878870863872,
  "in_reply_to_status_id" : 683828210023284736,
  "created_at" : "2016-01-04 02:10:37 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]