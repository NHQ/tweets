Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17274095133",
  "geo" : { },
  "id_str" : "17437513368",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb the propagation of waves",
  "id" : 17437513368,
  "in_reply_to_status_id" : 17274095133,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17440420395",
  "geo" : { },
  "id_str" : "17443062180",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb torus wonder why everything seem to be moving away in all directions ... Was it something torus banged?",
  "id" : 17443062180,
  "in_reply_to_status_id" : 17440420395,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17273900893",
  "text" : "hurricanes are going to splatter oil over the south. sorry, the south!",
  "id" : 17273900893,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dfw",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "tennis",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "wimbledon",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16888825064",
  "text" : "wow, if only david foster wallace was alive to see this (( #dfw #tennis #wimbledon )) http:\/\/nyti.ms\/98E0NW",
  "id" : 16888825064,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 0, 10 ],
      "id_str" : "15865878",
      "id" : 15865878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16927908607",
  "geo" : { },
  "id_str" : "16933187310",
  "in_reply_to_user_id" : 15865878,
  "text" : "@NiemanLab \"happy iphone 4 day?\" Is gadget fappery the high end journalism u harvard heads set out to protect? I dont think its endangered.",
  "id" : 16933187310,
  "in_reply_to_status_id" : 16927908607,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "NiemanLab",
  "in_reply_to_user_id_str" : "15865878",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chicago",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16878512028",
  "text" : "#chicago free stripper pole http:\/\/chicago.craigslist.org\/chc\/zip\/1807258741.html",
  "id" : 16878512028,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15975464098",
  "text" : "can't wait to watch Brazil vs N. korea world cup soccer",
  "id" : 15975464098,
  "created_at" : "2010-06-12 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worldcup",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15990430422",
  "text" : "#worldcup runeth over me",
  "id" : 15990430422,
  "created_at" : "2010-06-12 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15990568711",
  "text" : "what a witch is this AZ governor http:\/\/bit.ly\/dyYn77",
  "id" : 15990568711,
  "created_at" : "2010-06-12 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 113, 123 ],
      "id_str" : "15865878",
      "id" : 15865878
    }, {
      "name" : "Mediagazer",
      "screen_name" : "mediagazer",
      "indices" : [ 124, 135 ],
      "id_str" : "75357513",
      "id" : 75357513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15217580400",
  "text" : "Is it good journalism to say US Supreme Court J's are part of conservative \/ liberal blocs? http:\/\/bit.ly\/cZ8jQh @niemanlab @mediagazer",
  "id" : 15217580400,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15219520294",
  "text" : "Sympathies failing. Shut down. Reserve power for weapons. Don't fire til the computer tells you to. Computer, u got it. What's done is done.",
  "id" : 15219520294,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 33, 38 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15224299949",
  "text" : "12 minutes to Soyuz landing live @nasa http:\/\/bit.ly\/bXMe2J",
  "id" : 15224299949,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 12, 23 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15279599362",
  "text" : "if you play @foursquare you are a ponce",
  "id" : 15279599362,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Random Guy",
      "screen_name" : "ThatRandGuy",
      "indices" : [ 17, 29 ],
      "id_str" : "1638646304",
      "id" : 1638646304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15280998005",
  "text" : "you can check in @thatrandguy  but you can't check in to cash \u221A",
  "id" : 15280998005,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquin",
      "screen_name" : "foursquin",
      "indices" : [ 10, 20 ],
      "id_str" : "283811223",
      "id" : 283811223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15281260739",
  "text" : "more like @foursquin am i rite",
  "id" : 15281260739,
  "created_at" : "2010-06-02 00:00:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]