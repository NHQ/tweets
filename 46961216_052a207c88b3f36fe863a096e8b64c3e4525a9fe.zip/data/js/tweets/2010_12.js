Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20961669542838272",
  "text" : "turning off the real time new years celebration",
  "id" : 20961669542838272,
  "created_at" : "2010-12-31 21:57:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20957598173888512",
  "text" : "Truly an awful decade coming to an end here.",
  "id" : 20957598173888512,
  "created_at" : "2010-12-31 21:40:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20940490073448448",
  "text" : "fuck the internet!",
  "id" : 20940490073448448,
  "created_at" : "2010-12-31 20:32:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20417298074435584",
  "text" : "People, chanting aphorism into the people void",
  "id" : 20417298074435584,
  "created_at" : "2010-12-30 09:53:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20387256363651072",
  "text" : "What came first, the music or the dance?",
  "id" : 20387256363651072,
  "created_at" : "2010-12-30 07:54:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Stewart",
      "screen_name" : "MrFaulty",
      "indices" : [ 0, 9 ],
      "id_str" : "721751109132554242",
      "id" : 721751109132554242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20340941357322240",
  "text" : "@mrfaulty something about bad apples w\/r\/t spoilage",
  "id" : 20340941357322240,
  "created_at" : "2010-12-30 04:50:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20005112927756288",
  "text" : "Sir, please, allow me to wear the pants. This ain't no job for tumbled rocks.",
  "id" : 20005112927756288,
  "created_at" : "2010-12-29 06:36:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20004303779397632",
  "text" : "ima make my fortune in California wearing nobleman's blue jeans for them. no washing, showering. no underwear: new meaning to \"stone washed\"",
  "id" : 20004303779397632,
  "created_at" : "2010-12-29 06:32:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20003399055446016",
  "text" : "The evolution of one pair our Made in USA \u201CCalifornian\u201D Blue Jeans, after about 5 months of regular wear and abuse\u2026",
  "id" : 20003399055446016,
  "created_at" : "2010-12-29 06:29:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "Nestor Br\u00FBl\u00E9e",
      "screen_name" : "Nestor_tweets",
      "indices" : [ 17, 31 ],
      "id_str" : "221527591",
      "id" : 221527591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "20000896129703936",
  "geo" : { },
  "id_str" : "20001747355312130",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin @nestor_tweets i'M WILLING TO PAY EXTRA FOR DEPRESSION ERA WORKWEAR",
  "id" : 20001747355312130,
  "in_reply_to_status_id" : 20000896129703936,
  "created_at" : "2010-12-29 06:22:42 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19990194912493568",
  "text" : "RT @roundmyskull: Please start following this blog right now: Cardboard Cutout Sundown http:\/\/tinyurl.com\/382gqn9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "19973782940684289",
    "text" : "Please start following this blog right now: Cardboard Cutout Sundown http:\/\/tinyurl.com\/382gqn9",
    "id" : 19973782940684289,
    "created_at" : "2010-12-29 04:31:35 +0000",
    "user" : {
      "name" : "50 Watts",
      "screen_name" : "50WattsDotCom",
      "protected" : false,
      "id_str" : "15798635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629808186\/twitter-gebrauchs_normal.jpg",
      "id" : 15798635,
      "verified" : false
    }
  },
  "id" : 19990194912493568,
  "created_at" : "2010-12-29 05:36:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19979458031132672",
  "text" : "I always win that game",
  "id" : 19979458031132672,
  "created_at" : "2010-12-29 04:54:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truegritsequels",
      "indices" : [ 20, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19978906601787392",
  "text" : "Sufferin' Succotash #truegritsequels",
  "id" : 19978906601787392,
  "created_at" : "2010-12-29 04:51:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truegritsequels",
      "indices" : [ 13, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19978730264858624",
  "text" : "Cheese Grits #truegritsequels",
  "id" : 19978730264858624,
  "created_at" : "2010-12-29 04:51:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19969576775192576",
  "geo" : { },
  "id_str" : "19969878630862848",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin i just ate ayer veda food. I ate it a little too fast tho.",
  "id" : 19969878630862848,
  "in_reply_to_status_id" : 19969576775192576,
  "created_at" : "2010-12-29 04:16:04 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19967766819770368",
  "geo" : { },
  "id_str" : "19969332419239937",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin for what length of time?",
  "id" : 19969332419239937,
  "in_reply_to_status_id" : 19967766819770368,
  "created_at" : "2010-12-29 04:13:54 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Pequin",
      "screen_name" : "ryanpequin",
      "indices" : [ 0, 11 ],
      "id_str" : "17587331",
      "id" : 17587331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19637655595655170",
  "geo" : { },
  "id_str" : "19643554653540352",
  "in_reply_to_user_id" : 17587331,
  "text" : "@ryanpequin i forgot too, how hilarious hipster runnoff is",
  "id" : 19643554653540352,
  "in_reply_to_status_id" : 19637655595655170,
  "created_at" : "2010-12-28 06:39:23 +0000",
  "in_reply_to_screen_name" : "ryanpequin",
  "in_reply_to_user_id_str" : "17587331",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19636940018028544",
  "text" : "this bee a xmas gif if ever i had one sting so funny http:\/\/ameliagray.com\/?p=1818",
  "id" : 19636940018028544,
  "created_at" : "2010-12-28 06:13:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19513127838158848",
  "text" : "troubleshooting. trouble shooting back.",
  "id" : 19513127838158848,
  "created_at" : "2010-12-27 22:01:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bradford cross",
      "screen_name" : "bradfordcross",
      "indices" : [ 0, 14 ],
      "id_str" : "36153601",
      "id" : 36153601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19282458197360640",
  "geo" : { },
  "id_str" : "19283687245873152",
  "in_reply_to_user_id" : 36153601,
  "text" : "@bradfordcross Cairo, IL? I love that city! Tho, I doubt you'll find any of those whom you seek there.",
  "id" : 19283687245873152,
  "in_reply_to_status_id" : 19282458197360640,
  "created_at" : "2010-12-27 06:49:23 +0000",
  "in_reply_to_screen_name" : "bradfordcross",
  "in_reply_to_user_id_str" : "36153601",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 0, 7 ],
      "id_str" : "15540222",
      "id" : 15540222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "19279456266883075",
  "geo" : { },
  "id_str" : "19282329461592064",
  "in_reply_to_user_id" : 15540222,
  "text" : "@rauchg also, you are a southpark character???",
  "id" : 19282329461592064,
  "in_reply_to_status_id" : 19279456266883075,
  "created_at" : "2010-12-27 06:44:00 +0000",
  "in_reply_to_screen_name" : "rauchg",
  "in_reply_to_user_id_str" : "15540222",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19235465332793344",
  "text" : "don't you wish you could download hardware?",
  "id" : 19235465332793344,
  "created_at" : "2010-12-27 03:37:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bittorrentxmas",
      "indices" : [ 73, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19234242567340032",
  "text" : "which Phillip K. Dick book should I read first, now that I have them all #bittorrentxmas",
  "id" : 19234242567340032,
  "created_at" : "2010-12-27 03:32:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18189189229051904",
  "text" : "GIve me a budget of guns and blood.",
  "id" : 18189189229051904,
  "created_at" : "2010-12-24 06:20:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18188709400682496",
  "text" : "just watched Johnnie To's Vengence, starting to think To is a hack.",
  "id" : 18188709400682496,
  "created_at" : "2010-12-24 06:18:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18187977616261120",
  "text" : "today is not for stylesheets",
  "id" : 18187977616261120,
  "created_at" : "2010-12-24 06:15:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "18061871772860416",
  "geo" : { },
  "id_str" : "18062998732017664",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia served!",
  "id" : 18062998732017664,
  "in_reply_to_status_id" : 18061871772860416,
  "created_at" : "2010-12-23 21:58:49 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17457471211708416",
  "text" : "wow this is a fun game http:\/\/www.pirateslovedaisies.com\/",
  "id" : 17457471211708416,
  "created_at" : "2010-12-22 05:52:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AS-ISN'T CO.",
      "screen_name" : "asisntco",
      "indices" : [ 0, 9 ],
      "id_str" : "42496785",
      "id" : 42496785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17450697377185792",
  "geo" : { },
  "id_str" : "17452667991236608",
  "in_reply_to_user_id" : 42496785,
  "text" : "@asisntco i think u mean: $35 Million + $180 Million =  $3 Billion which is some math right there",
  "id" : 17452667991236608,
  "in_reply_to_status_id" : 17450697377185792,
  "created_at" : "2010-12-22 05:33:34 +0000",
  "in_reply_to_screen_name" : "asisntco",
  "in_reply_to_user_id_str" : "42496785",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17135390829846529",
  "text" : "looked at the lunar eclipse directly above, and then looked opposite of it, down below where the sun is, and I experienced slight vertigo",
  "id" : 17135390829846529,
  "created_at" : "2010-12-21 08:32:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17110173311045632",
  "text" : "lunar eclipse about halfway right now twitter lovers",
  "id" : 17110173311045632,
  "created_at" : "2010-12-21 06:52:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17109044854525952",
  "text" : "Vestibulum eget tellus eget augue rhoncus eleifend. Integer orci magna, dapibus pretium facilisis non, laoreet sed nisl.",
  "id" : 17109044854525952,
  "created_at" : "2010-12-21 06:48:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rosen",
      "screen_name" : "jayrosen_nyu",
      "indices" : [ 0, 13 ],
      "id_str" : "14834340",
      "id" : 14834340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17056028273152000",
  "geo" : { },
  "id_str" : "17097418134790144",
  "in_reply_to_user_id" : 14834340,
  "text" : "@jayrosen_nyu I didn't know there was a difference between the bankers and the regulators. They where the same uniform.",
  "id" : 17097418134790144,
  "in_reply_to_status_id" : 17056028273152000,
  "created_at" : "2010-12-21 06:01:56 +0000",
  "in_reply_to_screen_name" : "jayrosen_nyu",
  "in_reply_to_user_id_str" : "14834340",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17096886733250561",
  "text" : "now is when i consider the horizontal alignment of text columns on the internet",
  "id" : 17096886733250561,
  "created_at" : "2010-12-21 05:59:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17081712005611521",
  "text" : "people who don't even know are gonna regret forcing me to hustle my own (by not hiring me)",
  "id" : 17081712005611521,
  "created_at" : "2010-12-21 04:59:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16954401189011456",
  "geo" : { },
  "id_str" : "16955959108706304",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb http:\/\/impactjs.com\/",
  "id" : 16955959108706304,
  "in_reply_to_status_id" : 16954401189011456,
  "created_at" : "2010-12-20 20:39:50 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16953834236551168",
  "text" : "got my pro.embed.ly beta account yehaw!",
  "id" : 16953834236551168,
  "created_at" : "2010-12-20 20:31:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16714501248258048",
  "geo" : { },
  "id_str" : "16724236705992704",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb \"serenyippity\"",
  "id" : 16724236705992704,
  "in_reply_to_status_id" : 16714501248258048,
  "created_at" : "2010-12-20 05:19:03 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16712759517384704",
  "geo" : { },
  "id_str" : "16714287410053120",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb well banish the idea out of your head, cuz neither of us can rehister it in NM",
  "id" : 16714287410053120,
  "in_reply_to_status_id" : 16712759517384704,
  "created_at" : "2010-12-20 04:39:31 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16712858091913216",
  "geo" : { },
  "id_str" : "16713964696113152",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb \"you can smell the american spirits within\"",
  "id" : 16713964696113152,
  "in_reply_to_status_id" : 16712858091913216,
  "created_at" : "2010-12-20 04:38:14 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16712360987205632",
  "geo" : { },
  "id_str" : "16712675421593600",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb \"does it run ok?\" \"yeah it runs great\"",
  "id" : 16712675421593600,
  "in_reply_to_status_id" : 16712360987205632,
  "created_at" : "2010-12-20 04:33:06 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16707856636055553",
  "geo" : { },
  "id_str" : "16712381803532288",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb also shall i take it that the other options fell thru?",
  "id" : 16712381803532288,
  "in_reply_to_status_id" : 16707856636055553,
  "created_at" : "2010-12-20 04:31:56 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16707856636055553",
  "geo" : { },
  "id_str" : "16711999773741058",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb ehm why don't you just find ur way out here and then see about seeing about things",
  "id" : 16711999773741058,
  "in_reply_to_status_id" : 16707856636055553,
  "created_at" : "2010-12-20 04:30:25 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16646884999303168",
  "geo" : { },
  "id_str" : "16654464182124544",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb its sittin just off Historic Route 66 in ABQ",
  "id" : 16654464182124544,
  "in_reply_to_status_id" : 16646884999303168,
  "created_at" : "2010-12-20 00:41:48 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16625057820319744",
  "geo" : { },
  "id_str" : "16625497047830528",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin should i buy that van we saw for 300???",
  "id" : 16625497047830528,
  "in_reply_to_status_id" : 16625057820319744,
  "created_at" : "2010-12-19 22:46:42 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16619756006150145",
  "geo" : { },
  "id_str" : "16624680219705344",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin grapenuts for every meal!",
  "id" : 16624680219705344,
  "in_reply_to_status_id" : 16619756006150145,
  "created_at" : "2010-12-19 22:43:27 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "passthetray",
      "indices" : [ 70, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16413249603899392",
  "geo" : { },
  "id_str" : "16439851972829184",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb people will pay money to be shown what you speak of. #passthetray",
  "id" : 16439851972829184,
  "in_reply_to_status_id" : 16413249603899392,
  "created_at" : "2010-12-19 10:29:00 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16328712207212544",
  "text" : "birefly consodering buying domain name askallowed.com",
  "id" : 16328712207212544,
  "created_at" : "2010-12-19 03:07:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16328282882441216",
  "text" : "#DADT Repealed. Let's all ask who conspired to assassinate Kennedy.",
  "id" : 16328282882441216,
  "created_at" : "2010-12-19 03:05:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "indices" : [ 0, 9 ],
      "id_str" : "224",
      "id" : 224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16326512491892736",
  "geo" : { },
  "id_str" : "16327343144443906",
  "in_reply_to_user_id" : 224,
  "text" : "@davepell They say the truth will set you free. Now, in one of the  lowest echelons of gov't, the truth is no longer barred. More to follow?",
  "id" : 16327343144443906,
  "in_reply_to_status_id" : 16326512491892736,
  "created_at" : "2010-12-19 03:01:56 +0000",
  "in_reply_to_screen_name" : "davepell",
  "in_reply_to_user_id_str" : "224",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16326530888110080",
  "text" : "briefly considered buying domain name tehknowledgy.com",
  "id" : 16326530888110080,
  "created_at" : "2010-12-19 02:58:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16254028698624000",
  "geo" : { },
  "id_str" : "16261175155105792",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb so you saying that truth is beauty but since beauty is truth then truth is beauty is truth, cannot compute?",
  "id" : 16261175155105792,
  "in_reply_to_status_id" : 16254028698624000,
  "created_at" : "2010-12-18 22:39:00 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16243923261325312",
  "geo" : { },
  "id_str" : "16253377528733696",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb what is truth and what is beauty then HUH",
  "id" : 16253377528733696,
  "in_reply_to_status_id" : 16243923261325312,
  "created_at" : "2010-12-18 22:08:01 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16217618025291776",
  "geo" : { },
  "id_str" : "16243458280783872",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb truth and beauty are one. U cant fux with that.",
  "id" : 16243458280783872,
  "in_reply_to_status_id" : 16217618025291776,
  "created_at" : "2010-12-18 21:28:36 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16072437967884288",
  "geo" : { },
  "id_str" : "16078314691100673",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin good morning!",
  "id" : 16078314691100673,
  "in_reply_to_status_id" : 16072437967884288,
  "created_at" : "2010-12-18 10:32:23 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16036245100564481",
  "text" : "Cap't Beefheart's home\/recording studio went up for sale a few a few months ago http:\/\/bit.ly\/hWK62c",
  "id" : 16036245100564481,
  "created_at" : "2010-12-18 07:45:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15993888477028352",
  "text" : "ok but its touchy! (the tether)",
  "id" : 15993888477028352,
  "created_at" : "2010-12-18 04:56:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15992133441814528",
  "text" : "Also opera's new mobile browser 4 android is tits supreme",
  "id" : 15992133441814528,
  "created_at" : "2010-12-18 04:49:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15991947546071040",
  "text" : "HAHA I did it! I tethered my computer to my cell phone and beat the internet outage! Connection speeds pretty good.",
  "id" : 15991947546071040,
  "created_at" : "2010-12-18 04:49:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15919111804555264",
  "text" : "Why do all tethering services require I download software on the computer that isn't connected to the internet?",
  "id" : 15919111804555264,
  "created_at" : "2010-12-17 23:59:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15910283125981184",
  "text" : "Update. Half day without internet. Realized ive wasted my dubs. But thats what the dubs are for!",
  "id" : 15910283125981184,
  "created_at" : "2010-12-17 23:24:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15908420309745664",
  "text" : "ought I become a novelist?",
  "id" : 15908420309745664,
  "created_at" : "2010-12-17 23:17:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15907595952852993",
  "text" : "Internet out til monday. Sensations creeping.",
  "id" : 15907595952852993,
  "created_at" : "2010-12-17 23:14:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15899153179607040",
  "text" : "Shoot I had forgotten that mark twains autobiography was printed this year. Might actually purchase a new thing.",
  "id" : 15899153179607040,
  "created_at" : "2010-12-17 22:40:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15893111255343104",
  "text" : "Internet connection down today.watching cspan. muppets arguing nuclear arms treaty like true cold warriors. All about \"the russians\"!",
  "id" : 15893111255343104,
  "created_at" : "2010-12-17 22:16:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15690295890939904",
  "text" : "RT @GeoShore: Yahoo may close down AltaVista?! Might have to migrate to Lycos, Webcrawler or Veronica\/Gopher :( Going to send a protest  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "15511839098011648",
    "text" : "Yahoo may close down AltaVista?! Might have to migrate to Lycos, Webcrawler or Veronica\/Gopher :( Going to send a protest email over telnet.",
    "id" : 15511839098011648,
    "created_at" : "2010-12-16 21:01:25 +0000",
    "user" : {
      "name" : "John Kirriemuir",
      "screen_name" : "Wordshore",
      "protected" : false,
      "id_str" : "17076362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665516769092739072\/cYbJJvG6_normal.jpg",
      "id" : 17076362,
      "verified" : false
    }
  },
  "id" : 15690295890939904,
  "created_at" : "2010-12-17 08:50:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15687492858552321",
  "text" : "damn, why did grapenuts cost twice as much in Chicago as they do in Albuquerque?",
  "id" : 15687492858552321,
  "created_at" : "2010-12-17 08:39:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15671945135661056",
  "text" : "all the bad things they say about satellite television are true",
  "id" : 15671945135661056,
  "created_at" : "2010-12-17 07:37:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15668339091177472",
  "text" : "according to this here astrolabe, today is a day ima gonna bathe",
  "id" : 15668339091177472,
  "created_at" : "2010-12-17 07:23:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15662444030468096",
  "geo" : { },
  "id_str" : "15662980758765568",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin did u see this yet http:\/\/bit.ly\/eBi4kK",
  "id" : 15662980758765568,
  "in_reply_to_status_id" : 15662444030468096,
  "created_at" : "2010-12-17 07:02:00 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15662444030468096",
  "geo" : { },
  "id_str" : "15662640969809921",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin i just had an idea for video i wanna make and by god ima make it",
  "id" : 15662640969809921,
  "in_reply_to_status_id" : 15662444030468096,
  "created_at" : "2010-12-17 07:00:39 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15661857113112576",
  "geo" : { },
  "id_str" : "15662302212653056",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin \n\n&gt;:-[",
  "id" : 15662302212653056,
  "in_reply_to_status_id" : 15661857113112576,
  "created_at" : "2010-12-17 06:59:18 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15661233323638784",
  "text" : "lol",
  "id" : 15661233323638784,
  "created_at" : "2010-12-17 06:55:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15661158316904448",
  "text" : "RT @hotdogsladies: The new phonebooks are here!\n\nI shall peruse it for the \"phone-number\" of a smithy who might re-shoe the mare that dr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/birdhouseapp.com\" rel=\"nofollow\"\u003EBirdhouse\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "15660142762663936",
    "text" : "The new phonebooks are here!\n\nI shall peruse it for the \"phone-number\" of a smithy who might re-shoe the mare that draws my Conestoga wagon.",
    "id" : 15660142762663936,
    "created_at" : "2010-12-17 06:50:43 +0000",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548615975268921345\/15phrwGy_normal.jpeg",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 15661158316904448,
  "created_at" : "2010-12-17 06:54:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15658273424281600",
  "geo" : { },
  "id_str" : "15661104269103107",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin do i have the flip?",
  "id" : 15661104269103107,
  "in_reply_to_status_id" : 15658273424281600,
  "created_at" : "2010-12-17 06:54:32 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15657876060110849",
  "geo" : { },
  "id_str" : "15658124220305408",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin it's snowing in ABQ",
  "id" : 15658124220305408,
  "in_reply_to_status_id" : 15657876060110849,
  "created_at" : "2010-12-17 06:42:42 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15655445070880768",
  "geo" : { },
  "id_str" : "15657858460811264",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin its a chrome browser extension you can'y play",
  "id" : 15657858460811264,
  "in_reply_to_status_id" : 15655445070880768,
  "created_at" : "2010-12-17 06:41:39 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15655445070880768",
  "geo" : { },
  "id_str" : "15657605993074688",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin googles charity where tabs opened\/day = charity points. then you pick charity category. today i was busy @ 100 even.",
  "id" : 15657605993074688,
  "in_reply_to_status_id" : 15655445070880768,
  "created_at" : "2010-12-17 06:40:38 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15653957045067776",
  "text" : "lets all go broke hard caring about people",
  "id" : 15653957045067776,
  "created_at" : "2010-12-17 06:26:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15653169816141825",
  "text" : "totally man somebody should build a game layer on top of charity",
  "id" : 15653169816141825,
  "created_at" : "2010-12-17 06:23:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15651811176218624",
  "text" : "I figured b. gates is on vaccines. who needs books? the world is made of water.I chose 1 sq ft of shelter http:\/\/bit.ly\/h9jGJ9",
  "id" : 15651811176218624,
  "created_at" : "2010-12-17 06:17:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15650894230069248",
  "text" : "thats what 100 tabs\/day will get you. Also or some trees bullshit.",
  "id" : 15650894230069248,
  "created_at" : "2010-12-17 06:13:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15650681666932736",
  "text" : "should i donate my google chrome tab usage to 4 vaccinations, 10 books, half a persons water, or 1 sq ft of shelter?",
  "id" : 15650681666932736,
  "created_at" : "2010-12-17 06:13:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15589278721515521",
  "geo" : { },
  "id_str" : "15616105368260609",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb \"no more drugs for me, pussy and religion is all i need\" - kanye west, to a black sabbath melody, new album",
  "id" : 15616105368260609,
  "in_reply_to_status_id" : 15589278721515521,
  "created_at" : "2010-12-17 03:55:44 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xavier Damman",
      "screen_name" : "xdamman",
      "indices" : [ 0, 8 ],
      "id_str" : "55993",
      "id" : 55993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15580933100937216",
  "geo" : { },
  "id_str" : "15582028405669888",
  "in_reply_to_user_id" : 55993,
  "text" : "@xdamman watch out about \"hacking democracy\" + visa interview !!! YIKES delete delete delete!",
  "id" : 15582028405669888,
  "in_reply_to_status_id" : 15580933100937216,
  "created_at" : "2010-12-17 01:40:19 +0000",
  "in_reply_to_screen_name" : "xdamman",
  "in_reply_to_user_id_str" : "55993",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15363063804858368",
  "text" : "on things with strict mission of self-preservation: goes against nature",
  "id" : 15363063804858368,
  "created_at" : "2010-12-16 11:10:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mediagazer",
      "screen_name" : "mediagazer",
      "indices" : [ 3, 14 ],
      "id_str" : "75357513",
      "id" : 75357513
    }, {
      "name" : "The Concise Zax",
      "screen_name" : "DavidZax",
      "indices" : [ 85, 94 ],
      "id_str" : "39588173",
      "id" : 39588173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15176092713226240",
  "text" : "RT @mediagazer: \"Turbulence,\" an Interactive Movie, Coming Soon to an iPad Near You (@davidzax \/ Fast Company) http:\/\/j.mp\/dK0E44 http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mediagazer.com\/\" rel=\"nofollow\"\u003EMediagazer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Concise Zax",
        "screen_name" : "DavidZax",
        "indices" : [ 69, 78 ],
        "id_str" : "39588173",
        "id" : 39588173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "15166906134700032",
    "text" : "\"Turbulence,\" an Interactive Movie, Coming Soon to an iPad Near You (@davidzax \/ Fast Company) http:\/\/j.mp\/dK0E44 http:\/\/mgzr.us\/AQVO",
    "id" : 15166906134700032,
    "created_at" : "2010-12-15 22:10:46 +0000",
    "user" : {
      "name" : "Mediagazer",
      "screen_name" : "mediagazer",
      "protected" : false,
      "id_str" : "75357513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696569730035900416\/SRmlXT3E_normal.png",
      "id" : 75357513,
      "verified" : false
    }
  },
  "id" : 15176092713226240,
  "created_at" : "2010-12-15 22:47:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14935275713077248",
  "text" : "cool. if you use embedly's new chrome extension your wordpress posts shows up in twitter preview http:\/\/bit.ly\/ewYGze  ---&gt;",
  "id" : 14935275713077248,
  "created_at" : "2010-12-15 06:50:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zanga Zanga",
      "screen_name" : "ZungaZunga",
      "indices" : [ 58, 69 ],
      "id_str" : "245838018",
      "id" : 245838018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14933693118283776",
  "text" : "just reading up on woes of once and future home state. RT @zungazunga Richard Walker on the future of California: http:\/\/tinyurl.com\/29k2hub",
  "id" : 14933693118283776,
  "created_at" : "2010-12-15 06:44:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14838559424909312",
  "text" : "relationship status: revivifying last tortilla",
  "id" : 14838559424909312,
  "created_at" : "2010-12-15 00:26:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14830123127672832",
  "geo" : { },
  "id_str" : "14834637708722176",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin mmmmm",
  "id" : 14834637708722176,
  "in_reply_to_status_id" : 14830123127672832,
  "created_at" : "2010-12-15 00:10:27 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Borthwick",
      "screen_name" : "Borthwick",
      "indices" : [ 28, 38 ],
      "id_str" : "4488",
      "id" : 4488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14831998661033985",
  "geo" : { },
  "id_str" : "14834575519776768",
  "in_reply_to_user_id" : 4488,
  "text" : "Neat-oh chrome extension RT @Borthwick Embedly adds 103 providers to Twitter.com preview http:\/\/bit.ly\/ewYGze",
  "id" : 14834575519776768,
  "in_reply_to_status_id" : 14831998661033985,
  "created_at" : "2010-12-15 00:10:13 +0000",
  "in_reply_to_screen_name" : "Borthwick",
  "in_reply_to_user_id_str" : "4488",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14830940358451201",
  "text" : "starting to think a chinese ghost city might be the place to be http:\/\/read.bi\/hdQRDj",
  "id" : 14830940358451201,
  "created_at" : "2010-12-14 23:55:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davey D",
      "screen_name" : "mrdaveyd",
      "indices" : [ 3, 12 ],
      "id_str" : "20252085",
      "id" : 20252085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14822635099660288",
  "text" : "RT @mrdaveyd: Ask urself why there has been a media blackout on Day 5 of the biggest Prison strike by Inmates in US History? http:\/\/bit. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14802932922847232",
    "text" : "Ask urself why there has been a media blackout on Day 5 of the biggest Prison strike by Inmates in US History? http:\/\/bit.ly\/fOzoza",
    "id" : 14802932922847232,
    "created_at" : "2010-12-14 22:04:28 +0000",
    "user" : {
      "name" : "Davey D",
      "screen_name" : "mrdaveyd",
      "protected" : false,
      "id_str" : "20252085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000271101974\/68fd7f0a1f878d1168487263aaa4c0d3_normal.jpeg",
      "id" : 20252085,
      "verified" : false
    }
  },
  "id" : 14822635099660288,
  "created_at" : "2010-12-14 23:22:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14555203424489474",
  "geo" : { },
  "id_str" : "14570002833219584",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin are you at the theatuh?",
  "id" : 14570002833219584,
  "in_reply_to_status_id" : 14555203424489474,
  "created_at" : "2010-12-14 06:38:54 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14452056450404352",
  "text" : "RT @AngelineGragzin: I'm not going anywhere! I've moved to LA! I love it here! :D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14448855034634240",
    "text" : "I'm not going anywhere! I've moved to LA! I love it here! :D",
    "id" : 14448855034634240,
    "created_at" : "2010-12-13 22:37:30 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703307803574865921\/ZpTWouST_normal.jpg",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 14452056450404352,
  "created_at" : "2010-12-13 22:50:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Changelog",
      "screen_name" : "changelogshow",
      "indices" : [ 0, 14 ],
      "id_str" : "473142109",
      "id" : 473142109
    }, {
      "name" : "cloudhead",
      "screen_name" : "cloudhead",
      "indices" : [ 15, 25 ],
      "id_str" : "36156834",
      "id" : 36156834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14407998839459840",
  "geo" : { },
  "id_str" : "14408557621420032",
  "in_reply_to_user_id" : 90286855,
  "text" : "@changelogshow @cloudhead behind it? the same background that's behind node express! http:\/\/expressjs.com\/",
  "id" : 14408557621420032,
  "in_reply_to_status_id" : 14407998839459840,
  "created_at" : "2010-12-13 19:57:22 +0000",
  "in_reply_to_screen_name" : "changelog",
  "in_reply_to_user_id_str" : "90286855",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memeorandum",
      "screen_name" : "memeorandum",
      "indices" : [ 3, 15 ],
      "id_str" : "817652",
      "id" : 817652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14204324112502784",
  "text" : "RT @memeorandum: Arsonist Strikes on Cape Cod, Leaves Calling Card: 'F--k the Rich' (JammieWearingFool) http:\/\/j.mp\/gImHau http:\/\/mrand. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/memeorandum.com\/\" rel=\"nofollow\"\u003Ememeorandum\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14199994449928192",
    "text" : "Arsonist Strikes on Cape Cod, Leaves Calling Card: 'F--k the Rich' (JammieWearingFool) http:\/\/j.mp\/gImHau http:\/\/mrand.us\/APkf",
    "id" : 14199994449928192,
    "created_at" : "2010-12-13 06:08:37 +0000",
    "user" : {
      "name" : "memeorandum",
      "screen_name" : "memeorandum",
      "protected" : false,
      "id_str" : "817652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696565962309382144\/pMo4sXjK_normal.png",
      "id" : 817652,
      "verified" : false
    }
  },
  "id" : 14204324112502784,
  "created_at" : "2010-12-13 06:25:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14137124458594304",
  "geo" : { },
  "id_str" : "14137666828238848",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb whatever makes u feel like a cowboy...",
  "id" : 14137666828238848,
  "in_reply_to_status_id" : 14137124458594304,
  "created_at" : "2010-12-13 02:00:57 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14134080937402368",
  "geo" : { },
  "id_str" : "14136803380428800",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb warren zevon is a poseur",
  "id" : 14136803380428800,
  "in_reply_to_status_id" : 14134080937402368,
  "created_at" : "2010-12-13 01:57:31 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N'Gai Croal",
      "screen_name" : "ncroal",
      "indices" : [ 3, 10 ],
      "id_str" : "14199979",
      "id" : 14199979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14064877270212609",
  "text" : "RT @ncroal: The real scandal of Miley Cyrus' bong hit: today's youth is still listening to Bush. Really. http:\/\/bit.ly\/ewj7VB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14059463245832193",
    "text" : "The real scandal of Miley Cyrus' bong hit: today's youth is still listening to Bush. Really. http:\/\/bit.ly\/ewj7VB",
    "id" : 14059463245832193,
    "created_at" : "2010-12-12 20:50:11 +0000",
    "user" : {
      "name" : "N'Gai Croal",
      "screen_name" : "ncroal",
      "protected" : false,
      "id_str" : "14199979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/51996516\/level_up_headshot_190_by_190_normal.jpg",
      "id" : 14199979,
      "verified" : false
    }
  },
  "id" : 14064877270212609,
  "created_at" : "2010-12-12 21:11:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14064263660306432",
  "text" : "i was going to not have some pan cakes but instead i will not have french toast",
  "id" : 14064263660306432,
  "created_at" : "2010-12-12 21:09:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14063589086203905",
  "text" : "Neu! covering La bamba \"bahmb bahmb bahmba \/ repeat \/ South Afrika South Afrika ...\" end with fart noise",
  "id" : 14063589086203905,
  "created_at" : "2010-12-12 21:06:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "14062040456892416",
  "geo" : { },
  "id_str" : "14062592595075072",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin bring me home some dark meats",
  "id" : 14062592595075072,
  "in_reply_to_status_id" : 14062040456892416,
  "created_at" : "2010-12-12 21:02:38 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14060901741105152",
  "text" : "What now can you do with your cake, and still have it? You can have your cake and lay in it. Have your cake and give it to somebody else..",
  "id" : 14060901741105152,
  "created_at" : "2010-12-12 20:55:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14060727333556224",
  "text" : "@kmartsurrealism listening to Neu! \"live\"",
  "id" : 14060727333556224,
  "created_at" : "2010-12-12 20:55:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14060277142130689",
  "text" : "Bonus segment of Arguing With Cliches is to be literal with the cliche. In our case, cake as cake.",
  "id" : 14060277142130689,
  "created_at" : "2010-12-12 20:53:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14059465464614912",
  "text" : "Or can you? If love goes thru the stomach + to be possessed of love is the most universal of pursuits, is not to eat cake to have it too?",
  "id" : 14059465464614912,
  "created_at" : "2010-12-12 20:50:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14058257760919552",
  "text" : "If you eat your cake, you no longer have it. This is timeless wisdom you cannot refute.",
  "id" : 14058257760919552,
  "created_at" : "2010-12-12 20:45:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14057734232080384",
  "text" : "Today's cliche is \"You can't have your cake and eat it.\" It is almost not a cliche because of how easy it is to understand by parsing it.",
  "id" : 14057734232080384,
  "created_at" : "2010-12-12 20:43:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14057220635361280",
  "text" : "I like to explore cliches. Real cliches, not platitudes or stereotypes. avail yourself of the true def. of what is a cliche.",
  "id" : 14057220635361280,
  "created_at" : "2010-12-12 20:41:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13878688068145152",
  "geo" : { },
  "id_str" : "13880646447398913",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin give my halloos to carl",
  "id" : 13880646447398913,
  "in_reply_to_status_id" : 13878688068145152,
  "created_at" : "2010-12-12 08:59:38 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13876624801927168",
  "geo" : { },
  "id_str" : "13877806823907328",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin is it superior to microwaved tortillas with butter and hot sauce?",
  "id" : 13877806823907328,
  "in_reply_to_status_id" : 13876624801927168,
  "created_at" : "2010-12-12 08:48:21 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13864744888832000",
  "text" : "its gonna be a while 'fore i have me hot sauce dreams. I had a late grilled cheese nap.",
  "id" : 13864744888832000,
  "created_at" : "2010-12-12 07:56:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13863404213116928",
  "text" : "hot sauce dreams",
  "id" : 13863404213116928,
  "created_at" : "2010-12-12 07:51:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13750930549776384",
  "text" : "another day, another apple",
  "id" : 13750930549776384,
  "created_at" : "2010-12-12 00:24:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13748144198123520",
  "text" : "another day, another no dollars",
  "id" : 13748144198123520,
  "created_at" : "2010-12-12 00:13:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13722833783881728",
  "text" : "How social media of you.",
  "id" : 13722833783881728,
  "created_at" : "2010-12-11 22:32:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13683920021229568",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia real man writers get aggressive and accusatory everything *HUMP*",
  "id" : 13683920021229568,
  "created_at" : "2010-12-11 19:57:55 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13516334688108544",
  "text" : "just discovered the color of my ways, which was erroneous.",
  "id" : 13516334688108544,
  "created_at" : "2010-12-11 08:51:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13383992568971265",
  "text" : "it's peanut butter TV time",
  "id" : 13383992568971265,
  "created_at" : "2010-12-11 00:06:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13373270371864576",
  "geo" : { },
  "id_str" : "13377054854615041",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin i had a snake just like that :D did you hold it?",
  "id" : 13377054854615041,
  "in_reply_to_status_id" : 13373270371864576,
  "created_at" : "2010-12-10 23:38:33 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moe tkacik",
      "screen_name" : "moetkacik",
      "indices" : [ 0, 10 ],
      "id_str" : "25003152",
      "id" : 25003152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13375753806675968",
  "geo" : { },
  "id_str" : "13376530667274240",
  "in_reply_to_user_id" : 25003152,
  "text" : "@moetkacik yo income figures are the wrong horse. What they don't want you talking about is wealth. top 10% OWN 90% of wealth.",
  "id" : 13376530667274240,
  "in_reply_to_status_id" : 13375753806675968,
  "created_at" : "2010-12-10 23:36:28 +0000",
  "in_reply_to_screen_name" : "moetkacik",
  "in_reply_to_user_id_str" : "25003152",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 52, 63 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 130, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13357937116315648",
  "text" : "FF @survivesthebomb cuz he needs more eary eyes and @grayamelia because she don't tweet at you she tweets over ya'll. Follow thru #FF",
  "id" : 13357937116315648,
  "created_at" : "2010-12-10 22:22:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 3, 13 ],
      "id_str" : "15865878",
      "id" : 15865878
    }, {
      "name" : "@MacDiva",
      "screen_name" : "MacDivaONA",
      "indices" : [ 85, 96 ],
      "id_str" : "11648842",
      "id" : 11648842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13295437171658752",
  "text" : "RT @NiemanLab: A periodic table of the elements...of HTML5 http:\/\/nie.mn\/f7oQYq (via @MacDivaONA)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "@MacDiva",
        "screen_name" : "MacDivaONA",
        "indices" : [ 70, 81 ],
        "id_str" : "11648842",
        "id" : 11648842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "13288094329479168",
    "text" : "A periodic table of the elements...of HTML5 http:\/\/nie.mn\/f7oQYq (via @MacDivaONA)",
    "id" : 13288094329479168,
    "created_at" : "2010-12-10 17:45:03 +0000",
    "user" : {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "protected" : false,
      "id_str" : "15865878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512664555827126272\/pzZXwZC8_normal.jpeg",
      "id" : 15865878,
      "verified" : true
    }
  },
  "id" : 13295437171658752,
  "created_at" : "2010-12-10 18:14:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 17, 33 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13128051340607489",
  "geo" : { },
  "id_str" : "13131006521384961",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb @AngelineGragzin if (math in nature) return true",
  "id" : 13131006521384961,
  "in_reply_to_status_id" : 13128051340607489,
  "created_at" : "2010-12-10 07:20:50 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13109909667188736",
  "geo" : { },
  "id_str" : "13112756672659456",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb by unbelievable you mean totally faithful?",
  "id" : 13112756672659456,
  "in_reply_to_status_id" : 13109909667188736,
  "created_at" : "2010-12-10 06:08:19 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12316220082626560",
  "geo" : { },
  "id_str" : "12318962985472001",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb jeebus!",
  "id" : 12318962985472001,
  "in_reply_to_status_id" : 12316220082626560,
  "created_at" : "2010-12-08 01:34:04 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davide 'Fol' Casali",
      "screen_name" : "Folletto",
      "indices" : [ 0, 9 ],
      "id_str" : "21693",
      "id" : 21693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12265749485723648",
  "geo" : { },
  "id_str" : "12272550071500800",
  "in_reply_to_user_id" : 21693,
  "text" : "@Folletto youtube could have been, and maybe still is, google's best hope for gaining ground in the social web. But it's basically stagnant.",
  "id" : 12272550071500800,
  "in_reply_to_status_id" : 12265749485723648,
  "created_at" : "2010-12-07 22:29:38 +0000",
  "in_reply_to_screen_name" : "Folletto",
  "in_reply_to_user_id_str" : "21693",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wikileaks",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12243214484373504",
  "text" : "boycot IKEA #wikileaks",
  "id" : 12243214484373504,
  "created_at" : "2010-12-07 20:33:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wikileaks",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12242712665264128",
  "text" : "end US Gov't bureaucrat exceptionalism #wikileaks",
  "id" : 12242712665264128,
  "created_at" : "2010-12-07 20:31:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12242265242075136",
  "text" : "WikiLEAKS OR BUST",
  "id" : 12242265242075136,
  "created_at" : "2010-12-07 20:29:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freejules",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12240250403299328",
  "text" : "FREE JULES #freejules",
  "id" : 12240250403299328,
  "created_at" : "2010-12-07 20:21:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11982623911976961",
  "geo" : { },
  "id_str" : "11983193053855745",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin don't forget the costume stores",
  "id" : 11983193053855745,
  "in_reply_to_status_id" : 11982623911976961,
  "created_at" : "2010-12-07 03:19:50 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11650837386371073",
  "text" : "RT @wikileaks: Sarah Palin says Julian should be hunted down like Osama bin Laden--so he should be safe for at least a decade.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11620256778821632",
    "text" : "Sarah Palin says Julian should be hunted down like Osama bin Laden--so he should be safe for at least a decade.",
    "id" : 11620256778821632,
    "created_at" : "2010-12-06 03:17:39 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 11650837386371073,
  "created_at" : "2010-12-06 05:19:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11595191676829696",
  "text" : "wish I had some stats!",
  "id" : 11595191676829696,
  "created_at" : "2010-12-06 01:38:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11594387750387712",
  "text" : "holy crap this video is amazing: http:\/\/bit.ly\/gAX6aY watch what happens to Chine during the Cultural Revolution",
  "id" : 11594387750387712,
  "created_at" : "2010-12-06 01:34:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11590454843801600",
  "text" : "nice mustache blotbot http:\/\/blotbot.co\/#15ea44f5",
  "id" : 11590454843801600,
  "created_at" : "2010-12-06 01:19:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11590274442600448",
  "text" : "or this http:\/\/blotbot.co\/#ac5ed35c",
  "id" : 11590274442600448,
  "created_at" : "2010-12-06 01:18:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11590175981305857",
  "text" : "try this http:\/\/blotbot.co\/#21b123be",
  "id" : 11590175981305857,
  "created_at" : "2010-12-06 01:18:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wikileaks",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11574451732742144",
  "text" : "How am I supposed to compose my State Dept. Soap Opera #wikileaks???",
  "id" : 11574451732742144,
  "created_at" : "2010-12-06 00:15:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11574406971129856",
  "text" : "wikileaks more like wikiTrickles (am i rite?) so far only 837 \/ 251,287 of cables publicly released.",
  "id" : 11574406971129856,
  "created_at" : "2010-12-06 00:15:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11570692944306177",
  "geo" : { },
  "id_str" : "11571063120994304",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin Who doesn't know that one??? I've heard that one in credit card commercials!",
  "id" : 11571063120994304,
  "in_reply_to_status_id" : 11570692944306177,
  "created_at" : "2010-12-06 00:02:11 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11549957689446401",
  "text" : "It's Sunday. Make sure you get some Hooly Goost.",
  "id" : 11549957689446401,
  "created_at" : "2010-12-05 22:38:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11549636808409089",
  "geo" : { },
  "id_str" : "11549833768734720",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin why dont you ask Bashwiner?",
  "id" : 11549833768734720,
  "in_reply_to_status_id" : 11549636808409089,
  "created_at" : "2010-12-05 22:37:49 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11544349766582272",
  "geo" : { },
  "id_str" : "11548917678219264",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin ha! you thought a new-fangled app would know its classical music",
  "id" : 11548917678219264,
  "in_reply_to_status_id" : 11544349766582272,
  "created_at" : "2010-12-05 22:34:11 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11499292254535681",
  "geo" : { },
  "id_str" : "11522604464607233",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk thanks for the screen casts. keep em coming!",
  "id" : 11522604464607233,
  "in_reply_to_status_id" : 11499292254535681,
  "created_at" : "2010-12-05 20:49:37 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11517876074713088",
  "text" : "\u201CBarack Obama is a bigger danger\" by John Bolton, puppet with a mustache http:\/\/gu.com\/p\/2ytd6\/tf",
  "id" : 11517876074713088,
  "created_at" : "2010-12-05 20:30:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11301884870524928",
  "text" : "The word is imperative.",
  "id" : 11301884870524928,
  "created_at" : "2010-12-05 06:12:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11301475808452609",
  "text" : "I'm searching behind all the doors in the hallway of my brain for a word which I can see but not retrieve.",
  "id" : 11301475808452609,
  "created_at" : "2010-12-05 06:10:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359074131968",
  "in_reply_to_user_id" : 46277981,
  "text" : "@CocoHoneyB I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359074131968,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "Coco_BoujieB",
  "in_reply_to_user_id_str" : "46277981",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359078322176",
  "text" : "@radhityadj I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359078322176,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raw Signal Politics",
      "screen_name" : "RawSPolitics",
      "indices" : [ 0, 13 ],
      "id_str" : "217107845",
      "id" : 217107845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359095107584",
  "in_reply_to_user_id" : 217107845,
  "text" : "@RawSPolitics I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359095107584,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "RawSPolitics",
  "in_reply_to_user_id_str" : "217107845",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryMacElveen",
      "screen_name" : "MaryMacElveen",
      "indices" : [ 0, 14 ],
      "id_str" : "18498416",
      "id" : 18498416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359120265217",
  "in_reply_to_user_id" : 18498416,
  "text" : "@MaryMacElveen I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359120265217,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "MaryMacElveen",
  "in_reply_to_user_id_str" : "18498416",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Richards",
      "screen_name" : "djmarc",
      "indices" : [ 0, 7 ],
      "id_str" : "15711900",
      "id" : 15711900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359120273408",
  "in_reply_to_user_id" : 15711900,
  "text" : "@djmarc I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359120273408,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "djmarc",
  "in_reply_to_user_id_str" : "15711900",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Priley",
      "screen_name" : "Prioriello",
      "indices" : [ 0, 11 ],
      "id_str" : "22939379",
      "id" : 22939379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359128653825",
  "in_reply_to_user_id" : 22939379,
  "text" : "@Prioriello I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359128653825,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "Prioriello",
  "in_reply_to_user_id_str" : "22939379",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 0, 6 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359128662018",
  "in_reply_to_user_id" : 63188134,
  "text" : "@z56po I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359128662018,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "z56po",
  "in_reply_to_user_id_str" : "63188134",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liberal Hit-Girl",
      "screen_name" : "LiberalHitGirl",
      "indices" : [ 0, 15 ],
      "id_str" : "114060538",
      "id" : 114060538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359153819649",
  "in_reply_to_user_id" : 114060538,
  "text" : "@LiberalHitGirl I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359153819649,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "LiberalHitGirl",
  "in_reply_to_user_id_str" : "114060538",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Jones",
      "screen_name" : "sharonjones328",
      "indices" : [ 0, 15 ],
      "id_str" : "138050286",
      "id" : 138050286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359162208256",
  "in_reply_to_user_id" : 138050286,
  "text" : "@sharonjones328 I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359162208256,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "sharonjones328",
  "in_reply_to_user_id_str" : "138050286",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Watkins",
      "screen_name" : "Imaj727",
      "indices" : [ 0, 8 ],
      "id_str" : "108540036",
      "id" : 108540036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359178985472",
  "in_reply_to_user_id" : 108540036,
  "text" : "@ImaJ727 I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359178985472,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "Imaj727",
  "in_reply_to_user_id_str" : "108540036",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debby",
      "screen_name" : "Brvfan",
      "indices" : [ 0, 7 ],
      "id_str" : "137543147",
      "id" : 137543147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359543889920",
  "in_reply_to_user_id" : 137543147,
  "text" : "@Brvfan I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359543889920,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "Brvfan",
  "in_reply_to_user_id_str" : "137543147",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify 0\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reformed Democrat",
      "screen_name" : "midniterdr2010",
      "indices" : [ 0, 15 ],
      "id_str" : "166389147",
      "id" : 166389147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290359644553216",
  "in_reply_to_user_id" : 166389147,
  "text" : "@midniterdr2010 I've quoted you in my story, check it out: http:\/\/storify.com\/mostmodernist\/taxes",
  "id" : 11290359644553216,
  "created_at" : "2010-12-05 05:26:46 +0000",
  "in_reply_to_screen_name" : "midniterdr2010",
  "in_reply_to_user_id_str" : "166389147",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nestor Br\u00FBl\u00E9e",
      "screen_name" : "Nestor_tweets",
      "indices" : [ 0, 14 ],
      "id_str" : "221527591",
      "id" : 221527591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11165254989910016",
  "geo" : { },
  "id_str" : "11165793815363585",
  "in_reply_to_user_id" : 221527591,
  "text" : "@Nestor_tweets okay so if wikileaks already leaked it all, then why not torrent?",
  "id" : 11165793815363585,
  "in_reply_to_status_id" : 11165254989910016,
  "created_at" : "2010-12-04 21:11:47 +0000",
  "in_reply_to_screen_name" : "Nestor_tweets",
  "in_reply_to_user_id_str" : "221527591",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nestor Br\u00FBl\u00E9e",
      "screen_name" : "Nestor_tweets",
      "indices" : [ 0, 14 ],
      "id_str" : "221527591",
      "id" : 221527591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11162286349619200",
  "geo" : { },
  "id_str" : "11163112753340416",
  "in_reply_to_user_id" : 221527591,
  "text" : "@Nestor_tweets so they didn't release everything to the nytimes et al?",
  "id" : 11163112753340416,
  "in_reply_to_status_id" : 11162286349619200,
  "created_at" : "2010-12-04 21:01:08 +0000",
  "in_reply_to_screen_name" : "Nestor_tweets",
  "in_reply_to_user_id_str" : "221527591",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 11, 21 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cablegate",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11161126494535680",
  "text" : "why hasn't @wikileaks released a torrent of all the cables? #cablegate",
  "id" : 11161126494535680,
  "created_at" : "2010-12-04 20:53:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Winer",
      "screen_name" : "davewiner",
      "indices" : [ 3, 13 ],
      "id_str" : "3839",
      "id" : 3839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11160762491867136",
  "text" : "RT @davewiner: WikiLeaks - Mass Mirroring our website. http:\/\/r2.ly\/6b5d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11151308299964416",
    "text" : "WikiLeaks - Mass Mirroring our website. http:\/\/r2.ly\/6b5d",
    "id" : 11151308299964416,
    "created_at" : "2010-12-04 20:14:13 +0000",
    "user" : {
      "name" : "Dave Winer",
      "screen_name" : "davewiner",
      "protected" : false,
      "id_str" : "3839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716686126254321664\/v3citfg4_normal.jpg",
      "id" : 3839,
      "verified" : true
    }
  },
  "id" : 11160762491867136,
  "created_at" : "2010-12-04 20:51:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11150546828267520",
  "text" : "retweetable: anybody wanna collaborate \/ contribute on an ipad magazine =&gt; touch me, ima startup one juche style. Might call it juche. hmmm.",
  "id" : 11150546828267520,
  "created_at" : "2010-12-04 20:11:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10913862006079488",
  "text" : "not understanding the workings of recursion so ima come back to it later and not understand recursion some more.",
  "id" : 10913862006079488,
  "created_at" : "2010-12-04 04:30:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10894141739237376",
  "text" : "i finally found *the one* http:\/\/eloquentjavascript.net\/",
  "id" : 10894141739237376,
  "created_at" : "2010-12-04 03:12:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10797336359870464",
  "text" : "check out this awesome website http:\/\/benthebodyguard.com\/ \"A frenchman protecting your secrets. Yes, seriously\"",
  "id" : 10797336359870464,
  "created_at" : "2010-12-03 20:47:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instant Funds",
      "screen_name" : "evanatwired",
      "indices" : [ 3, 15 ],
      "id_str" : "2215942987",
      "id" : 2215942987
    }, {
      "name" : "Alexis C. Madrigal",
      "screen_name" : "alexismadrigal",
      "indices" : [ 20, 35 ],
      "id_str" : "11107172",
      "id" : 11107172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10796635663638528",
  "text" : "RT @evanatwired: RT @alexismadrigal: It's live: http:\/\/www.cablegateroulette.com\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexis C. Madrigal",
        "screen_name" : "alexismadrigal",
        "indices" : [ 3, 18 ],
        "id_str" : "11107172",
        "id" : 11107172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10788960502546433",
    "text" : "RT @alexismadrigal: It's live: http:\/\/www.cablegateroulette.com\/",
    "id" : 10788960502546433,
    "created_at" : "2010-12-03 20:14:23 +0000",
    "user" : {
      "name" : "Evan Hansen",
      "screen_name" : "evnhsn",
      "protected" : false,
      "id_str" : "771619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727579956461469697\/nzVvN4vr_normal.jpg",
      "id" : 771619,
      "verified" : false
    }
  },
  "id" : 10796635663638528,
  "created_at" : "2010-12-03 20:44:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 3, 14 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10784032728023040",
  "text" : "RT @zunguzungu: More on wikileaks from me: http:\/\/tinyurl.com\/2ctnkdg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10780763981090818",
    "text" : "More on wikileaks from me: http:\/\/tinyurl.com\/2ctnkdg",
    "id" : 10780763981090818,
    "created_at" : "2010-12-03 19:41:49 +0000",
    "user" : {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "protected" : false,
      "id_str" : "47951511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652293153534283776\/_EWFqc3W_normal.jpg",
      "id" : 47951511,
      "verified" : false
    }
  },
  "id" : 10784032728023040,
  "created_at" : "2010-12-03 19:54:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nestor Br\u00FBl\u00E9e",
      "screen_name" : "Nestor_tweets",
      "indices" : [ 0, 14 ],
      "id_str" : "221527591",
      "id" : 221527591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10545134236073984",
  "geo" : { },
  "id_str" : "10570912407490563",
  "in_reply_to_user_id" : 221527591,
  "text" : "@Nestor_tweets you see dis http:\/\/tarnac9.wordpress.com\/texts\/the-coming-insurrection\/",
  "id" : 10570912407490563,
  "in_reply_to_status_id" : 10545134236073984,
  "created_at" : "2010-12-03 05:47:56 +0000",
  "in_reply_to_screen_name" : "Nestor_tweets",
  "in_reply_to_user_id_str" : "221527591",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10450540970385409",
  "text" : "I knew it! I knew it all along:  GFAJ-1 of the Halomonadaceae family of Gammaproteobacteria",
  "id" : 10450540970385409,
  "created_at" : "2010-12-02 21:49:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 11, 16 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10448904529125376",
  "text" : "I see what @NASA said. Mono Lake! It appears in M. Twain's hilarious travelogue \"Roughing It\". Ever since reading I have wanted to go there.",
  "id" : 10448904529125376,
  "created_at" : "2010-12-02 21:43:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10447838110556160",
  "text" : "I missed what NASA said. What did NASA say?",
  "id" : 10447838110556160,
  "created_at" : "2010-12-02 21:38:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bradford cross",
      "screen_name" : "bradfordcross",
      "indices" : [ 0, 14 ],
      "id_str" : "36153601",
      "id" : 36153601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10423348194443265",
  "geo" : { },
  "id_str" : "10447548690997249",
  "in_reply_to_user_id" : 36153601,
  "text" : "@bradfordcross mail sent through your blog contact form",
  "id" : 10447548690997249,
  "in_reply_to_status_id" : 10423348194443265,
  "created_at" : "2010-12-02 21:37:44 +0000",
  "in_reply_to_screen_name" : "bradfordcross",
  "in_reply_to_user_id_str" : "36153601",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian US",
      "screen_name" : "guardianusa",
      "indices" : [ 23, 35 ],
      "id_str" : "475253507",
      "id" : 475253507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10427736346591232",
  "geo" : { },
  "id_str" : "10430953012854784",
  "in_reply_to_user_id" : 16042794,
  "text" : "what's a grizzly wolf? @GuardianUSA Grizzly bears and wolves may be taken off US protected species list http:\/\/gu.com\/p\/2yh42\/tf",
  "id" : 10430953012854784,
  "in_reply_to_status_id" : 10427736346591232,
  "created_at" : "2010-12-02 20:31:47 +0000",
  "in_reply_to_screen_name" : "GuardianUS",
  "in_reply_to_user_id_str" : "16042794",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinicius Vacanti",
      "screen_name" : "vacanti",
      "indices" : [ 93, 101 ],
      "id_str" : "14424445",
      "id" : 14424445
    }, {
      "name" : "bradford cross",
      "screen_name" : "bradfordcross",
      "indices" : [ 102, 116 ],
      "id_str" : "36153601",
      "id" : 36153601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10404590268710912",
  "text" : "This corroborates the idea behind my Knight News Challenge application. http:\/\/bit.ly\/eS44Dx @vacanti @bradfordcross",
  "id" : 10404590268710912,
  "created_at" : "2010-12-02 18:47:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Shirky",
      "screen_name" : "cshirky",
      "indices" : [ 3, 11 ],
      "id_str" : "6141832",
      "id" : 6141832
    }, {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 40, 51 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10396358263439360",
  "text" : "RT @cshirky: Just re-read Aaron Bady's (@zunguzungu) Wikileaks piece http:\/\/bit.ly\/eGFOhw. It's the best thing about WL ever written.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aaron Bady",
        "screen_name" : "zunguzungu",
        "indices" : [ 27, 38 ],
        "id_str" : "47951511",
        "id" : 47951511
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10389076943310848",
    "text" : "Just re-read Aaron Bady's (@zunguzungu) Wikileaks piece http:\/\/bit.ly\/eGFOhw. It's the best thing about WL ever written.",
    "id" : 10389076943310848,
    "created_at" : "2010-12-02 17:45:23 +0000",
    "user" : {
      "name" : "Clay Shirky",
      "screen_name" : "cshirky",
      "protected" : false,
      "id_str" : "6141832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536827114771578881\/tWr8z9im_normal.png",
      "id" : 6141832,
      "verified" : true
    }
  },
  "id" : 10396358263439360,
  "created_at" : "2010-12-02 18:14:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Petka",
      "screen_name" : "petka",
      "indices" : [ 3, 9 ],
      "id_str" : "14064126",
      "id" : 14064126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10181519616253952",
  "text" : "RT @petka: Haha... love the personal appeal from 4chan founder: http:\/\/www.4chan.org\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10178727216414720",
    "text" : "Haha... love the personal appeal from 4chan founder: http:\/\/www.4chan.org\/",
    "id" : 10178727216414720,
    "created_at" : "2010-12-02 03:49:32 +0000",
    "user" : {
      "name" : "Petka",
      "screen_name" : "petka",
      "protected" : false,
      "id_str" : "14064126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/123049025\/eyes_normal.jpg",
      "id" : 14064126,
      "verified" : false
    }
  },
  "id" : 10181519616253952,
  "created_at" : "2010-12-02 04:00:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]