Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/bOFFBVj21N",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/this-is-not-a-copy-machine",
      "display_url" : "soundcloud.com\/folkstack\/this\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726566112414961665",
  "geo" : { },
  "id_str" : "726593769668145154",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha https:\/\/t.co\/bOFFBVj21N",
  "id" : 726593769668145154,
  "in_reply_to_status_id" : 726566112414961665,
  "created_at" : "2016-05-01 02:07:08 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/726481657880944640\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ETL85lnEWj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChT7N7iU0AAsZAS.jpg",
      "id_str" : "726481656652025856",
      "id" : 726481656652025856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChT7N7iU0AAsZAS.jpg",
      "sizes" : [ {
        "h" : 459,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1070
      } ],
      "display_url" : "pic.twitter.com\/ETL85lnEWj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/3GmYp2bhzP",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/sandra-bland-arrest-transcript_us_55b03a88e4b0a9b94853b1f1",
      "display_url" : "huffingtonpost.com\/entry\/sandra-b\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726477458720051201",
  "geo" : { },
  "id_str" : "726481657880944640",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  reminded me of Sandra Bland's resistance... https:\/\/t.co\/3GmYp2bhzP https:\/\/t.co\/ETL85lnEWj",
  "id" : 726481657880944640,
  "in_reply_to_status_id" : 726477458720051201,
  "created_at" : "2016-04-30 18:41:39 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0F3B\u1D4F\u1D58\u1D50\u1D43\u1D5B\u2071\u02E2\u0F04\u0F1C",
      "screen_name" : "kumavis_",
      "indices" : [ 0, 9 ],
      "id_str" : "14402667",
      "id" : 14402667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726198860654071808",
  "geo" : { },
  "id_str" : "726209947214565376",
  "in_reply_to_user_id" : 14402667,
  "text" : "@kumavis_   ?_?",
  "id" : 726209947214565376,
  "in_reply_to_status_id" : 726198860654071808,
  "created_at" : "2016-04-30 00:41:58 +0000",
  "in_reply_to_screen_name" : "kumavis_",
  "in_reply_to_user_id_str" : "14402667",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726143812662235136",
  "text" : "life would be so good if we didn't have to GAF what maniac people 3000 miles away thought about every fucking thing",
  "id" : 726143812662235136,
  "created_at" : "2016-04-29 20:19:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BlackOUT Collective",
      "screen_name" : "blackoutcollect",
      "indices" : [ 3, 19 ],
      "id_str" : "2912990047",
      "id" : 2912990047
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/blackoutcollect\/status\/726142341409431552\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/1fBNlfZ7aW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChPGl5MUgAAv5mM.jpg",
      "id_str" : "726142319246737408",
      "id" : 726142319246737408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChPGl5MUgAAv5mM.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1fBNlfZ7aW"
    } ],
    "hashtags" : [ {
      "text" : "DumpTrump",
      "indices" : [ 38, 48 ]
    }, {
      "text" : "WeWillNotBeTrumped",
      "indices" : [ 51, 70 ]
    }, {
      "text" : "NotTrump16",
      "indices" : [ 71, 82 ]
    }, {
      "text" : "TransformDemocracy",
      "indices" : [ 83, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726143229410725889",
  "text" : "RT @blackoutcollect: Tshirts made for #DumpTrump \n\n#WeWillNotBeTrumped #NotTrump16 #TransformDemocracy https:\/\/t.co\/1fBNlfZ7aW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/blackoutcollect\/status\/726142341409431552\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/1fBNlfZ7aW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChPGl5MUgAAv5mM.jpg",
        "id_str" : "726142319246737408",
        "id" : 726142319246737408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChPGl5MUgAAv5mM.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1fBNlfZ7aW"
      } ],
      "hashtags" : [ {
        "text" : "DumpTrump",
        "indices" : [ 17, 27 ]
      }, {
        "text" : "WeWillNotBeTrumped",
        "indices" : [ 30, 49 ]
      }, {
        "text" : "NotTrump16",
        "indices" : [ 50, 61 ]
      }, {
        "text" : "TransformDemocracy",
        "indices" : [ 62, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726142341409431552",
    "text" : "Tshirts made for #DumpTrump \n\n#WeWillNotBeTrumped #NotTrump16 #TransformDemocracy https:\/\/t.co\/1fBNlfZ7aW",
    "id" : 726142341409431552,
    "created_at" : "2016-04-29 20:13:19 +0000",
    "user" : {
      "name" : "BlackOUT Collective",
      "screen_name" : "blackoutcollect",
      "protected" : false,
      "id_str" : "2912990047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684272036072439808\/tm_NYSHQ_normal.jpg",
      "id" : 2912990047,
      "verified" : false
    }
  },
  "id" : 726143229410725889,
  "created_at" : "2016-04-29 20:16:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726143051987460097",
  "text" : "west coast leading the protest as usual, east votes trump and hillary\n\ndisband the union pleeeeeeeease",
  "id" : 726143051987460097,
  "created_at" : "2016-04-29 20:16:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726116199310856192",
  "text" : "The controller is controlled.",
  "id" : 726116199310856192,
  "created_at" : "2016-04-29 18:29:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shadertoy",
      "screen_name" : "Shadertoy",
      "indices" : [ 1, 11 ],
      "id_str" : "1129365692",
      "id" : 1129365692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725795441749565441",
  "text" : ".@Shadertoy appears to draw ~7 watts on my machine",
  "id" : 725795441749565441,
  "created_at" : "2016-04-28 21:14:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725755545106407424",
  "geo" : { },
  "id_str" : "725757158516609024",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  the gross fetishization of somebody else's idyll",
  "id" : 725757158516609024,
  "in_reply_to_status_id" : 725755545106407424,
  "created_at" : "2016-04-28 18:42:45 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725418460214218752",
  "text" : "Early Music is gonna be an album of lyric, meme, and brand free music, plus also mostly non-modal (modes are habit forming).",
  "id" : 725418460214218752,
  "created_at" : "2016-04-27 20:16:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725417837582503936",
  "text" : "beware habit-forming music",
  "id" : 725417837582503936,
  "created_at" : "2016-04-27 20:14:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725414146049597440",
  "text" : "Johnny's graphic design process some quick javascript, DOM, CSS, a dash of GLSL, a stroke of CLI &amp;&amp; usually finished w\/ a cropped screencap.",
  "id" : 725414146049597440,
  "created_at" : "2016-04-27 19:59:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 16, 25 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/725411033909596160\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/ptbf7miePK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChEtfRoUgAAdu3M.jpg",
      "id_str" : "725411030315073536",
      "id" : 725411030315073536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChEtfRoUgAAdu3M.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 572
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 572
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 572
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ptbf7miePK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725411033909596160",
  "text" : "proto cover art @substack 4 EARLY MUSIC https:\/\/t.co\/ptbf7miePK",
  "id" : 725411033909596160,
  "created_at" : "2016-04-27 19:47:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725407649282555905",
  "text" : "I would give half my lot for the love of a devoted graphic artist.",
  "id" : 725407649282555905,
  "created_at" : "2016-04-27 19:33:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 66, 75 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725397516162736128",
  "text" : "I'm preparing a couple albums of algorithmic kids music by me and @substack stay chuned",
  "id" : 725397516162736128,
  "created_at" : "2016-04-27 18:53:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725397139908497408",
  "text" : "TIL I can't set prices for my own content on itunes or google play",
  "id" : 725397139908497408,
  "created_at" : "2016-04-27 18:52:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725389218910986240",
  "geo" : { },
  "id_str" : "725392351888171008",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz  only fair if you kill yourself too",
  "id" : 725392351888171008,
  "in_reply_to_status_id" : 725389218910986240,
  "created_at" : "2016-04-27 18:33:08 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/725192550940811264\/photo\/1",
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/pui2rWfGDr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChBmyB5UUAEHUqb.jpg",
      "id_str" : "725192549694984193",
      "id" : 725192549694984193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChBmyB5UUAEHUqb.jpg",
      "sizes" : [ {
        "h" : 387,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pui2rWfGDr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725192550940811264",
  "text" : "found https:\/\/t.co\/pui2rWfGDr",
  "id" : 725192550940811264,
  "created_at" : "2016-04-27 05:19:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/780xlZE7W0",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=NIvc4dl5X1I",
      "display_url" : "youtube.com\/watch?v=NIvc4d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725191938413060097",
  "text" : "_-_\nhttps:\/\/t.co\/780xlZE7W0",
  "id" : 725191938413060097,
  "created_at" : "2016-04-27 05:16:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725187825805709313",
  "text" : "Which file types have attribution \/ authorship \/ metadata params baked-in?  Browsers should support this data natively for web debs.",
  "id" : 725187825805709313,
  "created_at" : "2016-04-27 05:00:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725180147360489472",
  "geo" : { },
  "id_str" : "725181127913267200",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked is printing + redistributing yr words in a DIY zine considered fair use?  Pls allow me to suggest CC Attribution Share-Alike.",
  "id" : 725181127913267200,
  "in_reply_to_status_id" : 725180147360489472,
  "created_at" : "2016-04-27 04:33:48 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725179603610947584",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked What are your essays licensed? e.g. Creative Commons i.e. for redistribution?",
  "id" : 725179603610947584,
  "created_at" : "2016-04-27 04:27:45 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724837020120584192",
  "text" : "*SHOVES THESE RAINBOWS INTO EARS NOSE AND CORNEA*",
  "id" : 724837020120584192,
  "created_at" : "2016-04-26 05:46:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724836568624672770",
  "text" : "that's some bad edification1",
  "id" : 724836568624672770,
  "created_at" : "2016-04-26 05:44:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724836002687229952",
  "text" : "Fascism is when you align your best interests with the moral judgements of your totes-talitarian government.",
  "id" : 724836002687229952,
  "created_at" : "2016-04-26 05:42:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "thealphanerd",
      "indices" : [ 0, 13 ],
      "id_str" : "150664007",
      "id" : 150664007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724830565455777792",
  "geo" : { },
  "id_str" : "724834420553859072",
  "in_reply_to_user_id" : 150664007,
  "text" : "@thealphanerd  HEY SLOW IT DOWN BUH\n\nAND INCREASE THE PITCH",
  "id" : 724834420553859072,
  "in_reply_to_status_id" : 724830565455777792,
  "created_at" : "2016-04-26 05:36:07 +0000",
  "in_reply_to_screen_name" : "thealphanerd",
  "in_reply_to_user_id_str" : "150664007",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724830293295812608",
  "text" : "I join society for one day and have a totally fascist experience",
  "id" : 724830293295812608,
  "created_at" : "2016-04-26 05:19:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724075483923542020",
  "geo" : { },
  "id_str" : "724313466501140480",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha a bot is a meme assistant",
  "id" : 724313466501140480,
  "in_reply_to_status_id" : 724075483923542020,
  "created_at" : "2016-04-24 19:06:02 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jameszoo",
      "screen_name" : "Jameszooo",
      "indices" : [ 0, 10 ],
      "id_str" : "99915627",
      "id" : 99915627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/cer98B9f1y",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/sets\/demo-of-midi-keyboard-synths",
      "display_url" : "soundcloud.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723580167650578432",
  "in_reply_to_user_id" : 99915627,
  "text" : "@Jameszooo I'd &lt;3 to hear you play on my synths\n \nhttps:\/\/t.co\/cer98B9f1y",
  "id" : 723580167650578432,
  "created_at" : "2016-04-22 18:32:10 +0000",
  "in_reply_to_screen_name" : "Jameszooo",
  "in_reply_to_user_id_str" : "99915627",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 136, 144 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 143, 144 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/mPiCdBsNIf",
      "expanded_url" : "http:\/\/kukso.space\/",
      "display_url" : "kukso.space"
    } ]
  },
  "geo" : { },
  "id_str" : "723370343583240193",
  "text" : "RT @marinakukso: i've updated my site https:\/\/t.co\/mPiCdBsNIf to include my digital art, comics, &amp; some programming work. thank you @substa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "substack",
        "screen_name" : "substack",
        "indices" : [ 119, 128 ],
        "id_str" : "125027291",
        "id" : 125027291
      }, {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 135, 148 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/mPiCdBsNIf",
        "expanded_url" : "http:\/\/kukso.space\/",
        "display_url" : "kukso.space"
      } ]
    },
    "geo" : { },
    "id_str" : "723251892273319936",
    "text" : "i've updated my site https:\/\/t.co\/mPiCdBsNIf to include my digital art, comics, &amp; some programming work. thank you @substack &amp; @johnnyscript",
    "id" : 723251892273319936,
    "created_at" : "2016-04-21 20:47:43 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 723370343583240193,
  "created_at" : "2016-04-22 04:38:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723205714768879617",
  "text" : "GOODBYE SWEET PRINCE",
  "id" : 723205714768879617,
  "created_at" : "2016-04-21 17:44:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723203979996336128",
  "text" : "The Millennial vs Baby Boomer Junior",
  "id" : 723203979996336128,
  "created_at" : "2016-04-21 17:37:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723194383055486976",
  "text" : "i'll vote whichever candidate declares IDGAF ABOUT PRIMARIES",
  "id" : 723194383055486976,
  "created_at" : "2016-04-21 16:59:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HarrietTubman",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722952873554771968",
  "text" : "Harriet Dubman #HarrietTubman",
  "id" : 722952873554771968,
  "created_at" : "2016-04-21 00:59:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722896212874006530",
  "geo" : { },
  "id_str" : "722941934751211522",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight uh what's the computer's aesthetic exactly?  Is it UTF-8??",
  "id" : 722941934751211522,
  "in_reply_to_status_id" : 722896212874006530,
  "created_at" : "2016-04-21 00:16:03 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/2xZvGGGiEJ",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/722847014212362242",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722848212936032256",
  "text" : "LA DI DA DI DA https:\/\/t.co\/2xZvGGGiEJ",
  "id" : 722848212936032256,
  "created_at" : "2016-04-20 18:03:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722787530072928256",
  "text" : "Sext:  I need u to check me for ticks",
  "id" : 722787530072928256,
  "created_at" : "2016-04-20 14:02:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 42, 55 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "algowave",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/6uwccWaKe2",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/art-disco",
      "display_url" : "soundcloud.com\/johnnyscript\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722631949848739841",
  "text" : "RT @folkstack: new live demo recording by @johnnyscript mixing algorithms, playing keys and coding them at the same time #algowave\n\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 27, 40 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "algowave",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/6uwccWaKe2",
        "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/art-disco",
        "display_url" : "soundcloud.com\/johnnyscript\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722630382676381696",
    "text" : "new live demo recording by @johnnyscript mixing algorithms, playing keys and coding them at the same time #algowave\n\nhttps:\/\/t.co\/6uwccWaKe2",
    "id" : 722630382676381696,
    "created_at" : "2016-04-20 03:38:03 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 722631949848739841,
  "created_at" : "2016-04-20 03:44:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rageAgainstTheMachine",
      "indices" : [ 42, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722519539368329216",
  "text" : "tfw when yr auto-focus takes a blurry pic #rageAgainstTheMachine",
  "id" : 722519539368329216,
  "created_at" : "2016-04-19 20:17:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722502502491557889",
  "geo" : { },
  "id_str" : "722511448291717120",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked Killary Clinton",
  "id" : 722511448291717120,
  "in_reply_to_status_id" : 722502502491557889,
  "created_at" : "2016-04-19 19:45:27 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722147348789329920",
  "text" : "KINGDOM\nPHYLLUM\nCLASS\nORDER\nFAMILY\nGENUS\nSPECIES\nVARIETY",
  "id" : 722147348789329920,
  "created_at" : "2016-04-18 19:38:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722107416133787648",
  "text" : "even pets must show their papers in the US",
  "id" : 722107416133787648,
  "created_at" : "2016-04-18 16:59:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721941326845976576",
  "text" : "I do desire to be deciphered...",
  "id" : 721941326845976576,
  "created_at" : "2016-04-18 05:59:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/gjKaMUUpBJ",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/721803216422187009",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721803617221484544",
  "text" : "afaik it's caused by gravitational lensing :beaker: \n\nhttps:\/\/t.co\/gjKaMUUpBJ",
  "id" : 721803617221484544,
  "created_at" : "2016-04-17 20:52:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/J0HtBSWbSj",
      "expanded_url" : "http:\/\/physics.stackexchange.com\/questions\/30365\/why-does-paper-become-translucent-when-smeared-with-oil-but-not-so-much-with-w",
      "display_url" : "physics.stackexchange.com\/questions\/3036\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721803216422187009",
  "text" : "I was pondering the optical potential of see thru wet t-shirts and greasy fibers when https:\/\/t.co\/J0HtBSWbSj",
  "id" : 721803216422187009,
  "created_at" : "2016-04-17 20:51:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/VGTuRfxLNL",
      "expanded_url" : "https:\/\/twitter.com\/PatriotsOfMars\/status\/721727460245696512",
      "display_url" : "twitter.com\/PatriotsOfMars\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721760932506918912",
  "text" : "I AM REDUCED 0_0 https:\/\/t.co\/VGTuRfxLNL",
  "id" : 721760932506918912,
  "created_at" : "2016-04-17 18:03:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721751850945392640",
  "text" : "leave your politics, morals, and aesthetics at the door pls",
  "id" : 721751850945392640,
  "created_at" : "2016-04-17 17:27:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Archillect",
      "screen_name" : "archillect",
      "indices" : [ 1, 12 ],
      "id_str" : "2907774137",
      "id" : 2907774137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721751737992765440",
  "text" : ".@archillect is bourgie aesthetics and nobody cares about your personal aesthetics leave it alone",
  "id" : 721751737992765440,
  "created_at" : "2016-04-17 17:26:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 45, 58 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 63, 72 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/OGjWseY0ZB",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/rawr-data",
      "display_url" : "soundcloud.com\/johnnyscript\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721176051091505152",
  "text" : "RT @folkstack: WE FEEL COMFORTABLE DECLARING @JOHNNYSCRIPT AND @SUBSTACK THE BEST LIVE CODING ALGORITHMIC MUSICIANS IN THE WORLD https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 30, 43 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "substack",
        "screen_name" : "substack",
        "indices" : [ 48, 57 ],
        "id_str" : "125027291",
        "id" : 125027291
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/OGjWseY0ZB",
        "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/rawr-data",
        "display_url" : "soundcloud.com\/johnnyscript\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "721038525324374016",
    "text" : "WE FEEL COMFORTABLE DECLARING @JOHNNYSCRIPT AND @SUBSTACK THE BEST LIVE CODING ALGORITHMIC MUSICIANS IN THE WORLD https:\/\/t.co\/OGjWseY0ZB",
    "id" : 721038525324374016,
    "created_at" : "2016-04-15 18:12:35 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 721176051091505152,
  "created_at" : "2016-04-16 03:19:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riva-Melissa Tez",
      "screen_name" : "rivatez",
      "indices" : [ 3, 11 ],
      "id_str" : "586559221",
      "id" : 586559221
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rivatez\/status\/721106254765031425\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/BH13YxgyFQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgHiUS0UAAAMZ42.jpg",
      "id_str" : "721106253632503808",
      "id" : 721106253632503808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgHiUS0UAAAMZ42.jpg",
      "sizes" : [ {
        "h" : 968,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BH13YxgyFQ"
    } ],
    "hashtags" : [ {
      "text" : "recursion",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721129014325194752",
  "text" : "RT @rivatez: . #recursion https:\/\/t.co\/BH13YxgyFQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rivatez\/status\/721106254765031425\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/BH13YxgyFQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgHiUS0UAAAMZ42.jpg",
        "id_str" : "721106253632503808",
        "id" : 721106253632503808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgHiUS0UAAAMZ42.jpg",
        "sizes" : [ {
          "h" : 968,
          "resize" : "fit",
          "w" : 1376
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/BH13YxgyFQ"
      } ],
      "hashtags" : [ {
        "text" : "recursion",
        "indices" : [ 2, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721106254765031425",
    "text" : ". #recursion https:\/\/t.co\/BH13YxgyFQ",
    "id" : 721106254765031425,
    "created_at" : "2016-04-15 22:41:43 +0000",
    "user" : {
      "name" : "Riva-Melissa Tez",
      "screen_name" : "rivatez",
      "protected" : false,
      "id_str" : "586559221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716810206143848449\/NJE_IdCj_normal.jpg",
      "id" : 586559221,
      "verified" : false
    }
  },
  "id" : 721129014325194752,
  "created_at" : "2016-04-16 00:12:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/f8ef9lPzKV",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack",
      "display_url" : "soundcloud.com\/folkstack"
    }, {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/oE8eOQ2CR8",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript",
      "display_url" : "soundcloud.com\/johnnyscript"
    }, {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/2sF744jgPI",
      "expanded_url" : "https:\/\/soundcloud.com\/substack",
      "display_url" : "soundcloud.com\/substack"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/WddEWkK2Lv",
      "expanded_url" : "https:\/\/twitter.com\/HipHopDX\/status\/720823977044627456",
      "display_url" : "twitter.com\/HipHopDX\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721022175646343168",
  "text" : "RT @folkstack: Our tracks are CC licensed 4 u 2 sample: \nhttps:\/\/t.co\/f8ef9lPzKV \nhttps:\/\/t.co\/oE8eOQ2CR8\nhttps:\/\/t.co\/2sF744jgPI\n https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/f8ef9lPzKV",
        "expanded_url" : "https:\/\/soundcloud.com\/folkstack",
        "display_url" : "soundcloud.com\/folkstack"
      }, {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/oE8eOQ2CR8",
        "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript",
        "display_url" : "soundcloud.com\/johnnyscript"
      }, {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/2sF744jgPI",
        "expanded_url" : "https:\/\/soundcloud.com\/substack",
        "display_url" : "soundcloud.com\/substack"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/WddEWkK2Lv",
        "expanded_url" : "https:\/\/twitter.com\/HipHopDX\/status\/720823977044627456",
        "display_url" : "twitter.com\/HipHopDX\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "721021684187209729",
    "text" : "Our tracks are CC licensed 4 u 2 sample: \nhttps:\/\/t.co\/f8ef9lPzKV \nhttps:\/\/t.co\/oE8eOQ2CR8\nhttps:\/\/t.co\/2sF744jgPI\n https:\/\/t.co\/WddEWkK2Lv",
    "id" : 721021684187209729,
    "created_at" : "2016-04-15 17:05:40 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 721022175646343168,
  "created_at" : "2016-04-15 17:07:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721022139134947328",
  "text" : "RT @folkstack: NOT TRYING TO BE PART OF THE MUSIC INDUSTRIAL COMPLEX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721022026316521472",
    "text" : "NOT TRYING TO BE PART OF THE MUSIC INDUSTRIAL COMPLEX",
    "id" : 721022026316521472,
    "created_at" : "2016-04-15 17:07:01 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 721022139134947328,
  "created_at" : "2016-04-15 17:07:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721022067974348801",
  "text" : "CAVEAT AND EAT IT TO0",
  "id" : 721022067974348801,
  "created_at" : "2016-04-15 17:07:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/nKfy1t4y8F",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/4c94cf53cfbef38435c900ab6afd6e16",
      "display_url" : "gist.github.com\/NHQ\/4c94cf53cf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720869974990979072",
  "text" : "a poem in the night\n\nhttps:\/\/t.co\/nKfy1t4y8F",
  "id" : 720869974990979072,
  "created_at" : "2016-04-15 07:02:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720849835113324544",
  "text" : "nerds are the best allies",
  "id" : 720849835113324544,
  "created_at" : "2016-04-15 05:42:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allRise",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/f0GRZlcmNO",
      "expanded_url" : "https:\/\/twitter.com\/1JAKEBLEE\/status\/720766924595073024",
      "display_url" : "twitter.com\/1JAKEBLEE\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720840387531673600",
  "text" : "treat yr groupies to better, and then your girl too #allRise https:\/\/t.co\/f0GRZlcmNO",
  "id" : 720840387531673600,
  "created_at" : "2016-04-15 05:05:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720839643105595393",
  "text" : "activate and get involved",
  "id" : 720839643105595393,
  "created_at" : "2016-04-15 05:02:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720832221251121154",
  "text" : "I'd compete in the exciting 135 lbs women's bantamweight, but there's a line to get in the bathroom.",
  "id" : 720832221251121154,
  "created_at" : "2016-04-15 04:32:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720831596144627712",
  "text" : "Which tech entrepreneur wants to back my bid to become a world champion 125 lbs ultimate fighter?",
  "id" : 720831596144627712,
  "created_at" : "2016-04-15 04:30:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/E2hFspeCk0",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=xGv_igeCpMY",
      "display_url" : "youtube.com\/watch?v=xGv_ig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720823488575983616",
  "text" : "nightclub amnesia yes please \nhttps:\/\/t.co\/E2hFspeCk0",
  "id" : 720823488575983616,
  "created_at" : "2016-04-15 03:58:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jameszoo",
      "screen_name" : "Jameszooo",
      "indices" : [ 1, 11 ],
      "id_str" : "99915627",
      "id" : 99915627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/bnIKRrkBLQ",
      "expanded_url" : "https:\/\/soundcloud.com\/brainfeeder\/jameszoo-flake",
      "display_url" : "soundcloud.com\/brainfeeder\/ja\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720327134485438465",
  "text" : ".@Jameszooo playing on repeat https:\/\/t.co\/bnIKRrkBLQ",
  "id" : 720327134485438465,
  "created_at" : "2016-04-13 19:05:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720070283114078209",
  "text" : "twitter calls it \"follow\" but it's rlly more like \"witness my mania\"",
  "id" : 720070283114078209,
  "created_at" : "2016-04-13 02:05:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720058052183859200",
  "geo" : { },
  "id_str" : "720059231848665088",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon thx b tweets alone don't count  ;^P",
  "id" : 720059231848665088,
  "in_reply_to_status_id" : 720058052183859200,
  "created_at" : "2016-04-13 01:21:13 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Blue",
      "screen_name" : "rblue78",
      "indices" : [ 0, 8 ],
      "id_str" : "17322758",
      "id" : 17322758
    }, {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 9, 21 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/720058173403504640\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/w9fEzVtWoP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf4pF7pUMAAiDRd.jpg",
      "id_str" : "720058172312924160",
      "id" : 720058172312924160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf4pF7pUMAAiDRd.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/w9fEzVtWoP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720038520547631105",
  "geo" : { },
  "id_str" : "720058173403504640",
  "in_reply_to_user_id" : 17322758,
  "text" : "@rblue78 @vrroanhorse 2\/3 https:\/\/t.co\/w9fEzVtWoP",
  "id" : 720058173403504640,
  "in_reply_to_status_id" : 720038520547631105,
  "created_at" : "2016-04-13 01:17:01 +0000",
  "in_reply_to_screen_name" : "rblue78",
  "in_reply_to_user_id_str" : "17322758",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/AuaHNDBotu",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript",
      "display_url" : "soundcloud.com\/johnnyscript"
    } ]
  },
  "in_reply_to_status_id_str" : "720050201352732673",
  "geo" : { },
  "id_str" : "720057731965562880",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon here pass these raw beats around https:\/\/t.co\/AuaHNDBotu",
  "id" : 720057731965562880,
  "in_reply_to_status_id" : 720050201352732673,
  "created_at" : "2016-04-13 01:15:15 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 3, 14 ],
      "id_str" : "64105403",
      "id" : 64105403
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720051761810001920",
  "text" : "RT @legittalon: @johnnyscript yo. this is lit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "720046072375025664",
    "geo" : { },
    "id_str" : "720050201352732673",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript yo. this is lit",
    "id" : 720050201352732673,
    "in_reply_to_status_id" : 720046072375025664,
    "created_at" : "2016-04-13 00:45:20 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "protected" : false,
      "id_str" : "64105403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516448568706486274\/5oBt_x03_normal.png",
      "id" : 64105403,
      "verified" : false
    }
  },
  "id" : 720051761810001920,
  "created_at" : "2016-04-13 00:51:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/rf0OYoFdOB",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/fortress-knoxish",
      "display_url" : "soundcloud.com\/folkstack\/fort\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720046072375025664",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon  yo heard you like hip hop https:\/\/t.co\/rf0OYoFdOB",
  "id" : 720046072375025664,
  "created_at" : "2016-04-13 00:28:56 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/lDNzK2FlMY",
      "expanded_url" : "https:\/\/twitter.com\/papermagazine\/status\/719921691414163456",
      "display_url" : "twitter.com\/papermagazine\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719942417495928832",
  "text" : "win a date with me by taking me to this show in Berkeley! https:\/\/t.co\/lDNzK2FlMY",
  "id" : 719942417495928832,
  "created_at" : "2016-04-12 17:37:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719804569778135041",
  "text" : "my algorithms bring all the animals to the barn",
  "id" : 719804569778135041,
  "created_at" : "2016-04-12 08:29:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719795019549257728",
  "text" : "there's an owl on the roof hoot n I presume a booty call",
  "id" : 719795019549257728,
  "created_at" : "2016-04-12 07:51:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/nJ560CH3ph",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=r-UfiIOXP8A",
      "display_url" : "youtube.com\/watch?v=r-UfiI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719635110195138560",
  "text" : "Oppenheimer Analysis - \"New Mexico\"\n[minimal early 80s synthwave]\nhttps:\/\/t.co\/nJ560CH3ph",
  "id" : 719635110195138560,
  "created_at" : "2016-04-11 21:15:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719268128115458048",
  "text" : "XCLIP -O &gt; DAMN SON",
  "id" : 719268128115458048,
  "created_at" : "2016-04-10 20:57:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719012103302959104",
  "geo" : { },
  "id_str" : "719015522822529024",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost i think its just called signal",
  "id" : 719015522822529024,
  "in_reply_to_status_id" : 719012103302959104,
  "created_at" : "2016-04-10 04:13:53 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718928740873424897",
  "geo" : { },
  "id_str" : "718960403070386181",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost a toe head downloads textsecure by signal on a toe head's fone",
  "id" : 718960403070386181,
  "in_reply_to_status_id" : 718928740873424897,
  "created_at" : "2016-04-10 00:34:52 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718959465244962816",
  "text" : "a safe place to space out is in front of a mirror",
  "id" : 718959465244962816,
  "created_at" : "2016-04-10 00:31:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/zpCwV1K1OG",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/718898708251746304",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718900997922246656",
  "text" : "copy dis dat cuz i'll prob delete\n\nhttps:\/\/t.co\/zpCwV1K1OG",
  "id" : 718900997922246656,
  "created_at" : "2016-04-09 20:38:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718898708251746304",
  "text" : "If you want to contact me directly, you can text me via textsecure at 510-296-7167  (not regular texts, only textsecure)",
  "id" : 718898708251746304,
  "created_at" : "2016-04-09 20:29:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718893671869878274",
  "text" : "LIKE REAL FOOD ON FACEBOOK\n                             ^\n                          BUTT",
  "id" : 718893671869878274,
  "created_at" : "2016-04-09 20:09:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718892661931806720",
  "text" : "OH I GET IT\n\nLIKE * [BUT] ON FACEBOOK",
  "id" : 718892661931806720,
  "created_at" : "2016-04-09 20:05:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Murillo",
      "screen_name" : "Murillosaurus",
      "indices" : [ 0, 14 ],
      "id_str" : "2278603208",
      "id" : 2278603208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718555061341687808",
  "geo" : { },
  "id_str" : "718853893145276416",
  "in_reply_to_user_id" : 2278603208,
  "text" : "@Murillosaurus  our last jam was sick, ceiling all falling down.  let's play soon.  maybe co-gig in SD or nearby?",
  "id" : 718853893145276416,
  "in_reply_to_status_id" : 718555061341687808,
  "created_at" : "2016-04-09 17:31:38 +0000",
  "in_reply_to_screen_name" : "Murillosaurus",
  "in_reply_to_user_id_str" : "2278603208",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 0, 8 ],
      "id_str" : "185744472",
      "id" : 185744472
    }, {
      "name" : "Shadertoy",
      "screen_name" : "Shadertoy",
      "indices" : [ 9, 19 ],
      "id_str" : "1129365692",
      "id" : 1129365692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718516193057832964",
  "geo" : { },
  "id_str" : "718518410523455488",
  "in_reply_to_user_id" : 185744472,
  "text" : "@Cabbibo @Shadertoy ys",
  "id" : 718518410523455488,
  "in_reply_to_status_id" : 718516193057832964,
  "created_at" : "2016-04-08 19:18:33 +0000",
  "in_reply_to_screen_name" : "Cabbibo",
  "in_reply_to_user_id_str" : "185744472",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/q5XjZsonWI",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/disco-ltd",
      "display_url" : "soundcloud.com\/johnnyscript\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718271682977349635",
  "text" : "I wrote more beat today, this one on it's way to the dance https:\/\/t.co\/q5XjZsonWI",
  "id" : 718271682977349635,
  "created_at" : "2016-04-08 02:58:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718266148924600322",
  "text" : "I'm working here, from a hole in the ground, on an island in the sky.",
  "id" : 718266148924600322,
  "created_at" : "2016-04-08 02:36:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/zKAWvruicY",
      "expanded_url" : "https:\/\/twitter.com\/BernieSanders\/status\/718202901366185985",
      "display_url" : "twitter.com\/BernieSanders\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718217369546428416",
  "text" : "can Obama do this... or nah? https:\/\/t.co\/zKAWvruicY",
  "id" : 718217369546428416,
  "created_at" : "2016-04-07 23:22:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/69qNtQZZG5",
      "expanded_url" : "https:\/\/youtu.be\/eksEL8qhP-w?t=29s",
      "display_url" : "youtu.be\/eksEL8qhP-w?t=\u2026"
    }, {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/62qS35F4J5",
      "expanded_url" : "https:\/\/twitter.com\/marinakukso\/status\/718187166996692992",
      "display_url" : "twitter.com\/marinakukso\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718216917899579392",
  "text" : "tomorrow we learn to throw shit much farther with a basic sling\n\nhttps:\/\/t.co\/69qNtQZZG5 https:\/\/t.co\/62qS35F4J5",
  "id" : 718216917899579392,
  "created_at" : "2016-04-07 23:20:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718187162626236416",
  "text" : "go 'head act like you don't know",
  "id" : 718187162626236416,
  "created_at" : "2016-04-07 21:22:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718172088104673280",
  "text" : "hand synthesized",
  "id" : 718172088104673280,
  "created_at" : "2016-04-07 20:22:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "101bpm",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/AIkCzstrxJ",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/math-beats-101",
      "display_url" : "soundcloud.com\/johnnyscript\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718170877032931332",
  "text" : "you can download and sample this 100% OG pure code beat #101bpm \n\nhttps:\/\/t.co\/AIkCzstrxJ",
  "id" : 718170877032931332,
  "created_at" : "2016-04-07 20:17:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Ministry of GIFs",
      "screen_name" : "GIFs",
      "indices" : [ 3, 8 ],
      "id_str" : "1019188722",
      "id" : 1019188722
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GIFs\/status\/718085900769452034\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/xww7HhhpaA",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfcnUjaVAAEX8Kh.jpg",
      "id_str" : "718085899645419521",
      "id" : 718085899645419521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfcnUjaVAAEX8Kh.jpg",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/xww7HhhpaA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/wDqGgBf0sq",
      "expanded_url" : "http:\/\/ministryofgifs.org\/post\/142406594827",
      "display_url" : "ministryofgifs.org\/post\/142406594\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718099389751820290",
  "text" : "RT @GIFs: https:\/\/t.co\/wDqGgBf0sq https:\/\/t.co\/xww7HhhpaA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ministryofgifs.org\" rel=\"nofollow\"\u003EGIFs Daemon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GIFs\/status\/718085900769452034\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/xww7HhhpaA",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfcnUjaVAAEX8Kh.jpg",
        "id_str" : "718085899645419521",
        "id" : 718085899645419521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfcnUjaVAAEX8Kh.jpg",
        "sizes" : [ {
          "h" : 212,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/xww7HhhpaA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/wDqGgBf0sq",
        "expanded_url" : "http:\/\/ministryofgifs.org\/post\/142406594827",
        "display_url" : "ministryofgifs.org\/post\/142406594\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718085900769452034",
    "text" : "https:\/\/t.co\/wDqGgBf0sq https:\/\/t.co\/xww7HhhpaA",
    "id" : 718085900769452034,
    "created_at" : "2016-04-07 14:39:54 +0000",
    "user" : {
      "name" : "The Ministry of GIFs",
      "screen_name" : "GIFs",
      "protected" : false,
      "id_str" : "1019188722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616383986563072000\/bqBSdcY5_normal.png",
      "id" : 1019188722,
      "verified" : false
    }
  },
  "id" : 718099389751820290,
  "created_at" : "2016-04-07 15:33:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 29, 42 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 90, 106 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/oE8eOQ2CR8",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript",
      "display_url" : "soundcloud.com\/johnnyscript"
    } ]
  },
  "geo" : { },
  "id_str" : "717798261382184960",
  "text" : "RT @folkstack: all tracks on @johnnyscript's soundclod page are downloadable and licensed @creativecommons \n\nhttps:\/\/t.co\/oE8eOQ2CR8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 14, 27 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "Creative Commons",
        "screen_name" : "creativecommons",
        "indices" : [ 75, 91 ],
        "id_str" : "17462723",
        "id" : 17462723
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/oE8eOQ2CR8",
        "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript",
        "display_url" : "soundcloud.com\/johnnyscript"
      } ]
    },
    "geo" : { },
    "id_str" : "717798189110177792",
    "text" : "all tracks on @johnnyscript's soundclod page are downloadable and licensed @creativecommons \n\nhttps:\/\/t.co\/oE8eOQ2CR8",
    "id" : 717798189110177792,
    "created_at" : "2016-04-06 19:36:38 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 717798261382184960,
  "created_at" : "2016-04-06 19:36:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/1C6UO7MsFv",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/brrring",
      "display_url" : "soundcloud.com\/johnnyscript\/b\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/h3AqAe1o2X",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/brrring-72bpm",
      "display_url" : "soundcloud.com\/johnnyscript\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717787841632215040",
  "text" : "RT @folkstack: here is a simplex algo rhythm for you to download and embroider @ 66 bpm\n\nhttps:\/\/t.co\/1C6UO7MsFv\n\nalso @ 72 bpm\n\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/1C6UO7MsFv",
        "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/brrring",
        "display_url" : "soundcloud.com\/johnnyscript\/b\u2026"
      }, {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/h3AqAe1o2X",
        "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/brrring-72bpm",
        "display_url" : "soundcloud.com\/johnnyscript\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717787597850996736",
    "text" : "here is a simplex algo rhythm for you to download and embroider @ 66 bpm\n\nhttps:\/\/t.co\/1C6UO7MsFv\n\nalso @ 72 bpm\n\nhttps:\/\/t.co\/h3AqAe1o2X",
    "id" : 717787597850996736,
    "created_at" : "2016-04-06 18:54:33 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 717787841632215040,
  "created_at" : "2016-04-06 18:55:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/2teXwREIk1",
      "expanded_url" : "https:\/\/youtu.be\/XyJnmAVnE-I",
      "display_url" : "youtu.be\/XyJnmAVnE-I"
    } ]
  },
  "geo" : { },
  "id_str" : "717520753990602752",
  "text" : "RT @folkstack: content algorithmic\n\nhttps:\/\/t.co\/2teXwREIk1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/2teXwREIk1",
        "expanded_url" : "https:\/\/youtu.be\/XyJnmAVnE-I",
        "display_url" : "youtu.be\/XyJnmAVnE-I"
      } ]
    },
    "geo" : { },
    "id_str" : "717520321440382976",
    "text" : "content algorithmic\n\nhttps:\/\/t.co\/2teXwREIk1",
    "id" : 717520321440382976,
    "created_at" : "2016-04-06 01:12:30 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 717520753990602752,
  "created_at" : "2016-04-06 01:14:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/717471895558483968\/photo\/1",
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/kId3LMrDok",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfT40xDUsAAUhzJ.jpg",
      "id_str" : "717471826062913536",
      "id" : 717471826062913536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfT40xDUsAAUhzJ.jpg",
      "sizes" : [ {
        "h" : 120,
        "resize" : "fit",
        "w" : 144
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 144
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 144
      }, {
        "h" : 120,
        "resize" : "crop",
        "w" : 120
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 144
      } ],
      "display_url" : "pic.twitter.com\/kId3LMrDok"
    } ],
    "hashtags" : [ {
      "text" : "selfie",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717471895558483968",
  "text" : "#selfie https:\/\/t.co\/kId3LMrDok",
  "id" : 717471895558483968,
  "created_at" : "2016-04-05 22:00:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717045142511681537",
  "text" : "first haircut in 2 years",
  "id" : 717045142511681537,
  "created_at" : "2016-04-04 17:44:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/RD0HvScpT3",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=JyXdZOvk6fs",
      "display_url" : "youtube.com\/watch?v=JyXdZO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716833714588614656",
  "text" : "This Mexican Psyche is Los Dug Dugs  https:\/\/t.co\/RD0HvScpT3",
  "id" : 716833714588614656,
  "created_at" : "2016-04-04 03:44:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716712963676110848",
  "text" : "HERE'S THE D\u00C6TS",
  "id" : 716712963676110848,
  "created_at" : "2016-04-03 19:44:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/715957368891252736\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/VAKmlh5S5e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce-Xbr6UMAEkOyB.jpg",
      "id_str" : "715957367674777601",
      "id" : 715957367674777601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce-Xbr6UMAEkOyB.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/VAKmlh5S5e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715957368891252736",
  "text" : "this is your brain on twisted vectors https:\/\/t.co\/VAKmlh5S5e",
  "id" : 715957368891252736,
  "created_at" : "2016-04-01 17:41:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715932343739883520",
  "text" : "Aprils Fools!  \n\nHaha, jus kidding, this isn't a prank.",
  "id" : 715932343739883520,
  "created_at" : "2016-04-01 16:02:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]