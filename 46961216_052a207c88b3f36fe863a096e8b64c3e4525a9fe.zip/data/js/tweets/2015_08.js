Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638439523198758912",
  "text" : "ITS PEANUT BUTTER SELFIE TIME",
  "id" : 638439523198758912,
  "created_at" : "2015-08-31 19:53:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638092648276819968",
  "text" : "ME A TEA LEAF TERRAFORMER",
  "id" : 638092648276819968,
  "created_at" : "2015-08-30 20:55:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638092304549474304",
  "text" : "SEXUAL MOUNT EVEREST",
  "id" : 638092304549474304,
  "created_at" : "2015-08-30 20:53:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 64, 77 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 78, 87 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cyberwizard",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/mPiCdBsNIf",
      "expanded_url" : "http:\/\/kukso.space\/",
      "display_url" : "kukso.space"
    } ]
  },
  "geo" : { },
  "id_str" : "638070572635713536",
  "text" : "RT @marinakukso: http:\/\/t.co\/mPiCdBsNIf is launched! (thanks to @johnnyscript @substack &amp; all the other #cyberwizard's for help making the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 47, 60 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "substack",
        "screen_name" : "substack",
        "indices" : [ 61, 70 ],
        "id_str" : "125027291",
        "id" : 125027291
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cyberwizard",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/mPiCdBsNIf",
        "expanded_url" : "http:\/\/kukso.space\/",
        "display_url" : "kukso.space"
      } ]
    },
    "geo" : { },
    "id_str" : "637822728200851460",
    "text" : "http:\/\/t.co\/mPiCdBsNIf is launched! (thanks to @johnnyscript @substack &amp; all the other #cyberwizard's for help making the site :))",
    "id" : 637822728200851460,
    "created_at" : "2015-08-30 03:02:43 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 638070572635713536,
  "created_at" : "2015-08-30 19:27:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "637852139855835136",
  "geo" : { },
  "id_str" : "637905823176331264",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia  \"and what's your hourly?\"",
  "id" : 637905823176331264,
  "in_reply_to_status_id" : 637852139855835136,
  "created_at" : "2015-08-30 08:32:54 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "APTP First Response",
      "screen_name" : "aptpresponse",
      "indices" : [ 3, 16 ],
      "id_str" : "3065571846",
      "id" : 3065571846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/NckEeRsHXS",
      "expanded_url" : "http:\/\/www.siliconvalleydebug.org\/articles\/2015\/08\/28\/4-deaths-8-days-san-jose-4in8",
      "display_url" : "siliconvalleydebug.org\/articles\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "637337225131261952",
  "text" : "RT @aptpresponse: 4 people killed by police in san jose in 8 days\nhttp:\/\/t.co\/NckEeRsHXS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/NckEeRsHXS",
        "expanded_url" : "http:\/\/www.siliconvalleydebug.org\/articles\/2015\/08\/28\/4-deaths-8-days-san-jose-4in8",
        "display_url" : "siliconvalleydebug.org\/articles\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "637298972650897408",
    "text" : "4 people killed by police in san jose in 8 days\nhttp:\/\/t.co\/NckEeRsHXS",
    "id" : 637298972650897408,
    "created_at" : "2015-08-28 16:21:30 +0000",
    "user" : {
      "name" : "APTP First Response",
      "screen_name" : "aptpresponse",
      "protected" : false,
      "id_str" : "3065571846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574016379956785154\/NXeXkNh7_normal.jpeg",
      "id" : 3065571846,
      "verified" : false
    }
  },
  "id" : 637337225131261952,
  "created_at" : "2015-08-28 18:53:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UpsideDownWorld",
      "screen_name" : "UpsideDownTweet",
      "indices" : [ 3, 19 ],
      "id_str" : "88708629",
      "id" : 88708629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MyvChgfqQW",
      "expanded_url" : "http:\/\/fb.me\/6OeHxFdfr",
      "display_url" : "fb.me\/6OeHxFdfr"
    } ]
  },
  "geo" : { },
  "id_str" : "637188924763299840",
  "text" : "RT @UpsideDownTweet: A look at the crises and opportunities in Guatemala, Honduras and El Salvador, and the potential for a democratic... h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/MyvChgfqQW",
        "expanded_url" : "http:\/\/fb.me\/6OeHxFdfr",
        "display_url" : "fb.me\/6OeHxFdfr"
      } ]
    },
    "geo" : { },
    "id_str" : "637103480310755328",
    "text" : "A look at the crises and opportunities in Guatemala, Honduras and El Salvador, and the potential for a democratic... http:\/\/t.co\/MyvChgfqQW",
    "id" : 637103480310755328,
    "created_at" : "2015-08-28 03:24:41 +0000",
    "user" : {
      "name" : "UpsideDownWorld",
      "screen_name" : "UpsideDownTweet",
      "protected" : false,
      "id_str" : "88708629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501412823923060736\/wsYO0scG_normal.jpeg",
      "id" : 88708629,
      "verified" : false
    }
  },
  "id" : 637188924763299840,
  "created_at" : "2015-08-28 09:04:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/hNPD3OB4dM",
      "expanded_url" : "http:\/\/johnnyscript.neocities.org\/dow_jones.html",
      "display_url" : "johnnyscript.neocities.org\/dow_jones.html"
    }, {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/WKZo8MMAIE",
      "expanded_url" : "https:\/\/github.com\/NHQ\/bowdow",
      "display_url" : "github.com\/NHQ\/bowdow"
    } ]
  },
  "geo" : { },
  "id_str" : "637026810086060033",
  "text" : "some bodies please add some wicked visuals to this middle finger:  http:\/\/t.co\/hNPD3OB4dM\n\nhttps:\/\/t.co\/WKZo8MMAIE",
  "id" : 637026810086060033,
  "created_at" : "2015-08-27 22:20:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636833062198751232",
  "text" : "urgency and emurgency and punishement",
  "id" : 636833062198751232,
  "created_at" : "2015-08-27 09:30:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636824523774406656",
  "text" : "hasta vemos...",
  "id" : 636824523774406656,
  "created_at" : "2015-08-27 08:56:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636818304712048641",
  "text" : "Hollywood would have you believe that a swan song is the orgasm of your famously ecstatic death, but really it's justly your middle finger.",
  "id" : 636818304712048641,
  "created_at" : "2015-08-27 08:31:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/hNPD3OB4dM",
      "expanded_url" : "http:\/\/johnnyscript.neocities.org\/dow_jones.html",
      "display_url" : "johnnyscript.neocities.org\/dow_jones.html"
    } ]
  },
  "geo" : { },
  "id_str" : "636817350239502336",
  "text" : "I've listened to this for a cumulolunit of a at least 18 hours.  still good.  and this is as good as it repeated: http:\/\/t.co\/hNPD3OB4dM",
  "id" : 636817350239502336,
  "created_at" : "2015-08-27 08:27:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/hPaTkKPZDP",
      "expanded_url" : "https:\/\/twitter.com\/Scott_Gilmore\/status\/636674777772507136",
      "display_url" : "twitter.com\/Scott_Gilmore\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636726997830340609",
  "text" : "RT @dominictarr: Guns don't kill people,\nAmericans kill people.\nhttps:\/\/t.co\/hPaTkKPZDP\n\n(with guns)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/hPaTkKPZDP",
        "expanded_url" : "https:\/\/twitter.com\/Scott_Gilmore\/status\/636674777772507136",
        "display_url" : "twitter.com\/Scott_Gilmore\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636721835598606336",
    "text" : "Guns don't kill people,\nAmericans kill people.\nhttps:\/\/t.co\/hPaTkKPZDP\n\n(with guns)",
    "id" : 636721835598606336,
    "created_at" : "2015-08-27 02:08:09 +0000",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712569197126160384\/nvnXBzt-_normal.jpg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 636726997830340609,
  "created_at" : "2015-08-27 02:28:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/hNPD3OB4dM",
      "expanded_url" : "http:\/\/johnnyscript.neocities.org\/dow_jones.html",
      "display_url" : "johnnyscript.neocities.org\/dow_jones.html"
    } ]
  },
  "geo" : { },
  "id_str" : "636304473669828608",
  "text" : "I made an homage to the DOW JONES TOTALLY ARBITRARY INDEX THAT RUNS YOUR LIFE\n\nhttp:\/\/t.co\/hNPD3OB4dM",
  "id" : 636304473669828608,
  "created_at" : "2015-08-25 22:29:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Lamere",
      "screen_name" : "plamere",
      "indices" : [ 0, 8 ],
      "id_str" : "1685811",
      "id" : 1685811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636285795591065600",
  "in_reply_to_user_id" : 1685811,
  "text" : "@plamere  Q: Which parts of the echonest API does infinite jukebox query to get individual beat data?",
  "id" : 636285795591065600,
  "created_at" : "2015-08-25 21:15:29 +0000",
  "in_reply_to_screen_name" : "plamere",
  "in_reply_to_user_id_str" : "1685811",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636260925184413696",
  "text" : "RT @postcrunk: decades obsessing with individuality, competition, and exceptionalism created a cultural divide too toxic, indignant, and is\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636206491796639744",
    "text" : "decades obsessing with individuality, competition, and exceptionalism created a cultural divide too toxic, indignant, and isolated to cross",
    "id" : 636206491796639744,
    "created_at" : "2015-08-25 16:00:22 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 636260925184413696,
  "created_at" : "2015-08-25 19:36:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635894168095621120",
  "text" : "realness is radical rn",
  "id" : 635894168095621120,
  "created_at" : "2015-08-24 19:19:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/ujKp9F2DRW",
      "expanded_url" : "https:\/\/twitter.com\/neiltyson\/status\/635832130933657600",
      "display_url" : "twitter.com\/neiltyson\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635840254532947969",
  "text" : "The same is true for non-non-humans. https:\/\/t.co\/ujKp9F2DRW",
  "id" : 635840254532947969,
  "created_at" : "2015-08-24 15:45:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/1jgBmK8lWq",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=LDtycGXVcbk&list=PLRxF_x9iqxQgQnW38P43Z3bfUI4SSP5AL",
      "display_url" : "youtube.com\/watch?v=LDtycG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635839799887159296",
  "text" : "early Ratatat is so catharsis at the fall of your empire \n\nhttps:\/\/t.co\/1jgBmK8lWq",
  "id" : 635839799887159296,
  "created_at" : "2015-08-24 15:43:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/il1zGATrXJ",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/stretch-beat-thoerymix",
      "display_url" : "soundcloud.com\/folkstack\/stre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635667389271683072",
  "text" : "do not click play if you aint ready to sustain literal attempts to blow your mind with funk n amplitude\nhttps:\/\/t.co\/il1zGATrXJ",
  "id" : 635667389271683072,
  "created_at" : "2015-08-24 04:18:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635659657273446400",
  "text" : "I'VE GOT Z WHOLE VIDE WELTSCHMERZ IN MY HEAD",
  "id" : 635659657273446400,
  "created_at" : "2015-08-24 03:47:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Feichtinger",
      "screen_name" : "auxilit",
      "indices" : [ 3, 11 ],
      "id_str" : "156680765",
      "id" : 156680765
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/auxilit\/status\/631639227604692992\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KFAqmGGL5W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMQIhy_U8AAAxnO.png",
      "id_str" : "631639224454803456",
      "id" : 631639224454803456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMQIhy_U8AAAxnO.png",
      "sizes" : [ {
        "h" : 177,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KFAqmGGL5W"
    } ],
    "hashtags" : [ {
      "text" : "Dynabook",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "AdBlocking",
      "indices" : [ 91, 102 ]
    }, {
      "text" : "AlanKay",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/HU9UDujMOd",
      "expanded_url" : "http:\/\/www.mprove.de\/diplom\/gui\/Kay72a.pdf",
      "display_url" : "mprove.de\/diplom\/gui\/Kay\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635150368423346176",
  "text" : "RT @auxilit: Alan Kay weighs in on ad-blocking. In 1972 \u2014 http:\/\/t.co\/HU9UDujMOd #Dynabook #AdBlocking #AlanKay http:\/\/t.co\/KFAqmGGL5W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/auxilit\/status\/631639227604692992\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/KFAqmGGL5W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMQIhy_U8AAAxnO.png",
        "id_str" : "631639224454803456",
        "id" : 631639224454803456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMQIhy_U8AAAxnO.png",
        "sizes" : [ {
          "h" : 177,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 304,
          "resize" : "fit",
          "w" : 1032
        }, {
          "h" : 100,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KFAqmGGL5W"
      } ],
      "hashtags" : [ {
        "text" : "Dynabook",
        "indices" : [ 68, 77 ]
      }, {
        "text" : "AdBlocking",
        "indices" : [ 78, 89 ]
      }, {
        "text" : "AlanKay",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/HU9UDujMOd",
        "expanded_url" : "http:\/\/www.mprove.de\/diplom\/gui\/Kay72a.pdf",
        "display_url" : "mprove.de\/diplom\/gui\/Kay\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631639227604692992",
    "text" : "Alan Kay weighs in on ad-blocking. In 1972 \u2014 http:\/\/t.co\/HU9UDujMOd #Dynabook #AdBlocking #AlanKay http:\/\/t.co\/KFAqmGGL5W",
    "id" : 631639227604692992,
    "created_at" : "2015-08-13 01:31:41 +0000",
    "user" : {
      "name" : "Daniel Feichtinger",
      "screen_name" : "auxilit",
      "protected" : false,
      "id_str" : "156680765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1107841819\/favicon_256_normal.png",
      "id" : 156680765,
      "verified" : false
    }
  },
  "id" : 635150368423346176,
  "created_at" : "2015-08-22 18:03:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634591446721413124",
  "text" : "I can't say if I learned how to program over several years, or in one single instant.",
  "id" : 634591446721413124,
  "created_at" : "2015-08-21 05:02:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 3, 18 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634570538686386177",
  "text" : "RT @brownnoiseblog: Black, White, Gay, Straight, Cis, Transgender... doesnt matter. We can all agree that Olde English switching to plastic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634567070982647810",
    "text" : "Black, White, Gay, Straight, Cis, Transgender... doesnt matter. We can all agree that Olde English switching to plastic bottles is bullshit.",
    "id" : 634567070982647810,
    "created_at" : "2015-08-21 03:25:54 +0000",
    "user" : {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "protected" : false,
      "id_str" : "283708113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3182488049\/166dbd593d5eef02f3c21853931f3cfe_normal.jpeg",
      "id" : 283708113,
      "verified" : false
    }
  },
  "id" : 634570538686386177,
  "created_at" : "2015-08-21 03:39:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noSemiColons",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634487054299172864",
  "text" : "You want to talk about yourself\nand I don't\nwant to talk about either of us \n#noSemiColons",
  "id" : 634487054299172864,
  "created_at" : "2015-08-20 22:07:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634054822929502209",
  "text" : "the spirit, is very MOMENT and beauty. was I just to neologisms. basically stagnant. Status here, quo asshats.",
  "id" : 634054822929502209,
  "created_at" : "2015-08-19 17:30:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634054356208340992",
  "text" : "recursion so much venture capital, steps as echelons, Them of Let NOT Chillax.",
  "id" : 634054356208340992,
  "created_at" : "2015-08-19 17:28:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/n1Zr2l4CrP",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/The_New_Colossus",
      "display_url" : "en.wikipedia.org\/wiki\/The_New_C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633933257516552192",
  "text" : "http:\/\/t.co\/n1Zr2l4CrP Homeless methinks Johnny. Honestly.",
  "id" : 633933257516552192,
  "created_at" : "2015-08-19 09:27:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/WCK9PoyUZp",
      "expanded_url" : "http:\/\/kitties.neocities.org\/assemblyline\/assemblyline.html",
      "display_url" : "kitties.neocities.org\/assemblyline\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633930644024770560",
  "text" : "RT @marinakukso: the adventure continues! (my most recent comic) http:\/\/t.co\/WCK9PoyUZp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/WCK9PoyUZp",
        "expanded_url" : "http:\/\/kitties.neocities.org\/assemblyline\/assemblyline.html",
        "display_url" : "kitties.neocities.org\/assemblyline\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633880978914603008",
    "text" : "the adventure continues! (my most recent comic) http:\/\/t.co\/WCK9PoyUZp",
    "id" : 633880978914603008,
    "created_at" : "2015-08-19 05:59:36 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 633930644024770560,
  "created_at" : "2015-08-19 09:16:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633924788075933696",
  "text" : "attack sea against yourself.  font-weight:900",
  "id" : 633924788075933696,
  "created_at" : "2015-08-19 08:53:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633924746795552768",
  "text" : "of yr \"rights\". you on a Choice.  cuz People are corporate Introduction service argumenta. for hipsters!",
  "id" : 633924746795552768,
  "created_at" : "2015-08-19 08:53:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633924157508419584",
  "text" : "I goost Do Hooly a some beautiful for and UX\/UI BEAUTY spittin' was In \"The flyness",
  "id" : 633924157508419584,
  "created_at" : "2015-08-19 08:51:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/gu2nkxM9dA",
      "expanded_url" : "http:\/\/studio.substack.net\/theorymix?time=1396515264004",
      "display_url" : "studio.substack.net\/theorymix?time\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633827606958243840",
  "text" : "each(states, fn (st) http:\/\/t.co\/gu2nkxM9dA not grok &amp;amp; sisters, we're compatible",
  "id" : 633827606958243840,
  "created_at" : "2015-08-19 02:27:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633823624533676032",
  "text" : "nisl. Vestibulum sed eget laoreet tellus NON eget facilisis augue pretium rhoncus dapibus eleifend. magna, Integer orci!",
  "id" : 633823624533676032,
  "created_at" : "2015-08-19 02:11:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633818963982446592",
  "text" : "An earthquake that did not even wake me knocked my residence off the water grid for a day, for those keeping score of the end times at home.",
  "id" : 633818963982446592,
  "created_at" : "2015-08-19 01:53:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633753083600723968",
  "text" : "THINK NOT, DO IT FOR I\n\nTHINK AYE, DO IT BETTER THAN ME",
  "id" : 633753083600723968,
  "created_at" : "2015-08-18 21:31:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/tSgbZDpVJX",
      "expanded_url" : "http:\/\/www.vpc.org\/studies\/wmmw2014.pdf",
      "display_url" : "vpc.org\/studies\/wmmw20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633384720890331137",
  "text" : "RT @marinakukso: \"13x as many females were murdered by a male they knew (1,487 victims) than by male strangers (107 victims)\" http:\/\/t.co\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/tSgbZDpVJX",
        "expanded_url" : "http:\/\/www.vpc.org\/studies\/wmmw2014.pdf",
        "display_url" : "vpc.org\/studies\/wmmw20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633363890374479872",
    "text" : "\"13x as many females were murdered by a male they knew (1,487 victims) than by male strangers (107 victims)\" http:\/\/t.co\/tSgbZDpVJX",
    "id" : 633363890374479872,
    "created_at" : "2015-08-17 19:44:53 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 633384720890331137,
  "created_at" : "2015-08-17 21:07:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/qkwVOyAjrg",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Violence_against_women",
      "display_url" : "en.wikipedia.org\/wiki\/Violence_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633383360967020544",
  "text" : "RT @marinakukso: \"there is no region of the world, no country, &amp; no culture in which women\u2019s freedom from violence has been secured.\" https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/qkwVOyAjrg",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Violence_against_women",
        "display_url" : "en.wikipedia.org\/wiki\/Violence_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633377965816942592",
    "text" : "\"there is no region of the world, no country, &amp; no culture in which women\u2019s freedom from violence has been secured.\" https:\/\/t.co\/qkwVOyAjrg",
    "id" : 633377965816942592,
    "created_at" : "2015-08-17 20:40:49 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 633383360967020544,
  "created_at" : "2015-08-17 21:02:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/qkwVOyAjrg",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Violence_against_women",
      "display_url" : "en.wikipedia.org\/wiki\/Violence_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633383327118962688",
  "text" : "RT @marinakukso: \"At least 1 out of 3 women around the world has been beaten, coerced into sex, or otherwise abused in her lifetime\" https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/qkwVOyAjrg",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Violence_against_women",
        "display_url" : "en.wikipedia.org\/wiki\/Violence_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633368845911064576",
    "text" : "\"At least 1 out of 3 women around the world has been beaten, coerced into sex, or otherwise abused in her lifetime\" https:\/\/t.co\/qkwVOyAjrg",
    "id" : 633368845911064576,
    "created_at" : "2015-08-17 20:04:34 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 633383327118962688,
  "created_at" : "2015-08-17 21:02:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/qkwVOyAjrg",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Violence_against_women",
      "display_url" : "en.wikipedia.org\/wiki\/Violence_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633383318705180672",
  "text" : "RT @marinakukso: \"violence against women is a crucial social mechanism by which women are forced into a subordinate position to men\" https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/qkwVOyAjrg",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Violence_against_women",
        "display_url" : "en.wikipedia.org\/wiki\/Violence_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633368612925915142",
    "text" : "\"violence against women is a crucial social mechanism by which women are forced into a subordinate position to men\" https:\/\/t.co\/qkwVOyAjrg",
    "id" : 633368612925915142,
    "created_at" : "2015-08-17 20:03:39 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 633383318705180672,
  "created_at" : "2015-08-17 21:02:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "633004335547355136",
  "geo" : { },
  "id_str" : "633019741532090368",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove  they do their worst for commuter train travel, but still I prefer it.",
  "id" : 633019741532090368,
  "in_reply_to_status_id" : 633004335547355136,
  "created_at" : "2015-08-16 20:57:21 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Supawanich",
      "screen_name" : "tweetsupa",
      "indices" : [ 3, 13 ],
      "id_str" : "14904610",
      "id" : 14904610
    }, {
      "name" : "Aarjav Trivedi",
      "screen_name" : "aarjav",
      "indices" : [ 100, 107 ],
      "id_str" : "2631141",
      "id" : 2631141
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tweetsupa\/status\/632951994349568000\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/JbEGT2B01l",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CMiyfAwUsAAXc1E.png",
      "id_str" : "632951993493925888",
      "id" : 632951993493925888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CMiyfAwUsAAXc1E.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 703
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 703
      } ],
      "display_url" : "pic.twitter.com\/JbEGT2B01l"
    } ],
    "hashtags" : [ {
      "text" : "SEA",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633010447248060417",
  "text" : "RT @tweetsupa: A reminder why self-driving, electric, wi-fi enabled cars won't save our cities. (cc @aarjav ) #SEA http:\/\/t.co\/JbEGT2B01l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aarjav Trivedi",
        "screen_name" : "aarjav",
        "indices" : [ 85, 92 ],
        "id_str" : "2631141",
        "id" : 2631141
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tweetsupa\/status\/632951994349568000\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/JbEGT2B01l",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CMiyfAwUsAAXc1E.png",
        "id_str" : "632951993493925888",
        "id" : 632951993493925888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CMiyfAwUsAAXc1E.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 703
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 703
        } ],
        "display_url" : "pic.twitter.com\/JbEGT2B01l"
      } ],
      "hashtags" : [ {
        "text" : "SEA",
        "indices" : [ 95, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632951994349568000",
    "text" : "A reminder why self-driving, electric, wi-fi enabled cars won't save our cities. (cc @aarjav ) #SEA http:\/\/t.co\/JbEGT2B01l",
    "id" : 632951994349568000,
    "created_at" : "2015-08-16 16:28:09 +0000",
    "user" : {
      "name" : "Paul Supawanich",
      "screen_name" : "tweetsupa",
      "protected" : false,
      "id_str" : "14904610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600524683910361088\/WDpftfqz_normal.jpg",
      "id" : 14904610,
      "verified" : false
    }
  },
  "id" : 633010447248060417,
  "created_at" : "2015-08-16 20:20:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/MUBIWspbxG",
      "expanded_url" : "https:\/\/twitter.com\/yoshuawuyts\/status\/632797801441808384",
      "display_url" : "twitter.com\/yoshuawuyts\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633000428582498305",
  "text" : "Don't believe the hype. https:\/\/t.co\/MUBIWspbxG",
  "id" : 633000428582498305,
  "created_at" : "2015-08-16 19:40:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/hIrTpzv2AI",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=h4Nsp0hg6Ug",
      "display_url" : "youtube.com\/watch?v=h4Nsp0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632795407974666240",
  "text" : "i love the melodramatic story in this song  https:\/\/t.co\/hIrTpzv2AI",
  "id" : 632795407974666240,
  "created_at" : "2015-08-16 06:05:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632649097447510016",
  "text" : "What have you done for FREE lately?",
  "id" : 632649097447510016,
  "created_at" : "2015-08-15 20:24:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632376211033882624",
  "text" : "so fucking mad at avconv rn",
  "id" : 632376211033882624,
  "created_at" : "2015-08-15 02:20:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632317447966621696",
  "text" : "It's the happening, you know?",
  "id" : 632317447966621696,
  "created_at" : "2015-08-14 22:26:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632278679112933376",
  "text" : "We are the roots, but the overgrowth is ruining us.",
  "id" : 632278679112933376,
  "created_at" : "2015-08-14 19:52:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631966044458872832",
  "text" : "It is time to burn their delusions.",
  "id" : 631966044458872832,
  "created_at" : "2015-08-13 23:10:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631329835931938816",
  "geo" : { },
  "id_str" : "631376886891810816",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs  Donald Barthelme",
  "id" : 631376886891810816,
  "in_reply_to_status_id" : 631329835931938816,
  "created_at" : "2015-08-12 08:09:14 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "631373276514627585",
  "geo" : { },
  "id_str" : "631374807272022016",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  I mention this because it will come true.",
  "id" : 631374807272022016,
  "in_reply_to_status_id" : 631373276514627585,
  "created_at" : "2015-08-12 08:00:59 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sharingEconomy",
      "indices" : [ 37, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631373276514627585",
  "text" : "AirBnB for Adopting Elderly Persons  #sharingEconomy",
  "id" : 631373276514627585,
  "created_at" : "2015-08-12 07:54:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631367729052692480",
  "text" : "call me a mumbo jumboist, if you must",
  "id" : 631367729052692480,
  "created_at" : "2015-08-12 07:32:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 109, 118 ]
    }, {
      "text" : "BlackLivesMatter",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631172986188402688",
  "text" : "Citizen using their Second amendment to suppress other people's First.  Is supposed to go in that direction? #ferguson #BlackLivesMatter",
  "id" : 631172986188402688,
  "created_at" : "2015-08-11 18:39:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Perdue",
      "screen_name" : "DueOrDie",
      "indices" : [ 3, 12 ],
      "id_str" : "40112850",
      "id" : 40112850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631170604951998464",
  "text" : "RT @DueOrDie: There are really dudes armed w\/ AR's, New Balances &amp; dad jeans patrolling #Ferguson, telling ppl how Trump will fix Americas \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631167780365021184",
    "text" : "There are really dudes armed w\/ AR's, New Balances &amp; dad jeans patrolling #Ferguson, telling ppl how Trump will fix Americas problems...",
    "id" : 631167780365021184,
    "created_at" : "2015-08-11 18:18:20 +0000",
    "user" : {
      "name" : "David Perdue",
      "screen_name" : "DueOrDie",
      "protected" : false,
      "id_str" : "40112850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688610536989306880\/ZO7PXvBo_normal.jpg",
      "id" : 40112850,
      "verified" : false
    }
  },
  "id" : 631170604951998464,
  "created_at" : "2015-08-11 18:29:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/PeHF40DoLC",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=V30Somb7Hv8#t=259",
      "display_url" : "youtube.com\/watch?v=V30Som\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631169500159737856",
  "text" : "watch til the end https:\/\/t.co\/PeHF40DoLC",
  "id" : 631169500159737856,
  "created_at" : "2015-08-11 18:25:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630432964036300800",
  "geo" : { },
  "id_str" : "630434084808863744",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso but",
  "id" : 630434084808863744,
  "in_reply_to_status_id" : 630432964036300800,
  "created_at" : "2015-08-09 17:42:53 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/630432746658140160\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/NhFNzBd40F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL-_PhFUMAEr8Du.png",
      "id_str" : "630432746154766337",
      "id" : 630432746154766337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL-_PhFUMAEr8Du.png",
      "sizes" : [ {
        "h" : 499,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 931,
        "resize" : "fit",
        "w" : 1911
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NhFNzBd40F"
    } ],
    "hashtags" : [ {
      "text" : "debugArt",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630432746658140160",
  "text" : "#debugArt http:\/\/t.co\/NhFNzBd40F",
  "id" : 630432746658140160,
  "created_at" : "2015-08-09 17:37:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "630360035734847488",
  "geo" : { },
  "id_str" : "630430042904899584",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts  yeah how many users you reppin' buddy?",
  "id" : 630430042904899584,
  "in_reply_to_status_id" : 630360035734847488,
  "created_at" : "2015-08-09 17:26:49 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630110547673911296",
  "text" : "MORE UNDERGROUND AND UPCOMING\n\nLESS OVERHEAD AND CRUMBLING DOWN",
  "id" : 630110547673911296,
  "created_at" : "2015-08-08 20:17:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 3, 15 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/WM7DxjoIAD",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2014\/05\/15\/native-american-judge_n_5330273.html",
      "display_url" : "huffingtonpost.com\/2014\/05\/15\/nat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630108850926977025",
  "text" : "RT @vrroanhorse: Quietly history was made this week: 1st American Indian named a federal judge! A bad ass woman! http:\/\/t.co\/WM7DxjoIAD via",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/WM7DxjoIAD",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2014\/05\/15\/native-american-judge_n_5330273.html",
        "display_url" : "huffingtonpost.com\/2014\/05\/15\/nat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "630058346750435328",
    "text" : "Quietly history was made this week: 1st American Indian named a federal judge! A bad ass woman! http:\/\/t.co\/WM7DxjoIAD via",
    "id" : 630058346750435328,
    "created_at" : "2015-08-08 16:49:50 +0000",
    "user" : {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "protected" : false,
      "id_str" : "557228721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652515840194056193\/vt9WrUY__normal.jpg",
      "id" : 557228721,
      "verified" : false
    }
  },
  "id" : 630108850926977025,
  "created_at" : "2015-08-08 20:10:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629868218019020801",
  "geo" : { },
  "id_str" : "629875113601576960",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts  This kind of thing happens all the time to dwellers of the Infinite Library.",
  "id" : 629875113601576960,
  "in_reply_to_status_id" : 629868218019020801,
  "created_at" : "2015-08-08 04:41:44 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/4z0N4Cw1D5",
      "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/the-point-of-no-return-climate-change-nightmares-are-already-here-20150805?page=3",
      "display_url" : "rollingstone.com\/politics\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629871880732737536",
  "text" : "\"As scientists, we can't keep up with it, and neither can the animals.\"\n\nhttp:\/\/t.co\/4z0N4Cw1D5",
  "id" : 629871880732737536,
  "created_at" : "2015-08-08 04:28:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Slater",
      "screen_name" : "nslater",
      "indices" : [ 3, 11 ],
      "id_str" : "1240466215",
      "id" : 1240466215
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 30, 38 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nslater\/status\/629709736477356032\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/1FPGblgx5i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL0tqwjWsAAQZ2x.png",
      "id_str" : "629709735512682496",
      "id" : 629709735512682496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL0tqwjWsAAQZ2x.png",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 1220
      } ],
      "display_url" : "pic.twitter.com\/1FPGblgx5i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629729809044639744",
  "text" : "RT @nslater: fixed it for you @twitter http:\/\/t.co\/1FPGblgx5i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 17, 25 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nslater\/status\/629709736477356032\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/1FPGblgx5i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL0tqwjWsAAQZ2x.png",
        "id_str" : "629709735512682496",
        "id" : 629709735512682496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL0tqwjWsAAQZ2x.png",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 136,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 1220
        } ],
        "display_url" : "pic.twitter.com\/1FPGblgx5i"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629709736477356032",
    "text" : "fixed it for you @twitter http:\/\/t.co\/1FPGblgx5i",
    "id" : 629709736477356032,
    "created_at" : "2015-08-07 17:44:35 +0000",
    "user" : {
      "name" : "Noah Slater",
      "screen_name" : "nslater",
      "protected" : false,
      "id_str" : "1240466215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424991056640233472\/VRvvf5ez_normal.jpeg",
      "id" : 1240466215,
      "verified" : false
    }
  },
  "id" : 629729809044639744,
  "created_at" : "2015-08-07 19:04:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 0, 12 ],
      "id_str" : "557228721",
      "id" : 557228721
    }, {
      "name" : "EPA Region6",
      "screen_name" : "EPAregion6",
      "indices" : [ 13, 24 ],
      "id_str" : "44506183",
      "id" : 44506183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629682639901831169",
  "geo" : { },
  "id_str" : "629722032259796992",
  "in_reply_to_user_id" : 557228721,
  "text" : "@vrroanhorse @EPAregion6  the people who live in Durango are actually the same color as that water, srsly.  I thought it was a mountain tan.",
  "id" : 629722032259796992,
  "in_reply_to_status_id" : 629682639901831169,
  "created_at" : "2015-08-07 18:33:26 +0000",
  "in_reply_to_screen_name" : "vrroanhorse",
  "in_reply_to_user_id_str" : "557228721",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629720810152833024",
  "text" : "Water bills are pretty high in the East Bay, but it all goes to development taxes, not actual usage. It's a property tax renters are paying.",
  "id" : 629720810152833024,
  "created_at" : "2015-08-07 18:28:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629529784247173120",
  "text" : "I started a journal called \"today.md\" and continually append to it.",
  "id" : 629529784247173120,
  "created_at" : "2015-08-07 05:49:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 0, 11 ],
      "id_str" : "15734539",
      "id" : 15734539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629524519443693568",
  "geo" : { },
  "id_str" : "629528787529568256",
  "in_reply_to_user_id" : 15734539,
  "text" : "@FrozenFire  can you imagine the potentials for overclocking???",
  "id" : 629528787529568256,
  "in_reply_to_status_id" : 629524519443693568,
  "created_at" : "2015-08-07 05:45:33 +0000",
  "in_reply_to_screen_name" : "FrozenFire",
  "in_reply_to_user_id_str" : "15734539",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 0, 11 ],
      "id_str" : "15734539",
      "id" : 15734539
    }, {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 12, 19 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629500868900093953",
  "geo" : { },
  "id_str" : "629502865703186432",
  "in_reply_to_user_id" : 15734539,
  "text" : "@FrozenFire @tmpvar  okay which one?",
  "id" : 629502865703186432,
  "in_reply_to_status_id" : 629500868900093953,
  "created_at" : "2015-08-07 04:02:33 +0000",
  "in_reply_to_screen_name" : "FrozenFire",
  "in_reply_to_user_id_str" : "15734539",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 0, 11 ],
      "id_str" : "15734539",
      "id" : 15734539
    }, {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 12, 19 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629498455686311936",
  "geo" : { },
  "id_str" : "629499230894190592",
  "in_reply_to_user_id" : 15734539,
  "text" : "@FrozenFire @tmpvar does it automatically move and lock in on signals, and come with a 3d visualization app for navigation?",
  "id" : 629499230894190592,
  "in_reply_to_status_id" : 629498455686311936,
  "created_at" : "2015-08-07 03:48:06 +0000",
  "in_reply_to_screen_name" : "FrozenFire",
  "in_reply_to_user_id_str" : "15734539",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 0, 11 ],
      "id_str" : "15734539",
      "id" : 15734539
    }, {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 12, 19 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/eIbkUSWQpg",
      "expanded_url" : "http:\/\/www.instructables.com\/id\/Cell-Phone-WiFi-Signal-Booster-Antenna\/",
      "display_url" : "instructables.com\/id\/Cell-Phone-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "629497229204680705",
  "geo" : { },
  "id_str" : "629498077443854336",
  "in_reply_to_user_id" : 15734539,
  "text" : "@FrozenFire @tmpvar http:\/\/t.co\/eIbkUSWQpg",
  "id" : 629498077443854336,
  "in_reply_to_status_id" : 629497229204680705,
  "created_at" : "2015-08-07 03:43:31 +0000",
  "in_reply_to_screen_name" : "FrozenFire",
  "in_reply_to_user_id_str" : "15734539",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629496920847843328",
  "geo" : { },
  "id_str" : "629497536827396096",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  was it not all laid with the help of massive government subsidies?",
  "id" : 629497536827396096,
  "in_reply_to_status_id" : 629496920847843328,
  "created_at" : "2015-08-07 03:41:22 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629492575444017156",
  "geo" : { },
  "id_str" : "629496659068596224",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar as to your challenge: we adopt dolphins and whales to carry an oceanic wireless mesh.  Over land, we take back our infra from corps.",
  "id" : 629496659068596224,
  "in_reply_to_status_id" : 629492575444017156,
  "created_at" : "2015-08-07 03:37:53 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629492575444017156",
  "geo" : { },
  "id_str" : "629494191496671232",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  this is a solution designed for our consumer services world, so communities can give everybody in their area access.",
  "id" : 629494191496671232,
  "in_reply_to_status_id" : 629492575444017156,
  "created_at" : "2015-08-07 03:28:05 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629491406629793792",
  "text" : "A multi-WIFI signal multiplexer. You sign it into yr LAN. Allows many to give a small amount of bandwidth to a larger public mesh.  Shazaam.",
  "id" : 629491406629793792,
  "created_at" : "2015-08-07 03:17:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/tTf96IypJx",
      "expanded_url" : "https:\/\/twitter.com\/marinakukso\/status\/629016642484174848",
      "display_url" : "twitter.com\/marinakukso\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629017540786663424",
  "text" : "next level https:\/\/t.co\/tTf96IypJx",
  "id" : 629017540786663424,
  "created_at" : "2015-08-05 19:54:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/85YNHeYedN",
      "expanded_url" : "http:\/\/www.strombergschickens.com\/prod_detail_list\/Starplate-Dome-Kit",
      "display_url" : "strombergschickens.com\/prod_detail_li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628991662568554496",
  "text" : "this is the cheapest and easiest bucky dome assembly I have found.\n\nhttp:\/\/t.co\/85YNHeYedN",
  "id" : 628991662568554496,
  "created_at" : "2015-08-05 18:11:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthijs Pontier",
      "screen_name" : "Matthijs85",
      "indices" : [ 3, 14 ],
      "id_str" : "47361215",
      "id" : 47361215
    }, {
      "name" : "Ancilla",
      "screen_name" : "ncilla",
      "indices" : [ 93, 100 ],
      "id_str" : "16391453",
      "id" : 16391453
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Matthijs85\/status\/628650986618388480\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2Ts4N4RxWU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlqvZMUMAATVvc.jpg",
      "id_str" : "628650985443831808",
      "id" : 628650985443831808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlqvZMUMAATVvc.jpg",
      "sizes" : [ {
        "h" : 310,
        "resize" : "fit",
        "w" : 367
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 367
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 367
      } ],
      "display_url" : "pic.twitter.com\/2Ts4N4RxWU"
    } ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "airport",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "biometrics",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/GW0qM799Tb",
      "expanded_url" : "http:\/\/www.cnet.com\/news\/feds-admit-storing-checkpoint-body-scan-images\/",
      "display_url" : "cnet.com\/news\/feds-admi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628856864940253184",
  "text" : "RT @Matthijs85: Feds admit storing airport security bodyscan images http:\/\/t.co\/GW0qM799Tb RT@ncilla #privacy #airport #biometrics http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ancilla",
        "screen_name" : "ncilla",
        "indices" : [ 77, 84 ],
        "id_str" : "16391453",
        "id" : 16391453
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Matthijs85\/status\/628650986618388480\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/2Ts4N4RxWU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlqvZMUMAATVvc.jpg",
        "id_str" : "628650985443831808",
        "id" : 628650985443831808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlqvZMUMAATVvc.jpg",
        "sizes" : [ {
          "h" : 310,
          "resize" : "fit",
          "w" : 367
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 367
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 367
        } ],
        "display_url" : "pic.twitter.com\/2Ts4N4RxWU"
      } ],
      "hashtags" : [ {
        "text" : "privacy",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "airport",
        "indices" : [ 94, 102 ]
      }, {
        "text" : "biometrics",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/GW0qM799Tb",
        "expanded_url" : "http:\/\/www.cnet.com\/news\/feds-admit-storing-checkpoint-body-scan-images\/",
        "display_url" : "cnet.com\/news\/feds-admi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628650986618388480",
    "text" : "Feds admit storing airport security bodyscan images http:\/\/t.co\/GW0qM799Tb RT@ncilla #privacy #airport #biometrics http:\/\/t.co\/2Ts4N4RxWU",
    "id" : 628650986618388480,
    "created_at" : "2015-08-04 19:37:29 +0000",
    "user" : {
      "name" : "Matthijs Pontier",
      "screen_name" : "Matthijs85",
      "protected" : false,
      "id_str" : "47361215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695061017399791617\/E8xZCNGr_normal.jpg",
      "id" : 47361215,
      "verified" : false
    }
  },
  "id" : 628856864940253184,
  "created_at" : "2015-08-05 09:15:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628619936512892928",
  "text" : "When I say \"lose control\", I mean lose the people and stuff that control you.",
  "id" : 628619936512892928,
  "created_at" : "2015-08-04 17:34:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/2CdEUvNxAP",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Gtvaes6vSzQ",
      "display_url" : "youtube.com\/watch?v=Gtvaes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628377860378497024",
  "text" : "RT @substack: live streaming for cyber wizard institute vim lecture starting now https:\/\/t.co\/2CdEUvNxAP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/2CdEUvNxAP",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Gtvaes6vSzQ",
        "display_url" : "youtube.com\/watch?v=Gtvaes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628372922508296192",
    "text" : "live streaming for cyber wizard institute vim lecture starting now https:\/\/t.co\/2CdEUvNxAP",
    "id" : 628372922508296192,
    "created_at" : "2015-08-04 01:12:33 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 628377860378497024,
  "created_at" : "2015-08-04 01:32:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628060110435123200",
  "text" : "Observed:  ain't nobody claiming we are in these times on the verge of peace and loveliness.",
  "id" : 628060110435123200,
  "created_at" : "2015-08-03 04:29:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 13, 22 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Forrest L Norvell",
      "screen_name" : "othiym23",
      "indices" : [ 23, 32 ],
      "id_str" : "682433",
      "id" : 682433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627955930492178436",
  "geo" : { },
  "id_str" : "627961266091393028",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @substack @othiym23 today I introduced my student to level-sublevel",
  "id" : 627961266091393028,
  "in_reply_to_status_id" : 627955930492178436,
  "created_at" : "2015-08-02 21:56:47 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627960597930360832",
  "text" : "had a small panic that the text field was gonna redline the inevitable mispelling of a certain word.  Relieved to look up and see vim.",
  "id" : 627960597930360832,
  "created_at" : "2015-08-02 21:54:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/DZgGPDdRsk",
      "expanded_url" : "http:\/\/substack.neocities.org\/polar.html#dmFyIGMgPSBbJ2xpbWUnLCAncGluaycsICdicm93bicsJ09yYW5nZVJlZCddO3ZhciBzPWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ3N2ZyBwYXRoJykuc3R5bGU7cy5zdHJva2U9cy5maWxsPWNbTWF0aC5mbG9vcihEYXRlLm5vdygpLzY2Nyo2JWMubGVuZ3RoKV07cmV0dXJuIE1hdGguc2luKHgqNikrTWF0aC5zaW4oRGF0ZS5ub3coKS80MjAreCoxMipNYXRoLnNpbih4ICogMzYpKQ==",
      "display_url" : "substack.neocities.org\/polar.html#dmF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "627672919162785793",
  "geo" : { },
  "id_str" : "627689791987912704",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack \n\nhttp:\/\/t.co\/DZgGPDdRsk",
  "id" : 627689791987912704,
  "in_reply_to_status_id" : 627672919162785793,
  "created_at" : "2015-08-02 03:58:02 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/KVP23SkQ0W",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/627672919162785793",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627686286195757057",
  "text" : "420 https:\/\/t.co\/KVP23SkQ0W",
  "id" : 627686286195757057,
  "created_at" : "2015-08-02 03:44:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627685562149810176",
  "text" : "Epic rigid-body tug-n-angle-war battle with my lil bear ends in a decisive stalemate, when 1-inch pear tree branch snapped.",
  "id" : 627685562149810176,
  "created_at" : "2015-08-02 03:41:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "civilization",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627534259868184576",
  "text" : "Dear friends, I am adopting tribal technology into my real social life.  #civilization",
  "id" : 627534259868184576,
  "created_at" : "2015-08-01 17:40:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]