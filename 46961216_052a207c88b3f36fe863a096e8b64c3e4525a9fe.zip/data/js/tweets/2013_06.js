Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351393770606043137",
  "text" : "mo money, mo monsters",
  "id" : 351393770606043137,
  "created_at" : "2013-06-30 17:36:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350314233386377216",
  "text" : "feel n good, where n is up to you to define",
  "id" : 350314233386377216,
  "created_at" : "2013-06-27 18:06:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 15, 24 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350004710545174528",
  "geo" : { },
  "id_str" : "350056547965087744",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair go to @sudoroom",
  "id" : 350056547965087744,
  "in_reply_to_status_id" : 350004710545174528,
  "created_at" : "2013-06-27 01:02:39 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/dfUGmhIP43",
      "expanded_url" : "https:\/\/github.com\/NHQ\/nbfs",
      "display_url" : "github.com\/NHQ\/nbfs"
    } ]
  },
  "geo" : { },
  "id_str" : "349993126368251904",
  "text" : "just published a partial clone of Node.j's fs module for the browser File System API. Stream on! https:\/\/t.co\/dfUGmhIP43",
  "id" : 349993126368251904,
  "created_at" : "2013-06-26 20:50:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349121079060611072",
  "text" : "module.experts",
  "id" : 349121079060611072,
  "created_at" : "2013-06-24 11:05:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348485977674743808",
  "text" : "Incite codemonium!",
  "id" : 348485977674743808,
  "created_at" : "2013-06-22 17:01:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348475834094473216",
  "geo" : { },
  "id_str" : "348478180744638464",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden codemonium",
  "id" : 348478180744638464,
  "in_reply_to_status_id" : 348475834094473216,
  "created_at" : "2013-06-22 16:30:47 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opsMonsanto",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/vKGqV9k01u",
      "expanded_url" : "http:\/\/naturalsociety.com\/grassroots-campaign-monsanto-video-revolt-monsanto-july-24th\/",
      "display_url" : "naturalsociety.com\/grassroots-cam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "348477415321894912",
  "text" : "#opsMonsanto http:\/\/t.co\/vKGqV9k01u",
  "id" : 348477415321894912,
  "created_at" : "2013-06-22 16:27:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347597945945862144",
  "geo" : { },
  "id_str" : "347599578180251649",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove kawai gozaimas",
  "id" : 347599578180251649,
  "in_reply_to_status_id" : 347597945945862144,
  "created_at" : "2013-06-20 06:19:32 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "guessTheAcronym",
      "indices" : [ 8, 24 ]
    }, {
      "text" : "GTA",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347086940396482560",
  "text" : "AFAICTU #guessTheAcronym #GTA",
  "id" : 347086940396482560,
  "created_at" : "2013-06-18 20:22:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346545793991323648",
  "text" : "All that's missing is an elephant ride,, and soem kind of fried dough if they are going for truly authentic. Fried dough is old as cooking.",
  "id" : 346545793991323648,
  "created_at" : "2013-06-17 08:32:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346545092435271680",
  "text" : "IN the first 3 eps: a war warning, incessant winter metaphorshadow (of winter), royal incest, tween drama, a droll dwarf, &amp; sexy pagans.",
  "id" : 346545092435271680,
  "created_at" : "2013-06-17 08:29:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346534386734346241",
  "text" : "Unless the display is intentionally fake, meaning the characters and the audience both should know this is not real sex.",
  "id" : 346534386734346241,
  "created_at" : "2013-06-17 07:46:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346533059090325504",
  "text" : "The display of fake sex asks you to choose either to neuter your disbelief completely, or indulge your disbelief in makeup and dragons.",
  "id" : 346533059090325504,
  "created_at" : "2013-06-17 07:41:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346527817883856897",
  "text" : "The breasts, butts bellies and thies are reality based. The gore looks authentic, but is of course no more so than the sex.",
  "id" : 346527817883856897,
  "created_at" : "2013-06-17 07:20:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lol",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346525586178596864",
  "text" : "I started watching a rennfair fantasy medieval soap opera by HBO. Ep.3 ends w\/ actual rennfair wood swords, but metal sword folio. #lol",
  "id" : 346525586178596864,
  "created_at" : "2013-06-17 07:11:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346358218060083200",
  "text" : "The internet is giving rise to people staking their own claim to neologisms. Basically you have a thought and map it to a wordmash.",
  "id" : 346358218060083200,
  "created_at" : "2013-06-16 20:06:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Latour Swag",
      "screen_name" : "LatourSwag",
      "indices" : [ 0, 11 ],
      "id_str" : "1081686444",
      "id" : 1081686444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swaghurt",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "swag",
      "indices" : [ 41, 46 ]
    }, {
      "text" : "swagabond",
      "indices" : [ 47, 57 ]
    }, {
      "text" : "swagman",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346356213388283904",
  "geo" : { },
  "id_str" : "346356889333936129",
  "in_reply_to_user_id" : 1081686444,
  "text" : "@LatourSwag and that's so true #swaghurt #swag #swagabond #swagman",
  "id" : 346356889333936129,
  "in_reply_to_status_id" : 346356213388283904,
  "created_at" : "2013-06-16 20:01:32 +0000",
  "in_reply_to_screen_name" : "LatourSwag",
  "in_reply_to_user_id_str" : "1081686444",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345410024488722432",
  "text" : "When are we going to talk about money?",
  "id" : 345410024488722432,
  "created_at" : "2013-06-14 05:19:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/hJ5Ukmhocv",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/5778704",
      "display_url" : "gist.github.com\/NHQ\/5778704"
    }, {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/SIJ70mYOlN",
      "expanded_url" : "http:\/\/jsfiddle.net\/hdRQK\/",
      "display_url" : "jsfiddle.net\/hdRQK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "345352032783310848",
  "text" : "web audio scriptProcessor node, basically https:\/\/t.co\/hJ5Ukmhocv, see also http:\/\/t.co\/SIJ70mYOlN",
  "id" : 345352032783310848,
  "created_at" : "2013-06-14 01:28:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343872283728834561",
  "text" : "You can reveal the employees at tech companies who cannot speak of their contact with secret agents with this one silly little algorithm.",
  "id" : 343872283728834561,
  "created_at" : "2013-06-09 23:28:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/T56UNz2gd1",
      "expanded_url" : "http:\/\/www.google.com\/imgres?imgurl=http:\/\/preview.turbosquid.com\/Preview\/2011\/01\/02__12_33_36\/Wooden_Cable_Reel_4.jpg9c69a6fe-93dc-45a1-a314-93b39d965916Large.jpg&imgrefurl=http:\/\/www.turbosquid.com\/3d-models\/3dsmax-wooden-cable-reel\/578044&h=600&w=600&sz=83&tbnid=8cDiuVWg6wus0M:&tbnh=90&tbnw=90&zoom=1&usg=__Xxyn8GjYGWa65zHGSUTG3Wua3do=&docid=T0Lu3GqJf2O1dM&sa=X&ei=o-y0UZvPJKWUiQLphYAw&ved=0CEwQ9QEwAA&dur=1191",
      "display_url" : "google.com\/imgres?imgurl=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343834799120740352",
  "text" : "where can I buy one or two wooden cable reels? This kinda thing http:\/\/t.co\/T56UNz2gd1",
  "id" : 343834799120740352,
  "created_at" : "2013-06-09 20:59:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343810786180874240",
  "text" : "RT @IAM_SHAKESPEARE: Of dark forgetfulness and deep oblivion.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343809727769231361",
    "text" : "Of dark forgetfulness and deep oblivion.",
    "id" : 343809727769231361,
    "created_at" : "2013-06-09 19:20:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 343810786180874240,
  "created_at" : "2013-06-09 19:24:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noJokes",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/BMjtxIwFWK",
      "expanded_url" : "https:\/\/www.commondreams.org\/view\/2013\/05\/15-7",
      "display_url" : "commondreams.org\/view\/2013\/05\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343805801489637377",
  "text" : "Three elder pacifist walk into a federal court, three terrorist walk out (in chains) https:\/\/t.co\/BMjtxIwFWK #noJokes",
  "id" : 343805801489637377,
  "created_at" : "2013-06-09 19:04:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason \u0311\u0308",
      "screen_name" : "XaiaX",
      "indices" : [ 0, 6 ],
      "id_str" : "16076115",
      "id" : 16076115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342676092823429121",
  "geo" : { },
  "id_str" : "342676735281725440",
  "in_reply_to_user_id" : 16076115,
  "text" : "@XaiaX is that guy carrying a super soaker?",
  "id" : 342676735281725440,
  "in_reply_to_status_id" : 342676092823429121,
  "created_at" : "2013-06-06 16:17:54 +0000",
  "in_reply_to_screen_name" : "XaiaX",
  "in_reply_to_user_id_str" : "16076115",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pikachu",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342675160257671168",
  "text" : "It's sad that Bradley Manning's defense has to be all \"he was just young, idealistic, and naive #pikachu\" to keep out the klink for life.",
  "id" : 342675160257671168,
  "created_at" : "2013-06-06 16:11:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 0, 9 ],
      "id_str" : "83876527",
      "id" : 83876527
    }, {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 10, 21 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342393454065774592",
  "geo" : { },
  "id_str" : "342402914381348864",
  "in_reply_to_user_id" : 83876527,
  "text" : "@tejucole @zunguzungu he's no hipster runoff!",
  "id" : 342402914381348864,
  "in_reply_to_status_id" : 342393454065774592,
  "created_at" : "2013-06-05 22:09:50 +0000",
  "in_reply_to_screen_name" : "tejucole",
  "in_reply_to_user_id_str" : "83876527",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/astromanies\/status\/342393933818638336\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/0vU6MejgIZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMBtd_7CMAEdTsd.png",
      "id_str" : "342393933822832641",
      "id" : 342393933822832641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMBtd_7CMAEdTsd.png",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 251
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 251
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 251
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 251
      } ],
      "display_url" : "pic.twitter.com\/0vU6MejgIZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342393933818638336",
  "text" : "q.v. http:\/\/t.co\/0vU6MejgIZ",
  "id" : 342393933818638336,
  "created_at" : "2013-06-05 21:34:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342393518569951233",
  "text" : "thank you mad nyan catter",
  "id" : 342393518569951233,
  "created_at" : "2013-06-05 21:32:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342393289045065729",
  "text" : "right now there are approximately 13-14 bots following me &amp; clicking my links according to google's doc's anonymous animal analytics",
  "id" : 342393289045065729,
  "created_at" : "2013-06-05 21:31:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342392856285179904",
  "text" : "If anybody who is not a bot is clicking these links and reading, pls tell me so cuz I am curious how many of you are notbots",
  "id" : 342392856285179904,
  "created_at" : "2013-06-05 21:29:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/so7rwWozc4",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/144YV7HolDC5m4JvZJec4sHxO60I8tRiF48LlPvIigko\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/144\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342392567645749248",
  "text" : "PAIN PATCH PRODUCT is a stupid screenplay I wrote for real commercial that never became  https:\/\/t.co\/so7rwWozc4",
  "id" : 342392567645749248,
  "created_at" : "2013-06-05 21:28:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Y8ZHm9uG6a",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1Gsiy4Yym-83_bXDL9wdi2xAiDBaW81QiWjq4iEL3MRE\/edit",
      "display_url" : "docs.google.com\/document\/d\/1Gs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342389296529043457",
  "text" : "\"The Blob\" is a silly short story about the singularity. https:\/\/t.co\/Y8ZHm9uG6a",
  "id" : 342389296529043457,
  "created_at" : "2013-06-05 21:15:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342385403023728640",
  "text" : "A speculation checker. Alerts of increasing futures speculation. Consumers organize to drop demand on time, causing loss to speculators.",
  "id" : 342385403023728640,
  "created_at" : "2013-06-05 21:00:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342383778276192257",
  "text" : "Fun watching animals read.",
  "id" : 342383778276192257,
  "created_at" : "2013-06-05 20:53:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edit",
      "indices" : [ 136, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342383596750913538",
  "text" : "\"If the same logic was applied to movies, books, &amp; music, some company would own the patents to suspense, to thrill, to crescendo.\" #edit",
  "id" : 342383596750913538,
  "created_at" : "2013-06-05 20:53:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 5, 12 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342380977445826560",
  "geo" : { },
  "id_str" : "342381673595416576",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs @mikeal damn son not even a proper error",
  "id" : 342381673595416576,
  "in_reply_to_status_id" : 342380977445826560,
  "created_at" : "2013-06-05 20:45:26 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342380765692178432",
  "text" : "they are gone now",
  "id" : 342380765692178432,
  "created_at" : "2013-06-05 20:41:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/astromanies\/status\/342380674109558784\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/9ZMNWmZxQk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMBhaLrCUAAYWXh.png",
      "id_str" : "342380674117947392",
      "id" : 342380674117947392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMBhaLrCUAAYWXh.png",
      "sizes" : [ {
        "h" : 141,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 1263
      } ],
      "display_url" : "pic.twitter.com\/9ZMNWmZxQk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342380674109558784",
  "text" : "cool 14 anonymous animals clicks that last link http:\/\/t.co\/9ZMNWmZxQk",
  "id" : 342380674109558784,
  "created_at" : "2013-06-05 20:41:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pQDsuFUAPf",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1irlES_K8F-PhmNPtY0v5Wij6R4g82lpPlq_cZ8xvo5M\/edit?usp=sharing&authkey=CJmsyKQM",
      "display_url" : "docs.google.com\/document\/d\/1ir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342379709084102656",
  "text" : "I wrote an essay a while back \"Software Patents for Politicians\". tl;dr software is a medium, ergo not patentable.  https:\/\/t.co\/pQDsuFUAPf",
  "id" : 342379709084102656,
  "created_at" : "2013-06-05 20:37:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342372676427476992",
  "text" : "'forward looking' is a PR statement that is a lie, and 'looking forward' an expressions of anticipation that is inadequate.",
  "id" : 342372676427476992,
  "created_at" : "2013-06-05 20:09:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/U6JyXsCHTJ",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/06\/02\/opinion\/sunday\/the-banality-of-googles-dont-be-evil.html?_r=0",
      "display_url" : "nytimes.com\/2013\/06\/02\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341675451250511873",
  "text" : "Julian Assange vs Googleschmidt et al  http:\/\/t.co\/U6JyXsCHTJ",
  "id" : 341675451250511873,
  "created_at" : "2013-06-03 21:59:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340902986190565376",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack achievement unlocked : nothing to lose",
  "id" : 340902986190565376,
  "created_at" : "2013-06-01 18:49:40 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]