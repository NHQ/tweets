Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rhodey orbits",
      "screen_name" : "NotRhodey",
      "indices" : [ 0, 10 ],
      "id_str" : "1131293652",
      "id" : 1131293652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649421540065280000",
  "geo" : { },
  "id_str" : "649447854398771200",
  "in_reply_to_user_id" : 1131293652,
  "text" : "@NotRhodey  don't lie, you put 500 hours into java",
  "id" : 649447854398771200,
  "in_reply_to_status_id" : 649421540065280000,
  "created_at" : "2015-10-01 04:56:49 +0000",
  "in_reply_to_screen_name" : "NotRhodey",
  "in_reply_to_user_id_str" : "1131293652",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649401756112289792",
  "geo" : { },
  "id_str" : "649409861596266496",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair there is only one bug",
  "id" : 649409861596266496,
  "in_reply_to_status_id" : 649401756112289792,
  "created_at" : "2015-10-01 02:25:51 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649399687141720064",
  "geo" : { },
  "id_str" : "649400640922238976",
  "in_reply_to_user_id" : 46961216,
  "text" : "never maintained, \nrestarts perfectly.  \nwhen you encounter a bug,\nsimply restart perfectly.",
  "id" : 649400640922238976,
  "in_reply_to_status_id" : 649399687141720064,
  "created_at" : "2015-10-01 01:49:12 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649335129530241025",
  "text" : "what is this emotion you call... identity?",
  "id" : 649335129530241025,
  "created_at" : "2015-09-30 21:28:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648932560169361409",
  "text" : "im surrounded by half asses",
  "id" : 648932560169361409,
  "created_at" : "2015-09-29 18:49:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "350 dot org",
      "screen_name" : "350",
      "indices" : [ 3, 7 ],
      "id_str" : "14266598",
      "id" : 14266598
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/350\/status\/648842763287560192\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/bH8KPGr7r3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQEnDizWwAQiOJb.jpg",
      "id_str" : "648842763153358852",
      "id" : 648842763153358852,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQEnDizWwAQiOJb.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/bH8KPGr7r3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/CfVj26wCFV",
      "expanded_url" : "http:\/\/bit.ly\/1VkP1R1",
      "display_url" : "bit.ly\/1VkP1R1"
    } ]
  },
  "geo" : { },
  "id_str" : "648925064881004544",
  "text" : "RT @350: Paris went car-free this weekend and it was \u201Clike a headache lifting\u201D http:\/\/t.co\/CfVj26wCFV http:\/\/t.co\/bH8KPGr7r3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/350\/status\/648842763287560192\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/bH8KPGr7r3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQEnDizWwAQiOJb.jpg",
        "id_str" : "648842763153358852",
        "id" : 648842763153358852,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQEnDizWwAQiOJb.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/bH8KPGr7r3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/CfVj26wCFV",
        "expanded_url" : "http:\/\/bit.ly\/1VkP1R1",
        "display_url" : "bit.ly\/1VkP1R1"
      } ]
    },
    "geo" : { },
    "id_str" : "648842763287560192",
    "text" : "Paris went car-free this weekend and it was \u201Clike a headache lifting\u201D http:\/\/t.co\/CfVj26wCFV http:\/\/t.co\/bH8KPGr7r3",
    "id" : 648842763287560192,
    "created_at" : "2015-09-29 12:52:24 +0000",
    "user" : {
      "name" : "350 dot org",
      "screen_name" : "350",
      "protected" : false,
      "id_str" : "14266598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514780508392148993\/dpNt8McB_normal.jpeg",
      "id" : 14266598,
      "verified" : true
    }
  },
  "id" : 648925064881004544,
  "created_at" : "2015-09-29 18:19:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/5v4blP5q3o",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wWSAI9d3Vxk",
      "display_url" : "youtube.com\/watch?v=wWSAI9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648923332222435328",
  "text" : "RT @marinakukso: @johnnyscript https:\/\/t.co\/5v4blP5q3o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/5v4blP5q3o",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wWSAI9d3Vxk",
        "display_url" : "youtube.com\/watch?v=wWSAI9\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "648922300406870016",
    "geo" : { },
    "id_str" : "648922887403913216",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript https:\/\/t.co\/5v4blP5q3o",
    "id" : 648922887403913216,
    "in_reply_to_status_id" : 648922300406870016,
    "created_at" : "2015-09-29 18:10:47 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 648923332222435328,
  "created_at" : "2015-09-29 18:12:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648922300406870016",
  "text" : "google search would not autocomplete the word marijuana \n\nthe some Nixonian shit",
  "id" : 648922300406870016,
  "created_at" : "2015-09-29 18:08:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/4nAX6G7YDN",
      "expanded_url" : "https:\/\/chrome.google.com\/webstore\/detail\/doodremove\/mkjkajgmalenojgeaknkdbenpmlgnhjn\/related?hl=en",
      "display_url" : "chrome.google.com\/webstore\/detai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648603849381404672",
  "text" : "This removes the google logo and their doodley, branded, cultural appropriations from your chrome start page \n\n https:\/\/t.co\/4nAX6G7YDN",
  "id" : 648603849381404672,
  "created_at" : "2015-09-28 21:03:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647965378925064192",
  "text" : "there is a diff gulf between what ppl do and who ppl are\nsome ppl define ppl by what they do\nsome ppl define ppl by who they are\noopsy poops",
  "id" : 647965378925064192,
  "created_at" : "2015-09-27 02:45:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647955533966610436",
  "text" : "take me out tonight",
  "id" : 647955533966610436,
  "created_at" : "2015-09-27 02:06:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647954488758632448",
  "text" : "chill &amp;&amp;",
  "id" : 647954488758632448,
  "created_at" : "2015-09-27 02:02:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647847197011083265",
  "text" : "regress and sanity \ncheck check\nregress regress \nand sanity check",
  "id" : 647847197011083265,
  "created_at" : "2015-09-26 18:56:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647837898461442048",
  "text" : "imma hit la strada wit dada",
  "id" : 647837898461442048,
  "created_at" : "2015-09-26 18:19:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647564759185756160",
  "text" : "A rare synecdoche!",
  "id" : 647564759185756160,
  "created_at" : "2015-09-26 00:14:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647517548120961024",
  "text" : "Pitbull Chariots as an Oakland Based Alternative to Uber.",
  "id" : 647517548120961024,
  "created_at" : "2015-09-25 21:06:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647114220144754688",
  "text" : "I did the write thing this morning.",
  "id" : 647114220144754688,
  "created_at" : "2015-09-24 18:23:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omni Commons",
      "screen_name" : "omnicommons",
      "indices" : [ 3, 15 ],
      "id_str" : "2476635312",
      "id" : 2476635312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 128, 144 ],
      "url" : "https:\/\/t.co\/0j7hLMZrde",
      "expanded_url" : "https:\/\/omnicommons.org\/rentparty",
      "display_url" : "omnicommons.org\/rentparty"
    } ]
  },
  "geo" : { },
  "id_str" : "646829148783030272",
  "text" : "RT @omnicommons: Rent Party: Part Two! 9\/27 (Sun 10am - 10pm) Rummage &amp; Bake Sale, Lunch \/ Dinner, Live Music, Movie Night! https:\/\/t.co\/0j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/0j7hLMZrde",
        "expanded_url" : "https:\/\/omnicommons.org\/rentparty",
        "display_url" : "omnicommons.org\/rentparty"
      } ]
    },
    "geo" : { },
    "id_str" : "646064844869779456",
    "text" : "Rent Party: Part Two! 9\/27 (Sun 10am - 10pm) Rummage &amp; Bake Sale, Lunch \/ Dinner, Live Music, Movie Night! https:\/\/t.co\/0j7hLMZrde",
    "id" : 646064844869779456,
    "created_at" : "2015-09-21 20:53:56 +0000",
    "user" : {
      "name" : "Omni Commons",
      "screen_name" : "omnicommons",
      "protected" : false,
      "id_str" : "2476635312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511714409220014081\/S94wtVoI_normal.jpeg",
      "id" : 2476635312,
      "verified" : false
    }
  },
  "id" : 646829148783030272,
  "created_at" : "2015-09-23 23:31:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/1tGxEiIJb7",
      "expanded_url" : "http:\/\/valleywag.gawker.com\/uber-is-now-sponsoring-a-police-militarization-conferen-1631115661",
      "display_url" : "valleywag.gawker.com\/uber-is-now-sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646826988510904320",
  "text" : "RT @substack: to prempt illusions that uber is going to be a good responsible oakland neighbor, remember urban shield last year http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/1tGxEiIJb7",
        "expanded_url" : "http:\/\/valleywag.gawker.com\/uber-is-now-sponsoring-a-police-militarization-conferen-1631115661",
        "display_url" : "valleywag.gawker.com\/uber-is-now-sp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "646585412379475969",
    "text" : "to prempt illusions that uber is going to be a good responsible oakland neighbor, remember urban shield last year http:\/\/t.co\/1tGxEiIJb7",
    "id" : 646585412379475969,
    "created_at" : "2015-09-23 07:22:29 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 646826988510904320,
  "created_at" : "2015-09-23 23:22:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646159471027159040",
  "text" : "if there is one thing I love \nit's all of me",
  "id" : 646159471027159040,
  "created_at" : "2015-09-22 03:09:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646069931189006336",
  "geo" : { },
  "id_str" : "646070377492287488",
  "in_reply_to_user_id" : 46961216,
  "text" : "when yr unemployed",
  "id" : 646070377492287488,
  "in_reply_to_status_id" : 646069931189006336,
  "created_at" : "2015-09-21 21:15:56 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/vBWKauBUnW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1YrEXlpnQBk",
      "display_url" : "youtube.com\/watch?v=1YrEXl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646069931189006336",
  "text" : "every day is sunday\n\nhttps:\/\/t.co\/vBWKauBUnW",
  "id" : 646069931189006336,
  "created_at" : "2015-09-21 21:14:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 13, 22 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 23, 35 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Scott Edmonds",
      "screen_name" : "scottedmonds",
      "indices" : [ 36, 49 ],
      "id_str" : "16482669",
      "id" : 16482669
    }, {
      "name" : "Shani Aviram",
      "screen_name" : "sunshine_av",
      "indices" : [ 50, 62 ],
      "id_str" : "89637495",
      "id" : 89637495
    }, {
      "name" : "harperbole",
      "screen_name" : "_harperbole",
      "indices" : [ 63, 75 ],
      "id_str" : "26007295",
      "id" : 26007295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645088594864947201",
  "geo" : { },
  "id_str" : "645686106319486976",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso @substack @dominictarr @scottedmonds @sunshine_av @_harperbole  I hated this song and that group",
  "id" : 645686106319486976,
  "in_reply_to_status_id" : 645088594864947201,
  "created_at" : "2015-09-20 19:48:58 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Bw6lB87dxe",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/rats-theorymix",
      "display_url" : "soundcloud.com\/folkstack\/rats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645084192481546240",
  "text" : "what would ratatats think of my excessive deejay algo minimal ruh ruh remix?\n\nhttps:\/\/t.co\/Bw6lB87dxe",
  "id" : 645084192481546240,
  "created_at" : "2015-09-19 03:57:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/2UsWEN9huc",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/645064450366550016",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645082148743962624",
  "text" : "solidarity  https:\/\/t.co\/2UsWEN9huc",
  "id" : 645082148743962624,
  "created_at" : "2015-09-19 03:49:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645080332610310144",
  "text" : "Sometimes science is more art than science.  Amen.",
  "id" : 645080332610310144,
  "created_at" : "2015-09-19 03:41:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644685262342123520",
  "text" : "I can't wait to start my own decentralized network instafeed interface.  i dub it Nutter.",
  "id" : 644685262342123520,
  "created_at" : "2015-09-18 01:31:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644684918774067200",
  "text" : "that's the plan, in a nutshell",
  "id" : 644684918774067200,
  "created_at" : "2015-09-18 01:30:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644684853175173120",
  "text" : "turn your local government against your state and federal ones",
  "id" : 644684853175173120,
  "created_at" : "2015-09-18 01:30:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644684597674971137",
  "text" : "wrap up your local life first",
  "id" : 644684597674971137,
  "created_at" : "2015-09-18 01:29:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644684508466274305",
  "text" : "i dont care who president is",
  "id" : 644684508466274305,
  "created_at" : "2015-09-18 01:28:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644684381022392320",
  "text" : "to any intelligence, the current alcohol laws are about as bad as prohibition",
  "id" : 644684381022392320,
  "created_at" : "2015-09-18 01:28:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644598469961756672",
  "text" : "sneezes are the orgasm of another plexus",
  "id" : 644598469961756672,
  "created_at" : "2015-09-17 19:47:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644397896540909568",
  "text" : "brainwashing is a good thing.  wash your brains often.",
  "id" : 644397896540909568,
  "created_at" : "2015-09-17 06:30:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644253596872142848",
  "text" : "capitalism is gross",
  "id" : 644253596872142848,
  "created_at" : "2015-09-16 20:56:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644253456916570112",
  "text" : "fire away",
  "id" : 644253456916570112,
  "created_at" : "2015-09-16 20:56:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644253333444628480",
  "text" : "my musings weigh a ton",
  "id" : 644253333444628480,
  "created_at" : "2015-09-16 20:55:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644253268688830464",
  "text" : "I'm free to begin monetizing my invested genius, cuz I've been giving mine away gratis.",
  "id" : 644253268688830464,
  "created_at" : "2015-09-16 20:55:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644251798652325888",
  "text" : "How do you spend your genius?",
  "id" : 644251798652325888,
  "created_at" : "2015-09-16 20:49:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644251723523997696",
  "text" : "I've kept my genius from the system most my life, tho I had to start selling my body at a young age.",
  "id" : 644251723523997696,
  "created_at" : "2015-09-16 20:49:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644250601744797696",
  "text" : "Build local systems for free, and doubly take away from the System.  When the balance is more shifted, monetize against thy weaknd enemy.",
  "id" : 644250601744797696,
  "created_at" : "2015-09-16 20:44:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644249395274190848",
  "text" : "Be the free food.",
  "id" : 644249395274190848,
  "created_at" : "2015-09-16 20:40:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644249314210877440",
  "text" : "non monetary power exists, there is a ton of it it in giving away thy labor libre gratis to the people directly around you.",
  "id" : 644249314210877440,
  "created_at" : "2015-09-16 20:39:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644248214783131648",
  "text" : "money is the drug",
  "id" : 644248214783131648,
  "created_at" : "2015-09-16 20:35:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644248196361785344",
  "text" : "You don't know power until you drop out of the system, when you begin playing the same game as the capitalist, but without that money.",
  "id" : 644248196361785344,
  "created_at" : "2015-09-16 20:35:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643925859611471872",
  "text" : "u gotta let go to be u",
  "id" : 643925859611471872,
  "created_at" : "2015-09-15 23:14:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "indices" : [ 3, 13 ],
      "id_str" : "224828427",
      "id" : 224828427
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 35, 48 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/wJKAiyhb1T",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/rats-theorymix",
      "display_url" : "soundcloud.com\/folkstack\/rats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643879759785492480",
  "text" : "RT @folkstack: algo remix coded by @johnnyscript \n\nhttps:\/\/t.co\/wJKAiyhb1T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 20, 33 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/wJKAiyhb1T",
        "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/rats-theorymix",
        "display_url" : "soundcloud.com\/folkstack\/rats\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643875563699048448",
    "text" : "algo remix coded by @johnnyscript \n\nhttps:\/\/t.co\/wJKAiyhb1T",
    "id" : 643875563699048448,
    "created_at" : "2015-09-15 19:54:31 +0000",
    "user" : {
      "name" : "FOLKSTACK",
      "screen_name" : "folkstack",
      "protected" : false,
      "id_str" : "224828427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618081193754361856\/gKoaUGWw_normal.png",
      "id" : 224828427,
      "verified" : false
    }
  },
  "id" : 643879759785492480,
  "created_at" : "2015-09-15 20:11:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StonewallJacksonsArm",
      "screen_name" : "oldtomfool",
      "indices" : [ 3, 14 ],
      "id_str" : "3003790936",
      "id" : 3003790936
    }, {
      "name" : "Vanderbilt Libraries",
      "screen_name" : "VandyLibraries",
      "indices" : [ 109, 124 ],
      "id_str" : "107126428",
      "id" : 107126428
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/oldtomfool\/status\/643212817672351744\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/z1uE46pgOr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO0mo-aUsAAk4d1.jpg",
      "id_str" : "643212807173877760",
      "id" : 643212807173877760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO0mo-aUsAAk4d1.jpg",
      "sizes" : [ {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 873
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 873
      } ],
      "display_url" : "pic.twitter.com\/z1uE46pgOr"
    } ],
    "hashtags" : [ {
      "text" : "AnchorDown",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643854263169458176",
  "text" : "RT @oldtomfool: For my professor &amp; librarian friends: check out the epic sign on ESPN's College GameDay. @VandyLibraries #AnchorDown http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vanderbilt Libraries",
        "screen_name" : "VandyLibraries",
        "indices" : [ 93, 108 ],
        "id_str" : "107126428",
        "id" : 107126428
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/oldtomfool\/status\/643212817672351744\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/z1uE46pgOr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CO0mo-aUsAAk4d1.jpg",
        "id_str" : "643212807173877760",
        "id" : 643212807173877760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO0mo-aUsAAk4d1.jpg",
        "sizes" : [ {
          "h" : 195,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 873
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 873
        } ],
        "display_url" : "pic.twitter.com\/z1uE46pgOr"
      } ],
      "hashtags" : [ {
        "text" : "AnchorDown",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643212817672351744",
    "text" : "For my professor &amp; librarian friends: check out the epic sign on ESPN's College GameDay. @VandyLibraries #AnchorDown http:\/\/t.co\/z1uE46pgOr",
    "id" : 643212817672351744,
    "created_at" : "2015-09-14 00:01:00 +0000",
    "user" : {
      "name" : "StonewallJacksonsArm",
      "screen_name" : "oldtomfool",
      "protected" : false,
      "id_str" : "3003790936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645777203733626880\/ES33jMlq_normal.jpg",
      "id" : 3003790936,
      "verified" : false
    }
  },
  "id" : 643854263169458176,
  "created_at" : "2015-09-15 18:29:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643472480691073024",
  "geo" : { },
  "id_str" : "643477687651033088",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso   we need more prisoners!",
  "id" : 643477687651033088,
  "in_reply_to_status_id" : 643472480691073024,
  "created_at" : "2015-09-14 17:33:30 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643279734932004864",
  "text" : "wish this adblock effected google doodles",
  "id" : 643279734932004864,
  "created_at" : "2015-09-14 04:26:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643220032533590016",
  "text" : "If you follow me you're in twitter's half-blind and retarded demographics.",
  "id" : 643220032533590016,
  "created_at" : "2015-09-14 00:29:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643199805326422016",
  "text" : "I got called a hot mom today for admonishing usafe biking.",
  "id" : 643199805326422016,
  "created_at" : "2015-09-13 23:09:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642019265759965184",
  "text" : "In terms of popularity, bitcoin is yet only where the internet was c. 1996.  Majority of people know nothing about it.",
  "id" : 642019265759965184,
  "created_at" : "2015-09-10 16:58:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642004802147237888",
  "text" : "remember the plan",
  "id" : 642004802147237888,
  "created_at" : "2015-09-10 16:00:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ypNbuSBc6f",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Labor_Day#Retail_Sale_Day",
      "display_url" : "en.wikipedia.org\/wiki\/Labor_Day\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640963447132258304",
  "text" : "RT @substack: Happy North American Retail Sale Day. This is what an apolitical labor movement looks like: https:\/\/t.co\/ypNbuSBc6f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/ypNbuSBc6f",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Labor_Day#Retail_Sale_Day",
        "display_url" : "en.wikipedia.org\/wiki\/Labor_Day\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "640894361476042752",
    "text" : "Happy North American Retail Sale Day. This is what an apolitical labor movement looks like: https:\/\/t.co\/ypNbuSBc6f",
    "id" : 640894361476042752,
    "created_at" : "2015-09-07 14:28:17 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 640963447132258304,
  "created_at" : "2015-09-07 19:02:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FUSICOLOGY",
      "screen_name" : "fusicology",
      "indices" : [ 3, 14 ],
      "id_str" : "13578632",
      "id" : 13578632
    }, {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 39, 47 ],
      "id_str" : "19417999",
      "id" : 19417999
    }, {
      "name" : "The Independent",
      "screen_name" : "indysf",
      "indices" : [ 54, 61 ],
      "id_str" : "74572689",
      "id" : 74572689
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/fusicology\/status\/640610542512680960\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/CUG9J0hL9Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COPn5OeWwAAd_d8.jpg",
      "id_str" : "640610542340718592",
      "id" : 640610542340718592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COPn5OeWwAAd_d8.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/CUG9J0hL9Y"
    } ],
    "hashtags" : [ {
      "text" : "Tonight",
      "indices" : [ 16, 24 ]
    }, {
      "text" : "SanFrancisco",
      "indices" : [ 25, 38 ]
    }, {
      "text" : "LIVE",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "DamFunk",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "TheIndependent",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/d28JnO9Cn2",
      "expanded_url" : "http:\/\/fuse.ms\/1KiJHIz",
      "display_url" : "fuse.ms\/1KiJHIz"
    } ]
  },
  "geo" : { },
  "id_str" : "640631017380823040",
  "text" : "RT @fusicology: #Tonight #SanFrancisco @DaMFunK #LIVE @indysf http:\/\/t.co\/d28JnO9Cn2 #DamFunk #TheIndependent http:\/\/t.co\/CUG9J0hL9Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
        "screen_name" : "DaMFunK",
        "indices" : [ 23, 31 ],
        "id_str" : "19417999",
        "id" : 19417999
      }, {
        "name" : "The Independent",
        "screen_name" : "indysf",
        "indices" : [ 38, 45 ],
        "id_str" : "74572689",
        "id" : 74572689
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/fusicology\/status\/640610542512680960\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/CUG9J0hL9Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COPn5OeWwAAd_d8.jpg",
        "id_str" : "640610542340718592",
        "id" : 640610542340718592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COPn5OeWwAAd_d8.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/CUG9J0hL9Y"
      } ],
      "hashtags" : [ {
        "text" : "Tonight",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "SanFrancisco",
        "indices" : [ 9, 22 ]
      }, {
        "text" : "LIVE",
        "indices" : [ 32, 37 ]
      }, {
        "text" : "DamFunk",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "TheIndependent",
        "indices" : [ 78, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/d28JnO9Cn2",
        "expanded_url" : "http:\/\/fuse.ms\/1KiJHIz",
        "display_url" : "fuse.ms\/1KiJHIz"
      } ]
    },
    "geo" : { },
    "id_str" : "640610542512680960",
    "text" : "#Tonight #SanFrancisco @DaMFunK #LIVE @indysf http:\/\/t.co\/d28JnO9Cn2 #DamFunk #TheIndependent http:\/\/t.co\/CUG9J0hL9Y",
    "id" : 640610542512680960,
    "created_at" : "2015-09-06 19:40:29 +0000",
    "user" : {
      "name" : "FUSICOLOGY",
      "screen_name" : "fusicology",
      "protected" : false,
      "id_str" : "13578632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551330905294270464\/Q9u8ApwX_normal.jpeg",
      "id" : 13578632,
      "verified" : false
    }
  },
  "id" : 640631017380823040,
  "created_at" : "2015-09-06 21:01:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew McAfee",
      "screen_name" : "amcafee",
      "indices" : [ 0, 8 ],
      "id_str" : "15008449",
      "id" : 15008449
    }, {
      "name" : "Financial Times",
      "screen_name" : "FT",
      "indices" : [ 9, 12 ],
      "id_str" : "18949452",
      "id" : 18949452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640525154506928129",
  "geo" : { },
  "id_str" : "640583696030941185",
  "in_reply_to_user_id" : 15008449,
  "text" : "@amcafee @FT The rich have way more privileges the poor will never see.  \"Varian Rule\" sounds like trickle down by another promise.",
  "id" : 640583696030941185,
  "in_reply_to_status_id" : 640525154506928129,
  "created_at" : "2015-09-06 17:53:49 +0000",
  "in_reply_to_screen_name" : "amcafee",
  "in_reply_to_user_id_str" : "15008449",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640350424055181312",
  "geo" : { },
  "id_str" : "640393631640109057",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon what am I watching, I don't know",
  "id" : 640393631640109057,
  "in_reply_to_status_id" : 640350424055181312,
  "created_at" : "2015-09-06 05:18:34 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640392196743495680",
  "text" : "the gmail chat frowny faceblob means \"I don't have any beer\"",
  "id" : 640392196743495680,
  "created_at" : "2015-09-06 05:12:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640383052191936512",
  "text" : "Do not trust inferior technology.",
  "id" : 640383052191936512,
  "created_at" : "2015-09-06 04:36:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/YEMMGov8PB",
      "expanded_url" : "http:\/\/www.thisiscolossal.com\/2015\/08\/stepwell-architecture\/",
      "display_url" : "thisiscolossal.com\/2015\/08\/stepwe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640293821641682944",
  "text" : "amazing  http:\/\/t.co\/YEMMGov8PB",
  "id" : 640293821641682944,
  "created_at" : "2015-09-05 22:41:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tempa (RIP Depz)",
      "screen_name" : "QuickTempa",
      "indices" : [ 3, 14 ],
      "id_str" : "270114854",
      "id" : 270114854
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/QuickTempa\/status\/639483881494745088\/video\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/coUa6jdRsE",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/639483596940554241\/pu\/img\/v9WHRQhuDvQmnssW.jpg",
      "id_str" : "639483596940554241",
      "id" : 639483596940554241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/639483596940554241\/pu\/img\/v9WHRQhuDvQmnssW.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/coUa6jdRsE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640217424709578752",
  "text" : "RT @QuickTempa: When you graduated from Hogwarts, but the job market is trash. Cotton candy magic http:\/\/t.co\/coUa6jdRsE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/QuickTempa\/status\/639483881494745088\/video\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/coUa6jdRsE",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/639483596940554241\/pu\/img\/v9WHRQhuDvQmnssW.jpg",
        "id_str" : "639483596940554241",
        "id" : 639483596940554241,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/639483596940554241\/pu\/img\/v9WHRQhuDvQmnssW.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/coUa6jdRsE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639483881494745088",
    "text" : "When you graduated from Hogwarts, but the job market is trash. Cotton candy magic http:\/\/t.co\/coUa6jdRsE",
    "id" : 639483881494745088,
    "created_at" : "2015-09-03 17:03:33 +0000",
    "user" : {
      "name" : "Tempa (RIP Depz)",
      "screen_name" : "QuickTempa",
      "protected" : false,
      "id_str" : "270114854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723531006746091520\/JXJGcK3J_normal.jpg",
      "id" : 270114854,
      "verified" : false
    }
  },
  "id" : 640217424709578752,
  "created_at" : "2015-09-05 17:38:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640089638963535873",
  "text" : "We have entered a Golden Era of Dropping Out, Muffhuckers!",
  "id" : 640089638963535873,
  "created_at" : "2015-09-05 09:10:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640083278276378624",
  "text" : "What's it like when your local police force can be turned against you by people thousands of miles distant?",
  "id" : 640083278276378624,
  "created_at" : "2015-09-05 08:45:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kwan Booth",
      "screen_name" : "Boothism",
      "indices" : [ 3, 12 ],
      "id_str" : "19642990",
      "id" : 19642990
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Y88DZztaki",
      "expanded_url" : "http:\/\/tmblr.co\/ZU1pRy1tXiuzb",
      "display_url" : "tmblr.co\/ZU1pRy1tXiuzb"
    } ]
  },
  "geo" : { },
  "id_str" : "640069329002762240",
  "text" : "RT @Boothism: The Craigslist ad most #Oakland folks really want to post. http:\/\/t.co\/Y88DZztaki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 23, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/Y88DZztaki",
        "expanded_url" : "http:\/\/tmblr.co\/ZU1pRy1tXiuzb",
        "display_url" : "tmblr.co\/ZU1pRy1tXiuzb"
      } ]
    },
    "geo" : { },
    "id_str" : "639838560170999808",
    "text" : "The Craigslist ad most #Oakland folks really want to post. http:\/\/t.co\/Y88DZztaki",
    "id" : 639838560170999808,
    "created_at" : "2015-09-04 16:32:55 +0000",
    "user" : {
      "name" : "Kwan Booth",
      "screen_name" : "Boothism",
      "protected" : false,
      "id_str" : "19642990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1331680555\/kwan1_normal.jpg",
      "id" : 19642990,
      "verified" : false
    }
  },
  "id" : 640069329002762240,
  "created_at" : "2015-09-05 07:49:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/0i8XPgLsoS",
      "expanded_url" : "http:\/\/thinkprogress.org\/climate\/2015\/05\/05\/3654388\/california-drought-oil-wastewater-agriculture\/",
      "display_url" : "thinkprogress.org\/climate\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639804630222794752",
  "text" : "this has been happening for *decades*\n\nhttp:\/\/t.co\/0i8XPgLsoS",
  "id" : 639804630222794752,
  "created_at" : "2015-09-04 14:18:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639643730920669184",
  "text" : "love to my devils",
  "id" : 639643730920669184,
  "created_at" : "2015-09-04 03:38:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639642187009908736",
  "text" : "what is a stack?",
  "id" : 639642187009908736,
  "created_at" : "2015-09-04 03:32:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639641497013387264",
  "text" : "I observe all religions, religions you never hearda.  That's why I can't work no job.  Every day is a holy day.",
  "id" : 639641497013387264,
  "created_at" : "2015-09-04 03:29:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639641095794614273",
  "text" : "RT @nexxylove: Do not let religious people manipulate you into thinking that you owe even a shred of reverence to their belief system, what\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639623651252244480",
    "text" : "Do not let religious people manipulate you into thinking that you owe even a shred of reverence to their belief system, whatever it may be.",
    "id" : 639623651252244480,
    "created_at" : "2015-09-04 02:18:56 +0000",
    "user" : {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719047162793828353\/ilHIszOy_normal.jpg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 639641095794614273,
  "created_at" : "2015-09-04 03:28:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639539058843119616",
  "text" : "prior to the age of mechanical reproduction, most raps were not worth setting down for the record.",
  "id" : 639539058843119616,
  "created_at" : "2015-09-03 20:42:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639177784162582528",
  "geo" : { },
  "id_str" : "639178697312980993",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  This is but one proof of the deep psychic oppressions we face from birth, bequeathed to us by dead profiteers.",
  "id" : 639178697312980993,
  "in_reply_to_status_id" : 639177784162582528,
  "created_at" : "2015-09-02 20:50:51 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639177784162582528",
  "text" : "Listening to a mom scream punitively at her kid to use fuckin' bike breaks.  Otherwise kids at play get hit by cars in our civil society.",
  "id" : 639177784162582528,
  "created_at" : "2015-09-02 20:47:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/4wicMhNVjm",
      "expanded_url" : "https:\/\/github.com\/NHQ\/journal",
      "display_url" : "github.com\/NHQ\/journal"
    } ]
  },
  "geo" : { },
  "id_str" : "638910797154902016",
  "text" : "I published my private journal https:\/\/t.co\/4wicMhNVjm",
  "id" : 638910797154902016,
  "created_at" : "2015-09-02 03:06:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638884012480589824",
  "text" : "RT @: Oh shit! T-shirt cannons!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638870269780733952",
    "text" : "Oh shit! T-shirt cannons!!!",
    "id" : 638870269780733952,
    "created_at" : "2015-09-02 00:25:16 +0000",
    "user" : {
      "name" : "Mysteriously Unnamed",
      "screen_name" : "",
      "protected" : false,
      "id_str" : "73260582",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_3_normal.png",
      "id" : 73260582,
      "verified" : false
    }
  },
  "id" : 638884012480589824,
  "created_at" : "2015-09-02 01:19:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "~~\u273FALANIS M. ASMR\u273F~~",
      "screen_name" : "wyrdtweeter",
      "indices" : [ 3, 15 ],
      "id_str" : "1014064182",
      "id" : 1014064182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638849121617510400",
  "text" : "RT @wyrdtweeter: everyone is a socialist until some tentative social connection gains them access to some semi-exclusive hotel rooftop bull\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638838871799656448",
    "text" : "everyone is a socialist until some tentative social connection gains them access to some semi-exclusive hotel rooftop bullshit",
    "id" : 638838871799656448,
    "created_at" : "2015-09-01 22:20:30 +0000",
    "user" : {
      "name" : "~~\u273FALANIS M. ASMR\u273F~~",
      "screen_name" : "wyrdtweeter",
      "protected" : false,
      "id_str" : "1014064182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2980174241\/6728e8d411b365d0653d02232c6c9194_normal.jpeg",
      "id" : 1014064182,
      "verified" : false
    }
  },
  "id" : 638849121617510400,
  "created_at" : "2015-09-01 23:01:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 0, 8 ],
      "id_str" : "185744472",
      "id" : 185744472
    }, {
      "name" : "Steve Teeps",
      "screen_name" : "Steveteeps",
      "indices" : [ 9, 20 ],
      "id_str" : "19431469",
      "id" : 19431469
    }, {
      "name" : "PNO",
      "screen_name" : "L4suicide",
      "indices" : [ 21, 31 ],
      "id_str" : "331640776",
      "id" : 331640776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638826292519944192",
  "geo" : { },
  "id_str" : "638827366861553664",
  "in_reply_to_user_id" : 185744472,
  "text" : "@Cabbibo @Steveteeps @L4suicide  I got tethered to 3 space buoys out somewhere all by myself.   scared and alone, would not play again.",
  "id" : 638827366861553664,
  "in_reply_to_status_id" : 638826292519944192,
  "created_at" : "2015-09-01 21:34:47 +0000",
  "in_reply_to_screen_name" : "Cabbibo",
  "in_reply_to_user_id_str" : "185744472",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638825076599623680",
  "text" : "It's been almost two years since I had a wad.  That's a long time since your last wad.",
  "id" : 638825076599623680,
  "created_at" : "2015-09-01 21:25:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lady Alex",
      "screen_name" : "Sounjaneer",
      "indices" : [ 3, 14 ],
      "id_str" : "2588867390",
      "id" : 2588867390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/BAH20fBz9J",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=gPfJDv5yTAw",
      "display_url" : "youtube.com\/watch?v=gPfJDv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638615077373935616",
  "text" : "RT @Sounjaneer: new diy project up! music video for my newest song 'ecstasy of empathy'\nhttps:\/\/t.co\/BAH20fBz9J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/BAH20fBz9J",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=gPfJDv5yTAw",
        "display_url" : "youtube.com\/watch?v=gPfJDv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638555996739141632",
    "text" : "new diy project up! music video for my newest song 'ecstasy of empathy'\nhttps:\/\/t.co\/BAH20fBz9J",
    "id" : 638555996739141632,
    "created_at" : "2015-09-01 03:36:28 +0000",
    "user" : {
      "name" : "Lady Alex",
      "screen_name" : "Sounjaneer",
      "protected" : false,
      "id_str" : "2588867390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638553909204652034\/HoQxURW6_normal.jpg",
      "id" : 2588867390,
      "verified" : false
    }
  },
  "id" : 638615077373935616,
  "created_at" : "2015-09-01 07:31:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]