Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avi Bryant",
      "screen_name" : "avibryant",
      "indices" : [ 0, 10 ],
      "id_str" : "13192",
      "id" : 13192
    }, {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 11, 18 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571799073566552064",
  "geo" : { },
  "id_str" : "571829947813142528",
  "in_reply_to_user_id" : 13192,
  "text" : "@avibryant @feross  HOLY CARP",
  "id" : 571829947813142528,
  "in_reply_to_status_id" : 571799073566552064,
  "created_at" : "2015-03-01 00:30:58 +0000",
  "in_reply_to_screen_name" : "avibryant",
  "in_reply_to_user_id_str" : "13192",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "modulhaus",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571764772552622080",
  "text" : "Thanks for all the positive vibes and feedback!  #modulhaus",
  "id" : 571764772552622080,
  "created_at" : "2015-02-28 20:11:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 3, 11 ],
      "id_str" : "185744472",
      "id" : 185744472
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 13, 26 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571711671984513024",
  "text" : "RT @Cabbibo: @johnnyscript brilliant profile pic. Monk Raccoon is one of my favorite spiritual leaders.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571597052544618496",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript brilliant profile pic. Monk Raccoon is one of my favorite spiritual leaders.",
    "id" : 571597052544618496,
    "created_at" : "2015-02-28 09:05:31 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "protected" : false,
      "id_str" : "185744472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544543762743975937\/3lS7IL8l_normal.png",
      "id" : 185744472,
      "verified" : false
    }
  },
  "id" : 571711671984513024,
  "created_at" : "2015-02-28 16:40:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 0, 8 ],
      "id_str" : "185744472",
      "id" : 185744472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571597052544618496",
  "geo" : { },
  "id_str" : "571711656486518784",
  "in_reply_to_user_id" : 185744472,
  "text" : "@Cabbibo  Why hello I was just admiring your crazy awesome work.",
  "id" : 571711656486518784,
  "in_reply_to_status_id" : 571597052544618496,
  "created_at" : "2015-02-28 16:40:55 +0000",
  "in_reply_to_screen_name" : "Cabbibo",
  "in_reply_to_user_id_str" : "185744472",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/tP2cW0rNPn",
      "expanded_url" : "http:\/\/rednuht.org\/genetic_walkers\/",
      "display_url" : "rednuht.org\/genetic_walker\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571705722091659264",
  "text" : "i love this http:\/\/t.co\/tP2cW0rNPn",
  "id" : 571705722091659264,
  "created_at" : "2015-02-28 16:17:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 3, 7 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/jYEXRfJgqu",
      "expanded_url" : "http:\/\/i.imgur.com\/kC32rxH.jpg",
      "display_url" : "i.imgur.com\/kC32rxH.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "571515260760301568",
  "text" : "RT @izs: Are you listening to me neo? http:\/\/t.co\/jYEXRfJgqu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/jYEXRfJgqu",
        "expanded_url" : "http:\/\/i.imgur.com\/kC32rxH.jpg",
        "display_url" : "i.imgur.com\/kC32rxH.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "571484305660112898",
    "text" : "Are you listening to me neo? http:\/\/t.co\/jYEXRfJgqu",
    "id" : 571484305660112898,
    "created_at" : "2015-02-28 01:37:30 +0000",
    "user" : {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "protected" : false,
      "id_str" : "8038312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649690687860899840\/bSyKUJfg_normal.png",
      "id" : 8038312,
      "verified" : false
    }
  },
  "id" : 571515260760301568,
  "created_at" : "2015-02-28 03:40:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haunted TweetBot",
      "screen_name" : "cwlcks",
      "indices" : [ 3, 10 ],
      "id_str" : "63545584",
      "id" : 63545584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rideshare",
      "indices" : [ 44, 54 ]
    }, {
      "text" : "LA",
      "indices" : [ 60, 63 ]
    }, {
      "text" : "Texas",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "Austin",
      "indices" : [ 85, 92 ]
    }, {
      "text" : "SanAntonio",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "Houston",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571513930108952577",
  "text" : "RT @cwlcks: Hello twitter I'm looking for a #rideshare from #LA to #Texas next week. #Austin #SanAntonio or #Houston",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rideshare",
        "indices" : [ 32, 42 ]
      }, {
        "text" : "LA",
        "indices" : [ 48, 51 ]
      }, {
        "text" : "Texas",
        "indices" : [ 55, 61 ]
      }, {
        "text" : "Austin",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "SanAntonio",
        "indices" : [ 81, 92 ]
      }, {
        "text" : "Houston",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571497775981969408",
    "text" : "Hello twitter I'm looking for a #rideshare from #LA to #Texas next week. #Austin #SanAntonio or #Houston",
    "id" : 571497775981969408,
    "created_at" : "2015-02-28 02:31:02 +0000",
    "user" : {
      "name" : "Haunted TweetBot",
      "screen_name" : "cwlcks",
      "protected" : false,
      "id_str" : "63545584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715275353959170049\/t78f4Zag_normal.jpg",
      "id" : 63545584,
      "verified" : false
    }
  },
  "id" : 571513930108952577,
  "created_at" : "2015-02-28 03:35:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reza Akhavan",
      "screen_name" : "jedireza",
      "indices" : [ 9, 18 ],
      "id_str" : "39129267",
      "id" : 39129267
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 19, 28 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571470144041451523",
  "geo" : { },
  "id_str" : "571513498691215361",
  "in_reply_to_user_id" : 39129267,
  "text" : "Thanks!  @jedireza @substack",
  "id" : 571513498691215361,
  "in_reply_to_status_id" : 571470144041451523,
  "created_at" : "2015-02-28 03:33:30 +0000",
  "in_reply_to_screen_name" : "jedireza",
  "in_reply_to_user_id_str" : "39129267",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/U7cYziagaw",
      "expanded_url" : "https:\/\/42713ae780d99dfaac4e100c6acf8f81ba16ea99.htmlb.in\/",
      "display_url" : "\u20269dfaac4e100c6acf8f81ba16ea99.htmlb.in"
    } ]
  },
  "geo" : { },
  "id_str" : "571467087824089088",
  "text" : "permaseo  https:\/\/t.co\/U7cYziagaw",
  "id" : 571467087824089088,
  "created_at" : "2015-02-28 00:29:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/FRN3l7HEi3",
      "expanded_url" : "https:\/\/www.npmjs.com\/private-modules",
      "display_url" : "npmjs.com\/private-modules"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571454466169262080",
  "text" : "Dear Dev Teams:\n\nPrivate Modules on NPM + Distributed module development?\n\nIt's all done. \n\nhttps:\/\/t.co\/FRN3l7HEi3\n\nhttp:\/\/t.co\/HotCwCz91x",
  "id" : 571454466169262080,
  "created_at" : "2015-02-27 23:38:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Vlnas",
      "screen_name" : "janvlnas",
      "indices" : [ 0, 9 ],
      "id_str" : "244909101",
      "id" : 244909101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571448342791614464",
  "geo" : { },
  "id_str" : "571450208514547713",
  "in_reply_to_user_id" : 244909101,
  "text" : "@janvlnas  many thanks!  fixed.  a vestige of my personal web framework, which I use for absolute positioned interfaces  ;^)",
  "id" : 571450208514547713,
  "in_reply_to_status_id" : 571448342791614464,
  "created_at" : "2015-02-27 23:22:01 +0000",
  "in_reply_to_screen_name" : "janvlnas",
  "in_reply_to_user_id_str" : "244909101",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571446730907983872",
  "text" : "We are writers and researchers.  \nWe possess the agency.\nOwn yours today.",
  "id" : 571446730907983872,
  "created_at" : "2015-02-27 23:08:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571442334526627840",
  "text" : "Many thanks to all the people who make the module library an inspiring place to be.  I would probably hate coding w\/o Modules &amp; Open Source.",
  "id" : 571442334526627840,
  "created_at" : "2015-02-27 22:50:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571440259642171392",
  "text" : "Years of conspiring and collaboration\nThree half-days of front-end web development\nhttp:\/\/t.co\/HotCwCz91x",
  "id" : 571440259642171392,
  "created_at" : "2015-02-27 22:42:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Vlnas",
      "screen_name" : "janvlnas",
      "indices" : [ 0, 9 ],
      "id_str" : "244909101",
      "id" : 244909101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Icxb3PKOZL",
      "expanded_url" : "https:\/\/github.com\/MODULHAUS\/modulha.us\/blob\/master\/index.md",
      "display_url" : "github.com\/MODULHAUS\/modu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "571436285153427458",
  "geo" : { },
  "id_str" : "571439475257053184",
  "in_reply_to_user_id" : 244909101,
  "text" : "@janvlnas heh. Odd that your brow didn't slim it down, it's pretty defaultish. Mine did. Def not optimized for mob.  https:\/\/t.co\/Icxb3PKOZL",
  "id" : 571439475257053184,
  "in_reply_to_status_id" : 571436285153427458,
  "created_at" : "2015-02-27 22:39:22 +0000",
  "in_reply_to_screen_name" : "janvlnas",
  "in_reply_to_user_id_str" : "244909101",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 73, 82 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571437706883960832",
  "text" : "Modular software.  \nYou know it, you love it.\nModular development?  \nAsk @substack\nhttp:\/\/t.co\/HotCwCz91x",
  "id" : 571437706883960832,
  "created_at" : "2015-02-27 22:32:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garth",
      "screen_name" : "garthk",
      "indices" : [ 3, 10 ],
      "id_str" : "704593",
      "id" : 704593
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 31, 44 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 49, 58 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571435813482815488",
  "text" : "RT @garthk: Inspiring madness, @johnnyscript and @substack. Prove 'em all wrong.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 19, 32 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "substack",
        "screen_name" : "substack",
        "indices" : [ 37, 46 ],
        "id_str" : "125027291",
        "id" : 125027291
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "571421322267357185",
    "geo" : { },
    "id_str" : "571434989532762112",
    "in_reply_to_user_id" : 46961216,
    "text" : "Inspiring madness, @johnnyscript and @substack. Prove 'em all wrong.",
    "id" : 571434989532762112,
    "in_reply_to_status_id" : 571421322267357185,
    "created_at" : "2015-02-27 22:21:32 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Garth",
      "screen_name" : "garthk",
      "protected" : false,
      "id_str" : "704593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629845204258832384\/imJ2Efsl_normal.jpg",
      "id" : 704593,
      "verified" : false
    }
  },
  "id" : 571435813482815488,
  "created_at" : "2015-02-27 22:24:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 87, 101 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "modulhaus",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571435641780613120",
  "text" : "once again that number is http:\/\/t.co\/HotCwCz91x,  #modulhaus on IRC via freenode, and @modulhaus3000",
  "id" : 571435641780613120,
  "created_at" : "2015-02-27 22:24:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571435181036318720",
  "text" : "Thank you for site \/ design feedbacks http:\/\/t.co\/HotCwCz91x",
  "id" : 571435181036318720,
  "created_at" : "2015-02-27 22:22:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571432126731538432",
  "text" : "My only regret is that selfie is a year old and captures neither my hair nor beauty.",
  "id" : 571432126731538432,
  "created_at" : "2015-02-27 22:10:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571429342581903360",
  "text" : "AND NOW CHECK OUT THESE COSTUMED LLAMAS\n\nhttp:\/\/t.co\/HotCwCz91x",
  "id" : 571429342581903360,
  "created_at" : "2015-02-27 21:59:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571428942743085056",
  "text" : "Give us the requirements, we'll source the dependencies.  \n\nhttp:\/\/t.co\/HotCwCz91x",
  "id" : 571428942743085056,
  "created_at" : "2015-02-27 21:57:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571428819636105216",
  "text" : "You may represent modulhaus.  projects, gigs, experiments.  all you need to know is the application's requirements.  http:\/\/t.co\/HotCwCz91x",
  "id" : 571428819636105216,
  "created_at" : "2015-02-27 21:57:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571428292294680576",
  "text" : "Modulhaus is a system you can use.",
  "id" : 571428292294680576,
  "created_at" : "2015-02-27 21:54:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571427985661669376",
  "text" : "Modulhaus is a radical free agency.  We must represent each other.  You can represent modulhaus.  YOU CAN REPRESENT MODULHAUS!",
  "id" : 571427985661669376,
  "created_at" : "2015-02-27 21:53:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571427513252974592",
  "text" : "If you are a dev in a dev shop or startup,  think of the ways you could tap into modulhaus, and let us know.",
  "id" : 571427513252974592,
  "created_at" : "2015-02-27 21:51:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 42, 56 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571426852054511616",
  "text" : "That is all for now.  you can also follow @modulhaus3000",
  "id" : 571426852054511616,
  "created_at" : "2015-02-27 21:49:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "modulhaus",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571425076861476864",
  "geo" : { },
  "id_str" : "571426652820865024",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon  #modulhaus  on freenode",
  "id" : 571426652820865024,
  "in_reply_to_status_id" : 571425076861476864,
  "created_at" : "2015-02-27 21:48:25 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "modulhaus",
      "indices" : [ 6, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571426226327330816",
  "text" : "\/join #modulhaus on freenode",
  "id" : 571426226327330816,
  "created_at" : "2015-02-27 21:46:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571426054415388672",
  "text" : "Modulhaus can handle any load.  We are a distributed, dynamic, scalable, collaborative mass of master hackers.  http:\/\/t.co\/HotCwCz91x",
  "id" : 571426054415388672,
  "created_at" : "2015-02-27 21:46:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571425491166453761",
  "text" : "It's not like we don't have future plans n schemes.  But the bread and nutbutter is web development.  Send us work!  http:\/\/t.co\/HotCwCz91x",
  "id" : 571425491166453761,
  "created_at" : "2015-02-27 21:43:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571424862071189504",
  "text" : "Your feedback is welcome.  Your affiliation is encouraged.  Your referrals gratefully accepted.   http:\/\/t.co\/HotCwCz91x",
  "id" : 571424862071189504,
  "created_at" : "2015-02-27 21:41:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571424087731339265",
  "text" : "Modulhaus is a simple plan. A modular, open source workforce for web development.  Real work &amp; support for indie devs http:\/\/t.co\/HotCwCz91x",
  "id" : 571424087731339265,
  "created_at" : "2015-02-27 21:38:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 3, 14 ],
      "id_str" : "64105403",
      "id" : 64105403
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 30, 39 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571423301240639488",
  "text" : "RT @legittalon: @johnnyscript @substack love it and would love to be involved",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "substack",
        "screen_name" : "substack",
        "indices" : [ 14, 23 ],
        "id_str" : "125027291",
        "id" : 125027291
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571423094851571712",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript @substack love it and would love to be involved",
    "id" : 571423094851571712,
    "created_at" : "2015-02-27 21:34:16 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "protected" : false,
      "id_str" : "64105403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516448568706486274\/5oBt_x03_normal.png",
      "id" : 64105403,
      "verified" : false
    }
  },
  "id" : 571423301240639488,
  "created_at" : "2015-02-27 21:35:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571423218659037185",
  "text" : "You know and love modular, open source software development.  You will love Modulhaus.  http:\/\/t.co\/HotCwCz91x",
  "id" : 571423218659037185,
  "created_at" : "2015-02-27 21:34:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 74, 83 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571422878026964992",
  "text" : "What is Modulhaus?  The concepts shall be expounded.  Primarily, me &amp; @substack are repping modular OSS development  http:\/\/t.co\/HotCwCz91x",
  "id" : 571422878026964992,
  "created_at" : "2015-02-27 21:33:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571422278711320577",
  "text" : "twitter announcements are no place for a dyslexic",
  "id" : 571422278711320577,
  "created_at" : "2015-02-27 21:31:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571422140202766336",
  "text" : "Actually, we are skipping some levels.  Modulhaus is going to beat all the bosses.\n\nhttp:\/\/t.co\/HotCwCz91x",
  "id" : 571422140202766336,
  "created_at" : "2015-02-27 21:30:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571421661490126848",
  "text" : "modulhaus \n\nhttp:\/\/t.co\/HotCwCz91x",
  "id" : 571421661490126848,
  "created_at" : "2015-02-27 21:28:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571421477062385665",
  "text" : "We are going to the another level.",
  "id" : 571421477062385665,
  "created_at" : "2015-02-27 21:27:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 34, 43 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/HotCwCz91x",
      "expanded_url" : "http:\/\/modulha.us",
      "display_url" : "modulha.us"
    } ]
  },
  "geo" : { },
  "id_str" : "571421322267357185",
  "text" : "THE ANNOUNCEMENT, PLEASE!\n\nAHEMS\n\n@substack and I are taking modular OSS to another level.  \n\nhttp:\/\/t.co\/HotCwCz91x",
  "id" : 571421322267357185,
  "created_at" : "2015-02-27 21:27:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571417176889958400",
  "text" : "The announcement is trynna be something.",
  "id" : 571417176889958400,
  "created_at" : "2015-02-27 21:10:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571417029967613952",
  "text" : "The announcement comes after much conspiring among some of the most amazing hackers in the open source community.",
  "id" : 571417029967613952,
  "created_at" : "2015-02-27 21:10:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571415921161408512",
  "text" : "And now, the announcement.",
  "id" : 571415921161408512,
  "created_at" : "2015-02-27 21:05:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571414849839702017",
  "text" : "It could have been any preposition tho, that way those are.",
  "id" : 571414849839702017,
  "created_at" : "2015-02-27 21:01:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571414728406249474",
  "text" : "There was a vital preposition missing.",
  "id" : 571414728406249474,
  "created_at" : "2015-02-27 21:01:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571414576228491264",
  "text" : "the announcement is for open source devs, and for organizations which design and build web applications on open source OSS stacks.",
  "id" : 571414576228491264,
  "created_at" : "2015-02-27 21:00:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571414389087084544",
  "text" : "the announcement is for open source devs, and for organizations which design and build web applications open source OSS stacks.",
  "id" : 571414389087084544,
  "created_at" : "2015-02-27 20:59:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571413955307966464",
  "text" : "this announcement is for you.",
  "id" : 571413955307966464,
  "created_at" : "2015-02-27 20:57:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571413829936029696",
  "text" : "And now for the announcement.  I will give you the announcement.",
  "id" : 571413829936029696,
  "created_at" : "2015-02-27 20:57:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571413707537776640",
  "text" : "The preamble is over.",
  "id" : 571413707537776640,
  "created_at" : "2015-02-27 20:56:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571413603133206530",
  "text" : "The announcement comes with a preamble.",
  "id" : 571413603133206530,
  "created_at" : "2015-02-27 20:56:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571413285267861504",
  "text" : "I will be going on about what I am about go on about.",
  "id" : 571413285267861504,
  "created_at" : "2015-02-27 20:55:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571413125234233345",
  "text" : "Ok here it comes.  \nOk here it goes.",
  "id" : 571413125234233345,
  "created_at" : "2015-02-27 20:54:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571401150815055872",
  "text" : "Yesterday's announcement is coming today.  I wasn't about to compete with the llamas.",
  "id" : 571401150815055872,
  "created_at" : "2015-02-27 20:07:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Cyrin",
      "screen_name" : "lynnmagic",
      "indices" : [ 0, 10 ],
      "id_str" : "3235701608",
      "id" : 3235701608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571397791026540544",
  "geo" : { },
  "id_str" : "571399417065971712",
  "in_reply_to_user_id" : 2212879538,
  "text" : "@LynnMagic  yes, organizer would be indispensable.  a lot else tho.  media, ops, web apps...",
  "id" : 571399417065971712,
  "in_reply_to_status_id" : 571397791026540544,
  "created_at" : "2015-02-27 20:00:11 +0000",
  "in_reply_to_screen_name" : "lynncyrin",
  "in_reply_to_user_id_str" : "2212879538",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Cyrin",
      "screen_name" : "lynnmagic",
      "indices" : [ 0, 10 ],
      "id_str" : "3235701608",
      "id" : 3235701608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571398232737222656",
  "geo" : { },
  "id_str" : "571398687735173120",
  "in_reply_to_user_id" : 2212879538,
  "text" : "@LynnMagic  heh yeah that is what I was getting at re: a mechanism.  but lots of planning, organization and outreach see it thru.",
  "id" : 571398687735173120,
  "in_reply_to_status_id" : 571398232737222656,
  "created_at" : "2015-02-27 19:57:17 +0000",
  "in_reply_to_screen_name" : "lynncyrin",
  "in_reply_to_user_id_str" : "2212879538",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/571396869764415489\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/oFZexb0oNG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-4CbOaUsAMBL4D.png",
      "id_str" : "571396869470859267",
      "id" : 571396869470859267,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-4CbOaUsAMBL4D.png",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 257
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 257
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 257
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 257
      } ],
      "display_url" : "pic.twitter.com\/oFZexb0oNG"
    } ],
    "hashtags" : [ {
      "text" : "humanContact",
      "indices" : [ 12, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571396869764415489",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove  #humanContact http:\/\/t.co\/oFZexb0oNG",
  "id" : 571396869764415489,
  "created_at" : "2015-02-27 19:50:04 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571178475110801409",
  "geo" : { },
  "id_str" : "571178762680709120",
  "in_reply_to_user_id" : 46961216,
  "text" : "4.  those who do get evicted are lodged with others\n5.  in a few months the banks are crying defeat",
  "id" : 571178762680709120,
  "in_reply_to_status_id" : 571178475110801409,
  "created_at" : "2015-02-27 05:23:23 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571178475110801409",
  "text" : "1.  we all agree to stop paying rent\n2.  protesters to block city hall and courthouse from eviction procedures\n3.  we all sit back and relax",
  "id" : 571178475110801409,
  "created_at" : "2015-02-27 05:22:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eddie pepitone",
      "screen_name" : "eddiepepitone",
      "indices" : [ 3, 17 ],
      "id_str" : "68810491",
      "id" : 68810491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571177151837245440",
  "text" : "RT @eddiepepitone: We are all a couple of paychecks away from being homeless. That's why I use Jergens face cream. Jergens. Because it's al\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571160761898135552",
    "text" : "We are all a couple of paychecks away from being homeless. That's why I use Jergens face cream. Jergens. Because it's all very tenuous.",
    "id" : 571160761898135552,
    "created_at" : "2015-02-27 04:11:51 +0000",
    "user" : {
      "name" : "eddie pepitone",
      "screen_name" : "eddiepepitone",
      "protected" : false,
      "id_str" : "68810491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567179876877078528\/yhLg_2L__normal.jpeg",
      "id" : 68810491,
      "verified" : false
    }
  },
  "id" : 571177151837245440,
  "created_at" : "2015-02-27 05:16:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571177059684261888",
  "text" : "if only we had some mechanism for coordinating mass actions, we'd bring it all down in a month or two",
  "id" : 571177059684261888,
  "created_at" : "2015-02-27 05:16:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 3, 9 ],
      "id_str" : "6604912",
      "id" : 6604912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571176681114722304",
  "text" : "RT @mkruz: \"...and that kids, is how February 26th became National Internet Day, and why we decorate llamas in white and gold\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571158485129244672",
    "text" : "\"...and that kids, is how February 26th became National Internet Day, and why we decorate llamas in white and gold\"",
    "id" : 571158485129244672,
    "created_at" : "2015-02-27 04:02:49 +0000",
    "user" : {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "protected" : false,
      "id_str" : "6604912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000242987343\/c5f548f1294b2399dd999d3e072b2711_normal.jpeg",
      "id" : 6604912,
      "verified" : false
    }
  },
  "id" : 571176681114722304,
  "created_at" : "2015-02-27 05:15:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571176395692331008",
  "text" : "paying rent is playing the prisoners dilemma the stupid way",
  "id" : 571176395692331008,
  "created_at" : "2015-02-27 05:13:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eddie pepitone",
      "screen_name" : "eddiepepitone",
      "indices" : [ 0, 14 ],
      "id_str" : "68810491",
      "id" : 68810491
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 15, 27 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571160761898135552",
  "geo" : { },
  "id_str" : "571176330902908929",
  "in_reply_to_user_id" : 68810491,
  "text" : "@eddiepepitone @marinakukso rent strike debt strike",
  "id" : 571176330902908929,
  "in_reply_to_status_id" : 571160761898135552,
  "created_at" : "2015-02-27 05:13:43 +0000",
  "in_reply_to_screen_name" : "eddiepepitone",
  "in_reply_to_user_id_str" : "68810491",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "css",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571152581487042562",
  "text" : "#css filters are sweet",
  "id" : 571152581487042562,
  "created_at" : "2015-02-27 03:39:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clint",
      "screen_name" : "Gnoscere",
      "indices" : [ 0, 9 ],
      "id_str" : "2996511476",
      "id" : 2996511476
    }, {
      "name" : "Andrew Rader",
      "screen_name" : "marsrader",
      "indices" : [ 10, 20 ],
      "id_str" : "1087860428",
      "id" : 1087860428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571143155187195904",
  "geo" : { },
  "id_str" : "571149345560461314",
  "in_reply_to_user_id" : 2996511476,
  "text" : "@Gnoscere @marsrader  changes in the sun's angle on the horizon over 100 days?",
  "id" : 571149345560461314,
  "in_reply_to_status_id" : 571143155187195904,
  "created_at" : "2015-02-27 03:26:30 +0000",
  "in_reply_to_screen_name" : "Gnoscere",
  "in_reply_to_user_id_str" : "2996511476",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571136937903271936",
  "text" : "I closed today's internet issues.",
  "id" : 571136937903271936,
  "created_at" : "2015-02-27 02:37:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 5, 16 ],
      "id_str" : "15734539",
      "id" : 15734539
    }, {
      "name" : "Brett Banditelli",
      "screen_name" : "banditelli",
      "indices" : [ 17, 28 ],
      "id_str" : "16397938",
      "id" : 16397938
    }, {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 29, 35 ],
      "id_str" : "15453",
      "id" : 15453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571128544572518400",
  "geo" : { },
  "id_str" : "571136797847085056",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs @FrozenFire @banditelli @seldo  idea: police must wear goggles that have a similar effect on skin tones.  And llama fur.",
  "id" : 571136797847085056,
  "in_reply_to_status_id" : 571128544572518400,
  "created_at" : "2015-02-27 02:36:38 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571067039609069568",
  "text" : "me n my llamas comin at ya",
  "id" : 571067039609069568,
  "created_at" : "2015-02-26 21:59:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571055466756730881",
  "text" : "I will  be making a very special announcement soon!",
  "id" : 571055466756730881,
  "created_at" : "2015-02-26 21:13:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 0, 12 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571040236911726593",
  "geo" : { },
  "id_str" : "571053365041369088",
  "in_reply_to_user_id" : 557228721,
  "text" : "@vrroanhorse I recall big snowfalls as late april \/ may.  don't act surprised!",
  "id" : 571053365041369088,
  "in_reply_to_status_id" : 571040236911726593,
  "created_at" : "2015-02-26 21:05:06 +0000",
  "in_reply_to_screen_name" : "vrroanhorse",
  "in_reply_to_user_id_str" : "557228721",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 0, 12 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571040236911726593",
  "geo" : { },
  "id_str" : "571053035721338881",
  "in_reply_to_user_id" : 557228721,
  "text" : "@vrroanhorse   daaaayumn, but when was february ever nice in the CHI?  I've been sun bathing since the new year.  After a two week winter.",
  "id" : 571053035721338881,
  "in_reply_to_status_id" : 571040236911726593,
  "created_at" : "2015-02-26 21:03:48 +0000",
  "in_reply_to_screen_name" : "vrroanhorse",
  "in_reply_to_user_id_str" : "557228721",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 3, 16 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/OccupyRMN\/status\/571044227469017089\/photo\/1",
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/TAXU6IR3F2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-zBsl1UUAAqQZW.png",
      "id_str" : "571044224583356416",
      "id" : 571044224583356416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-zBsl1UUAAqQZW.png",
      "sizes" : [ {
        "h" : 343,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TAXU6IR3F2"
    } ],
    "hashtags" : [ {
      "text" : "BREAKING",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "llamas",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571051864092856321",
  "text" : "RT @occupythemob: #BREAKING: Turns out the black llama was shot 78 times by police. Authorities say they felt intimidated. http:\/\/t.co\/TAXU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.GroupTweet.com\" rel=\"nofollow\"\u003EGroupTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/OccupyRMN\/status\/571044227469017089\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/TAXU6IR3F2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-zBsl1UUAAqQZW.png",
        "id_str" : "571044224583356416",
        "id" : 571044224583356416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-zBsl1UUAAqQZW.png",
        "sizes" : [ {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TAXU6IR3F2"
      } ],
      "hashtags" : [ {
        "text" : "BREAKING",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "llamas",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571050034546008066",
    "text" : "#BREAKING: Turns out the black llama was shot 78 times by police. Authorities say they felt intimidated. http:\/\/t.co\/TAXU6IR3F2 #llamas",
    "id" : 571050034546008066,
    "created_at" : "2015-02-26 20:51:52 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "AnonyMobLife",
      "protected" : false,
      "id_str" : "341908197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627989340111654912\/Xo6hS4Ab_normal.jpg",
      "id" : 341908197,
      "verified" : false
    }
  },
  "id" : 571051864092856321,
  "created_at" : "2015-02-26 20:59:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#OpLizardSquad",
      "screen_name" : "OpLizardsquad_",
      "indices" : [ 0, 15 ],
      "id_str" : "2943115108",
      "id" : 2943115108
    }, {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 16, 29 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571024753756119040",
  "geo" : { },
  "id_str" : "571033223460818944",
  "in_reply_to_user_id" : 2943115108,
  "text" : "@OpLizardsquad_ @occupythemob  uhm I think we made Internet FUTURE",
  "id" : 571033223460818944,
  "in_reply_to_status_id" : 571024753756119040,
  "created_at" : "2015-02-26 19:45:04 +0000",
  "in_reply_to_screen_name" : "OpLizardsquad_",
  "in_reply_to_user_id_str" : "2943115108",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Surgeons",
      "screen_name" : "digitalsurgeons",
      "indices" : [ 0, 16 ],
      "id_str" : "18189130",
      "id" : 18189130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571032455416647680",
  "in_reply_to_user_id" : 18189130,
  "text" : "@digitalsurgeons hi I'm trying to contact yall and am unable to.  I'm looking for the dev dept.  thx.  an email 4 direct contact would be +1",
  "id" : 571032455416647680,
  "created_at" : "2015-02-26 19:42:01 +0000",
  "in_reply_to_screen_name" : "digitalsurgeons",
  "in_reply_to_user_id_str" : "18189130",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571010395063726080",
  "text" : "nsa fuckin up my ssh",
  "id" : 571010395063726080,
  "created_at" : "2015-02-26 18:14:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570840778584367105",
  "geo" : { },
  "id_str" : "570842503781306368",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  I take much solace seeing in others what extremes the body can withstand.  the strange \/ painful things began with life afaik.",
  "id" : 570842503781306368,
  "in_reply_to_status_id" : 570840778584367105,
  "created_at" : "2015-02-26 07:07:13 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570841734738882560",
  "text" : "666 unsent emails in my drafts folder.  give me a badge, or I will unleash the beasts.",
  "id" : 570841734738882560,
  "created_at" : "2015-02-26 07:04:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stagas",
      "screen_name" : "stagas",
      "indices" : [ 0, 7 ],
      "id_str" : "50715651",
      "id" : 50715651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570486559776100352",
  "geo" : { },
  "id_str" : "570793929697681408",
  "in_reply_to_user_id" : 50715651,
  "text" : "@stagas  awesome stuff.  I checked out openDSP.  Freeverb!  however, I soon seem to have broken wavepot. completely. possible GH rate limit?",
  "id" : 570793929697681408,
  "in_reply_to_status_id" : 570486559776100352,
  "created_at" : "2015-02-26 03:54:12 +0000",
  "in_reply_to_screen_name" : "stagas",
  "in_reply_to_user_id_str" : "50715651",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570782403716780032",
  "text" : "RT @postcrunk: every thought you have and every word you speak, you must ask yourself: \"is this how I really feel or just an ideology?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570778008383987712",
    "text" : "every thought you have and every word you speak, you must ask yourself: \"is this how I really feel or just an ideology?\"",
    "id" : 570778008383987712,
    "created_at" : "2015-02-26 02:50:56 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 570782403716780032,
  "created_at" : "2015-02-26 03:08:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570760338792062976",
  "text" : "Herculean... or Hulk Hogean?",
  "id" : 570760338792062976,
  "created_at" : "2015-02-26 01:40:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "indices" : [ 3, 11 ],
      "id_str" : "14145296",
      "id" : 14145296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570757929206312961",
  "text" : "RT @susie_c: W\u00F6rk will redefine fast casual: you cook, serve, and do your own dishes. Labor is so fun! Only $40\/person. Everything served i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "570755807052107776",
    "geo" : { },
    "id_str" : "570756792784850944",
    "in_reply_to_user_id" : 14145296,
    "text" : "W\u00F6rk will redefine fast casual: you cook, serve, and do your own dishes. Labor is so fun! Only $40\/person. Everything served in a mason jar.",
    "id" : 570756792784850944,
    "in_reply_to_status_id" : 570755807052107776,
    "created_at" : "2015-02-26 01:26:38 +0000",
    "in_reply_to_screen_name" : "susie_c",
    "in_reply_to_user_id_str" : "14145296",
    "user" : {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "protected" : false,
      "id_str" : "14145296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656882091414585344\/JWq9-3gF_normal.png",
      "id" : 14145296,
      "verified" : false
    }
  },
  "id" : 570757929206312961,
  "created_at" : "2015-02-26 01:31:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "indices" : [ 3, 11 ],
      "id_str" : "14145296",
      "id" : 14145296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570757910206107648",
  "text" : "RT @susie_c: At MaMa, a sweet middle aged woman will do your laundry for you while you suck on a wall-mounted breast filled with White Russ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "570754427675521024",
    "geo" : { },
    "id_str" : "570755807052107776",
    "in_reply_to_user_id" : 14145296,
    "text" : "At MaMa, a sweet middle aged woman will do your laundry for you while you suck on a wall-mounted breast filled with White Russian",
    "id" : 570755807052107776,
    "in_reply_to_status_id" : 570754427675521024,
    "created_at" : "2015-02-26 01:22:43 +0000",
    "in_reply_to_screen_name" : "susie_c",
    "in_reply_to_user_id_str" : "14145296",
    "user" : {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "protected" : false,
      "id_str" : "14145296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656882091414585344\/JWq9-3gF_normal.png",
      "id" : 14145296,
      "verified" : false
    }
  },
  "id" : 570757910206107648,
  "created_at" : "2015-02-26 01:31:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "indices" : [ 3, 11 ],
      "id_str" : "14145296",
      "id" : 14145296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570757896864079872",
  "text" : "RT @susie_c: Bring your own bottle teat for a $1 discount. Get it baby bird style and we'll chew it first for you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "570754187987808257",
    "geo" : { },
    "id_str" : "570754427675521024",
    "in_reply_to_user_id" : 14145296,
    "text" : "Bring your own bottle teat for a $1 discount. Get it baby bird style and we'll chew it first for you.",
    "id" : 570754427675521024,
    "in_reply_to_status_id" : 570754187987808257,
    "created_at" : "2015-02-26 01:17:14 +0000",
    "in_reply_to_screen_name" : "susie_c",
    "in_reply_to_user_id_str" : "14145296",
    "user" : {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "protected" : false,
      "id_str" : "14145296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656882091414585344\/JWq9-3gF_normal.png",
      "id" : 14145296,
      "verified" : false
    }
  },
  "id" : 570757896864079872,
  "created_at" : "2015-02-26 01:31:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "indices" : [ 3, 11 ],
      "id_str" : "14145296",
      "id" : 14145296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570757887393337344",
  "text" : "RT @susie_c: Bay Area restaurant scene trajectory seems headed for artisanal baby food. High quality organic puddings, microbrew sippy cups\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570754187987808257",
    "text" : "Bay Area restaurant scene trajectory seems headed for artisanal baby food. High quality organic puddings, microbrew sippy cups, no utensils.",
    "id" : 570754187987808257,
    "created_at" : "2015-02-26 01:16:17 +0000",
    "user" : {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "protected" : false,
      "id_str" : "14145296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656882091414585344\/JWq9-3gF_normal.png",
      "id" : 14145296,
      "verified" : false
    }
  },
  "id" : 570757887393337344,
  "created_at" : "2015-02-26 01:30:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "indices" : [ 3, 12 ],
      "id_str" : "65433646",
      "id" : 65433646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570757685521440768",
  "text" : "RT @crylenol: He died doing what he loved: making fun of bears",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570745937095729152",
    "text" : "He died doing what he loved: making fun of bears",
    "id" : 570745937095729152,
    "created_at" : "2015-02-26 00:43:30 +0000",
    "user" : {
      "name" : "sadvil",
      "screen_name" : "crylenol",
      "protected" : false,
      "id_str" : "65433646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583977287521071105\/fdTqV-kn_normal.png",
      "id" : 65433646,
      "verified" : false
    }
  },
  "id" : 570757685521440768,
  "created_at" : "2015-02-26 01:30:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570743797442744320",
  "text" : "I am writing copy about myself.  I don't like it.  I mean I don't like doing it.  Please send descriptions of me that will entice shoppers.",
  "id" : 570743797442744320,
  "created_at" : "2015-02-26 00:34:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "markdown",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570725726321643520",
  "geo" : { },
  "id_str" : "570726491585011712",
  "in_reply_to_user_id" : 46961216,
  "text" : "also blame #markdown, since markdown stupidly left out class declaration",
  "id" : 570726491585011712,
  "in_reply_to_status_id" : 570725726321643520,
  "created_at" : "2015-02-25 23:26:13 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "css",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570725726321643520",
  "text" : "img[alt=\"hackety hack hack hack\"]\u007B\n  #css\n\u007D",
  "id" : 570725726321643520,
  "created_at" : "2015-02-25 23:23:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/570720295998218240\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/OfVFywCLZT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-ubFcHUAAA_z02.png",
      "id_str" : "570720295541014528",
      "id" : 570720295541014528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-ubFcHUAAA_z02.png",
      "sizes" : [ {
        "h" : 294,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 110,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OfVFywCLZT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570720295998218240",
  "text" : "coming soon to a domain near you http:\/\/t.co\/OfVFywCLZT",
  "id" : 570720295998218240,
  "created_at" : "2015-02-25 23:01:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 3, 11 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570663905896177664",
  "text" : "RT @bigeasy: It's important to try to see things from the other person's point of view, but nobody needs your fucking empathy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570516313816190978",
    "text" : "It's important to try to see things from the other person's point of view, but nobody needs your fucking empathy.",
    "id" : 570516313816190978,
    "created_at" : "2015-02-25 09:31:03 +0000",
    "user" : {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "protected" : false,
      "id_str" : "4784511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685849341496561664\/KOzfse57_normal.jpg",
      "id" : 4784511,
      "verified" : false
    }
  },
  "id" : 570663905896177664,
  "created_at" : "2015-02-25 19:17:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/vftDyZ8Gyo",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Universal_Decimal_Classification",
      "display_url" : "en.wikipedia.org\/wiki\/Universal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570425784885600256",
  "text" : "Universal Decimal Classification \nhttp:\/\/t.co\/vftDyZ8Gyo",
  "id" : 570425784885600256,
  "created_at" : "2015-02-25 03:31:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570336050180022272",
  "text" : "yesterday in the east bay we musta had hella high barometric pressure.  My bass gong became several notes tighter, and so did your sinews.",
  "id" : 570336050180022272,
  "created_at" : "2015-02-24 21:34:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "indices" : [ 3, 14 ],
      "id_str" : "14606079",
      "id" : 14606079
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ProPublica\/status\/570284275645292545\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/gHe3uQPSIJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-oOhvBUEAA0sh6.png",
      "id_str" : "570284275536236544",
      "id" : 570284275536236544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-oOhvBUEAA0sh6.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 101,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 609
      } ],
      "display_url" : "pic.twitter.com\/gHe3uQPSIJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/s6c0NrjIj2",
      "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2015\/feb\/24\/chicago-police-detain-americans-black-site",
      "display_url" : "theguardian.com\/us-news\/2015\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570334332436422658",
  "text" : "RT @ProPublica: Abuse, no rights at Chicago PD secret interrogation facility equivalent of a CIA \"black site\" \nhttp:\/\/t.co\/s6c0NrjIj2 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ProPublica\/status\/570284275645292545\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/gHe3uQPSIJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-oOhvBUEAA0sh6.png",
        "id_str" : "570284275536236544",
        "id" : 570284275536236544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-oOhvBUEAA0sh6.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 101,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 609
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 609
        } ],
        "display_url" : "pic.twitter.com\/gHe3uQPSIJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/s6c0NrjIj2",
        "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2015\/feb\/24\/chicago-police-detain-americans-black-site",
        "display_url" : "theguardian.com\/us-news\/2015\/f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570284275645292545",
    "text" : "Abuse, no rights at Chicago PD secret interrogation facility equivalent of a CIA \"black site\" \nhttp:\/\/t.co\/s6c0NrjIj2 http:\/\/t.co\/gHe3uQPSIJ",
    "id" : 570284275645292545,
    "created_at" : "2015-02-24 18:09:01 +0000",
    "user" : {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "protected" : false,
      "id_str" : "14606079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660147326091182081\/Q4TLW_Fe_normal.jpg",
      "id" : 14606079,
      "verified" : true
    }
  },
  "id" : 570334332436422658,
  "created_at" : "2015-02-24 21:27:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 0, 9 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 10, 19 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 20, 32 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570328304458137600",
  "geo" : { },
  "id_str" : "570331888339910656",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jfhbrook @substack @dominictarr dominic is nothing if not a trendsetter among the cyberhobo set",
  "id" : 570331888339910656,
  "in_reply_to_status_id" : 570328304458137600,
  "created_at" : "2015-02-24 21:18:13 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570312602569613312",
  "text" : "Writing OSS is not a side job, or a passion project. It is not 20% on Friday.  For indie oss devs, it comprises most of our life's work.",
  "id" : 570312602569613312,
  "created_at" : "2015-02-24 20:01:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570311456174043136",
  "geo" : { },
  "id_str" : "570311977609895936",
  "in_reply_to_user_id" : 46961216,
  "text" : "So when one of us asks for real dev money for real dev work, know that this is a real factor.  We have to get money for the droughts.",
  "id" : 570311977609895936,
  "in_reply_to_status_id" : 570311456174043136,
  "created_at" : "2015-02-24 19:59:06 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570311456174043136",
  "text" : "I think one important yet underestimated fact of life as an indie, OSS dev is that it costs real money to stay available &amp; not on contract.",
  "id" : 570311456174043136,
  "created_at" : "2015-02-24 19:57:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570307612710993921",
  "text" : "I have a couple rooms for rent, short or long term, furnished or not, here in Oakland. Beautiful house, wonderful housemates. Nonstop hacks.",
  "id" : 570307612710993921,
  "created_at" : "2015-02-24 19:41:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 19, 28 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570300329713131521",
  "text" : "Nobody can replace @substack but somebody can rent his former bedroom, in this great house.  Ask me how.",
  "id" : 570300329713131521,
  "created_at" : "2015-02-24 19:12:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570299511702216704",
  "text" : "RT @dominictarr: @johnnyscript until you load that description into universe simulator and something evolves and asks: wtf?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "570104627963670529",
    "geo" : { },
    "id_str" : "570170351834963968",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript until you load that description into universe simulator and something evolves and asks: wtf?",
    "id" : 570170351834963968,
    "in_reply_to_status_id" : 570104627963670529,
    "created_at" : "2015-02-24 10:36:19 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712569197126160384\/nvnXBzt-_normal.jpg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 570299511702216704,
  "created_at" : "2015-02-24 19:09:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570132863342878722",
  "geo" : { },
  "id_str" : "570132946847289345",
  "in_reply_to_user_id" : 46961216,
  "text" : "NEVERMIND IT DOESN'T WORK",
  "id" : 570132946847289345,
  "in_reply_to_status_id" : 570132863342878722,
  "created_at" : "2015-02-24 08:07:41 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570132863342878722",
  "text" : "NEW TREND:  SUBTWEET PROMOTWEETS",
  "id" : 570132863342878722,
  "created_at" : "2015-02-24 08:07:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570132627014811648",
  "text" : "GOOD THEN WE SHALL NEVER NEED TO SEE ANOTHER ONE AGAIN. SO WHY WATCH?  FOR THE FOULS?  ITS ALL FOUL WITH PRO SPORTS!",
  "id" : 570132627014811648,
  "created_at" : "2015-02-24 08:06:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570108405991415809",
  "geo" : { },
  "id_str" : "570131884144898048",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs  A demographic !need share culture... But * is complicated by media, consumerism, disintegration,&amp; totalitarian politics, so ttyirl ;^p",
  "id" : 570131884144898048,
  "in_reply_to_status_id" : 570108405991415809,
  "created_at" : "2015-02-24 08:03:28 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570096376333275137",
  "geo" : { },
  "id_str" : "570127815544213505",
  "in_reply_to_user_id" : 104772730,
  "text" : "@realkatbella  AYE!",
  "id" : 570127815544213505,
  "in_reply_to_status_id" : 570096376333275137,
  "created_at" : "2015-02-24 07:47:18 +0000",
  "in_reply_to_screen_name" : "_katbella",
  "in_reply_to_user_id_str" : "104772730",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570108468197085184",
  "geo" : { },
  "id_str" : "570127644416561152",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs  I don't watch television",
  "id" : 570127644416561152,
  "in_reply_to_status_id" : 570108468197085184,
  "created_at" : "2015-02-24 07:46:37 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570104627963670529",
  "text" : "All models of the physical universe are merely descriptions.",
  "id" : 570104627963670529,
  "created_at" : "2015-02-24 06:15:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Leicester",
      "screen_name" : "bigstilton",
      "indices" : [ 3, 14 ],
      "id_str" : "94881676",
      "id" : 94881676
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "randomthought",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570102921154531329",
  "text" : "RT @bigstilton: @johnnyscript Is a vacuum true to its name while photons stream through? #randomthought",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "randomthought",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "570079972099928064",
    "geo" : { },
    "id_str" : "570100068533051392",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript Is a vacuum true to its name while photons stream through? #randomthought",
    "id" : 570100068533051392,
    "in_reply_to_status_id" : 570079972099928064,
    "created_at" : "2015-02-24 05:57:02 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Chris Leicester",
      "screen_name" : "bigstilton",
      "protected" : false,
      "id_str" : "94881676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561915968\/Crazy_Chris_Profile_Picture_normal.jpg",
      "id" : 94881676,
      "verified" : false
    }
  },
  "id" : 570102921154531329,
  "created_at" : "2015-02-24 06:08:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570095600374403072",
  "text" : "I'll shutup now.",
  "id" : 570095600374403072,
  "created_at" : "2015-02-24 05:39:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570088381863997440",
  "geo" : { },
  "id_str" : "570092543301431296",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs   That reads more like a definition of \"demographic\", to me.  And but I agree white people should change their TV viewing habits.",
  "id" : 570092543301431296,
  "in_reply_to_status_id" : 570088381863997440,
  "created_at" : "2015-02-24 05:27:08 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570088056436314113",
  "text" : "As for me, I am willing.",
  "id" : 570088056436314113,
  "created_at" : "2015-02-24 05:09:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570086871541223424",
  "text" : "Unless you are willing to have your every action scrutinized, focus on what you can do IRL for real people &amp; STFU abt mass\/abstract culture.",
  "id" : 570086871541223424,
  "created_at" : "2015-02-24 05:04:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570053200100917248",
  "geo" : { },
  "id_str" : "570082201506697217",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs  Can you define culture?",
  "id" : 570082201506697217,
  "in_reply_to_status_id" : 570053200100917248,
  "created_at" : "2015-02-24 04:46:03 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OK Council",
      "screen_name" : "OKcouncil",
      "indices" : [ 3, 13 ],
      "id_str" : "414106728",
      "id" : 414106728
    }, {
      "name" : "Abel Guillen",
      "screen_name" : "Abel_Guillen",
      "indices" : [ 100, 113 ],
      "id_str" : "14319867",
      "id" : 14319867
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/OKcouncil\/status\/568117023592415232\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MwmvocVoSc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-JbbDGCUAAKggX.jpg",
      "id_str" : "568117023247323136",
      "id" : 568117023247323136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-JbbDGCUAAKggX.jpg",
      "sizes" : [ {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 695
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 695
      } ],
      "display_url" : "pic.twitter.com\/MwmvocVoSc"
    } ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "oakmtg",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570081101768585217",
  "text" : "RT @OKcouncil: Oakland renter median income: $34,195\nOakland median rent: $2,124\/mo ($25,488\/yr)\nHT @Abel_Guillen #Oakland #oakmtg http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Abel Guillen",
        "screen_name" : "Abel_Guillen",
        "indices" : [ 85, 98 ],
        "id_str" : "14319867",
        "id" : 14319867
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/OKcouncil\/status\/568117023592415232\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/MwmvocVoSc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-JbbDGCUAAKggX.jpg",
        "id_str" : "568117023247323136",
        "id" : 568117023247323136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-JbbDGCUAAKggX.jpg",
        "sizes" : [ {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 503,
          "resize" : "fit",
          "w" : 695
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 503,
          "resize" : "fit",
          "w" : 695
        } ],
        "display_url" : "pic.twitter.com\/MwmvocVoSc"
      } ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 99, 107 ]
      }, {
        "text" : "oakmtg",
        "indices" : [ 108, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568117023592415232",
    "text" : "Oakland renter median income: $34,195\nOakland median rent: $2,124\/mo ($25,488\/yr)\nHT @Abel_Guillen #Oakland #oakmtg http:\/\/t.co\/MwmvocVoSc",
    "id" : 568117023592415232,
    "created_at" : "2015-02-18 18:37:08 +0000",
    "user" : {
      "name" : "OK Council",
      "screen_name" : "OKcouncil",
      "protected" : false,
      "id_str" : "414106728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660952431610630144\/KETEYrzx_normal.jpg",
      "id" : 414106728,
      "verified" : false
    }
  },
  "id" : 570081101768585217,
  "created_at" : "2015-02-24 04:41:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570079972099928064",
  "text" : "ENTROPY DOES NOT EXIST IN A VACUUM",
  "id" : 570079972099928064,
  "created_at" : "2015-02-24 04:37:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570027191020494848",
  "text" : "It is is some kind of funny that, vertically, our eyes are really in the middle of our skull\/head\/face, and that hair hides this fact.",
  "id" : 570027191020494848,
  "created_at" : "2015-02-24 01:07:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OaklandAnimalShelter",
      "screen_name" : "oaklandsanimals",
      "indices" : [ 3, 19 ],
      "id_str" : "50572752",
      "id" : 50572752
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/oaklandsanimals\/status\/569987088931692545\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/k2kK8fpu2P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-kAPKYCIAA8ZRy.jpg",
      "id_str" : "569987088322273280",
      "id" : 569987088322273280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-kAPKYCIAA8ZRy.jpg",
      "sizes" : [ {
        "h" : 735,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1393
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/k2kK8fpu2P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570006978908581888",
  "text" : "RT @oaklandsanimals: Great art and adoptable pets -with no adoption fee- all Feb at OAS! Pepper by artist David Polka! http:\/\/t.co\/k2kK8fpu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/oaklandsanimals\/status\/569987088931692545\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/k2kK8fpu2P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-kAPKYCIAA8ZRy.jpg",
        "id_str" : "569987088322273280",
        "id" : 569987088322273280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-kAPKYCIAA8ZRy.jpg",
        "sizes" : [ {
          "h" : 735,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1393
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/k2kK8fpu2P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569987088931692545",
    "text" : "Great art and adoptable pets -with no adoption fee- all Feb at OAS! Pepper by artist David Polka! http:\/\/t.co\/k2kK8fpu2P",
    "id" : 569987088931692545,
    "created_at" : "2015-02-23 22:28:06 +0000",
    "user" : {
      "name" : "OaklandAnimalShelter",
      "screen_name" : "oaklandsanimals",
      "protected" : false,
      "id_str" : "50572752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722824688137711616\/imQ1OyhV_normal.jpg",
      "id" : 50572752,
      "verified" : false
    }
  },
  "id" : 570006978908581888,
  "created_at" : "2015-02-23 23:47:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569996935081238529",
  "geo" : { },
  "id_str" : "570006662272188416",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr   the other is a curse.  not to the creator, but the rest of us, who mus hear about it.  especially john cage's music.",
  "id" : 570006662272188416,
  "in_reply_to_status_id" : 569996935081238529,
  "created_at" : "2015-02-23 23:45:53 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569930895076896768",
  "text" : "If you are trying to convince people, no matter what, you must learn to write well. I know they don't teach that in college, but no excuses.",
  "id" : 569930895076896768,
  "created_at" : "2015-02-23 18:44:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569925213946716161",
  "text" : "All this cultural criticism making generalizations and supporting it with anecdotes is like you learned to think and write watching FOXNEWS.",
  "id" : 569925213946716161,
  "created_at" : "2015-02-23 18:22:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kelsey",
      "screen_name" : "kelseyinnis",
      "indices" : [ 0, 12 ],
      "id_str" : "3222708420",
      "id" : 3222708420
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 13, 22 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569906948025397248",
  "geo" : { },
  "id_str" : "569924626257547264",
  "in_reply_to_user_id" : 435236587,
  "text" : "@kelseyinnis @maxogden  That MVC essay is some bad grade garbage!  Opens w\/ gross generalization, supports it with personal anecdotes.",
  "id" : 569924626257547264,
  "in_reply_to_status_id" : 569906948025397248,
  "created_at" : "2015-02-23 18:19:54 +0000",
  "in_reply_to_screen_name" : "_K_E_L_S_E_Y",
  "in_reply_to_user_id_str" : "435236587",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569915077895139329",
  "geo" : { },
  "id_str" : "569916353777262592",
  "in_reply_to_user_id" : 46961216,
  "text" : "If you target generalizations, ie subjects, you are hitting everybody with chaff, including your supposed allies, as well as potential ones.",
  "id" : 569916353777262592,
  "in_reply_to_status_id" : 569915077895139329,
  "created_at" : "2015-02-23 17:47:01 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569915077895139329",
  "geo" : { },
  "id_str" : "569915913144705025",
  "in_reply_to_user_id" : 46961216,
  "text" : "Use the power of objectification.  Target individuals, companies, groups.  Decrease their appeal to mimesis.",
  "id" : 569915913144705025,
  "in_reply_to_status_id" : 569915077895139329,
  "created_at" : "2015-02-23 17:45:16 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569913894811996160",
  "geo" : { },
  "id_str" : "569915077895139329",
  "in_reply_to_user_id" : 46961216,
  "text" : "It is amazing to me that so much cultural criticism are generalizations.  Like, didn't we learn that is a bad thing to do a long time ago?",
  "id" : 569915077895139329,
  "in_reply_to_status_id" : 569913894811996160,
  "created_at" : "2015-02-23 17:41:57 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569913894811996160",
  "text" : "I wish there was less cultural criticism in my feed.  Please switch to cultural review instead.  Pick at actual objects, not broad subjects.",
  "id" : 569913894811996160,
  "created_at" : "2015-02-23 17:37:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drollery",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569907857283354624",
  "text" : "while looking through my spam folder, all gmail ads are for spam recipes #drollery",
  "id" : 569907857283354624,
  "created_at" : "2015-02-23 17:13:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 32, 45 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569893177106128896",
  "text" : "RT @marinakukso: when you're at @johnnyscript's house, excellent live music comes to YOU.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 15, 28 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569710782809661440",
    "text" : "when you're at @johnnyscript's house, excellent live music comes to YOU.",
    "id" : 569710782809661440,
    "created_at" : "2015-02-23 04:10:09 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 569893177106128896,
  "created_at" : "2015-02-23 16:14:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569710782809661440",
  "geo" : { },
  "id_str" : "569893165898952704",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  toot toot &lt;3",
  "id" : 569893165898952704,
  "in_reply_to_status_id" : 569710782809661440,
  "created_at" : "2015-02-23 16:14:53 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569579983472959488",
  "text" : "All workplaces are a competition to the top, a pyramid scheme, bosses, managers, authority.  In such an environment, expect bad behaviors.",
  "id" : 569579983472959488,
  "created_at" : "2015-02-22 19:30:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "keri",
      "screen_name" : "kerihw",
      "indices" : [ 3, 10 ],
      "id_str" : "43328711",
      "id" : 43328711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569560570703138816",
  "text" : "RT @kerihw: A bunch of old white guys have decided what the best movies of 2014 were, those results right after we criticise what the women\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569551899747323904",
    "text" : "A bunch of old white guys have decided what the best movies of 2014 were, those results right after we criticise what the women are wearing.",
    "id" : 569551899747323904,
    "created_at" : "2015-02-22 17:38:49 +0000",
    "user" : {
      "name" : "keri",
      "screen_name" : "kerihw",
      "protected" : false,
      "id_str" : "43328711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614691805259546624\/aVoodwVj_normal.jpg",
      "id" : 43328711,
      "verified" : false
    }
  },
  "id" : 569560570703138816,
  "created_at" : "2015-02-22 18:13:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569348304569376769",
  "text" : "a sound system is the only system",
  "id" : 569348304569376769,
  "created_at" : "2015-02-22 04:09:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JusticeforYuvette",
      "indices" : [ 20, 38 ]
    }, {
      "text" : "BlackLivesMatter",
      "indices" : [ 88, 105 ]
    }, {
      "text" : "oakland",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "berkeley",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/9sYvE5b2eu",
      "expanded_url" : "https:\/\/occupyoakland.org\/ai1ec_event\/action-memory-yvette-henderson\/?instance_id=281493",
      "display_url" : "occupyoakland.org\/ai1ec_event\/ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569253354989158400",
  "text" : "checkin this tag rn #JusticeforYuvette\n \nbackground info here: https:\/\/t.co\/9sYvE5b2eu\n\n#BlackLivesMatter #oakland #berkeley",
  "id" : 569253354989158400,
  "created_at" : "2015-02-21 21:52:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569250763731443713",
  "text" : "None of that paranoid shit about pit bulls is true.  They are dogs &lt;3  \n\nIt amazes me that even dogowners can be so ignorant. No it doesn't.",
  "id" : 569250763731443713,
  "created_at" : "2015-02-21 21:42:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/geONEhcZsy",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Bp4tGTNNi1I",
      "display_url" : "youtube.com\/watch?v=Bp4tGT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569229236810092544",
  "text" : "RT @marinakukso: the amazing do nothing machine at the museum of craftsmanship https:\/\/t.co\/geONEhcZsy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/geONEhcZsy",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Bp4tGTNNi1I",
        "display_url" : "youtube.com\/watch?v=Bp4tGT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "569220487605149697",
    "text" : "the amazing do nothing machine at the museum of craftsmanship https:\/\/t.co\/geONEhcZsy",
    "id" : 569220487605149697,
    "created_at" : "2015-02-21 19:41:54 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 569229236810092544,
  "created_at" : "2015-02-21 20:16:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569214459392077824",
  "text" : "Unless you are honeypotting, beware emulating what you are trying to subvert.",
  "id" : 569214459392077824,
  "created_at" : "2015-02-21 19:17:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569002605780664321",
  "text" : "Be on the feel out for momentous occasions.",
  "id" : 569002605780664321,
  "created_at" : "2015-02-21 05:16:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569000476378673152",
  "text" : "How much entropy does it take to prevent them from getting to the tootsie roll center?",
  "id" : 569000476378673152,
  "created_at" : "2015-02-21 05:07:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/fAhWtVwipw",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Multiple_dispatch",
      "display_url" : "en.wikipedia.org\/wiki\/Multiple_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568984854437584896",
  "text" : "I don't know what to think about \"multiple dispatch\" until I try it, but I like to think what I think until then.  http:\/\/t.co\/fAhWtVwipw",
  "id" : 568984854437584896,
  "created_at" : "2015-02-21 04:05:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568976415057580032",
  "text" : "RT @marinakukso: everything is fucked. anyone know what to do?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568975358785032192",
    "text" : "everything is fucked. anyone know what to do?",
    "id" : 568975358785032192,
    "created_at" : "2015-02-21 03:27:51 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 568976415057580032,
  "created_at" : "2015-02-21 03:32:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 0, 9 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568576439492186114",
  "geo" : { },
  "id_str" : "568585502535737344",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jfhbrook I tried that, but got the following error, pls advise: \nNo manual entry for fuck\nNo manual entry for computers",
  "id" : 568585502535737344,
  "in_reply_to_status_id" : 568576439492186114,
  "created_at" : "2015-02-20 01:38:42 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568582385790377984",
  "geo" : { },
  "id_str" : "568584901940760576",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  altho I thought it was gonna say \"....so that german scientists would realize they were losing.\"",
  "id" : 568584901940760576,
  "in_reply_to_status_id" : 568582385790377984,
  "created_at" : "2015-02-20 01:36:19 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568582385790377984",
  "geo" : { },
  "id_str" : "568584681685254144",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr haha,  \"the problem was proposed to be dropped over Germany so that German scientists 'could also waste their time on it'.\"",
  "id" : 568584681685254144,
  "in_reply_to_status_id" : 568582385790377984,
  "created_at" : "2015-02-20 01:35:26 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 3, 11 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/fw56k0FRYV",
      "expanded_url" : "http:\/\/mzl.la\/1K55aRm",
      "display_url" : "mzl.la\/1K55aRm"
    } ]
  },
  "geo" : { },
  "id_str" : "568570207045709825",
  "text" : "RT @Gyselie: I just took action to protect net neutrality. The FCC votes soon! Take action here: http:\/\/t.co\/fw56k0FRYV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/fw56k0FRYV",
        "expanded_url" : "http:\/\/mzl.la\/1K55aRm",
        "display_url" : "mzl.la\/1K55aRm"
      } ]
    },
    "geo" : { },
    "id_str" : "568539353355403264",
    "text" : "I just took action to protect net neutrality. The FCC votes soon! Take action here: http:\/\/t.co\/fw56k0FRYV",
    "id" : 568539353355403264,
    "created_at" : "2015-02-19 22:35:19 +0000",
    "user" : {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "protected" : false,
      "id_str" : "433715578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469656620155154432\/1XOA8tYu_normal.jpeg",
      "id" : 433715578,
      "verified" : false
    }
  },
  "id" : 568570207045709825,
  "created_at" : "2015-02-20 00:37:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/ai0vDAd5aG",
      "expanded_url" : "https:\/\/htmlb.in",
      "display_url" : "htmlb.in"
    } ]
  },
  "geo" : { },
  "id_str" : "568521859806801921",
  "text" : "htmlb is the future of application publishing  https:\/\/t.co\/ai0vDAd5aG",
  "id" : 568521859806801921,
  "created_at" : "2015-02-19 21:25:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/XTfx4JPA4k",
      "expanded_url" : "https:\/\/afa37e10e5c52f0080a752f1f63b0abb0c50d0f5.htmlb.in\/",
      "display_url" : "\u20262f0080a752f1f63b0abb0c50d0f5.htmlb.in"
    } ]
  },
  "in_reply_to_status_id_str" : "568521199862431744",
  "geo" : { },
  "id_str" : "568521442335174656",
  "in_reply_to_user_id" : 46961216,
  "text" : "which see this colorful circle-circle intersection test I made, now with moar circles https:\/\/t.co\/XTfx4JPA4k",
  "id" : 568521442335174656,
  "in_reply_to_status_id" : 568521199862431744,
  "created_at" : "2015-02-19 21:24:09 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/RPSQwgWtDy",
      "expanded_url" : "http:\/\/paperjs.org\/",
      "display_url" : "paperjs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "568521199862431744",
  "text" : "I have always like this lib, cuz it implements vectors and mouse events on polygons n stuff in canvas http:\/\/t.co\/RPSQwgWtDy",
  "id" : 568521199862431744,
  "created_at" : "2015-02-19 21:23:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568474057080836097",
  "text" : "all is mimesis with humanity",
  "id" : 568474057080836097,
  "created_at" : "2015-02-19 18:15:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Levine",
      "screen_name" : "thomaslevine",
      "indices" : [ 0, 13 ],
      "id_str" : "14256979",
      "id" : 14256979
    }, {
      "name" : "Zippo",
      "screen_name" : "Zippo",
      "indices" : [ 14, 20 ],
      "id_str" : "20722965",
      "id" : 20722965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568418701151748096",
  "geo" : { },
  "id_str" : "568466313997201409",
  "in_reply_to_user_id" : 14256979,
  "text" : "@thomaslevine @Zippo  In a size way too big?  At \"Just for Hobos\"?",
  "id" : 568466313997201409,
  "in_reply_to_status_id" : 568418701151748096,
  "created_at" : "2015-02-19 17:45:05 +0000",
  "in_reply_to_screen_name" : "thomaslevine",
  "in_reply_to_user_id_str" : "14256979",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "unmet dependency",
      "screen_name" : "shamakry",
      "indices" : [ 0, 9 ],
      "id_str" : "16900280",
      "id" : 16900280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568463849378029569",
  "geo" : { },
  "id_str" : "568464945001533440",
  "in_reply_to_user_id" : 16900280,
  "text" : "@shamakry  I am of the opinion that the very idea of OSS still needs to be peddled.",
  "id" : 568464945001533440,
  "in_reply_to_status_id" : 568463849378029569,
  "created_at" : "2015-02-19 17:39:39 +0000",
  "in_reply_to_screen_name" : "shamakry",
  "in_reply_to_user_id_str" : "16900280",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568464710686760960",
  "text" : "javascribble",
  "id" : 568464710686760960,
  "created_at" : "2015-02-19 17:38:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 0, 8 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/LKyKAXlEKO",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Equestrian_statue#Hoof-position_symbolism",
      "display_url" : "en.wikipedia.org\/wiki\/Equestria\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "568235213723033601",
  "geo" : { },
  "id_str" : "568258063544659968",
  "in_reply_to_user_id" : 4784511,
  "text" : "@bigeasy  but... he didn't die in battle  http:\/\/t.co\/LKyKAXlEKO",
  "id" : 568258063544659968,
  "in_reply_to_status_id" : 568235213723033601,
  "created_at" : "2015-02-19 03:57:34 +0000",
  "in_reply_to_screen_name" : "bigeasy",
  "in_reply_to_user_id_str" : "4784511",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 1, 8 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ahem",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568161085938741248",
  "geo" : { },
  "id_str" : "568168995674722304",
  "in_reply_to_user_id" : 110396781,
  "text" : ".@ajplus  also governments  #ahem",
  "id" : 568168995674722304,
  "in_reply_to_status_id" : 568161085938741248,
  "created_at" : "2015-02-18 22:03:39 +0000",
  "in_reply_to_screen_name" : "ajplus",
  "in_reply_to_user_id_str" : "110396781",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568159915459547136",
  "text" : "im considering offering intro web dev classes at the local park building.  problem is i have to guess at the best format.  long, short, etc.",
  "id" : 568159915459547136,
  "created_at" : "2015-02-18 21:27:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568106432836419584",
  "text" : "come live in hackistan,  we are looking for 2 roommates",
  "id" : 568106432836419584,
  "created_at" : "2015-02-18 17:55:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568102699603865600",
  "text" : "lol if yr company is trying to attract hackers with retirement plans",
  "id" : 568102699603865600,
  "created_at" : "2015-02-18 17:40:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568093967549509632",
  "text" : "I do not understand why anybody wishing to hire software developers would make the application process the least bit annoying.",
  "id" : 568093967549509632,
  "created_at" : "2015-02-18 17:05:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567885302515175425",
  "text" : "debajo de mi sombrero amarillo, que tengo?\ndebajo de mi sombrero amarillo, que tengo?\ntengo un grand cerebro debajo mi sombrero.",
  "id" : 567885302515175425,
  "created_at" : "2015-02-18 03:16:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567880500586479619",
  "text" : "only bass and polyrhythms soothe my soul",
  "id" : 567880500586479619,
  "created_at" : "2015-02-18 02:57:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567872842420736000",
  "geo" : { },
  "id_str" : "567879830265417728",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove  it's not because every iphone has its own vehicle?",
  "id" : 567879830265417728,
  "in_reply_to_status_id" : 567872842420736000,
  "created_at" : "2015-02-18 02:54:36 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567879383098073088",
  "text" : "IM AN ADOLT",
  "id" : 567879383098073088,
  "created_at" : "2015-02-18 02:52:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "jenny ryan",
      "screen_name" : "tunabananas",
      "indices" : [ 13, 25 ],
      "id_str" : "16680003",
      "id" : 16680003
    }, {
      "name" : "Maximilian Klein",
      "screen_name" : "notconfusing",
      "indices" : [ 26, 39 ],
      "id_str" : "286504285",
      "id" : 286504285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567871372564647937",
  "geo" : { },
  "id_str" : "567875514007822336",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso @tunabananas @notconfusing   mostly I am against theatre that is not momentus.  I heart shakespeare.  I disheart actors.",
  "id" : 567875514007822336,
  "in_reply_to_status_id" : 567871372564647937,
  "created_at" : "2015-02-18 02:37:27 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "jenny ryan",
      "screen_name" : "tunabananas",
      "indices" : [ 13, 25 ],
      "id_str" : "16680003",
      "id" : 16680003
    }, {
      "name" : "Maximilian Klein",
      "screen_name" : "notconfusing",
      "indices" : [ 26, 39 ],
      "id_str" : "286504285",
      "id" : 286504285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567871372564647937",
  "geo" : { },
  "id_str" : "567874781166440448",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso @tunabananas @notconfusing  I confess.  I played Juliet.",
  "id" : 567874781166440448,
  "in_reply_to_status_id" : 567871372564647937,
  "created_at" : "2015-02-18 02:34:33 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567863852471169025",
  "text" : "My new name is Arabic Poopbutt.",
  "id" : 567863852471169025,
  "created_at" : "2015-02-18 01:51:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567863753426862080",
  "text" : "Have I ever experience positive feedback in my life?  How would I know?",
  "id" : 567863753426862080,
  "created_at" : "2015-02-18 01:50:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567854898773024768",
  "text" : "Do you know somebody looking for housing in Oakland?  We have rooms open in our haxxor house.  Short or long term.",
  "id" : 567854898773024768,
  "created_at" : "2015-02-18 01:15:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567853770849144832",
  "text" : "I recently watched the first Rambo movie, First Blood, wherein Rambo, a homeless war vet, is harassed, detained and abused by asshole cops.",
  "id" : 567853770849144832,
  "created_at" : "2015-02-18 01:11:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maximilian Klein",
      "screen_name" : "notconfusing",
      "indices" : [ 0, 13 ],
      "id_str" : "286504285",
      "id" : 286504285
    }, {
      "name" : "Omni Commons",
      "screen_name" : "omnicommons",
      "indices" : [ 14, 26 ],
      "id_str" : "2476635312",
      "id" : 2476635312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567772744758992896",
  "geo" : { },
  "id_str" : "567815939179192320",
  "in_reply_to_user_id" : 286504285,
  "text" : "@notconfusing @omnicommons  oh gawd why did this have to happen at the OMNI",
  "id" : 567815939179192320,
  "in_reply_to_status_id" : 567772744758992896,
  "created_at" : "2015-02-17 22:40:44 +0000",
  "in_reply_to_screen_name" : "notconfusing",
  "in_reply_to_user_id_str" : "286504285",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/567814617289789440\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ri7fcWZDVC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-FIYrTCAAAO5-I.png",
      "id_str" : "567814616802000896",
      "id" : 567814616802000896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-FIYrTCAAAO5-I.png",
      "sizes" : [ {
        "h" : 574,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ri7fcWZDVC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567814617289789440",
  "text" : "check out this caricature of the united states government.  \"wirtschaft\"  is german for education. http:\/\/t.co\/ri7fcWZDVC",
  "id" : 567814617289789440,
  "created_at" : "2015-02-17 22:35:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Hanley",
      "screen_name" : "hanleybrand",
      "indices" : [ 0, 12 ],
      "id_str" : "218105056",
      "id" : 218105056
    }, {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 13, 22 ],
      "id_str" : "16891384",
      "id" : 16891384
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 23, 27 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567768805603282945",
  "geo" : { },
  "id_str" : "567769573170147328",
  "in_reply_to_user_id" : 218105056,
  "text" : "@hanleybrand @KentBeck @izs true. knowing that humans, like you, need sanctuary, is empathy. but that doesn't make u a house builder either.",
  "id" : 567769573170147328,
  "in_reply_to_status_id" : 567768805603282945,
  "created_at" : "2015-02-17 19:36:29 +0000",
  "in_reply_to_screen_name" : "hanleybrand",
  "in_reply_to_user_id_str" : "218105056",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567768804807208960",
  "text" : "I just wondered if it is a good idea to liberate people who are thoroughly brainwashed consumers harboring get-rich-and-famous fantasies.",
  "id" : 567768804807208960,
  "created_at" : "2015-02-17 19:33:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567766762431606784",
  "text" : "It is too late for the US.  By the time these animals make good on their demands, their demands will be as feebly consumerist as ever.",
  "id" : 567766762431606784,
  "created_at" : "2015-02-17 19:25:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Demos",
      "screen_name" : "Demos_Org",
      "indices" : [ 3, 13 ],
      "id_str" : "17086475",
      "id" : 17086475
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Demos_Org\/status\/567750583717986304\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/dox3IXVb6s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EOJb0CMAE3XGH.png",
      "id_str" : "567750583273009153",
      "id" : 567750583273009153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EOJb0CMAE3XGH.png",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/dox3IXVb6s"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/aJi8OtSUXj",
      "expanded_url" : "http:\/\/america.aljazeera.com\/opinions\/2015\/2\/new-evidence-suggests-that-the-rich-own-our-democracy.html",
      "display_url" : "america.aljazeera.com\/opinions\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567766261398040576",
  "text" : "RT @Demos_Org: Senators are almost perfectly aligned with their donors, but distant from voters. http:\/\/t.co\/aJi8OtSUXj http:\/\/t.co\/dox3IXV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Demos_Org\/status\/567750583717986304\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/dox3IXVb6s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EOJb0CMAE3XGH.png",
        "id_str" : "567750583273009153",
        "id" : 567750583273009153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EOJb0CMAE3XGH.png",
        "sizes" : [ {
          "h" : 370,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/dox3IXVb6s"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/aJi8OtSUXj",
        "expanded_url" : "http:\/\/america.aljazeera.com\/opinions\/2015\/2\/new-evidence-suggests-that-the-rich-own-our-democracy.html",
        "display_url" : "america.aljazeera.com\/opinions\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "567750583717986304",
    "text" : "Senators are almost perfectly aligned with their donors, but distant from voters. http:\/\/t.co\/aJi8OtSUXj http:\/\/t.co\/dox3IXVb6s",
    "id" : 567750583717986304,
    "created_at" : "2015-02-17 18:21:02 +0000",
    "user" : {
      "name" : "Demos",
      "screen_name" : "Demos_Org",
      "protected" : false,
      "id_str" : "17086475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615523850399391744\/ziYMzIOb_normal.png",
      "id" : 17086475,
      "verified" : true
    }
  },
  "id" : 567766261398040576,
  "created_at" : "2015-02-17 19:23:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567765299420602370",
  "text" : "I tried to buy little papers from a corner store in the USA, but I guess a federal agent was behind the counter, and I didn't have my ID.",
  "id" : 567765299420602370,
  "created_at" : "2015-02-17 19:19:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567764617105039361",
  "text" : "Meditate on this. Are you an arm of the state?  Fuck you!",
  "id" : 567764617105039361,
  "created_at" : "2015-02-17 19:16:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567764332034990080",
  "text" : "OH  \"this is a cannabis club, it's more serious than airport security.\"",
  "id" : 567764332034990080,
  "created_at" : "2015-02-17 19:15:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567764048600649728",
  "text" : "What has it come to that a ugly teenager behind a counter is the arbiter of valid identification? That every citizen is an arm of the state?",
  "id" : 567764048600649728,
  "created_at" : "2015-02-17 19:14:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 0, 15 ],
      "id_str" : "283708113",
      "id" : 283708113
    }, {
      "name" : "audibletreats",
      "screen_name" : "audibletreats",
      "indices" : [ 16, 30 ],
      "id_str" : "7911062",
      "id" : 7911062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567753761578561536",
  "geo" : { },
  "id_str" : "567755367283576832",
  "in_reply_to_user_id" : 283708113,
  "text" : "@brownnoiseblog @audibletreats  thank you for blogging!",
  "id" : 567755367283576832,
  "in_reply_to_status_id" : 567753761578561536,
  "created_at" : "2015-02-17 18:40:02 +0000",
  "in_reply_to_screen_name" : "brownnoiseblog",
  "in_reply_to_user_id_str" : "283708113",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "audibletreats",
      "screen_name" : "audibletreats",
      "indices" : [ 0, 14 ],
      "id_str" : "7911062",
      "id" : 7911062
    }, {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 15, 30 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567729432002310144",
  "geo" : { },
  "id_str" : "567753613745729537",
  "in_reply_to_user_id" : 7911062,
  "text" : "@audibletreats @brownnoiseblog  kilt it a long time ago wake up",
  "id" : 567753613745729537,
  "in_reply_to_status_id" : 567729432002310144,
  "created_at" : "2015-02-17 18:33:04 +0000",
  "in_reply_to_screen_name" : "audibletreats",
  "in_reply_to_user_id_str" : "7911062",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567749453228056576",
  "text" : "Oh make an appointment to save yourself time at the DMV.  The next available one is in two months!",
  "id" : 567749453228056576,
  "created_at" : "2015-02-17 18:16:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567749222067388416",
  "geo" : { },
  "id_str" : "567749312495378432",
  "in_reply_to_user_id" : 46961216,
  "text" : "Protest a motherfucking identification card",
  "id" : 567749312495378432,
  "in_reply_to_status_id" : 567749222067388416,
  "created_at" : "2015-02-17 18:15:59 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567749222067388416",
  "text" : "The DMV must make money hand over fist, and it all goes to furthering corruption and hampering us with more laws!",
  "id" : 567749222067388416,
  "created_at" : "2015-02-17 18:15:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567748935230296064",
  "text" : "I refuse to wait several hours to get an ID.  Nothing but fuck words for that shit.",
  "id" : 567748935230296064,
  "created_at" : "2015-02-17 18:14:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/bHSsUhrlOI",
      "expanded_url" : "https:\/\/69856c436a82d0b4ab5eefca96dc278bc35b8fb1.htmlb.in\/",
      "display_url" : "\u2026d0b4ab5eefca96dc278bc35b8fb1.htmlb.in"
    } ]
  },
  "geo" : { },
  "id_str" : "567530834156986368",
  "text" : "I found an old circle collision detection test I made w\/ canvas + paper.js.\n\nhttps:\/\/t.co\/bHSsUhrlOI",
  "id" : 567530834156986368,
  "created_at" : "2015-02-17 03:47:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567451180263936000",
  "text" : "\u0CA7",
  "id" : 567451180263936000,
  "created_at" : "2015-02-16 22:31:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567439519096397824",
  "text" : "education is a cash crop",
  "id" : 567439519096397824,
  "created_at" : "2015-02-16 21:44:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567351068514729985",
  "text" : "Find us in our regular ascii hole",
  "id" : 567351068514729985,
  "created_at" : "2015-02-16 15:53:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567349973369384961",
  "text" : "Components of Chaos",
  "id" : 567349973369384961,
  "created_at" : "2015-02-16 15:49:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567058715568644096",
  "text" : "Lil Bear kept knocking my audio adapter off the table, annoying I, and now me did it, too, so we can empathize.",
  "id" : 567058715568644096,
  "created_at" : "2015-02-15 20:31:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567057555197669376",
  "text" : "this HDMI connection imparts hella noise on the audio out\n\n:    &gt;   (",
  "id" : 567057555197669376,
  "created_at" : "2015-02-15 20:27:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567028271951273984",
  "geo" : { },
  "id_str" : "567053632713924610",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia  the gate is open",
  "id" : 567053632713924610,
  "in_reply_to_status_id" : 567028271951273984,
  "created_at" : "2015-02-15 20:11:36 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 51, 62 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/wmtQTKIarD",
      "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2015\/02\/16\/labyrinth-4",
      "display_url" : "newyorker.com\/magazine\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567025974575775744",
  "text" : "speaking of minotaurs, friend and fiction hustler .@grayamelia got a horn in the new yorker http:\/\/t.co\/wmtQTKIarD",
  "id" : 567025974575775744,
  "created_at" : "2015-02-15 18:21:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567022360079769600",
  "geo" : { },
  "id_str" : "567024310074609665",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia  That's a warning.",
  "id" : 567024310074609665,
  "in_reply_to_status_id" : 567022360079769600,
  "created_at" : "2015-02-15 18:15:04 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567022078709075970",
  "text" : "a bug that was practically inconceivable to reason about yesterday is buttered nuts today, and it was b\/c of muscle soreness and fatigue.",
  "id" : 567022078709075970,
  "created_at" : "2015-02-15 18:06:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567018973779095553",
  "geo" : { },
  "id_str" : "567019704368132096",
  "in_reply_to_user_id" : 46961216,
  "text" : "As was said in Oakland so it is said again, the hippy revolution is over.",
  "id" : 567019704368132096,
  "in_reply_to_status_id" : 567018973779095553,
  "created_at" : "2015-02-15 17:56:46 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Roxberry",
      "screen_name" : "infosecdev",
      "indices" : [ 0, 11 ],
      "id_str" : "3047022791",
      "id" : 3047022791
    }, {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 12, 21 ],
      "id_str" : "16891384",
      "id" : 16891384
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 22, 26 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566983670977036288",
  "geo" : { },
  "id_str" : "567019398133583873",
  "in_reply_to_user_id" : 11380912,
  "text" : "@infosecdev @KentBeck @izs  for our creations are us, therefore we may have empathy for them.",
  "id" : 567019398133583873,
  "in_reply_to_status_id" : 566983670977036288,
  "created_at" : "2015-02-15 17:55:33 +0000",
  "in_reply_to_screen_name" : "skiptrace_",
  "in_reply_to_user_id_str" : "11380912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567018973779095553",
  "text" : "We went from flower mamas and flower children, to problem mamas and problem children.",
  "id" : 567018973779095553,
  "created_at" : "2015-02-15 17:53:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/Lsij9NZ7GJ",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Argument_from_fallacy",
      "display_url" : "en.wikipedia.org\/wiki\/Argument_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566858541600759809",
  "text" : "This is my new defence http:\/\/t.co\/Lsij9NZ7GJ",
  "id" : 566858541600759809,
  "created_at" : "2015-02-15 07:16:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566659324907249664",
  "text" : "A hard candy coated shell, with chocolate inside, and a big data center.",
  "id" : 566659324907249664,
  "created_at" : "2015-02-14 18:04:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566650778366918657",
  "text" : "RT @TheHatGhost: @johnnyscript once again big ag is solving the important problems",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "566503324573106178",
    "geo" : { },
    "id_str" : "566582650107080705",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript once again big ag is solving the important problems",
    "id" : 566582650107080705,
    "in_reply_to_status_id" : 566503324573106178,
    "created_at" : "2015-02-14 13:00:05 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606927351168036864\/lzGOA4HX_normal.jpg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 566650778366918657,
  "created_at" : "2015-02-14 17:30:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566503324573106178",
  "text" : "The government on Friday approved planting of genetically engineered apples that are resistant to turning brown when sliced.  You're next.",
  "id" : 566503324573106178,
  "created_at" : "2015-02-14 07:44:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566498891076362241",
  "text" : "\"explicit lyrics\" is the label for the strong over use of few generic word sounds.",
  "id" : 566498891076362241,
  "created_at" : "2015-02-14 07:27:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayson Musson",
      "screen_name" : "therealhennessy",
      "indices" : [ 3, 19 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/therealhennessy\/status\/566490292573196288\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/3gGoarWEYw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9yT6rbCYAQn1xG.jpg",
      "id_str" : "566490289439662084",
      "id" : 566490289439662084,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9yT6rbCYAQn1xG.jpg",
      "sizes" : [ {
        "h" : 297,
        "resize" : "fit",
        "w" : 216
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 216
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 216
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 216
      } ],
      "display_url" : "pic.twitter.com\/3gGoarWEYw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566497068999389185",
  "text" : "RT @therealhennessy: when u at the club but all u wanna do is go home and try out the new paper shredder u got on amazon http:\/\/t.co\/3gGoar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/therealhennessy\/status\/566490292573196288\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/3gGoarWEYw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9yT6rbCYAQn1xG.jpg",
        "id_str" : "566490289439662084",
        "id" : 566490289439662084,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9yT6rbCYAQn1xG.jpg",
        "sizes" : [ {
          "h" : 297,
          "resize" : "fit",
          "w" : 216
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 216
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 216
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 216
        } ],
        "display_url" : "pic.twitter.com\/3gGoarWEYw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566490292573196288",
    "text" : "when u at the club but all u wanna do is go home and try out the new paper shredder u got on amazon http:\/\/t.co\/3gGoarWEYw",
    "id" : 566490292573196288,
    "created_at" : "2015-02-14 06:53:05 +0000",
    "user" : {
      "name" : "Jayson Musson",
      "screen_name" : "therealhennessy",
      "protected" : false,
      "id_str" : "137090436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710908032515964928\/7_bdCSc4_normal.jpg",
      "id" : 137090436,
      "verified" : false
    }
  },
  "id" : 566497068999389185,
  "created_at" : "2015-02-14 07:20:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566496258932473857",
  "text" : "i could be rilly clever, rilly functional, or rilly practical.  I chose an event emitter.  \/me wipes hands",
  "id" : 566496258932473857,
  "created_at" : "2015-02-14 07:16:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 0, 9 ],
      "id_str" : "16891384",
      "id" : 16891384
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 10, 14 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/g97V7y04jW",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/53922193771d0cb94b92",
      "display_url" : "gist.github.com\/NHQ\/5392219377\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566469417492443136",
  "in_reply_to_user_id" : 16891384,
  "text" : "@KentBeck @izs\n\nFor your consideration, some text regarding empathy, craft, and kung foo.  Lo siento mucho.\n\nhttps:\/\/t.co\/g97V7y04jW",
  "id" : 566469417492443136,
  "created_at" : "2015-02-14 05:30:08 +0000",
  "in_reply_to_screen_name" : "KentBeck",
  "in_reply_to_user_id_str" : "16891384",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 0, 9 ],
      "id_str" : "16891384",
      "id" : 16891384
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 10, 14 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566420720335339520",
  "geo" : { },
  "id_str" : "566463324250841088",
  "in_reply_to_user_id" : 16891384,
  "text" : "@KentBeck @izs  sportball players... banksters... \"good\" politicians appear to be high empathy &amp; craftless, but are completely the opposite.",
  "id" : 566463324250841088,
  "in_reply_to_status_id" : 566420720335339520,
  "created_at" : "2015-02-14 05:05:55 +0000",
  "in_reply_to_screen_name" : "KentBeck",
  "in_reply_to_user_id_str" : "16891384",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 0, 9 ],
      "id_str" : "16891384",
      "id" : 16891384
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 10, 14 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566324208922529793",
  "geo" : { },
  "id_str" : "566413069002104833",
  "in_reply_to_user_id" : 16891384,
  "text" : "@KentBeck @izs  You can easily find v. obvious cases of low empathy + high craft, in this money motivated world.  Correlation !neccessary.",
  "id" : 566413069002104833,
  "in_reply_to_status_id" : 566324208922529793,
  "created_at" : "2015-02-14 01:46:13 +0000",
  "in_reply_to_screen_name" : "KentBeck",
  "in_reply_to_user_id_str" : "16891384",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 0, 9 ],
      "id_str" : "16891384",
      "id" : 16891384
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 10, 14 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566282712936235008",
  "geo" : { },
  "id_str" : "566317829838745600",
  "in_reply_to_user_id" : 16891384,
  "text" : "@KentBeck @izs  \nGenerally: to learn, grow competent, and master your kung foo.  \nSpecifically: whatsoever the student of the craft choose.",
  "id" : 566317829838745600,
  "in_reply_to_status_id" : 566282712936235008,
  "created_at" : "2015-02-13 19:27:46 +0000",
  "in_reply_to_screen_name" : "KentBeck",
  "in_reply_to_user_id_str" : "16891384",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 3, 11 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bigeasy\/status\/566162944531001344\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/LlPd0WltjQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9tqMrgCAAM2uQr.jpg",
      "id_str" : "566162944233177091",
      "id" : 566162944233177091,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9tqMrgCAAM2uQr.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/LlPd0WltjQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566276764691738624",
  "text" : "RT @bigeasy: Unicorncycle. http:\/\/t.co\/LlPd0WltjQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bigeasy\/status\/566162944531001344\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/LlPd0WltjQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9tqMrgCAAM2uQr.jpg",
        "id_str" : "566162944233177091",
        "id" : 566162944233177091,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9tqMrgCAAM2uQr.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1920,
          "resize" : "fit",
          "w" : 2880
        } ],
        "display_url" : "pic.twitter.com\/LlPd0WltjQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566162944531001344",
    "text" : "Unicorncycle. http:\/\/t.co\/LlPd0WltjQ",
    "id" : 566162944531001344,
    "created_at" : "2015-02-13 09:12:19 +0000",
    "user" : {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "protected" : false,
      "id_str" : "4784511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685849341496561664\/KOzfse57_normal.jpg",
      "id" : 4784511,
      "verified" : false
    }
  },
  "id" : 566276764691738624,
  "created_at" : "2015-02-13 16:44:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 0, 9 ],
      "id_str" : "16891384",
      "id" : 16891384
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 10, 14 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566255102067871744",
  "geo" : { },
  "id_str" : "566276303981006848",
  "in_reply_to_user_id" : 16891384,
  "text" : "@KentBeck @izs  ok empathy is trending and all, yay, but craft = technique, discipline, form.  U can't build house jus cuz u sry 4 homeless.",
  "id" : 566276303981006848,
  "in_reply_to_status_id" : 566255102067871744,
  "created_at" : "2015-02-13 16:42:46 +0000",
  "in_reply_to_screen_name" : "KentBeck",
  "in_reply_to_user_id_str" : "16891384",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/566012126737616897\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/Swapyapxq3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rhB7zCYAIbgKu.jpg",
      "id_str" : "566012126536294402",
      "id" : 566012126536294402,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rhB7zCYAIbgKu.jpg",
      "sizes" : [ {
        "h" : 1045,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Swapyapxq3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566010677400064000",
  "geo" : { },
  "id_str" : "566012126737616897",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript . http:\/\/t.co\/Swapyapxq3",
  "id" : 566012126737616897,
  "in_reply_to_status_id" : 566010677400064000,
  "created_at" : "2015-02-12 23:13:01 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/566010677400064000\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Fy297J6IWE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rftk6CUAEBpTj.jpg",
      "id_str" : "566010677282623489",
      "id" : 566010677282623489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rftk6CUAEBpTj.jpg",
      "sizes" : [ {
        "h" : 1045,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Fy297J6IWE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566010677400064000",
  "text" : "Is Lil Bear brown?\nIs Lil Bear gray?\nLil bear is a disarrayed lenticular prism.\nHappy dog day, bitches. http:\/\/t.co\/Fy297J6IWE",
  "id" : 566010677400064000,
  "created_at" : "2015-02-12 23:07:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Hatmaker",
      "screen_name" : "tayhatmaker",
      "indices" : [ 0, 12 ],
      "id_str" : "14983480",
      "id" : 14983480
    }, {
      "name" : "Kyle Drake",
      "screen_name" : "kyledrake",
      "indices" : [ 13, 23 ],
      "id_str" : "7171612",
      "id" : 7171612
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 24, 32 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565969346443218944",
  "geo" : { },
  "id_str" : "565988294219952128",
  "in_reply_to_user_id" : 14983480,
  "text" : "@tayhatmaker @kyledrake @Spotify  Thanks, but I'm not ready to have ultimate sex yet.",
  "id" : 565988294219952128,
  "in_reply_to_status_id" : 565969346443218944,
  "created_at" : "2015-02-12 21:38:19 +0000",
  "in_reply_to_screen_name" : "tayhatmaker",
  "in_reply_to_user_id_str" : "14983480",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565949534597947394",
  "text" : "Mass media and political monoculture is terribly at odds with the multicultural population of the USA.  Should we ruthlessly purge bigots?",
  "id" : 565949534597947394,
  "created_at" : "2015-02-12 19:04:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565930717146669056",
  "text" : "cointelprocoin",
  "id" : 565930717146669056,
  "created_at" : "2015-02-12 17:49:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 0, 15 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565909133057335297",
  "geo" : { },
  "id_str" : "565929381546041344",
  "in_reply_to_user_id" : 283708113,
  "text" : "@brownnoiseblog  i dont care if it comes with a million newly canned sounds.",
  "id" : 565929381546041344,
  "in_reply_to_status_id" : 565909133057335297,
  "created_at" : "2015-02-12 17:44:13 +0000",
  "in_reply_to_screen_name" : "brownnoiseblog",
  "in_reply_to_user_id_str" : "283708113",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565680761609928704",
  "text" : "I will beat you with my lotus position pitbull fighting style",
  "id" : 565680761609928704,
  "created_at" : "2015-02-12 01:16:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonah Owen Lamb",
      "screen_name" : "jonahowenlamb",
      "indices" : [ 3, 17 ],
      "id_str" : "220118448",
      "id" : 220118448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/P5eR1K8adU",
      "expanded_url" : "http:\/\/www.insidebayarea.com\/breaking-news\/ci_27503550\/berkeley-council-approves-moratorium-certain-police-tactics",
      "display_url" : "insidebayarea.com\/breaking-news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565678368704978944",
  "text" : "RT @jonahowenlamb: Berkeley passes police moratorium tear gas, rubber bullets &amp; over shoulder baton hits after #ferguson protests http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ferguson",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/P5eR1K8adU",
        "expanded_url" : "http:\/\/www.insidebayarea.com\/breaking-news\/ci_27503550\/berkeley-council-approves-moratorium-certain-police-tactics",
        "display_url" : "insidebayarea.com\/breaking-news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565637634882809856",
    "text" : "Berkeley passes police moratorium tear gas, rubber bullets &amp; over shoulder baton hits after #ferguson protests http:\/\/t.co\/P5eR1K8adU",
    "id" : 565637634882809856,
    "created_at" : "2015-02-11 22:24:55 +0000",
    "user" : {
      "name" : "Jonah Owen Lamb",
      "screen_name" : "jonahowenlamb",
      "protected" : false,
      "id_str" : "220118448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700114784646135812\/8zYR8r_b_normal.jpg",
      "id" : 220118448,
      "verified" : false
    }
  },
  "id" : 565678368704978944,
  "created_at" : "2015-02-12 01:06:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565674995419201537",
  "text" : "Causation does not cause correlation.",
  "id" : 565674995419201537,
  "created_at" : "2015-02-12 00:53:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565327448318177281",
  "geo" : { },
  "id_str" : "565330370372329473",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  well that's neat, but you are hiding the real secret.  Tell us how you sailed for years in a single day.",
  "id" : 565330370372329473,
  "in_reply_to_status_id" : 565327448318177281,
  "created_at" : "2015-02-11 02:03:58 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565320603109167104",
  "text" : "imma daobug some code",
  "id" : 565320603109167104,
  "created_at" : "2015-02-11 01:25:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565282876074512388",
  "text" : "are any of you bum hackers willing to be included in my knight fund application?  don't ask questions.",
  "id" : 565282876074512388,
  "created_at" : "2015-02-10 22:55:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 0, 15 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565132101763477504",
  "geo" : { },
  "id_str" : "565133088343064577",
  "in_reply_to_user_id" : 283708113,
  "text" : "@brownnoiseblog  cuz yahoo",
  "id" : 565133088343064577,
  "in_reply_to_status_id" : 565132101763477504,
  "created_at" : "2015-02-10 13:00:02 +0000",
  "in_reply_to_screen_name" : "brownnoiseblog",
  "in_reply_to_user_id_str" : "283708113",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564915369609920513",
  "text" : "RT @TheHatGhost: Is there a \"cycling only\" social media filter I can turn on somewhere?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564900818475032577",
    "text" : "Is there a \"cycling only\" social media filter I can turn on somewhere?",
    "id" : 564900818475032577,
    "created_at" : "2015-02-09 21:37:05 +0000",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606927351168036864\/lzGOA4HX_normal.jpg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 564915369609920513,
  "created_at" : "2015-02-09 22:34:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/bGzfQeE1cG",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/swing-n-on-a-saturday\/",
      "display_url" : "soundcloud.com\/folkstack\/swin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564899931345809408",
  "text" : "+1 if you can bang this in your small to midsize startup office with whiskey and beer on tap https:\/\/t.co\/bGzfQeE1cG",
  "id" : 564899931345809408,
  "created_at" : "2015-02-09 21:33:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 3, 12 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/Qg2xmfdgPL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1IOukA10QeQ",
      "display_url" : "youtube.com\/watch?v=1IOukA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564874803199238144",
  "text" : "RT @maxogden: wow, just wow https:\/\/t.co\/Qg2xmfdgPL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/Qg2xmfdgPL",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1IOukA10QeQ",
        "display_url" : "youtube.com\/watch?v=1IOukA\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564864955208327169",
    "text" : "wow, just wow https:\/\/t.co\/Qg2xmfdgPL",
    "id" : 564864955208327169,
    "created_at" : "2015-02-09 19:14:34 +0000",
    "user" : {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "protected" : false,
      "id_str" : "12241752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706616363599532032\/b5z-Hw5g_normal.jpg",
      "id" : 12241752,
      "verified" : false
    }
  },
  "id" : 564874803199238144,
  "created_at" : "2015-02-09 19:53:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 10, 19 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 20, 29 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/ai0vDAd5aG",
      "expanded_url" : "https:\/\/htmlb.in",
      "display_url" : "htmlb.in"
    }, {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HUg2C1m84s",
      "expanded_url" : "https:\/\/wzrd.in",
      "display_url" : "wzrd.in"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/HXOpYNGjKi",
      "expanded_url" : "https:\/\/a457f4f8ea3b961650e8bb6634447028a77bff2d.htmlb.in\/",
      "display_url" : "\u2026961650e8bb6634447028a77bff2d.htmlb.in"
    } ]
  },
  "in_reply_to_status_id_str" : "564666786294267905",
  "geo" : { },
  "id_str" : "564872538715463681",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @jfhbrook @maxogden and now apps served via https:\/\/t.co\/ai0vDAd5aG can use https:\/\/t.co\/HUg2C1m84s!\n\nlike https:\/\/t.co\/HXOpYNGjKi",
  "id" : 564872538715463681,
  "in_reply_to_status_id" : 564666786294267905,
  "created_at" : "2015-02-09 19:44:42 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 10, 19 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 20, 29 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564666786294267905",
  "geo" : { },
  "id_str" : "564872096258355200",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @jfhbrook @maxogden  \nI bugged and made some CORS posts to '\/' instead of '\/mutli', maybe that did something.  else all good!",
  "id" : 564872096258355200,
  "in_reply_to_status_id" : 564666786294267905,
  "created_at" : "2015-02-09 19:42:57 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mill",
      "screen_name" : "konklone",
      "indices" : [ 0, 9 ],
      "id_str" : "5232171",
      "id" : 5232171
    }, {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 10, 19 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 20, 29 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hbSld06fuX",
      "expanded_url" : "https:\/\/www.npmjs.com\/package\/es666",
      "display_url" : "npmjs.com\/package\/es666"
    } ]
  },
  "in_reply_to_status_id_str" : "564612435160858625",
  "geo" : { },
  "id_str" : "564653844693393408",
  "in_reply_to_user_id" : 5232171,
  "text" : "@konklone @jfhbrook @maxogden  sweet!  I updated my front end async module loader module.  now defaulting to https.\n\nhttps:\/\/t.co\/hbSld06fuX",
  "id" : 564653844693393408,
  "in_reply_to_status_id" : 564612435160858625,
  "created_at" : "2015-02-09 05:15:41 +0000",
  "in_reply_to_screen_name" : "konklone",
  "in_reply_to_user_id_str" : "5232171",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/bGzfQeE1cG",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/swing-n-on-a-saturday\/",
      "display_url" : "soundcloud.com\/folkstack\/swin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564576880448110592",
  "text" : "uhhh and I aint een live code n these new algos yet, im only testing static scripts\n\nhttps:\/\/t.co\/bGzfQeE1cG",
  "id" : 564576880448110592,
  "created_at" : "2015-02-09 00:09:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564574770717413376",
  "geo" : { },
  "id_str" : "564576170167910400",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript of course I am also playing it back thru my stack.  your sounds may vary.",
  "id" : 564576170167910400,
  "in_reply_to_status_id" : 564574770717413376,
  "created_at" : "2015-02-09 00:07:02 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/bGzfQeE1cG",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/swing-n-on-a-saturday\/",
      "display_url" : "soundcloud.com\/folkstack\/swin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564574770717413376",
  "text" : "played out my bespoke bass barrel but recorded through the soundcloud web interface + built in mic.  love it.\n\nhttps:\/\/t.co\/bGzfQeE1cG",
  "id" : 564574770717413376,
  "created_at" : "2015-02-09 00:01:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564574239135920130",
  "text" : "I will be dropping soundcloud soon as I make an awesome web audio band website.  Until then, here comes quick recording of my algoooooooooze",
  "id" : 564574239135920130,
  "created_at" : "2015-02-08 23:59:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564567321113407488",
  "geo" : { },
  "id_str" : "564569723447558144",
  "in_reply_to_user_id" : 46961216,
  "text" : "idk my best guess is that floating point errors are making them resolve to be awesome",
  "id" : 564569723447558144,
  "in_reply_to_status_id" : 564567321113407488,
  "created_at" : "2015-02-08 23:41:25 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564567321113407488",
  "text" : "I'm testing swing(n) musical timing algos I jus wrote.  I'm not certain of how they work yet, but they do be swing(n)!",
  "id" : 564567321113407488,
  "created_at" : "2015-02-08 23:31:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564547780807372800",
  "text" : "I got on the internet and forgot.",
  "id" : 564547780807372800,
  "created_at" : "2015-02-08 22:14:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564547431526723584",
  "text" : "Are there cattle prods in 1984?  There are cattle prods in 2015.  We call them tasers.  Ban cattle prods.  #oakland",
  "id" : 564547431526723584,
  "created_at" : "2015-02-08 22:12:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "curtis b",
      "screen_name" : "cjb007jhx7",
      "indices" : [ 0, 11 ],
      "id_str" : "23910861",
      "id" : 23910861
    }, {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 12, 25 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563977508781957120",
  "geo" : { },
  "id_str" : "563979835542757376",
  "in_reply_to_user_id" : 23910861,
  "text" : "@cjb007jhx7 @occupythemob who can resist playing proxy battle with that oil defense money?  The US can't &amp;&amp; can't expect it's tenant states.",
  "id" : 563979835542757376,
  "in_reply_to_status_id" : 563977508781957120,
  "created_at" : "2015-02-07 08:37:25 +0000",
  "in_reply_to_screen_name" : "cjb007jhx7",
  "in_reply_to_user_id_str" : "23910861",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/563978494976065537\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/bcRGzvn004",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B9Onc84CIAI1Wua.png",
      "id_str" : "563978494170767362",
      "id" : 563978494170767362,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B9Onc84CIAI1Wua.png",
      "sizes" : [ {
        "h" : 130,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 130,
        "resize" : "crop",
        "w" : 130
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 148
      } ],
      "display_url" : "pic.twitter.com\/bcRGzvn004"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563978494976065537",
  "text" : "ha HA http:\/\/t.co\/bcRGzvn004",
  "id" : 563978494976065537,
  "created_at" : "2015-02-07 08:32:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563976837907247104",
  "geo" : { },
  "id_str" : "563977001539608576",
  "in_reply_to_user_id" : 46961216,
  "text" : "This is like accusing Israel of being aggressive with their Military.",
  "id" : 563977001539608576,
  "in_reply_to_status_id" : 563976837907247104,
  "created_at" : "2015-02-07 08:26:10 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/BOXEPnCDHW",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/02\/05\/world\/middleeast\/pre-9-11-ties-haunt-saudis-as-new-accusations-surface.html?smid=tw-nytimes&_r=0",
      "display_url" : "nytimes.com\/2015\/02\/05\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563976837907247104",
  "text" : "look at this, 10's of millions (!!!) from Saudis to al Queda, as if every Saudi \"riyal\" didn't come from a dollar: \n\nhttp:\/\/t.co\/BOXEPnCDHW",
  "id" : 563976837907247104,
  "created_at" : "2015-02-07 08:25:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 0, 13 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563974117561729024",
  "geo" : { },
  "id_str" : "563976105992781824",
  "in_reply_to_user_id" : 341908197,
  "text" : "@occupythemob And?  there was a past, explicit alliance between the US and Saddam Hussein. And also the Taliban! Oil Proxy wars with Russia.",
  "id" : 563976105992781824,
  "in_reply_to_status_id" : 563974117561729024,
  "created_at" : "2015-02-07 08:22:36 +0000",
  "in_reply_to_screen_name" : "AnonyMobLife",
  "in_reply_to_user_id_str" : "341908197",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nodeconf",
      "screen_name" : "nodeconf",
      "indices" : [ 0, 9 ],
      "id_str" : "186697923",
      "id" : 186697923
    }, {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 10, 21 ],
      "id_str" : "15734539",
      "id" : 15734539
    }, {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 22, 29 ],
      "id_str" : "668423",
      "id" : 668423
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 78, 87 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563935222807678976",
  "geo" : { },
  "id_str" : "563972307740155905",
  "in_reply_to_user_id" : 186697923,
  "text" : "@nodeconf @FrozenFire @mikeal  I have long suspected what is shown here, that @substack is a living NPM product placement.",
  "id" : 563972307740155905,
  "in_reply_to_status_id" : 563935222807678976,
  "created_at" : "2015-02-07 08:07:30 +0000",
  "in_reply_to_screen_name" : "nodeconf",
  "in_reply_to_user_id_str" : "186697923",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563970461919227904",
  "text" : "If I can drink this wine like water, am I the anti-christ?",
  "id" : 563970461919227904,
  "created_at" : "2015-02-07 08:00:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563868886269841408",
  "text" : "Hm, Alameda County and CA State gov attach a surcharge fee to strictly local fines (street cleaning violation).  #oakland",
  "id" : 563868886269841408,
  "created_at" : "2015-02-07 01:16:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "indices" : [ 3, 11 ],
      "id_str" : "15665323",
      "id" : 15665323
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/fLXV2rc7IB",
      "expanded_url" : "http:\/\/talkingpointsmemo.com\/theslice\/what-are-cops-really-good-for-a-brief-history",
      "display_url" : "talkingpointsmemo.com\/theslice\/what-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563819880344866817",
  "text" : "RT @afrobot: Replace police as first responders w\/ life-saving, money-saving, preventative public services  http:\/\/t.co\/fLXV2rc7IB #BlackLi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ 118, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/fLXV2rc7IB",
        "expanded_url" : "http:\/\/talkingpointsmemo.com\/theslice\/what-are-cops-really-good-for-a-brief-history",
        "display_url" : "talkingpointsmemo.com\/theslice\/what-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563795150623617026",
    "text" : "Replace police as first responders w\/ life-saving, money-saving, preventative public services  http:\/\/t.co\/fLXV2rc7IB #BlackLivesMatter",
    "id" : 563795150623617026,
    "created_at" : "2015-02-06 20:23:33 +0000",
    "user" : {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "protected" : false,
      "id_str" : "15665323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442925524835254272\/1FJx1Wzd_normal.png",
      "id" : 15665323,
      "verified" : false
    }
  },
  "id" : 563819880344866817,
  "created_at" : "2015-02-06 22:01:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563630292309516290",
  "text" : "I use my kung fu well.",
  "id" : 563630292309516290,
  "created_at" : "2015-02-06 09:28:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 0, 6 ],
      "id_str" : "15453",
      "id" : 15453
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 7, 11 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563489389129367552",
  "geo" : { },
  "id_str" : "563628962497064961",
  "in_reply_to_user_id" : 15453,
  "text" : "@seldo @izs Try calling it UX",
  "id" : 563628962497064961,
  "in_reply_to_status_id" : 563489389129367552,
  "created_at" : "2015-02-06 09:23:11 +0000",
  "in_reply_to_screen_name" : "seldo",
  "in_reply_to_user_id_str" : "15453",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563626934702055424",
  "text" : "I'm into poly dependence",
  "id" : 563626934702055424,
  "created_at" : "2015-02-06 09:15:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563205761707147266",
  "text" : "strange what a full moon on an apogee do to you",
  "id" : 563205761707147266,
  "created_at" : "2015-02-05 05:21:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563205474326020096",
  "text" : "fullish moon and lunar apogees",
  "id" : 563205474326020096,
  "created_at" : "2015-02-05 05:20:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 3, 7 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563191597081178114",
  "text" : "RT @izs: Bringing sexy baby back ribs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563181036977147904",
    "text" : "Bringing sexy baby back ribs",
    "id" : 563181036977147904,
    "created_at" : "2015-02-05 03:43:17 +0000",
    "user" : {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "protected" : false,
      "id_str" : "8038312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649690687860899840\/bSyKUJfg_normal.png",
      "id" : 8038312,
      "verified" : false
    }
  },
  "id" : 563191597081178114,
  "created_at" : "2015-02-05 04:25:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "indices" : [ 3, 11 ],
      "id_str" : "14145296",
      "id" : 14145296
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/562670531707936769\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/XZ01O1cTWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88B18SIQAAD5el.png",
      "id_str" : "562670504671461376",
      "id" : 562670504671461376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88B18SIQAAD5el.png",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 535
      } ],
      "display_url" : "pic.twitter.com\/XZ01O1cTWP"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/562670531707936769\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/XZ01O1cTWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88B3eRIYAAG6tu.png",
      "id_str" : "562670530973949952",
      "id" : 562670530973949952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88B3eRIYAAG6tu.png",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XZ01O1cTWP"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/562670531707936769\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/XZ01O1cTWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88B3TtIEAIE_ip.png",
      "id_str" : "562670528138579970",
      "id" : 562670528138579970,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88B3TtIEAIE_ip.png",
      "sizes" : [ {
        "h" : 485,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 702
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 702
      } ],
      "display_url" : "pic.twitter.com\/XZ01O1cTWP"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/562670531707936769\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/XZ01O1cTWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88B1lIIgAEgCaT.png",
      "id_str" : "562670498455519233",
      "id" : 562670498455519233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88B1lIIgAEgCaT.png",
      "sizes" : [ {
        "h" : 286,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 546
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 546
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 546
      } ],
      "display_url" : "pic.twitter.com\/XZ01O1cTWP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562694406676156416",
  "text" : "RT @susie_c: A lot of new Silk Road paintings, with a few more to come as the case wraps up. http:\/\/t.co\/XZ01O1cTWP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/562670531707936769\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/XZ01O1cTWP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88B18SIQAAD5el.png",
        "id_str" : "562670504671461376",
        "id" : 562670504671461376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88B18SIQAAD5el.png",
        "sizes" : [ {
          "h" : 679,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 535
        } ],
        "display_url" : "pic.twitter.com\/XZ01O1cTWP"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/562670531707936769\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/XZ01O1cTWP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88B3eRIYAAG6tu.png",
        "id_str" : "562670530973949952",
        "id" : 562670530973949952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88B3eRIYAAG6tu.png",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XZ01O1cTWP"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/562670531707936769\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/XZ01O1cTWP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88B3TtIEAIE_ip.png",
        "id_str" : "562670528138579970",
        "id" : 562670528138579970,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88B3TtIEAIE_ip.png",
        "sizes" : [ {
          "h" : 485,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 275,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 702
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 702
        } ],
        "display_url" : "pic.twitter.com\/XZ01O1cTWP"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/susie_c\/status\/562670531707936769\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/XZ01O1cTWP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88B1lIIgAEgCaT.png",
        "id_str" : "562670498455519233",
        "id" : 562670498455519233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88B1lIIgAEgCaT.png",
        "sizes" : [ {
          "h" : 286,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 546
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 546
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 546
        } ],
        "display_url" : "pic.twitter.com\/XZ01O1cTWP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562670531707936769",
    "text" : "A lot of new Silk Road paintings, with a few more to come as the case wraps up. http:\/\/t.co\/XZ01O1cTWP",
    "id" : 562670531707936769,
    "created_at" : "2015-02-03 17:54:43 +0000",
    "user" : {
      "name" : "Susie Cagle",
      "screen_name" : "susie_c",
      "protected" : false,
      "id_str" : "14145296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656882091414585344\/JWq9-3gF_normal.png",
      "id" : 14145296,
      "verified" : false
    }
  },
  "id" : 562694406676156416,
  "created_at" : "2015-02-03 19:29:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562341553696305152",
  "text" : "I changed my name to Ajax of Stacks, which is a good one for the web developers and rappers. but twitter sux, avatar social club coming soon",
  "id" : 562341553696305152,
  "created_at" : "2015-02-02 20:07:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haunted TweetBot",
      "screen_name" : "cwlcks",
      "indices" : [ 3, 10 ],
      "id_str" : "63545584",
      "id" : 63545584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562339663466086401",
  "text" : "RT @cwlcks: I got an email about receiving 1 XPM (prime coin) for a contribution on github. Is this spam?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562328381069340673",
    "text" : "I got an email about receiving 1 XPM (prime coin) for a contribution on github. Is this spam?",
    "id" : 562328381069340673,
    "created_at" : "2015-02-02 19:15:08 +0000",
    "user" : {
      "name" : "Haunted TweetBot",
      "screen_name" : "cwlcks",
      "protected" : false,
      "id_str" : "63545584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715275353959170049\/t78f4Zag_normal.jpg",
      "id" : 63545584,
      "verified" : false
    }
  },
  "id" : 562339663466086401,
  "created_at" : "2015-02-02 19:59:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561974195479773184",
  "text" : "My identity is especially valuable, more valuable than most.  Plus, my identity has the potential of a beautiful, dilapidated downtown bldg.",
  "id" : 561974195479773184,
  "created_at" : "2015-02-01 19:47:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561973580674506752",
  "text" : "My identity is very valuable in this day and age.  I would be willing to lease it out to somebody with a drive to make legit money with it.",
  "id" : 561973580674506752,
  "created_at" : "2015-02-01 19:45:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561973056407474179",
  "text" : "is there anybody willing to take my state\/official identity and use it better than I have?",
  "id" : 561973056407474179,
  "created_at" : "2015-02-01 19:43:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561972788731199489",
  "text" : "no idea how that debit card started working again, github squeezed it somehow",
  "id" : 561972788731199489,
  "created_at" : "2015-02-01 19:42:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupythemob",
      "screen_name" : "occupythemob",
      "indices" : [ 0, 13 ],
      "id_str" : "3955445774",
      "id" : 3955445774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561969906821124096",
  "geo" : { },
  "id_str" : "561971652569731072",
  "in_reply_to_user_id" : 341908197,
  "text" : "@occupythemob  \nblacks kids beware\nmoms be on alert\nplaying with a toy drone \nmight get you murked",
  "id" : 561971652569731072,
  "in_reply_to_status_id" : 561969906821124096,
  "created_at" : "2015-02-01 19:37:37 +0000",
  "in_reply_to_screen_name" : "AnonyMobLife",
  "in_reply_to_user_id_str" : "341908197",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561968761876410368",
  "geo" : { },
  "id_str" : "561970266553597952",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden \n1.  Start local ISP\n2.  String up fibers like xmas lights\n3.  Lease ops to Google\n4.  Profit",
  "id" : 561970266553597952,
  "in_reply_to_status_id" : 561968761876410368,
  "created_at" : "2015-02-01 19:32:07 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561969453173190656",
  "text" : "hey futurists, all you need to know = taylor swift is among the most popular culture == the masses have not budged since the bush\/reagan 80s",
  "id" : 561969453173190656,
  "created_at" : "2015-02-01 19:28:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561965446295855105",
  "geo" : { },
  "id_str" : "561965927361572865",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript culture is free for the taking.  full stop.  but profit \/ influence motivated co's, with power to brand\/own\/distribute, abuse.",
  "id" : 561965927361572865,
  "in_reply_to_status_id" : 561965446295855105,
  "created_at" : "2015-02-01 19:14:52 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561965446295855105",
  "text" : "how are google doodles not an extreme case of cultural appropriation?  Not b\/c they share the expression, b\/c branding + mass dissemination.",
  "id" : 561965446295855105,
  "created_at" : "2015-02-01 19:12:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561951305355112449",
  "text" : "data visualizations can fill your head with a lot of useless news really fast, beware",
  "id" : 561951305355112449,
  "created_at" : "2015-02-01 18:16:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]