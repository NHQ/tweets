Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cyberwiz",
      "indices" : [ 8, 17 ]
    }, {
      "text" : "oakland",
      "indices" : [ 136, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561650761185386497",
  "text" : "# Final #cyberwiz stats:  \n* Majority of 30+ attendees finished the program.  \n* Only 1 person was shot, &amp; he returned after a day.\n#oakland",
  "id" : 561650761185386497,
  "created_at" : "2015-01-31 22:22:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561614163785428992",
  "text" : "wow I published a bug in module jsynth 4 months ago, yet somehow... idk wtf",
  "id" : 561614163785428992,
  "created_at" : "2015-01-31 19:57:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560531421195141120",
  "text" : "Join my series A round to raise social capital",
  "id" : 560531421195141120,
  "created_at" : "2015-01-28 20:14:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559895734518960128",
  "text" : "3-4 days without IRC seemed like an eternity",
  "id" : 559895734518960128,
  "created_at" : "2015-01-27 02:08:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559447502370263041",
  "text" : "this beer has enough dog",
  "id" : 559447502370263041,
  "created_at" : "2015-01-25 20:27:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/hgUvBjhWqK",
      "expanded_url" : "https:\/\/8f9aa0d21df30840a4d74e80e128713bf898c7e0.htmlb.in\/",
      "display_url" : "\u20260840a4d74e80e128713bf898c7e0.htmlb.in"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/goU6KqcX20",
      "expanded_url" : "https:\/\/7f5c596a9740eee5bdb1a6ddfea9a71d1da07f20.htmlb.in\/",
      "display_url" : "\u2026eee5bdb1a6ddfea9a71d1da07f20.htmlb.in"
    } ]
  },
  "geo" : { },
  "id_str" : "559437771614330881",
  "text" : "i made these internet art.  some cuttings from a game I haven't released.\n\nlow res https:\/\/t.co\/hgUvBjhWqK\nhi-res https:\/\/t.co\/goU6KqcX20",
  "id" : 559437771614330881,
  "created_at" : "2015-01-25 19:48:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558005613066596353",
  "text" : "You fuckheads",
  "id" : 558005613066596353,
  "created_at" : "2015-01-21 20:58:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558004728689217536",
  "text" : "Our system is fucking us in the heads.",
  "id" : 558004728689217536,
  "created_at" : "2015-01-21 20:54:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557665586143297539",
  "text" : "wake me when it doesn't seem like 2015 is gonna be 2014 with a vengeance",
  "id" : 557665586143297539,
  "created_at" : "2015-01-20 22:26:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/qUzcNXnvlY",
      "expanded_url" : "https:\/\/www.changetip.com\/tip-amounts",
      "display_url" : "changetip.com\/tip-amounts"
    } ]
  },
  "geo" : { },
  "id_str" : "557611092327686144",
  "text" : "you can gift a burrito https:\/\/t.co\/qUzcNXnvlY",
  "id" : 557611092327686144,
  "created_at" : "2015-01-20 18:50:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 0, 7 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557512542931939328",
  "geo" : { },
  "id_str" : "557607838990610432",
  "in_reply_to_user_id" : 110396781,
  "text" : "@ajplus  cuz the president is your personal genie",
  "id" : 557607838990610432,
  "in_reply_to_status_id" : 557512542931939328,
  "created_at" : "2015-01-20 18:37:23 +0000",
  "in_reply_to_screen_name" : "ajplus",
  "in_reply_to_user_id_str" : "110396781",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 0, 11 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557248884922404866",
  "geo" : { },
  "id_str" : "557265534006206464",
  "in_reply_to_user_id" : 2375721396,
  "text" : "@Satoshi_N_  \n\na clue",
  "id" : 557265534006206464,
  "in_reply_to_status_id" : 557248884922404866,
  "created_at" : "2015-01-19 19:57:11 +0000",
  "in_reply_to_screen_name" : "Satoshi_N_",
  "in_reply_to_user_id_str" : "2375721396",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557265138609160192",
  "text" : "The Curly Brace &amp; Sickle",
  "id" : 557265138609160192,
  "created_at" : "2015-01-19 19:55:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556911667171176448",
  "text" : "i am behind on my digital ocean rent\n\nyeah",
  "id" : 556911667171176448,
  "created_at" : "2015-01-18 20:31:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Nakamoto",
      "screen_name" : "DorianSatoshi",
      "indices" : [ 114, 128 ],
      "id_str" : "2421580772",
      "id" : 2421580772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoinmiami",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556562502730145793",
  "text" : "I shoulda rode the blockchain to #bitcoinmiami n hustled investors but I'd prefer do whatever it takes to attract @DorianSatoshi to Oakland.",
  "id" : 556562502730145793,
  "created_at" : "2015-01-17 21:23:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Nakamoto",
      "screen_name" : "DorianSatoshi",
      "indices" : [ 3, 17 ],
      "id_str" : "2421580772",
      "id" : 2421580772
    }, {
      "name" : "Jeremy Ross",
      "screen_name" : "jebus911",
      "indices" : [ 20, 29 ],
      "id_str" : "162573283",
      "id" : 162573283
    }, {
      "name" : "ChangeTip",
      "screen_name" : "ChangeTip",
      "indices" : [ 122, 132 ],
      "id_str" : "2238411649",
      "id" : 2238411649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556560467607691267",
  "text" : "RT @DorianSatoshi: .@jebus911 Bitcoin doesn't need us to hold its hand.  We just need to stand back.  Take a chill pill.  @ChangeTip",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy Ross",
        "screen_name" : "jebus911",
        "indices" : [ 1, 10 ],
        "id_str" : "162573283",
        "id" : 162573283
      }, {
        "name" : "ChangeTip",
        "screen_name" : "ChangeTip",
        "indices" : [ 103, 113 ],
        "id_str" : "2238411649",
        "id" : 2238411649
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "556523243654610944",
    "geo" : { },
    "id_str" : "556559586547625985",
    "in_reply_to_user_id" : 162573283,
    "text" : ".@jebus911 Bitcoin doesn't need us to hold its hand.  We just need to stand back.  Take a chill pill.  @ChangeTip",
    "id" : 556559586547625985,
    "in_reply_to_status_id" : 556523243654610944,
    "created_at" : "2015-01-17 21:12:00 +0000",
    "in_reply_to_screen_name" : "jebus911",
    "in_reply_to_user_id_str" : "162573283",
    "user" : {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "protected" : false,
      "id_str" : "2375721396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727448034024525825\/nxaF8tNf_normal.jpg",
      "id" : 2375721396,
      "verified" : false
    }
  },
  "id" : 556560467607691267,
  "created_at" : "2015-01-17 21:15:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 3, 7 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556532082675945472",
  "text" : "RT @izs: When people say that studies \"dating back to the sixties\" prove this or that, I wonder if they've seen any NEWER studies.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "556498468559020033",
    "text" : "When people say that studies \"dating back to the sixties\" prove this or that, I wonder if they've seen any NEWER studies.",
    "id" : 556498468559020033,
    "created_at" : "2015-01-17 17:09:08 +0000",
    "user" : {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "protected" : false,
      "id_str" : "8038312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649690687860899840\/bSyKUJfg_normal.png",
      "id" : 8038312,
      "verified" : false
    }
  },
  "id" : 556532082675945472,
  "created_at" : "2015-01-17 19:22:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556530722014371840",
  "text" : "I can wiggle both of my ears, and breathe thru both of my nostrils.",
  "id" : 556530722014371840,
  "created_at" : "2015-01-17 19:17:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556530047121518592",
  "text" : "sure bikes are efficient, but I rarely care for efficiency.  efficiency is no friend to the flow.",
  "id" : 556530047121518592,
  "created_at" : "2015-01-17 19:14:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556529269912793088",
  "text" : "we really fucked up with this automobile societys",
  "id" : 556529269912793088,
  "created_at" : "2015-01-17 19:11:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556529197900767232",
  "text" : "it is my professes opinion as a kung foo master that bicycles are a bad form of exercise; and stressful form of commute, thanks to cars.",
  "id" : 556529197900767232,
  "created_at" : "2015-01-17 19:11:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "556273646386176000",
  "geo" : { },
  "id_str" : "556275077474295809",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray the quote defending Horton is from one of Horton's family members",
  "id" : 556275077474295809,
  "in_reply_to_status_id" : 556273646386176000,
  "created_at" : "2015-01-17 02:21:28 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/A7KXca4N6B",
      "expanded_url" : "http:\/\/cir.ca\/news\/us-pushes-for-broadband-expansion",
      "display_url" : "cir.ca\/news\/us-pushes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556217459036811264",
  "text" : "New York is gonna spend half a billion to build ISPs more public utility to charge and and throttle http:\/\/t.co\/A7KXca4N6B",
  "id" : 556217459036811264,
  "created_at" : "2015-01-16 22:32:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PurpleHippie4Life \u2728",
      "screen_name" : "_reeceNshit",
      "indices" : [ 3, 15 ],
      "id_str" : "85470285",
      "id" : 85470285
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 18, 24 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/deray\/status\/556199601133195264\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/NcPOOasXTW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7gElRJCYAAtFZP.jpg",
      "id_str" : "556199592283234304",
      "id" : 556199592283234304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7gElRJCYAAtFZP.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NcPOOasXTW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556213628022448130",
  "text" : "RT @_reeceNshit: \u201C@deray: Oakland. Protest. http:\/\/t.co\/NcPOOasXTW\u201D I hella love Oakland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 1, 7 ],
        "id_str" : "29417304",
        "id" : 29417304
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/deray\/status\/556199601133195264\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/NcPOOasXTW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7gElRJCYAAtFZP.jpg",
        "id_str" : "556199592283234304",
        "id" : 556199592283234304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7gElRJCYAAtFZP.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NcPOOasXTW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "556200773890359296",
    "text" : "\u201C@deray: Oakland. Protest. http:\/\/t.co\/NcPOOasXTW\u201D I hella love Oakland",
    "id" : 556200773890359296,
    "created_at" : "2015-01-16 21:26:12 +0000",
    "user" : {
      "name" : "PurpleHippie4Life \u2728",
      "screen_name" : "_reeceNshit",
      "protected" : false,
      "id_str" : "85470285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729420100235866112\/lt1sjqNN_normal.jpg",
      "id" : 85470285,
      "verified" : false
    }
  },
  "id" : 556213628022448130,
  "created_at" : "2015-01-16 22:17:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cyberwizard",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556160160289148929",
  "text" : "last night in the #cyberwizard IRC room:  \n&gt; the wizards are jamming\n&gt; wizardmusic\n&gt; evening entertainment\nthis is the institute we imagined",
  "id" : 556160160289148929,
  "created_at" : "2015-01-16 18:44:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556133796383170560",
  "text" : "last captcha was \"los thatslob\"",
  "id" : 556133796383170560,
  "created_at" : "2015-01-16 17:00:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "metaprogramming",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556113821186949120",
  "text" : "var xyz is silly\n\n#metaprogramming",
  "id" : 556113821186949120,
  "created_at" : "2015-01-16 15:40:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556109482246565888",
  "text" : "fizz bar boop baap beep boop",
  "id" : 556109482246565888,
  "created_at" : "2015-01-16 15:23:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556077573076045825",
  "text" : "O, what a tangle of passwords we weave.",
  "id" : 556077573076045825,
  "created_at" : "2015-01-16 13:16:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555769158839701504",
  "text" : "i need money somehow",
  "id" : 555769158839701504,
  "created_at" : "2015-01-15 16:51:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555180560985767936",
  "geo" : { },
  "id_str" : "555183277284143104",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross  but app store... smh",
  "id" : 555183277284143104,
  "in_reply_to_status_id" : 555180560985767936,
  "created_at" : "2015-01-14 02:03:02 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555179215549497345",
  "text" : "the money is here, but it is not evenly distributed",
  "id" : 555179215549497345,
  "created_at" : "2015-01-14 01:46:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/qaKrqVvU2y",
      "expanded_url" : "http:\/\/hakshop.myshopify.com\/collections\/wifi-pineapple-kits\/products\/wifi-pineapple?variant=81044992",
      "display_url" : "hakshop.myshopify.com\/collections\/wi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555073779622088704",
  "text" : "I found this on the internet, wondering if it would make a good mesh wifi device  \n\nhttp:\/\/t.co\/qaKrqVvU2y",
  "id" : 555073779622088704,
  "created_at" : "2015-01-13 18:47:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 0, 11 ],
      "id_str" : "407296703",
      "id" : 407296703
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 12, 21 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554859478500143104",
  "geo" : { },
  "id_str" : "554864996740395009",
  "in_reply_to_user_id" : 407296703,
  "text" : "@obensource @maxogden  well don't hold out now",
  "id" : 554864996740395009,
  "in_reply_to_status_id" : 554859478500143104,
  "created_at" : "2015-01-13 04:58:18 +0000",
  "in_reply_to_screen_name" : "obensource",
  "in_reply_to_user_id_str" : "407296703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554752709610319872",
  "text" : "play + leisure =",
  "id" : 554752709610319872,
  "created_at" : "2015-01-12 21:32:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maximilian Klein",
      "screen_name" : "notconfusing",
      "indices" : [ 3, 16 ],
      "id_str" : "286504285",
      "id" : 286504285
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 61, 70 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/notconfusing\/status\/554750390135042048\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/9Uht5V3Pzq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7LeilaCcAA1Hs2.jpg",
      "id_str" : "554750389858234368",
      "id" : 554750389858234368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7LeilaCcAA1Hs2.jpg",
      "sizes" : [ {
        "h" : 445,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1560,
        "resize" : "fit",
        "w" : 2104
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9Uht5V3Pzq"
    } ],
    "hashtags" : [ {
      "text" : "cyberwiz",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554751816231948288",
  "text" : "RT @notconfusing: Jd talking about networks at #cyberwiz at  @sudoroom http:\/\/t.co\/9Uht5V3Pzq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/play.google.com\/store\/apps\/details?id=org.mariotaku.twidere\" rel=\"nofollow\"\u003ETwidere for Android #3\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sudo Room",
        "screen_name" : "sudoroom",
        "indices" : [ 43, 52 ],
        "id_str" : "411733308",
        "id" : 411733308
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/notconfusing\/status\/554750390135042048\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/9Uht5V3Pzq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7LeilaCcAA1Hs2.jpg",
        "id_str" : "554750389858234368",
        "id" : 554750389858234368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7LeilaCcAA1Hs2.jpg",
        "sizes" : [ {
          "h" : 445,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 759,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1560,
          "resize" : "fit",
          "w" : 2104
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9Uht5V3Pzq"
      } ],
      "hashtags" : [ {
        "text" : "cyberwiz",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "554750390135042048",
    "text" : "Jd talking about networks at #cyberwiz at  @sudoroom http:\/\/t.co\/9Uht5V3Pzq",
    "id" : 554750390135042048,
    "created_at" : "2015-01-12 21:22:54 +0000",
    "user" : {
      "name" : "Maximilian Klein",
      "screen_name" : "notconfusing",
      "protected" : false,
      "id_str" : "286504285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702547454768492544\/c6f2ROAR_normal.jpg",
      "id" : 286504285,
      "verified" : false
    }
  },
  "id" : 554751816231948288,
  "created_at" : "2015-01-12 21:28:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "J.D. Zamfirescu",
      "screen_name" : "jdzamfi",
      "indices" : [ 53, 61 ],
      "id_str" : "106967093",
      "id" : 106967093
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cyberwiz",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554751794438344705",
  "text" : "RT @marinakukso: 30 people at #cyberwiz listening to @jdzamfi giving a workshop about how the internet works!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "J.D. Zamfirescu",
        "screen_name" : "jdzamfi",
        "indices" : [ 36, 44 ],
        "id_str" : "106967093",
        "id" : 106967093
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cyberwiz",
        "indices" : [ 13, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "554751283286921216",
    "text" : "30 people at #cyberwiz listening to @jdzamfi giving a workshop about how the internet works!",
    "id" : 554751283286921216,
    "created_at" : "2015-01-12 21:26:27 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 554751794438344705,
  "created_at" : "2015-01-12 21:28:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene - Our Oakland",
      "screen_name" : "DIYGene",
      "indices" : [ 3, 11 ],
      "id_str" : "90479930",
      "id" : 90479930
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 13, 26 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554750942541656065",
  "text" : "RT @DIYGene: @johnnyscript happy modulo zero day! :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "554682310679732224",
    "geo" : { },
    "id_str" : "554682615962161152",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript happy modulo zero day! :-)",
    "id" : 554682615962161152,
    "in_reply_to_status_id" : 554682310679732224,
    "created_at" : "2015-01-12 16:53:35 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Gene - Our Oakland",
      "screen_name" : "DIYGene",
      "protected" : false,
      "id_str" : "90479930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656265936257716224\/M4rE9jcl_normal.jpg",
      "id" : 90479930,
      "verified" : false
    }
  },
  "id" : 554750942541656065,
  "created_at" : "2015-01-12 21:25:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der Noffle",
      "screen_name" : "noffle",
      "indices" : [ 3, 10 ],
      "id_str" : "157503599",
      "id" : 157503599
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 12, 25 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554750933913960448",
  "text" : "RT @Noffle: @johnnyscript Happy birthday.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "554682310679732224",
    "geo" : { },
    "id_str" : "554682889561190400",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript Happy birthday.",
    "id" : 554682889561190400,
    "in_reply_to_status_id" : 554682310679732224,
    "created_at" : "2015-01-12 16:54:41 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Der Noffle",
      "screen_name" : "noffle",
      "protected" : false,
      "id_str" : "157503599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604703830891102208\/Xfkg9Wlp_normal.png",
      "id" : 157503599,
      "verified" : false
    }
  },
  "id" : 554750933913960448,
  "created_at" : "2015-01-12 21:25:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554682310679732224",
  "text" : "ME % 365 == 0",
  "id" : 554682310679732224,
  "created_at" : "2015-01-12 16:52:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554553365548781568",
  "text" : "You learn because you are im\/com\/pelled.  You are autodidactic if you teach yourself for to comprehend what the dumb is.",
  "id" : 554553365548781568,
  "created_at" : "2015-01-12 08:20:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554539940474654720",
  "geo" : { },
  "id_str" : "554552214363340800",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  I added a post psyche (ps)",
  "id" : 554552214363340800,
  "in_reply_to_status_id" : 554539940474654720,
  "created_at" : "2015-01-12 08:15:25 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cyberwiz",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/VRCYUhSx6n",
      "expanded_url" : "https:\/\/github.com\/cyberwizardinstitute\/workshops\/blob\/master\/node_101.md",
      "display_url" : "github.com\/cyberwizardins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554539940474654720",
  "text" : "#cyberwiz basics: node, events and callbacks  https:\/\/t.co\/VRCYUhSx6n",
  "id" : 554539940474654720,
  "created_at" : "2015-01-12 07:26:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554442073575653377",
  "text" : "high hors d'oeuvres functions",
  "id" : 554442073575653377,
  "created_at" : "2015-01-12 00:57:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554391131413549056",
  "text" : "RT @nexxylove: God Hates Facts",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "554388515308322816",
    "text" : "God Hates Facts",
    "id" : 554388515308322816,
    "created_at" : "2015-01-11 21:24:56 +0000",
    "user" : {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719047162793828353\/ilHIszOy_normal.jpg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 554391131413549056,
  "created_at" : "2015-01-11 21:35:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554382318966931458",
  "geo" : { },
  "id_str" : "554382554330308609",
  "in_reply_to_user_id" : 46961216,
  "text" : "Immediate result:  fewer sandwich artists and baristas;  higher pay for sandwich artists and baristas.",
  "id" : 554382554330308609,
  "in_reply_to_status_id" : 554382318966931458,
  "created_at" : "2015-01-11 21:01:15 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554381594174435328",
  "geo" : { },
  "id_str" : "554382318966931458",
  "in_reply_to_user_id" : 46961216,
  "text" : "What is unemployment but a condition of the labor market?  We need greater job demand, not \"more jobs\".  Ergo, pay people to not work.",
  "id" : 554382318966931458,
  "in_reply_to_status_id" : 554381594174435328,
  "created_at" : "2015-01-11 21:00:19 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554381594174435328",
  "text" : "We pay farmer to not-grow crops, for market logic reasons.  Does the same market logic apply to jobs and demand for labor?",
  "id" : 554381594174435328,
  "created_at" : "2015-01-11 20:57:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554381162769313793",
  "text" : "asking other open source librarians for advice and module recommendations is part of my framework",
  "id" : 554381162769313793,
  "created_at" : "2015-01-11 20:55:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aria Stewart",
      "screen_name" : "aredridel",
      "indices" : [ 0, 10 ],
      "id_str" : "17950990",
      "id" : 17950990
    }, {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 11, 20 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    }, {
      "name" : "SecuriTay",
      "screen_name" : "SwiftOnSecurity",
      "indices" : [ 27, 43 ],
      "id_str" : "2436389418",
      "id" : 2436389418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554347109089280001",
  "geo" : { },
  "id_str" : "554360782289260544",
  "in_reply_to_user_id" : 17950990,
  "text" : "@aredridel @maxogden =&gt; @SwiftOnSecurity",
  "id" : 554360782289260544,
  "in_reply_to_status_id" : 554347109089280001,
  "created_at" : "2015-01-11 19:34:44 +0000",
  "in_reply_to_screen_name" : "aredridel",
  "in_reply_to_user_id_str" : "17950990",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/NbeEuqhE0t",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=KyO0gOuk5H0",
      "display_url" : "youtube.com\/watch?v=KyO0gO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554180760773869568",
  "text" : "but examine all the flawsky-wasky, awfully \n\nhttps:\/\/t.co\/NbeEuqhE0t",
  "id" : 554180760773869568,
  "created_at" : "2015-01-11 07:39:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554010706123575296",
  "text" : "tbqh this music is too good to be pushing to soundcloud, so imma relax and write next level internet applications in a style as a framework.",
  "id" : 554010706123575296,
  "created_at" : "2015-01-10 20:23:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Rfb0BwCCr8",
      "expanded_url" : "http:\/\/oaklandanimalservices.org\/2015\/01\/the-hard-luck-hounds-of-oas\/",
      "display_url" : "oaklandanimalservices.org\/2015\/01\/the-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553994212010504192",
  "text" : "there lots of cute dogs at the shelter, and no fee adoption for \"hard luck hounds\" #oakland\n \nhttp:\/\/t.co\/Rfb0BwCCr8",
  "id" : 553994212010504192,
  "created_at" : "2015-01-10 19:18:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553969925631385600",
  "text" : "I PUT A SPELL IN YOU COMPUTER\n\nBECAUSE YOU'RE MINE",
  "id" : 553969925631385600,
  "created_at" : "2015-01-10 17:41:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553969569119756288",
  "text" : "I met a sexy android in frisco\nWe talked abt its distro\nthen I laid it on \nw\/ a program, 1 line long\n\n\"U want to crash at my place tonight?\"",
  "id" : 553969569119756288,
  "created_at" : "2015-01-10 17:40:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asbjorn Enge",
      "screen_name" : "asbjornenge",
      "indices" : [ 0, 12 ],
      "id_str" : "71515090",
      "id" : 71515090
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 13, 22 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553858979500421120",
  "geo" : { },
  "id_str" : "553962325896466433",
  "in_reply_to_user_id" : 71515090,
  "text" : "@asbjornenge @substack thanks!",
  "id" : 553962325896466433,
  "in_reply_to_status_id" : 553858979500421120,
  "created_at" : "2015-01-10 17:11:25 +0000",
  "in_reply_to_screen_name" : "asbjornenge",
  "in_reply_to_user_id_str" : "71515090",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asbjorn Enge",
      "screen_name" : "asbjornenge",
      "indices" : [ 3, 15 ],
      "id_str" : "71515090",
      "id" : 71515090
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 107, 120 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/vbh8U6YHm2",
      "expanded_url" : "https:\/\/github.com\/cyberwizardinstitute\/workshops\/blob\/master\/html-css-javascript-an-eternal-rgb-triple-rainbo.md",
      "display_url" : "github.com\/cyberwizardins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553962208401448960",
  "text" : "RT @asbjornenge: \u201CIn the context of \u2018thefrontend\u2019\nwhere we find our weary selfies\u201D, great (typeof text) by @johnnyscript https:\/\/t.co\/vbh8U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 90, 103 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/vbh8U6YHm2",
        "expanded_url" : "https:\/\/github.com\/cyberwizardinstitute\/workshops\/blob\/master\/html-css-javascript-an-eternal-rgb-triple-rainbo.md",
        "display_url" : "github.com\/cyberwizardins\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "553861438201401344",
    "text" : "\u201CIn the context of \u2018thefrontend\u2019\nwhere we find our weary selfies\u201D, great (typeof text) by @johnnyscript https:\/\/t.co\/vbh8U6YHm2",
    "id" : 553861438201401344,
    "created_at" : "2015-01-10 10:30:31 +0000",
    "user" : {
      "name" : "Asbjorn Enge",
      "screen_name" : "asbjornenge",
      "protected" : false,
      "id_str" : "71515090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715860731602812928\/kpovR_AW_normal.jpg",
      "id" : 71515090,
      "verified" : false
    }
  },
  "id" : 553962208401448960,
  "created_at" : "2015-01-10 17:10:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ytVo5NWbDf",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/hella-gospel",
      "display_url" : "soundcloud.com\/folkstack\/hell\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553788571526504448",
  "text" : "some home recorded gospel, with a tl;dr section in the middle.\n\nalso, very groovy.  recorded 11\/2014\n\nhttps:\/\/t.co\/ytVo5NWbDf",
  "id" : 553788571526504448,
  "created_at" : "2015-01-10 05:40:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553779994732675072",
  "text" : "life is full of enough psychic pins, needles and swords, too much so to care about the great invisible society.",
  "id" : 553779994732675072,
  "created_at" : "2015-01-10 05:06:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 14, 27 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553768287188688896",
  "text" : "RT @substack: @johnnyscript the gods were not pleased at prometheus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "553744233543135233",
    "geo" : { },
    "id_str" : "553746016755658752",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript the gods were not pleased at prometheus",
    "id" : 553746016755658752,
    "in_reply_to_status_id" : 553744233543135233,
    "created_at" : "2015-01-10 02:51:53 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 553768287188688896,
  "created_at" : "2015-01-10 04:20:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553713506856357889",
  "geo" : { },
  "id_str" : "553744233543135233",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  and then the power was cut...",
  "id" : 553744233543135233,
  "in_reply_to_status_id" : 553713506856357889,
  "created_at" : "2015-01-10 02:44:48 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553337698123935745",
  "geo" : { },
  "id_str" : "553377170492370945",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray  this seems similar, maybe connected, to feelings of ownership of a culture.  they both lead to exclusion.",
  "id" : 553377170492370945,
  "in_reply_to_status_id" : 553337698123935745,
  "created_at" : "2015-01-09 02:26:13 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 0, 6 ],
      "id_str" : "15453",
      "id" : 15453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553328997531009024",
  "geo" : { },
  "id_str" : "553353014279286784",
  "in_reply_to_user_id" : 15453,
  "text" : "@seldo author(s)",
  "id" : 553353014279286784,
  "in_reply_to_status_id" : 553328997531009024,
  "created_at" : "2015-01-09 00:50:14 +0000",
  "in_reply_to_screen_name" : "seldo",
  "in_reply_to_user_id_str" : "15453",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553189278503550977",
  "text" : "This isn't poetry, there are rules.",
  "id" : 553189278503550977,
  "created_at" : "2015-01-08 13:59:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CharlieHebdo",
      "indices" : [ 4, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553160848567730177",
  "text" : "The #CharlieHebdo incident would not have been as easily done, if the employees didn't go to work in an office.",
  "id" : 553160848567730177,
  "created_at" : "2015-01-08 12:06:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552928582771539970",
  "text" : "my potential weighs a ton",
  "id" : 552928582771539970,
  "created_at" : "2015-01-07 20:43:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552928152024920064",
  "text" : "imma start an automatic money generating business as a service to myself and my investors.  who are my investors?",
  "id" : 552928152024920064,
  "created_at" : "2015-01-07 20:41:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552927503447126016",
  "text" : "I AM THE GROUND FLOOR",
  "id" : 552927503447126016,
  "created_at" : "2015-01-07 20:39:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552927472509927424",
  "text" : "I'm at the fucking ground floor.",
  "id" : 552927472509927424,
  "created_at" : "2015-01-07 20:39:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552927295506112512",
  "text" : "Bank said I need other things, I'm like, bank, do you know what I possess with this knowledge, are you stupid?",
  "id" : 552927295506112512,
  "created_at" : "2015-01-07 20:38:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552926928999432192",
  "text" : "I went to a bank to see about a loan to bootstrap some shit, they said I need to bootstrap first, I'm like, I don't keep money, you do.",
  "id" : 552926928999432192,
  "created_at" : "2015-01-07 20:37:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/XA29H6sIhx",
      "expanded_url" : "http:\/\/cyber.wizard.institute",
      "display_url" : "cyber.wizard.institute"
    }, {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/0Mi2cfAjgm",
      "expanded_url" : "https:\/\/github.com\/cyberwizardinstitute\/workshops\/blob\/master\/html-css-javascript-an-eternal-rgb-triple-rainbo.md",
      "display_url" : "github.com\/cyberwizardins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552926557862240256",
  "text" : "I wrote this last night about HTML, CSS and JAVASCRIPTS for http:\/\/t.co\/XA29H6sIhx\n\nhttps:\/\/t.co\/0Mi2cfAjgm",
  "id" : 552926557862240256,
  "created_at" : "2015-01-07 20:35:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552559991035420673",
  "text" : "I recorded ~300 improvised sessions 2014, with diverse musicians. All in mono with a single ribbon mic, inside a redwood acoustic chamber.",
  "id" : 552559991035420673,
  "created_at" : "2015-01-06 20:19:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552557485651808256",
  "geo" : { },
  "id_str" : "552558713374912512",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  this one really gets grooving at about 2:00",
  "id" : 552558713374912512,
  "in_reply_to_status_id" : 552557485651808256,
  "created_at" : "2015-01-06 20:13:57 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Slnh3klmJA",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/humanity-as-a-sibling-rivalry",
      "display_url" : "soundcloud.com\/folkstack\/huma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552557485651808256",
  "text" : "today's upload from the FOLKSTACKS. The first cut from another improvised session, recorded live in mono late 2014.\n\nhttps:\/\/t.co\/Slnh3klmJA",
  "id" : 552557485651808256,
  "created_at" : "2015-01-06 20:09:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 0, 11 ],
      "id_str" : "5943942",
      "id" : 5943942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552556632312258560",
  "geo" : { },
  "id_str" : "552556870439682049",
  "in_reply_to_user_id" : 46961216,
  "text" : "@SoundCloud  see how you cut off my text ^ , your designers are neutered corporate VC teetsuckers",
  "id" : 552556870439682049,
  "in_reply_to_status_id" : 552556632312258560,
  "created_at" : "2015-01-06 20:06:38 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 1, 12 ],
      "id_str" : "5943942",
      "id" : 5943942
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/552556632312258560\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/6JHyoQcmBW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6sTVDnCEAEBmQw.png",
      "id_str" : "552556631750217729",
      "id" : 552556631750217729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6sTVDnCEAEBmQw.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 821,
        "resize" : "fit",
        "w" : 1253
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6JHyoQcmBW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552556632312258560",
  "text" : ".@SoundCloud get yr promo shit out my UI n give room to artist's text about their tracks, goddamn myspace shit http:\/\/t.co\/6JHyoQcmBW",
  "id" : 552556632312258560,
  "created_at" : "2015-01-06 20:05:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/LmTQcskG4c",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/rachmaninov3-orchestra",
      "display_url" : "soundcloud.com\/johnnyscript\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552545754724974592",
  "text" : "one day I will add the bass track to this time travel collaboration between my algorithms and Rachmaninov's hands https:\/\/t.co\/LmTQcskG4c",
  "id" : 552545754724974592,
  "created_at" : "2015-01-06 19:22:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 0, 7 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552533902792097793",
  "geo" : { },
  "id_str" : "552544679011835905",
  "in_reply_to_user_id" : 110396781,
  "text" : "@ajplus  a list of 30... has 600 people on it?",
  "id" : 552544679011835905,
  "in_reply_to_status_id" : 552533902792097793,
  "created_at" : "2015-01-06 19:18:11 +0000",
  "in_reply_to_screen_name" : "ajplus",
  "in_reply_to_user_id_str" : "110396781",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552298656893009921",
  "text" : "zug zug",
  "id" : 552298656893009921,
  "created_at" : "2015-01-06 03:00:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552187676234088448",
  "geo" : { },
  "id_str" : "552188475513274368",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  + more calendar objects coming soon",
  "id" : 552188475513274368,
  "in_reply_to_status_id" : 552187676234088448,
  "created_at" : "2015-01-05 19:42:46 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552168189476765698",
  "geo" : { },
  "id_str" : "552187985702436866",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha moneyboners",
  "id" : 552187985702436866,
  "in_reply_to_status_id" : 552168189476765698,
  "created_at" : "2015-01-05 19:40:49 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 105, 114 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/Ja61h3NnLF",
      "expanded_url" : "http:\/\/cyber.wizard.institute",
      "display_url" : "cyber.wizard.institute"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/mzcboM0uYd",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/take-a-ride-on-the-innernet",
      "display_url" : "soundcloud.com\/folkstack\/take\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552187073651044352",
  "text" : "To commemorate the 1st day of http:\/\/t.co\/Ja61h3NnLF, a recording of command line vaporwave, by the whiz @substack https:\/\/t.co\/mzcboM0uYd",
  "id" : 552187073651044352,
  "created_at" : "2015-01-05 19:37:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552163662514094080",
  "text" : "i wonder if that was my first bath of 2015",
  "id" : 552163662514094080,
  "created_at" : "2015-01-05 18:04:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0625\u0646\u062A\u0641\u0627\u0636\u0629 \u0627\u0644\u0628\u0627\u064A \u0622\u0631\u064A\u0627",
      "screen_name" : "BayAreaIntifada",
      "indices" : [ 3, 19 ],
      "id_str" : "399867227",
      "id" : 399867227
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BayAreaIntifada\/status\/552148960916160512\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TEEWAACBLl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6mgjdxCcAA7XK4.png",
      "id_str" : "552148960475770880",
      "id" : 552148960475770880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6mgjdxCcAA7XK4.png",
      "sizes" : [ {
        "h" : 378,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/TEEWAACBLl"
    } ],
    "hashtags" : [ {
      "text" : "turnup",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "FTP",
      "indices" : [ 126, 130 ]
    }, {
      "text" : "ACAB",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/pqPX7jnPqT",
      "expanded_url" : "http:\/\/bit.ly\/14dJ1R1",
      "display_url" : "bit.ly\/14dJ1R1"
    } ]
  },
  "geo" : { },
  "id_str" : "552150194041524224",
  "text" : "RT @BayAreaIntifada: senior citizen vandalized police station, led cops on 300m scooter chase: http:\/\/t.co\/pqPX7jnPqT\n#turnup #FTP #ACAB ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BayAreaIntifada\/status\/552148960916160512\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/TEEWAACBLl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6mgjdxCcAA7XK4.png",
        "id_str" : "552148960475770880",
        "id" : 552148960475770880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6mgjdxCcAA7XK4.png",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 499
        } ],
        "display_url" : "pic.twitter.com\/TEEWAACBLl"
      } ],
      "hashtags" : [ {
        "text" : "turnup",
        "indices" : [ 97, 104 ]
      }, {
        "text" : "FTP",
        "indices" : [ 105, 109 ]
      }, {
        "text" : "ACAB",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/pqPX7jnPqT",
        "expanded_url" : "http:\/\/bit.ly\/14dJ1R1",
        "display_url" : "bit.ly\/14dJ1R1"
      } ]
    },
    "geo" : { },
    "id_str" : "552148960916160512",
    "text" : "senior citizen vandalized police station, led cops on 300m scooter chase: http:\/\/t.co\/pqPX7jnPqT\n#turnup #FTP #ACAB http:\/\/t.co\/TEEWAACBLl",
    "id" : 552148960916160512,
    "created_at" : "2015-01-05 17:05:45 +0000",
    "user" : {
      "name" : "\u0625\u0646\u062A\u0641\u0627\u0636\u0629 \u0627\u0644\u0628\u0627\u064A \u0622\u0631\u064A\u0627",
      "screen_name" : "BayAreaIntifada",
      "protected" : false,
      "id_str" : "399867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480873371337383936\/DdhkId2o_normal.jpeg",
      "id" : 399867227,
      "verified" : false
    }
  },
  "id" : 552150194041524224,
  "created_at" : "2015-01-05 17:10:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551878464182042625",
  "geo" : { },
  "id_str" : "551880150254489600",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  recorded last night, uploaded raw #oakland",
  "id" : 551880150254489600,
  "in_reply_to_status_id" : 551878464182042625,
  "created_at" : "2015-01-04 23:17:35 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/vgoFragbQO",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/organic-snakes",
      "display_url" : "soundcloud.com\/folkstack\/orga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551878464182042625",
  "text" : "\"organic snakes\"\n\nhttps:\/\/t.co\/vgoFragbQO",
  "id" : 551878464182042625,
  "created_at" : "2015-01-04 23:10:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CSS3EE",
      "screen_name" : "filtercake",
      "indices" : [ 3, 14 ],
      "id_str" : "78214742",
      "id" : 78214742
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Ilya",
      "screen_name" : "lessapathetic",
      "indices" : [ 30, 44 ],
      "id_str" : "4014391",
      "id" : 4014391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/x61mYdb7Da",
      "expanded_url" : "http:\/\/www.sketchplanations.com\/post\/107034196026\/stages-of-competence-framework-a-handy-mental",
      "display_url" : "sketchplanations.com\/post\/107034196\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551548040209641472",
  "text" : "RT @filtercake: @johnnyscript @lessapathetic aaaahhh, *this* is what meant: http:\/\/t.co\/x61mYdb7Da\n\nThread closed :D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "Ilya",
        "screen_name" : "lessapathetic",
        "indices" : [ 14, 28 ],
        "id_str" : "4014391",
        "id" : 4014391
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/x61mYdb7Da",
        "expanded_url" : "http:\/\/www.sketchplanations.com\/post\/107034196026\/stages-of-competence-framework-a-handy-mental",
        "display_url" : "sketchplanations.com\/post\/107034196\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "549280286408589315",
    "geo" : { },
    "id_str" : "551487105856438272",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript @lessapathetic aaaahhh, *this* is what meant: http:\/\/t.co\/x61mYdb7Da\n\nThread closed :D",
    "id" : 551487105856438272,
    "in_reply_to_status_id" : 549280286408589315,
    "created_at" : "2015-01-03 21:15:46 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "CSS3EE",
      "screen_name" : "filtercake",
      "protected" : false,
      "id_str" : "78214742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717093313824833536\/7Uhb_JsA_normal.jpg",
      "id" : 78214742,
      "verified" : false
    }
  },
  "id" : 551548040209641472,
  "created_at" : "2015-01-04 01:17:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 3, 11 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/pKKVfMrOMh",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wmP1uKOVTr4",
      "display_url" : "youtube.com\/watch?v=wmP1uK\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551547743429091328",
  "text" : "RT @bigeasy: 1930's film; The Weaker Sex. Sayest Thou!\n\nA highly entertaining English demonstration of Jujitsu. 2:52\n\nhttps:\/\/t.co\/pKKVfMrO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/pKKVfMrOMh",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wmP1uKOVTr4",
        "display_url" : "youtube.com\/watch?v=wmP1uK\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "551536554397560832",
    "text" : "1930's film; The Weaker Sex. Sayest Thou!\n\nA highly entertaining English demonstration of Jujitsu. 2:52\n\nhttps:\/\/t.co\/pKKVfMrOMh",
    "id" : 551536554397560832,
    "created_at" : "2015-01-04 00:32:16 +0000",
    "user" : {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "protected" : false,
      "id_str" : "4784511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685849341496561664\/KOzfse57_normal.jpg",
      "id" : 4784511,
      "verified" : false
    }
  },
  "id" : 551547743429091328,
  "created_at" : "2015-01-04 01:16:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/fKJAKLFE1T",
      "expanded_url" : "https:\/\/github.com\/cyberwizardinstitute\/course-map\/wiki\/External-Resources",
      "display_url" : "github.com\/cyberwizardins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551465034379849728",
  "text" : "I created an \"external resources\" wiki page for the Cyber Wizards\n\nhttps:\/\/t.co\/fKJAKLFE1T",
  "id" : 551465034379849728,
  "created_at" : "2015-01-03 19:48:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551455595149012992",
  "text" : "most film and media depicting pre-internet, post-industrial life will become garbage, the stuff of some freak period of civillization",
  "id" : 551455595149012992,
  "created_at" : "2015-01-03 19:10:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vann R. Newkirk II",
      "screen_name" : "fivefifths",
      "indices" : [ 0, 11 ],
      "id_str" : "36252186",
      "id" : 36252186
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 12, 18 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551410839555944448",
  "geo" : { },
  "id_str" : "551454791017046016",
  "in_reply_to_user_id" : 36252186,
  "text" : "@fivefifths @deray  Lynch looks like something straight out of a hollywood mafia flick from a soon-to-be-forgotten time",
  "id" : 551454791017046016,
  "in_reply_to_status_id" : 551410839555944448,
  "created_at" : "2015-01-03 19:07:22 +0000",
  "in_reply_to_screen_name" : "fivefifths",
  "in_reply_to_user_id_str" : "36252186",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chink Leuger",
      "screen_name" : "JeanVyaire",
      "indices" : [ 0, 11 ],
      "id_str" : "2954344617",
      "id" : 2954344617
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 12, 18 ],
      "id_str" : "29417304",
      "id" : 29417304
    }, {
      "name" : "NICKI MINAJ",
      "screen_name" : "NICKIMINAJ",
      "indices" : [ 19, 30 ],
      "id_str" : "35787166",
      "id" : 35787166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551452933943214080",
  "geo" : { },
  "id_str" : "551453623729676291",
  "in_reply_to_user_id" : 2954344617,
  "text" : "@JeanVyaire @deray @NICKIMINAJ  \n\nKANYE DOING PRETTY WELL",
  "id" : 551453623729676291,
  "in_reply_to_status_id" : 551452933943214080,
  "created_at" : "2015-01-03 19:02:44 +0000",
  "in_reply_to_screen_name" : "JeanVyaire",
  "in_reply_to_user_id_str" : "2954344617",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/lpwQsmfhoj",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack",
      "display_url" : "soundcloud.com\/folkstack"
    } ]
  },
  "geo" : { },
  "id_str" : "551448903376048128",
  "text" : "Musicians and performers in #Oakland tweet your soundcloud for followback.  I want to connect with you.\n\nhttps:\/\/t.co\/lpwQsmfhoj",
  "id" : 551448903376048128,
  "created_at" : "2015-01-03 18:43:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551448123176792064",
  "text" : "Folkstack is what I spent 2014 practicing.  It is a [ band + label + studio ] music project consisting of many players and bespoke warez.",
  "id" : 551448123176792064,
  "created_at" : "2015-01-03 18:40:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551446226990661632",
  "text" : "I recorded two new, live tracks yesterday.  We have blobs of them unreleased, from last year.  FOLKSTACK coming at you 2015.",
  "id" : 551446226990661632,
  "created_at" : "2015-01-03 18:33:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/J8uS7qrbNM",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/police-are-dumb",
      "display_url" : "soundcloud.com\/folkstack\/poli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551445276016119808",
  "text" : "I recorded this two days ago #oakland \n\nhttps:\/\/t.co\/J8uS7qrbNM",
  "id" : 551445276016119808,
  "created_at" : "2015-01-03 18:29:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lilia",
      "screen_name" : "liliakai",
      "indices" : [ 0, 9 ],
      "id_str" : "24231806",
      "id" : 24231806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551428850169556992",
  "geo" : { },
  "id_str" : "551429985634758656",
  "in_reply_to_user_id" : 24231806,
  "text" : "@liliakai  take IR photos of vehicle exhaust emissions pls",
  "id" : 551429985634758656,
  "in_reply_to_status_id" : 551428850169556992,
  "created_at" : "2015-01-03 17:28:48 +0000",
  "in_reply_to_screen_name" : "liliakai",
  "in_reply_to_user_id_str" : "24231806",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Old School Boston",
      "screen_name" : "OldSchoolBoston",
      "indices" : [ 0, 16 ],
      "id_str" : "1516409251",
      "id" : 1516409251
    }, {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 21, 33 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542668341547397120",
  "geo" : { },
  "id_str" : "551425090768744449",
  "in_reply_to_user_id" : 1516409251,
  "text" : "@OldSchoolBoston cc\/ @TheHatGhost",
  "id" : 551425090768744449,
  "in_reply_to_status_id" : 542668341547397120,
  "created_at" : "2015-01-03 17:09:21 +0000",
  "in_reply_to_screen_name" : "OldSchoolBoston",
  "in_reply_to_user_id_str" : "1516409251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551297979919773696",
  "text" : "Lord of the Rings 3\/8: The Missing Montage\n\ncoming soon",
  "id" : 551297979919773696,
  "created_at" : "2015-01-03 08:44:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 0, 15 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551220110619574272",
  "geo" : { },
  "id_str" : "551225577542524928",
  "in_reply_to_user_id" : 283708113,
  "text" : "@brownnoiseblog  clear your search history, cookies, everything, you don't want anybody to think you actually like that band",
  "id" : 551225577542524928,
  "in_reply_to_status_id" : 551220110619574272,
  "created_at" : "2015-01-03 03:56:33 +0000",
  "in_reply_to_screen_name" : "brownnoiseblog",
  "in_reply_to_user_id_str" : "283708113",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julio Salgado",
      "screen_name" : "julio1983",
      "indices" : [ 3, 13 ],
      "id_str" : "28043661",
      "id" : 28043661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/RMu9SPSlbQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/xYFPXPmlfF\/",
      "display_url" : "instagram.com\/p\/xYFPXPmlfF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "551224944000917504",
  "text" : "RT @julio1983: Take a pic of yourself and tag alamedacountyda and sfbart and tell them to drop charges against the\u2026 http:\/\/t.co\/RMu9SPSlbQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/RMu9SPSlbQ",
        "expanded_url" : "http:\/\/instagram.com\/p\/xYFPXPmlfF\/",
        "display_url" : "instagram.com\/p\/xYFPXPmlfF\/"
      } ]
    },
    "geo" : { },
    "id_str" : "551214591934754816",
    "text" : "Take a pic of yourself and tag alamedacountyda and sfbart and tell them to drop charges against the\u2026 http:\/\/t.co\/RMu9SPSlbQ",
    "id" : 551214591934754816,
    "created_at" : "2015-01-03 03:12:54 +0000",
    "user" : {
      "name" : "Julio Salgado",
      "screen_name" : "julio1983",
      "protected" : false,
      "id_str" : "28043661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000545587060\/3f59f0dc3fcb5f683189008883c5fc42_normal.jpeg",
      "id" : 28043661,
      "verified" : false
    }
  },
  "id" : 551224944000917504,
  "created_at" : "2015-01-03 03:54:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/551100516717965313\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/0h9F0WmMtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6Xm_hRCYAAewS2.jpg",
      "id_str" : "551100508358729728",
      "id" : 551100508358729728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6Xm_hRCYAAewS2.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0h9F0WmMtJ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/551100516717965313\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/0h9F0WmMtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6Xm_4LCUAAbvWR.jpg",
      "id_str" : "551100514507575296",
      "id" : 551100514507575296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6Xm_4LCUAAbvWR.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0h9F0WmMtJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551100516717965313",
  "text" : "Lil Bear the Usurper http:\/\/t.co\/0h9F0WmMtJ",
  "id" : 551100516717965313,
  "created_at" : "2015-01-02 19:39:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551073120418033666",
  "text" : "indiegoogoo",
  "id" : 551073120418033666,
  "created_at" : "2015-01-02 17:50:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/550852765363085312\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/aPGwV9J1ql",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6UFqn9CIAA75mJ.jpg",
      "id_str" : "550852759260372992",
      "id" : 550852759260372992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6UFqn9CIAA75mJ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aPGwV9J1ql"
    } ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550852765363085312",
  "text" : "I saw this out on a walk and loved it #oakland http:\/\/t.co\/aPGwV9J1ql",
  "id" : 550852765363085312,
  "created_at" : "2015-01-02 03:15:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550754791224143873",
  "text" : "I was born near the new year, yall fakers celebrating an arbitrary calendar day.  #2015",
  "id" : 550754791224143873,
  "created_at" : "2015-01-01 20:45:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550751054833258496",
  "text" : "In 2015, the internet is de facto the mainest stream.",
  "id" : 550751054833258496,
  "created_at" : "2015-01-01 20:30:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550658304624455682",
  "text" : "Capitalists enact discriminatory laws, which pass first + do damage before the law is tested.  Hey that's good plan to suppress capitalism.",
  "id" : 550658304624455682,
  "created_at" : "2015-01-01 14:22:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/jMEMoGaf9J",
      "expanded_url" : "http:\/\/youtu.be\/Et9Nf-rsALk",
      "display_url" : "youtu.be\/Et9Nf-rsALk"
    } ]
  },
  "geo" : { },
  "id_str" : "550652052917874690",
  "text" : "\"We live in capitalism.  It's power seems escapable.  So did the divine right of Kings.\"  http:\/\/t.co\/jMEMoGaf9J",
  "id" : 550652052917874690,
  "created_at" : "2015-01-01 13:57:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550631757809074176",
  "text" : "What did you do for NYE?  I nibbled on a cold block of cheese and read essays on idleness.",
  "id" : 550631757809074176,
  "created_at" : "2015-01-01 12:36:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]