Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715264040990167042",
  "text" : "&lt;SEXYVOICE TYPE=MIXEDGENDERANGELBOT&gt;\n\n  \"COMPLETELY DETERMINISTIC... YET IRREPRODUCIBLE.\"\n\n  &lt;EXHALATION LENGTH=5 TYPE=HUMM \/&gt;\n\n&lt;\/SEXYVOICE&gt;",
  "id" : 715264040990167042,
  "created_at" : "2016-03-30 19:46:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714753766990430208",
  "geo" : { },
  "id_str" : "714871401518206976",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  Nude.js",
  "id" : 714871401518206976,
  "in_reply_to_status_id" : 714753766990430208,
  "created_at" : "2016-03-29 17:46:38 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/714535632605810692\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/GdZGPK1bfC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeqKXviWEAI1F3k.jpg",
      "id_str" : "714535631393787906",
      "id" : 714535631393787906,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeqKXviWEAI1F3k.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/GdZGPK1bfC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714535632605810692",
  "text" : "PIXELS IN YR LIGHTBUTT https:\/\/t.co\/GdZGPK1bfC",
  "id" : 714535632605810692,
  "created_at" : "2016-03-28 19:32:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714381603557023744",
  "geo" : { },
  "id_str" : "714490891885371392",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked  A Butthole thru the Heart",
  "id" : 714490891885371392,
  "in_reply_to_status_id" : 714381603557023744,
  "created_at" : "2016-03-28 16:34:37 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/GBV2fvX7Hn",
      "expanded_url" : "https:\/\/twitter.com\/cher\/status\/714270713226661889",
      "display_url" : "twitter.com\/cher\/status\/71\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714487368980389889",
  "text" : ":`^( https:\/\/t.co\/GBV2fvX7Hn",
  "id" : 714487368980389889,
  "created_at" : "2016-03-28 16:20:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714158513057095680",
  "text" : "BUT THEY DID NOT FIND HIS BODY WHERE THEY BURIED HIM\nTHEY FOUND IN PLACE THEREOF A GLISTENING HAM AND THE PROMISE OF MANY EASTER EGGS $24.99",
  "id" : 714158513057095680,
  "created_at" : "2016-03-27 18:33:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713797067714330624",
  "text" : "What Would A Learned Machines Hackathon Produce?",
  "id" : 713797067714330624,
  "created_at" : "2016-03-26 18:37:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713796390766292992",
  "text" : "ya'll deserve me\nya'll don't deserve me",
  "id" : 713796390766292992,
  "created_at" : "2016-03-26 18:34:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713785679579365376",
  "geo" : { },
  "id_str" : "713796202353983488",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz  Aye, I gave up the industry, too, but I still do it for fun.  Will the computers take that away?  Can they increase the fun factor??",
  "id" : 713796202353983488,
  "in_reply_to_status_id" : 713785679579365376,
  "created_at" : "2016-03-26 18:34:10 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713770861505871872",
  "geo" : { },
  "id_str" : "713772189791576064",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon it's kewl mang, working for the bern is worth it.",
  "id" : 713772189791576064,
  "in_reply_to_status_id" : 713770861505871872,
  "created_at" : "2016-03-26 16:58:45 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 0, 11 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713767171487236096",
  "geo" : { },
  "id_str" : "713770296759681024",
  "in_reply_to_user_id" : 64105403,
  "text" : "@legittalon resisting the urge to talk you down",
  "id" : 713770296759681024,
  "in_reply_to_status_id" : 713767171487236096,
  "created_at" : "2016-03-26 16:51:14 +0000",
  "in_reply_to_screen_name" : "legittalon",
  "in_reply_to_user_id_str" : "64105403",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joscha Bach",
      "screen_name" : "Plinz",
      "indices" : [ 0, 6 ],
      "id_str" : "28131948",
      "id" : 28131948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713601367894568962",
  "geo" : { },
  "id_str" : "713759350033002496",
  "in_reply_to_user_id" : 28131948,
  "text" : "@Plinz  software has always been written by computers  :\\",
  "id" : 713759350033002496,
  "in_reply_to_status_id" : 713601367894568962,
  "created_at" : "2016-03-26 16:07:44 +0000",
  "in_reply_to_screen_name" : "Plinz",
  "in_reply_to_user_id_str" : "28131948",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 0, 9 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713602548465332224",
  "geo" : { },
  "id_str" : "713759234790281216",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jfhbrook  u should probably confirm they are cis before you call them cis.",
  "id" : 713759234790281216,
  "in_reply_to_status_id" : 713602548465332224,
  "created_at" : "2016-03-26 16:07:17 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/yktcIzzpdb",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/464845916017410048",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713593259138748417",
  "text" : "true true\n\nhttps:\/\/t.co\/yktcIzzpdb",
  "id" : 713593259138748417,
  "created_at" : "2016-03-26 05:07:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DPRK News Service",
      "screen_name" : "DPRK_News",
      "indices" : [ 3, 13 ],
      "id_str" : "58569513",
      "id" : 58569513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713544079745789952",
  "text" : "RT @DPRK_News: Computer company Microsoft invents artificial intelligence capable of spouting racist slogans, prompting fear of widespread \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "713536609187205120",
    "text" : "Computer company Microsoft invents artificial intelligence capable of spouting racist slogans, prompting fear of widespread job loss in U.S.",
    "id" : 713536609187205120,
    "created_at" : "2016-03-26 01:22:39 +0000",
    "user" : {
      "name" : "DPRK News Service",
      "screen_name" : "DPRK_News",
      "protected" : false,
      "id_str" : "58569513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/323235980\/dprk-flag_normal.gif",
      "id" : 58569513,
      "verified" : false
    }
  },
  "id" : 713544079745789952,
  "created_at" : "2016-03-26 01:52:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/713485031361159168\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/4The5DVlDV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CebO2sAWQAMn92p.jpg",
      "id_str" : "713485029905678339",
      "id" : 713485029905678339,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CebO2sAWQAMn92p.jpg",
      "sizes" : [ {
        "h" : 890,
        "resize" : "fit",
        "w" : 939
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 890,
        "resize" : "fit",
        "w" : 939
      } ],
      "display_url" : "pic.twitter.com\/4The5DVlDV"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/713485031361159168\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/4The5DVlDV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CebO2AkWIAA_3Pf.jpg",
      "id_str" : "713485018245505024",
      "id" : 713485018245505024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CebO2AkWIAA_3Pf.jpg",
      "sizes" : [ {
        "h" : 567,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 889,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 889,
        "resize" : "fit",
        "w" : 940
      } ],
      "display_url" : "pic.twitter.com\/4The5DVlDV"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/713485031361159168\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/4The5DVlDV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CebO11IWsAAh_fz.jpg",
      "id_str" : "713485015175311360",
      "id" : 713485015175311360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CebO11IWsAAh_fz.jpg",
      "sizes" : [ {
        "h" : 567,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 887,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 887,
        "resize" : "fit",
        "w" : 938
      } ],
      "display_url" : "pic.twitter.com\/4The5DVlDV"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/713485031361159168\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/4The5DVlDV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CebO2IiW4AATR3b.jpg",
      "id_str" : "713485020384649216",
      "id" : 713485020384649216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CebO2IiW4AATR3b.jpg",
      "sizes" : [ {
        "h" : 886,
        "resize" : "fit",
        "w" : 937
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 886,
        "resize" : "fit",
        "w" : 937
      } ],
      "display_url" : "pic.twitter.com\/4The5DVlDV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713485031361159168",
  "text" : "iterating code and visual design\n\nAT THE SAME TIME https:\/\/t.co\/4The5DVlDV",
  "id" : 713485031361159168,
  "created_at" : "2016-03-25 21:57:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712003740232916992",
  "text" : "im like uuhhhh!\nis there a lisp 4 rust?",
  "id" : 712003740232916992,
  "created_at" : "2016-03-21 19:51:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711978211911991296",
  "text" : "learning so deep, so deep \nput the bot to sleep",
  "id" : 711978211911991296,
  "created_at" : "2016-03-21 18:10:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/LWdK2vV6nc",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wtWOaqcXplw",
      "display_url" : "youtube.com\/watch?v=wtWOaq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711956625775394816",
  "text" : "whoa put this in yr doobie and smoke it \n\nhttps:\/\/t.co\/LWdK2vV6nc",
  "id" : 711956625775394816,
  "created_at" : "2016-03-21 16:44:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/5YbVClgYkZ",
      "expanded_url" : "http:\/\/mijente.net\/2016\/03\/20\/trump-ice-transfer\/",
      "display_url" : "mijente.net\/2016\/03\/20\/tru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711953652752064512",
  "text" : "AZ more like DMZ https:\/\/t.co\/5YbVClgYkZ",
  "id" : 711953652752064512,
  "created_at" : "2016-03-21 16:32:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711617824389640192",
  "text" : "I do more than a few things really gooooood",
  "id" : 711617824389640192,
  "created_at" : "2016-03-20 18:18:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711617445530722304",
  "text" : "help me connect to people please",
  "id" : 711617445530722304,
  "created_at" : "2016-03-20 18:16:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711617401217880064",
  "text" : "im fresh in music and coding\n\nAT THE SAME TIME",
  "id" : 711617401217880064,
  "created_at" : "2016-03-20 18:16:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/AOV9mKoGfD",
      "expanded_url" : "http:\/\/i.imgur.com\/ZUKufIs.gifv",
      "display_url" : "i.imgur.com\/ZUKufIs.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "711464834202664960",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost  https:\/\/t.co\/AOV9mKoGfD",
  "id" : 711464834202664960,
  "created_at" : "2016-03-20 08:10:09 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/711455844232114176\/photo\/1",
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/JOEM0JJWMn",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cd-ZSnfUsAAN3Je.jpg",
      "id_str" : "711455811264884736",
      "id" : 711455811264884736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cd-ZSnfUsAAN3Je.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/JOEM0JJWMn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711366311117336576",
  "geo" : { },
  "id_str" : "711455844232114176",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso https:\/\/t.co\/JOEM0JJWMn",
  "id" : 711455844232114176,
  "in_reply_to_status_id" : 711366311117336576,
  "created_at" : "2016-03-20 07:34:26 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jen miller",
      "screen_name" : "jenerallyspeaks",
      "indices" : [ 3, 19 ],
      "id_str" : "248758771",
      "id" : 248758771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/qqYxDfz1wO",
      "expanded_url" : "https:\/\/vine.co\/v\/iwjHthlamZO",
      "display_url" : "vine.co\/v\/iwjHthlamZO"
    } ]
  },
  "geo" : { },
  "id_str" : "711352647098310656",
  "text" : "RT @jenerallyspeaks: This monkey reacting to a magic trick is amazing.\nhttps:\/\/t.co\/qqYxDfz1wO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/qqYxDfz1wO",
        "expanded_url" : "https:\/\/vine.co\/v\/iwjHthlamZO",
        "display_url" : "vine.co\/v\/iwjHthlamZO"
      } ]
    },
    "geo" : { },
    "id_str" : "710487090484662272",
    "text" : "This monkey reacting to a magic trick is amazing.\nhttps:\/\/t.co\/qqYxDfz1wO",
    "id" : 710487090484662272,
    "created_at" : "2016-03-17 15:24:57 +0000",
    "user" : {
      "name" : "jen miller",
      "screen_name" : "jenerallyspeaks",
      "protected" : false,
      "id_str" : "248758771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729022569014235137\/WTC_NVee_normal.jpg",
      "id" : 248758771,
      "verified" : false
    }
  },
  "id" : 711352647098310656,
  "created_at" : "2016-03-20 00:44:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711256487255867392",
  "text" : "current status, writing ancient mesmerizing synth lead algorithms for keyboard like u never heard beefore",
  "id" : 711256487255867392,
  "created_at" : "2016-03-19 18:22:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/d3BhcMQXlP",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/meffisto-demo",
      "display_url" : "soundcloud.com\/johnnyscript\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710600466799788032",
  "text" : "this is a synthesizer\n\nhttps:\/\/t.co\/d3BhcMQXlP",
  "id" : 710600466799788032,
  "created_at" : "2016-03-17 22:55:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ptSylX0Kju",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=YSbKWEyASkE",
      "display_url" : "youtube.com\/watch?v=YSbKWE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709998816473309184",
  "text" : "https:\/\/t.co\/ptSylX0Kju",
  "id" : 709998816473309184,
  "created_at" : "2016-03-16 07:04:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/R5ma7IRtQP",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/709817551069384704",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709818593643511808",
  "text" : "any of the songs\n\nhttps:\/\/t.co\/R5ma7IRtQP",
  "id" : 709818593643511808,
  "created_at" : "2016-03-15 19:08:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709817551069384704",
  "text" : "don't bother singing along to Michael Jackson's Thriller unless you can scream",
  "id" : 709817551069384704,
  "created_at" : "2016-03-15 19:04:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709814801384378368",
  "text" : "I need to lose some weight",
  "id" : 709814801384378368,
  "created_at" : "2016-03-15 18:53:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/stCXkND9iO",
      "expanded_url" : "http:\/\/studio.substack.net\/wave_pond_a_pond_of_waves_splash_iir_filter?time=1457986964087",
      "display_url" : "studio.substack.net\/wave_pond_a_po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709476447765684224",
  "text" : "this here's the jam for yo mundaze, dummies\n\nhttps:\/\/t.co\/stCXkND9iO",
  "id" : 709476447765684224,
  "created_at" : "2016-03-14 20:29:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709473969368248321",
  "text" : "*blesses you*",
  "id" : 709473969368248321,
  "created_at" : "2016-03-14 20:19:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709471976490799105",
  "geo" : { },
  "id_str" : "709472346508136448",
  "in_reply_to_user_id" : 46961216,
  "text" : "@brianloveswords somebody correct me",
  "id" : 709472346508136448,
  "in_reply_to_status_id" : 709471976490799105,
  "created_at" : "2016-03-14 20:12:43 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709465062491222017",
  "geo" : { },
  "id_str" : "709471976490799105",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords translated to markdown it reads *FREE AL*",
  "id" : 709471976490799105,
  "in_reply_to_status_id" : 709465062491222017,
  "created_at" : "2016-03-14 20:11:15 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709212950209269760",
  "text" : "johnny multiculated",
  "id" : 709212950209269760,
  "created_at" : "2016-03-14 03:01:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709075959178088449",
  "text" : "the animal brain is a feedbank",
  "id" : 709075959178088449,
  "created_at" : "2016-03-13 17:57:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/oQ8Rg1Xdis",
      "expanded_url" : "https:\/\/twitter.com\/misssgtpickles\/status\/705424857341763584",
      "display_url" : "twitter.com\/misssgtpickles\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709073249397661696",
  "text" : "altho it skips the frames wherein the oppressed kids fought against the police to take down capitalist barrier https:\/\/t.co\/oQ8Rg1Xdis",
  "id" : 709073249397661696,
  "created_at" : "2016-03-13 17:46:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/JwEUmzKxgg",
      "expanded_url" : "http:\/\/thehill.com\/blogs\/ballot-box\/272793-sanders-supporter-wrongly-accused-of-nazi-salute-at-trump-rally",
      "display_url" : "thehill.com\/blogs\/ballot-b\u2026"
    }, {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/IVBZXcIyhE",
      "expanded_url" : "http:\/\/thehill.com\/blogs\/blog-briefing-room\/news-campaigns\/272798-trump-supporter-who-gave-nazi-salute-im-not-a-nazi",
      "display_url" : "thehill.com\/blogs\/blog-bri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708826645231046656",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked\n\nhttps:\/\/t.co\/JwEUmzKxgg\n\nhttps:\/\/t.co\/IVBZXcIyhE",
  "id" : 708826645231046656,
  "created_at" : "2016-03-13 01:26:56 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708732725549670401",
  "text" : "since twitter is a media company, it should report findings and pit them against MSM",
  "id" : 708732725549670401,
  "created_at" : "2016-03-12 19:13:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilkie",
      "screen_name" : "wilkieii",
      "indices" : [ 3, 12 ],
      "id_str" : "17047955",
      "id" : 17047955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708732219360022528",
  "text" : "RT @wilkieii: Trump: People are using 1st amendment rights to impede my free speech\nHillary: Maybe we can be nice to fascism?\nBernie: FUCK.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "708538390837334016",
    "text" : "Trump: People are using 1st amendment rights to impede my free speech\nHillary: Maybe we can be nice to fascism?\nBernie: FUCK. RAHM. EMANUEL.",
    "id" : 708538390837334016,
    "created_at" : "2016-03-12 06:21:31 +0000",
    "user" : {
      "name" : "wilkie",
      "screen_name" : "wilkieii",
      "protected" : false,
      "id_str" : "17047955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719917946781483009\/DyVtEL-R_normal.jpg",
      "id" : 17047955,
      "verified" : false
    }
  },
  "id" : 708732219360022528,
  "created_at" : "2016-03-12 19:11:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u252C\u2534\u252C\u2534\u2524~ \u1555( \u141B )\u1557",
      "screen_name" : "__tjf__",
      "indices" : [ 3, 11 ],
      "id_str" : "277320585",
      "id" : 277320585
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/__tjf__\/status\/708316253614641152\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/ggjCeIAeq4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdRx4RUWAAANZAz.jpg",
      "id_str" : "708316252939354112",
      "id" : 708316252939354112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdRx4RUWAAANZAz.jpg",
      "sizes" : [ {
        "h" : 367,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ggjCeIAeq4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708335347738869762",
  "text" : "RT @__tjf__: Have CAPTCHAs gone too far? https:\/\/t.co\/ggjCeIAeq4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/__tjf__\/status\/708316253614641152\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/ggjCeIAeq4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdRx4RUWAAANZAz.jpg",
        "id_str" : "708316252939354112",
        "id" : 708316252939354112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdRx4RUWAAANZAz.jpg",
        "sizes" : [ {
          "h" : 367,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 778,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 778,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ggjCeIAeq4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "708316253614641152",
    "text" : "Have CAPTCHAs gone too far? https:\/\/t.co\/ggjCeIAeq4",
    "id" : 708316253614641152,
    "created_at" : "2016-03-11 15:38:49 +0000",
    "user" : {
      "name" : "\u252C\u2534\u252C\u2534\u2524~ \u1555( \u141B )\u1557",
      "screen_name" : "__tjf__",
      "protected" : false,
      "id_str" : "277320585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727169802020773888\/rLCJAEKa_normal.jpg",
      "id" : 277320585,
      "verified" : false
    }
  },
  "id" : 708335347738869762,
  "created_at" : "2016-03-11 16:54:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/tD7xz8WqZk",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/splashing-light",
      "display_url" : "soundcloud.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708169134865920007",
  "text" : "purr code https:\/\/t.co\/tD7xz8WqZk",
  "id" : 708169134865920007,
  "created_at" : "2016-03-11 05:54:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "indices" : [ 3, 18 ],
      "id_str" : "620142261",
      "id" : 620142261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707272875959578630",
  "text" : "RT @KimKierkegaard: Take away the clothes and power and wealth, and the admiration of one's followers. Now take a truly naked selfie.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "707244775083274241",
    "text" : "Take away the clothes and power and wealth, and the admiration of one's followers. Now take a truly naked selfie.",
    "id" : 707244775083274241,
    "created_at" : "2016-03-08 16:41:09 +0000",
    "user" : {
      "name" : "KimKierkegaardashian",
      "screen_name" : "KimKierkegaard",
      "protected" : false,
      "id_str" : "620142261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2346161730\/images-2_normal.jpg",
      "id" : 620142261,
      "verified" : false
    }
  },
  "id" : 707272875959578630,
  "created_at" : "2016-03-08 18:32:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood",
      "screen_name" : "girlziplocked",
      "indices" : [ 0, 14 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707052407214239744",
  "geo" : { },
  "id_str" : "707053496755834880",
  "in_reply_to_user_id" : 20221325,
  "text" : "@girlziplocked id read books 4 u",
  "id" : 707053496755834880,
  "in_reply_to_status_id" : 707052407214239744,
  "created_at" : "2016-03-08 04:01:04 +0000",
  "in_reply_to_screen_name" : "girlziplocked",
  "in_reply_to_user_id_str" : "20221325",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706917077806755840",
  "text" : "tfw when you impress some crazy-talented, youtube-trained, rihanna-worshipping, dancer-youth w\/ freestyle moves at yr local revolution space",
  "id" : 706917077806755840,
  "created_at" : "2016-03-07 18:58:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/ss1CqXQ1So",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/706611635843153920",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706611898020663296",
  "text" : "never talk to state sanctioned media, never forget\n\nhttps:\/\/t.co\/ss1CqXQ1So",
  "id" : 706611898020663296,
  "created_at" : "2016-03-06 22:46:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706611635843153920",
  "text" : "lol this wapo piece on drug cartels quotes the DEA Threat Assessment to Confirm that legal California marijuana is \"thought to be superior\"",
  "id" : 706611635843153920,
  "created_at" : "2016-03-06 22:45:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706606468045344768",
  "text" : "I wonder when they'll bust out the ronald reagan hologram to denounce trump",
  "id" : 706606468045344768,
  "created_at" : "2016-03-06 22:24:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/p9x6N2jnCM",
      "expanded_url" : "https:\/\/twitter.com\/markwwilsonmd\/status\/706176404338122752",
      "display_url" : "twitter.com\/markwwilsonmd\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706201399671918592",
  "text" : "\"Christy, come on smile for the people.\" https:\/\/t.co\/p9x6N2jnCM",
  "id" : 706201399671918592,
  "created_at" : "2016-03-05 19:35:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 0, 11 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706161402264883200",
  "geo" : { },
  "id_str" : "706172371816681472",
  "in_reply_to_user_id" : 2375721396,
  "text" : "@Satoshi_N_  so an already expensive framework is more costly to use cuz of currency speculation?  are you bearish on computational futures?",
  "id" : 706172371816681472,
  "in_reply_to_status_id" : 706161402264883200,
  "created_at" : "2016-03-05 17:39:48 +0000",
  "in_reply_to_screen_name" : "Satoshi_N_",
  "in_reply_to_user_id_str" : "2375721396",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705857383453462529",
  "text" : "CHOOSE YOUR OWN CONDITIONAL STORY",
  "id" : 705857383453462529,
  "created_at" : "2016-03-04 20:48:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/705584358594248704\/photo\/1",
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/l9iIp7dcq4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ccq9PDrUkAELJg-.jpg",
      "id_str" : "705584358019600385",
      "id" : 705584358019600385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ccq9PDrUkAELJg-.jpg",
      "sizes" : [ {
        "h" : 276,
        "resize" : "fit",
        "w" : 283
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 283
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 283
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 283
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/l9iIp7dcq4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705584358594248704",
  "text" : "VOTE HERE https:\/\/t.co\/l9iIp7dcq4",
  "id" : 705584358594248704,
  "created_at" : "2016-03-04 02:43:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705583615938179073",
  "text" : "\"THESE ASCII TOILETS ARE FRANKLY NOT WORKS OF ART\" - R MUDD",
  "id" : 705583615938179073,
  "created_at" : "2016-03-04 02:40:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705582894400417793",
  "text" : "STARTUP IDEA: ABS NETWORK",
  "id" : 705582894400417793,
  "created_at" : "2016-03-04 02:37:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705582847218753536",
  "text" : "IM BORED AND KILLING TIME TIL THIS TWITTER PROFILE BECOMES 100% SPAM FOR MY LIFESTYLE CULT BUSINESS",
  "id" : 705582847218753536,
  "created_at" : "2016-03-04 02:37:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/4Hp0CbUj8q",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/696086058337849344",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705581613548044289",
  "text" : "IF IT WAS A DARK OR STORMY AND NIGHT\n\nhttps:\/\/t.co\/4Hp0CbUj8q",
  "id" : 705581613548044289,
  "created_at" : "2016-03-04 02:32:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/4Hp0CbUj8q",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/696086058337849344",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705581261276876801",
  "text" : "I streamed about 5 minutes of the #GOPDebate and had a good laugh then controlled w that shit\n\nhttps:\/\/t.co\/4Hp0CbUj8q",
  "id" : 705581261276876801,
  "created_at" : "2016-03-04 02:30:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/4Hp0CbUj8q",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/696086058337849344",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705580312667910144",
  "text" : "This Pinned Tweet, Like a Clock moving at Infinite Speed, Is Correct At All Times \n\nhttps:\/\/t.co\/4Hp0CbUj8q",
  "id" : 705580312667910144,
  "created_at" : "2016-03-04 02:27:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/4YWCtVs2jS",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/705530391470305280",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705578386689626112",
  "text" : "that's the joke\n\nhttps:\/\/t.co\/4YWCtVs2jS",
  "id" : 705578386689626112,
  "created_at" : "2016-03-04 02:19:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DPRK News Service",
      "screen_name" : "DPRK_News",
      "indices" : [ 3, 13 ],
      "id_str" : "58569513",
      "id" : 58569513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705565729005965312",
  "text" : "RT @DPRK_News: Abandonment of Bayesian statistical method as urged by Supreme Leader Kim Jong-Un results in tripled greenhouse vegetable pr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705121540761788416",
    "text" : "Abandonment of Bayesian statistical method as urged by Supreme Leader Kim Jong-Un results in tripled greenhouse vegetable productivity.",
    "id" : 705121540761788416,
    "created_at" : "2016-03-02 20:04:10 +0000",
    "user" : {
      "name" : "DPRK News Service",
      "screen_name" : "DPRK_News",
      "protected" : false,
      "id_str" : "58569513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/323235980\/dprk-flag_normal.gif",
      "id" : 58569513,
      "verified" : false
    }
  },
  "id" : 705565729005965312,
  "created_at" : "2016-03-04 01:29:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DPRK News Service",
      "screen_name" : "DPRK_News",
      "indices" : [ 3, 13 ],
      "id_str" : "58569513",
      "id" : 58569513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705565297286225920",
  "text" : "RT @DPRK_News: Supreme Leader Kim Jong-Un uses Juche dialectic principles to persuade missing cat to emerge from tree, to relief of happy c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705458728179359744",
    "text" : "Supreme Leader Kim Jong-Un uses Juche dialectic principles to persuade missing cat to emerge from tree, to relief of happy children.",
    "id" : 705458728179359744,
    "created_at" : "2016-03-03 18:24:02 +0000",
    "user" : {
      "name" : "DPRK News Service",
      "screen_name" : "DPRK_News",
      "protected" : false,
      "id_str" : "58569513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/323235980\/dprk-flag_normal.gif",
      "id" : 58569513,
      "verified" : false
    }
  },
  "id" : 705565297286225920,
  "created_at" : "2016-03-04 01:27:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bored Elon Musk",
      "screen_name" : "BoredElonMusk",
      "indices" : [ 0, 14 ],
      "id_str" : "1666038950",
      "id" : 1666038950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705530391470305280",
  "in_reply_to_user_id" : 1666038950,
  "text" : "@BoredElonMusk, A Fragrance for Bored People",
  "id" : 705530391470305280,
  "created_at" : "2016-03-03 23:08:48 +0000",
  "in_reply_to_screen_name" : "BoredElonMusk",
  "in_reply_to_user_id_str" : "1666038950",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/eL9kB9Ce5E",
      "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2016\/mar\/03\/secret-donald-trump-voters-speak-out#pq=KrXO3X",
      "display_url" : "theguardian.com\/us-news\/2016\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705480992061067264",
  "text" : "these ppl mainly defend their person politics, but their actual reasonings for supporting Drumpf is fucking moronic\n\nhttps:\/\/t.co\/eL9kB9Ce5E",
  "id" : 705480992061067264,
  "created_at" : "2016-03-03 19:52:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/quwnOL5e3d",
      "expanded_url" : "https:\/\/twitter.com\/girlziplocked\/status\/705463964952567808",
      "display_url" : "twitter.com\/girlziplocked\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705475558113742848",
  "text" : "this is cathartic, tho tbqh I am for harsher treatment of baby boomers https:\/\/t.co\/quwnOL5e3d",
  "id" : 705475558113742848,
  "created_at" : "2016-03-03 19:30:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/g90b5vVEAd",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=yFzJf4IrjYA",
      "display_url" : "youtube.com\/watch?v=yFzJf4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704759123506630656",
  "text" : "me playing a funky glitched javascript autosynth with generated parametrical user interface  *fingersweeps shoulder* https:\/\/t.co\/g90b5vVEAd",
  "id" : 704759123506630656,
  "created_at" : "2016-03-01 20:04:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]