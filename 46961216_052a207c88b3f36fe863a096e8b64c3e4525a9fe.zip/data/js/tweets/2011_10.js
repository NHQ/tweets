Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "indices" : [ 6, 16 ],
      "id_str" : "13696102",
      "id" : 13696102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131187018582593536",
  "text" : "HELP! @indexzero running forever 4 #nodejs started app, can't stop it! forever list says no processes, but it revives it after top-kill !!!",
  "id" : 131187018582593536,
  "created_at" : "2011-11-01 01:53:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/7PgJPmF2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ExP0BPf3gLI",
      "display_url" : "youtube.com\/watch?v=ExP0BP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "131036098691469312",
  "text" : "consumed by the dark side #ows http:\/\/t.co\/7PgJPmF2",
  "id" : 131036098691469312,
  "created_at" : "2011-10-31 15:53:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 43, 47 ]
    }, {
      "text" : "freeEducation",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131035466916040704",
  "text" : "student debt bailout $ &lt; bank bailout $ #ows #freeEducation",
  "id" : 131035466916040704,
  "created_at" : "2011-10-31 15:51:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130471270994280448",
  "in_reply_to_user_id" : 242154581,
  "text" : "@FourYawkeyWay What is your occupation\/affiliation re: news aggregation, reportage, etc etc?",
  "id" : 130471270994280448,
  "created_at" : "2011-10-30 02:29:09 +0000",
  "in_reply_to_screen_name" : "Igualitarista",
  "in_reply_to_user_id_str" : "242154581",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4thVoice",
      "screen_name" : "4thVoice",
      "indices" : [ 3, 12 ],
      "id_str" : "80131045",
      "id" : 80131045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupy",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130466595238719488",
  "text" : "RT @4thVoice: When we look back 5 years from now it will be obvious what #occupy was fighting and we'll think, why did we wait so long.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupy",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130462632019886080",
    "text" : "When we look back 5 years from now it will be obvious what #occupy was fighting and we'll think, why did we wait so long.",
    "id" : 130462632019886080,
    "created_at" : "2011-10-30 01:54:50 +0000",
    "user" : {
      "name" : "4thVoice",
      "screen_name" : "4thVoice",
      "protected" : false,
      "id_str" : "80131045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117499932\/thumbnail_normal.jpg",
      "id" : 80131045,
      "verified" : false
    }
  },
  "id" : 130466595238719488,
  "created_at" : "2011-10-30 02:10:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupyOakland",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129029534304583680",
  "text" : "Keep moving, don't let them surround you. Pull back, regroup, move to flank. Use ur mobility and decentralization! #occupyOakland",
  "id" : 129029534304583680,
  "created_at" : "2011-10-26 03:00:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupyAlbany",
      "indices" : [ 60, 73 ]
    }, {
      "text" : "ows",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/coC6sy8s",
      "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2011\/10\/24\/new-york-cops-defy-order-to-arrest-hundreds-of-occupy-protesters\/",
      "display_url" : "rawstory.com\/rs\/2011\/10\/24\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128941167302811648",
  "text" : "Police reject Mayor's, Governor's call to arrest protestors #occupyAlbany #ows http:\/\/t.co\/coC6sy8s",
  "id" : 128941167302811648,
  "created_at" : "2011-10-25 21:09:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/P7dIFbqL",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2011\/10\/18\/1027775\/-TSA-Arrests-Me-for-Using-the-Fourth-Amendment-as-a-Weapon-%28Tales-from-the-Edge-of-a-Revolution-2%29?via=siderec",
      "display_url" : "dailykos.com\/story\/2011\/10\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128257895518322688",
  "text" : "stirring report http:\/\/t.co\/P7dIFbqL",
  "id" : 128257895518322688,
  "created_at" : "2011-10-23 23:53:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fascism",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "ows",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/DF2ijLX6",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/commentisfree\/cifamerica\/2011\/oct\/19\/naomi-wolf-arrest-occupy-wall-street?CMP=twt_gu",
      "display_url" : "guardian.co.uk\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128214881970307072",
  "text" : "Fed & Local Government are usurping and eroding constitutional liberties. #fascism Naomi Wolf on her arrest at #ows http:\/\/t.co\/DF2ijLX6",
  "id" : 128214881970307072,
  "created_at" : "2011-10-23 21:03:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy Oakland",
      "screen_name" : "OccupyOakland",
      "indices" : [ 3, 17 ],
      "id_str" : "383558512",
      "id" : 383558512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127232689865621504",
  "text" : "RT @occupyoakland: the more #'s that are there, the harder it will b for them 2 evict us. Also, as seen through #ows, with enough number ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ows",
        "indices" : [ 93, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127231800291508224",
    "text" : "the more #'s that are there, the harder it will b for them 2 evict us. Also, as seen through #ows, with enough numbers they will back down",
    "id" : 127231800291508224,
    "created_at" : "2011-10-21 03:56:39 +0000",
    "user" : {
      "name" : "Occupy Oakland",
      "screen_name" : "OccupyOakland",
      "protected" : false,
      "id_str" : "383558512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000268346400\/547491411d2776db4dde89a63eb11607_normal.png",
      "id" : 383558512,
      "verified" : false
    }
  },
  "id" : 127232689865621504,
  "created_at" : "2011-10-21 04:00:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chicago",
      "indices" : [ 39, 47 ]
    }, {
      "text" : "occupy",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "occupychicago",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/vndipO08",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=s9Q16fTEMcE&feature=youtu.be&a",
      "display_url" : "youtube.com\/watch?v=s9Q16f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126847443278118912",
  "text" : "give this a full listen with your ears #chicago #occupy #occupychicago http:\/\/t.co\/vndipO08",
  "id" : 126847443278118912,
  "created_at" : "2011-10-20 02:29:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126554368597168128",
  "text" : "Sometimes the whirring of the computer sounds like the crowd cheering in Mike Tyson's Punch Out",
  "id" : 126554368597168128,
  "created_at" : "2011-10-19 07:04:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Geisend\u00F6rfer",
      "screen_name" : "felixge",
      "indices" : [ 50, 58 ],
      "id_str" : "9599342",
      "id" : 9599342
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125213345916796928",
  "geo" : { },
  "id_str" : "126038171334086656",
  "in_reply_to_user_id" : 9599342,
  "text" : "formidable and transloadit are both great, Thanks @felixge #nodejs",
  "id" : 126038171334086656,
  "in_reply_to_status_id" : 125213345916796928,
  "created_at" : "2011-10-17 20:53:36 +0000",
  "in_reply_to_screen_name" : "felixge",
  "in_reply_to_user_id_str" : "9599342",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126037364958179328",
  "text" : "what happens to my app if i do this #nodejs",
  "id" : 126037364958179328,
  "created_at" : "2011-10-17 20:50:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "census",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "data",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "semanticWeb",
      "indices" : [ 80, 92 ]
    }, {
      "text" : "javascript",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "dictionaries",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123985693172174848",
  "text" : "var california_cities = new States().ca().cities(\u007Bpop&gt;10,000\u007D) #census #data #semanticWeb #javascript #dictionaries",
  "id" : 123985693172174848,
  "created_at" : "2011-10-12 04:57:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "javascript",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123985092799500288",
  "text" : "Idea for that semantic web dream: var states = new States().all(), caps=[ ]; each(states, fn (st) \u007Bcaps.push(st.capital)\u007D) #javascript",
  "id" : 123985092799500288,
  "created_at" : "2011-10-12 04:55:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/WD0r3nTe",
      "expanded_url" : "http:\/\/j.mp\/pTrnHe",
      "display_url" : "j.mp\/pTrnHe"
    } ]
  },
  "geo" : { },
  "id_str" : "122845971678896129",
  "text" : "campaign finance as money laundering #ows http:\/\/t.co\/WD0r3nTe",
  "id" : 122845971678896129,
  "created_at" : "2011-10-09 01:28:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nicepeter",
      "screen_name" : "nicepeter",
      "indices" : [ 0, 10 ],
      "id_str" : "18424591",
      "id" : 18424591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122079546437672961",
  "in_reply_to_user_id" : 18424591,
  "text" : "@nicepeter did you ever perform at the saturday night \"open mic\" at the IO in chicago back in the early aughts?",
  "id" : 122079546437672961,
  "created_at" : "2011-10-06 22:43:26 +0000",
  "in_reply_to_screen_name" : "nicepeter",
  "in_reply_to_user_id_str" : "18424591",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 0, 11 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121781206021963777",
  "geo" : { },
  "id_str" : "121783391979962369",
  "in_reply_to_user_id" : 47951511,
  "text" : "@zunguzungu we should all be so lucky. accomplish the extraordinary, and live long enough to be forgotten in our own time.",
  "id" : 121783391979962369,
  "in_reply_to_status_id" : 121781206021963777,
  "created_at" : "2011-10-06 03:06:37 +0000",
  "in_reply_to_screen_name" : "zunguzungu",
  "in_reply_to_user_id_str" : "47951511",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lapham's Quarterly",
      "screen_name" : "LaphamsQuart",
      "indices" : [ 3, 16 ],
      "id_str" : "83665853",
      "id" : 83665853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3KGYrCsL",
      "expanded_url" : "http:\/\/bit.ly\/q9hfIX",
      "display_url" : "bit.ly\/q9hfIX"
    } ]
  },
  "geo" : { },
  "id_str" : "121777104319819776",
  "text" : "RT @LaphamsQuart: Genius: When the soul has been moved by an object itself, it is even more affected by the memory of the object. http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/3KGYrCsL",
        "expanded_url" : "http:\/\/bit.ly\/q9hfIX",
        "display_url" : "bit.ly\/q9hfIX"
      } ]
    },
    "geo" : { },
    "id_str" : "121775411561627648",
    "text" : "Genius: When the soul has been moved by an object itself, it is even more affected by the memory of the object. http:\/\/t.co\/3KGYrCsL",
    "id" : 121775411561627648,
    "created_at" : "2011-10-06 02:34:55 +0000",
    "user" : {
      "name" : "Lapham's Quarterly",
      "screen_name" : "LaphamsQuart",
      "protected" : false,
      "id_str" : "83665853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610510790794174464\/9FVsYFPZ_normal.png",
      "id" : 83665853,
      "verified" : false
    }
  },
  "id" : 121777104319819776,
  "created_at" : "2011-10-06 02:41:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121774265606488064",
  "text" : "Thank you for thinking about all of us, Steve Jobs.",
  "id" : 121774265606488064,
  "created_at" : "2011-10-06 02:30:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121772132425400322",
  "text" : "RT @AngelineGragzin: RIP Steve",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.0765183412, -118.3436893038 ]
    },
    "id_str" : "121749280951250945",
    "text" : "RIP Steve",
    "id" : 121749280951250945,
    "created_at" : "2011-10-06 00:51:05 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703307803574865921\/ZpTWouST_normal.jpg",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 121772132425400322,
  "created_at" : "2011-10-06 02:21:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HelpInternetHELPHELP",
      "indices" : [ 96, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/xZqpCkYt",
      "expanded_url" : "https:\/\/apps.facebook.com\/my-polls\/b9lk1rnt",
      "display_url" : "apps.facebook.com\/my-polls\/b9lk1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121267616902955008",
  "text" : "RT @AngelineGragzin: ONLY FIVE MINUTES LEFT!! Please vote for The Animals! http:\/\/t.co\/xZqpCkYt #HelpInternetHELPHELP!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HelpInternetHELPHELP",
        "indices" : [ 75, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/xZqpCkYt",
        "expanded_url" : "https:\/\/apps.facebook.com\/my-polls\/b9lk1rnt",
        "display_url" : "apps.facebook.com\/my-polls\/b9lk1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "121267068434784257",
    "text" : "ONLY FIVE MINUTES LEFT!! Please vote for The Animals! http:\/\/t.co\/xZqpCkYt #HelpInternetHELPHELP!",
    "id" : 121267068434784257,
    "created_at" : "2011-10-04 16:54:56 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703307803574865921\/ZpTWouST_normal.jpg",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 121267616902955008,
  "created_at" : "2011-10-04 16:57:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yankHank",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121031422382325760",
  "text" : "May the world be finally rid of Hank Williams II's shameful bafoonery #yankHank",
  "id" : 121031422382325760,
  "created_at" : "2011-10-04 01:18:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AiGameDev",
      "screen_name" : "AiGameDev",
      "indices" : [ 0, 10 ],
      "id_str" : "14116195",
      "id" : 14116195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121018924430131201",
  "in_reply_to_user_id" : 9115762,
  "text" : "@AiGameDev if you don't mind implementing backend features in node.js, I fit the bill. It's not hard to integrate. contact?",
  "id" : 121018924430131201,
  "created_at" : "2011-10-04 00:28:54 +0000",
  "in_reply_to_screen_name" : "alexjc",
  "in_reply_to_user_id_str" : "9115762",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 0, 16 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120924476295753728",
  "geo" : { },
  "id_str" : "121018114044461056",
  "in_reply_to_user_id" : 14475298,
  "text" : "@tinysubversions #nodejs meetup thursday los angeles",
  "id" : 121018114044461056,
  "in_reply_to_status_id" : 120924476295753728,
  "created_at" : "2011-10-04 00:25:41 +0000",
  "in_reply_to_screen_name" : "tinysubversions",
  "in_reply_to_user_id_str" : "14475298",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sundays",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120623084469370880",
  "text" : "I feel suddenly, slightly-ashamed at never having yet created a wikipedia profile. Never too late to step up to base plate. #sundays",
  "id" : 120623084469370880,
  "created_at" : "2011-10-02 22:15:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/nOrzK1AN",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Bitwise_operation",
      "display_url" : "en.wikipedia.org\/wiki\/Bitwise_o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120620085277765632",
  "text" : "it's important to know that reading bit numbers u go right to left. Prolly taught in CS, not mentioned on wikipedia. http:\/\/t.co\/nOrzK1AN",
  "id" : 120620085277765632,
  "created_at" : "2011-10-02 22:04:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120210806720835584",
  "text" : "throw your homies in the sky",
  "id" : 120210806720835584,
  "created_at" : "2011-10-01 18:57:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 9, 20 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/jKoWbXRK",
      "expanded_url" : "http:\/\/www.effectgames.com\/demos\/canvascycle\/",
      "display_url" : "effectgames.com\/demos\/canvascy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120186015838257152",
  "text" : "neat.io \u201C@uptownherd: @hymnhummer color coding http:\/\/t.co\/jKoWbXRK\u201D",
  "id" : 120186015838257152,
  "created_at" : "2011-10-01 17:19:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/tc7URij4",
      "expanded_url" : "http:\/\/www.willwilkinson.net\/flybottle\/2009\/03\/05\/on-going-galt\/",
      "display_url" : "willwilkinson.net\/flybottle\/2009\u2026"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/IbvfDqjS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Uz2j3BhL47c",
      "display_url" : "youtube.com\/watch?v=Uz2j3B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120008955249442817",
  "text" : "It's fun to read and watch about Ayn Rand novels without ever reading Ayn Rand novels http:\/\/t.co\/tc7URij4 y http:\/\/t.co\/IbvfDqjS",
  "id" : 120008955249442817,
  "created_at" : "2011-10-01 05:35:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Park",
      "screen_name" : "donpark",
      "indices" : [ 0, 8 ],
      "id_str" : "892821",
      "id" : 892821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "119947348737654786",
  "geo" : { },
  "id_str" : "120002259156336640",
  "in_reply_to_user_id" : 892821,
  "text" : "@donpark they're doing the \"odd tenths are not necessarily production stable\" kind of incrementation #nodejs",
  "id" : 120002259156336640,
  "in_reply_to_status_id" : 119947348737654786,
  "created_at" : "2011-10-01 05:09:02 +0000",
  "in_reply_to_screen_name" : "donpark",
  "in_reply_to_user_id_str" : "892821",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]