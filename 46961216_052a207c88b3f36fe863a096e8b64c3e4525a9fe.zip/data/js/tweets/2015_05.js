Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605132396199964672",
  "text" : "achievement unlocked:  my left leg",
  "id" : 605132396199964672,
  "created_at" : "2015-05-31 22:03:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605126313037275136",
  "text" : "birds always flying into my home.  that's cuz it's calm as ancient trees here.",
  "id" : 605126313037275136,
  "created_at" : "2015-05-31 21:38:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605115760273424384",
  "geo" : { },
  "id_str" : "605119151540019200",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey  Are you moving to the west coast?",
  "id" : 605119151540019200,
  "in_reply_to_status_id" : 605115760273424384,
  "created_at" : "2015-05-31 21:10:22 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandro Pasquali",
      "screen_name" : "spasquali",
      "indices" : [ 0, 10 ],
      "id_str" : "198922559",
      "id" : 198922559
    }, {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 11, 20 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605103076786208768",
  "geo" : { },
  "id_str" : "605118563771285504",
  "in_reply_to_user_id" : 198922559,
  "text" : "@spasquali @jfhbrook  pretty much, but we don't have to watch anymore if we don't want to. This article is totes correct, but also watching.",
  "id" : 605118563771285504,
  "in_reply_to_status_id" : 605103076786208768,
  "created_at" : "2015-05-31 21:08:02 +0000",
  "in_reply_to_screen_name" : "spasquali",
  "in_reply_to_user_id_str" : "198922559",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SecuriTay",
      "screen_name" : "SwiftOnSecurity",
      "indices" : [ 0, 16 ],
      "id_str" : "2436389418",
      "id" : 2436389418
    }, {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 17, 28 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605094015331999744",
  "geo" : { },
  "id_str" : "605115102098890753",
  "in_reply_to_user_id" : 2436389418,
  "text" : "@SwiftOnSecurity @legittalon drones of a certain moral persuasion with regard to property",
  "id" : 605115102098890753,
  "in_reply_to_status_id" : 605094015331999744,
  "created_at" : "2015-05-31 20:54:17 +0000",
  "in_reply_to_screen_name" : "SwiftOnSecurity",
  "in_reply_to_user_id_str" : "2436389418",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SecuriTay",
      "screen_name" : "SwiftOnSecurity",
      "indices" : [ 0, 16 ],
      "id_str" : "2436389418",
      "id" : 2436389418
    }, {
      "name" : "type Talon = Idiot",
      "screen_name" : "legittalon",
      "indices" : [ 17, 28 ],
      "id_str" : "64105403",
      "id" : 64105403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605094015331999744",
  "geo" : { },
  "id_str" : "605115047522631681",
  "in_reply_to_user_id" : 2436389418,
  "text" : "@SwiftOnSecurity @legittalon  the set of all the problems introduced by phones duct taped to drones",
  "id" : 605115047522631681,
  "in_reply_to_status_id" : 605094015331999744,
  "created_at" : "2015-05-31 20:54:04 +0000",
  "in_reply_to_screen_name" : "SwiftOnSecurity",
  "in_reply_to_user_id_str" : "2436389418",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/g2BJbi1rcl",
      "expanded_url" : "https:\/\/github.com\/feross\/whiteboard\/blob\/master\/client\/index.js#L226",
      "display_url" : "github.com\/feross\/whitebo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605109411460153345",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross  i also wondered if this kind of thing worked for webRTC peer discovery.  sweet hack  ;^D\n\nhttps:\/\/t.co\/g2BJbi1rcl",
  "id" : 605109411460153345,
  "created_at" : "2015-05-31 20:31:40 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 13, 25 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605109166160637953",
  "geo" : { },
  "id_str" : "605109374638383104",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost @marinakukso   \nKINDERSPIEL!",
  "id" : 605109374638383104,
  "in_reply_to_status_id" : 605109166160637953,
  "created_at" : "2015-05-31 20:31:31 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605094871058096128",
  "geo" : { },
  "id_str" : "605099562596835328",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross  I wonder at the legalities of how we seem to lose fundamental rights entering corporate territory, as consumers, and as workers.",
  "id" : 605099562596835328,
  "in_reply_to_status_id" : 605094871058096128,
  "created_at" : "2015-05-31 19:52:32 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 25, 37 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605061754003931136",
  "geo" : { },
  "id_str" : "605098576595685376",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso OH MFG  \ncc\/@TheHatGhost",
  "id" : 605098576595685376,
  "in_reply_to_status_id" : 605061754003931136,
  "created_at" : "2015-05-31 19:48:37 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604374545676517376",
  "geo" : { },
  "id_str" : "604709300871626752",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts whatcha makin?",
  "id" : 604709300871626752,
  "in_reply_to_status_id" : 604374545676517376,
  "created_at" : "2015-05-30 18:01:46 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604368420092661760",
  "geo" : { },
  "id_str" : "604371656362995712",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts  connect is really an API for \"lower level\" or other-process audio graphing, afaik",
  "id" : 604371656362995712,
  "in_reply_to_status_id" : 604368420092661760,
  "created_at" : "2015-05-29 19:40:06 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604368420092661760",
  "geo" : { },
  "id_str" : "604371184826765312",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts  true, but only one node really needs to be streamy, an I\/O node, which I have wrote.  it simply exports a createStream method.",
  "id" : 604371184826765312,
  "in_reply_to_status_id" : 604368420092661760,
  "created_at" : "2015-05-29 19:38:13 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/v416tccdsp",
      "expanded_url" : "http:\/\/www.eastbayexpress.com\/oakland\/counter-terrorism-officials-helped-track-black-lives-matter-protesters\/Content?oid=4247605",
      "display_url" : "eastbayexpress.com\/oakland\/counte\u2026"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Dyv8XWtciu",
      "expanded_url" : "http:\/\/m.eastbayexpress.com\/SevenDays\/archives\/2015\/05\/27\/ten-fbi-agents-joining-oakland-police-department",
      "display_url" : "m.eastbayexpress.com\/SevenDays\/arch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603665407636021248",
  "text" : "counter-terrorists tracking political protestors  http:\/\/t.co\/v416tccdsp\n\nFBI aiding OPD http:\/\/t.co\/Dyv8XWtciu\n\n#oakland",
  "id" : 603665407636021248,
  "created_at" : "2015-05-27 20:53:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603629852944637953",
  "text" : "STEP 1: JOIN THE SYSTEM TO BEAT SAME\nU ARE NOW A PART THE SYSTEM\nSTEP 2: FIGHT 4 SELF PRESERVATION\nU ARE NOW FIGHTING 4 PRESERVATION OF SAME",
  "id" : 603629852944637953,
  "created_at" : "2015-05-27 18:32:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603627504155402240",
  "text" : "ALL HOPED UP ON GOOF CONCEPTS",
  "id" : 603627504155402240,
  "created_at" : "2015-05-27 18:23:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603601139691606016",
  "text" : "how is TSP NP?  The only way to know that your solution is correct is to test all vectors.  That is not easy.",
  "id" : 603601139691606016,
  "created_at" : "2015-05-27 16:38:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Aam8e9vi6J",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/1836537355\/counter-culture-labs-your-biohacking-and-citizen-s",
      "display_url" : "kickstarter.com\/projects\/18365\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603382619036725248",
  "text" : "support biohacking, indie labs, and citizen science in #oakland  https:\/\/t.co\/Aam8e9vi6J",
  "id" : 603382619036725248,
  "created_at" : "2015-05-27 02:10:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/NQFYgAqehR",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/dionne",
      "display_url" : "soundcloud.com\/folkstack\/dion\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603364120818159616",
  "text" : "This beautiful sound was discovered testing muh software interface. Click if you like Dionne Warwick, or Vietnamese.\nhttps:\/\/t.co\/NQFYgAqehR",
  "id" : 603364120818159616,
  "created_at" : "2015-05-27 00:56:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "East Bay Express",
      "screen_name" : "EastBayExpress",
      "indices" : [ 3, 18 ],
      "id_str" : "19315665",
      "id" : 19315665
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EastBayExpress\/status\/603294546814967808\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8rAIylEk7h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF9VMZ9XIAIIZbl.jpg",
      "id_str" : "603294546705981442",
      "id" : 603294546705981442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF9VMZ9XIAIIZbl.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 475
      } ],
      "display_url" : "pic.twitter.com\/8rAIylEk7h"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/RBHG04jbwv",
      "expanded_url" : "http:\/\/buff.ly\/1cY5Lc0",
      "display_url" : "buff.ly\/1cY5Lc0"
    } ]
  },
  "geo" : { },
  "id_str" : "603304458366263296",
  "text" : "RT @EastBayExpress: OPD uses its resources to patrol poor neighborhoods, has poor track record for solving crime http:\/\/t.co\/RBHG04jbwv htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EastBayExpress\/status\/603294546814967808\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8rAIylEk7h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF9VMZ9XIAIIZbl.jpg",
        "id_str" : "603294546705981442",
        "id" : 603294546705981442,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF9VMZ9XIAIIZbl.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 475
        } ],
        "display_url" : "pic.twitter.com\/8rAIylEk7h"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/RBHG04jbwv",
        "expanded_url" : "http:\/\/buff.ly\/1cY5Lc0",
        "display_url" : "buff.ly\/1cY5Lc0"
      } ]
    },
    "geo" : { },
    "id_str" : "603294546814967808",
    "text" : "OPD uses its resources to patrol poor neighborhoods, has poor track record for solving crime http:\/\/t.co\/RBHG04jbwv http:\/\/t.co\/8rAIylEk7h",
    "id" : 603294546814967808,
    "created_at" : "2015-05-26 20:20:03 +0000",
    "user" : {
      "name" : "East Bay Express",
      "screen_name" : "EastBayExpress",
      "protected" : false,
      "id_str" : "19315665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727664063103148032\/mF_dtiRx_normal.jpg",
      "id" : 19315665,
      "verified" : false
    }
  },
  "id" : 603304458366263296,
  "created_at" : "2015-05-26 20:59:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603286936166367232",
  "text" : "kickstarter for a hoodie that has comb teeth inside the hood",
  "id" : 603286936166367232,
  "created_at" : "2015-05-26 19:49:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/603067947393757186\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/tfzUtFWS1g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF6HF9nUMAAomVK.png",
      "id_str" : "603067936622784512",
      "id" : 603067936622784512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF6HF9nUMAAomVK.png",
      "sizes" : [ {
        "h" : 985,
        "resize" : "fit",
        "w" : 1908
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/tfzUtFWS1g"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/VyoEMfzE2J",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/donfuccupmuhshitdof",
      "display_url" : "soundcloud.com\/folkstack\/donf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603067947393757186",
  "text" : "sample sound created messin round w\/ the sample mess creator\ncurrent version buggy but sound\n\nhttps:\/\/t.co\/VyoEMfzE2J http:\/\/t.co\/tfzUtFWS1g",
  "id" : 603067947393757186,
  "created_at" : "2015-05-26 05:19:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreakTheCurfew",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603007770686656512",
  "geo" : { },
  "id_str" : "603008069757325313",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  all for the exercise of power, by people who think they have more than they actually do.  It will run out.  #BreakTheCurfew",
  "id" : 603008069757325313,
  "in_reply_to_status_id" : 603007770686656512,
  "created_at" : "2015-05-26 01:21:41 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603007770686656512",
  "text" : "All the illegal arrests made of peaceful #oakland protesters will engender lawsuits against the OPD. Riot pay, overtime, settlements, waste.",
  "id" : 603007770686656512,
  "created_at" : "2015-05-26 01:20:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602640890633408512",
  "text" : "some entity must be accountable for this anomaly",
  "id" : 602640890633408512,
  "created_at" : "2015-05-25 01:02:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Pants",
      "screen_name" : "sirjamespants",
      "indices" : [ 3, 17 ],
      "id_str" : "157451644",
      "id" : 157451644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/RqiZSfCodc",
      "expanded_url" : "http:\/\/www.collectionstudio.com\/it\/blog\/wasp_nests\/",
      "display_url" : "collectionstudio.com\/it\/blog\/wasp_n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602632696687267841",
  "text" : "RT @sirjamespants: http:\/\/t.co\/RqiZSfCodc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/RqiZSfCodc",
        "expanded_url" : "http:\/\/www.collectionstudio.com\/it\/blog\/wasp_nests\/",
        "display_url" : "collectionstudio.com\/it\/blog\/wasp_n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "602607141019656193",
    "text" : "http:\/\/t.co\/RqiZSfCodc",
    "id" : 602607141019656193,
    "created_at" : "2015-05-24 22:48:32 +0000",
    "user" : {
      "name" : "James Pants",
      "screen_name" : "sirjamespants",
      "protected" : false,
      "id_str" : "157451644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694510327602503681\/Xo2SN-hi_normal.png",
      "id" : 157451644,
      "verified" : true
    }
  },
  "id" : 602632696687267841,
  "created_at" : "2015-05-25 00:30:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602595599196688384",
  "geo" : { },
  "id_str" : "602632214677889024",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  these people are high on something, but whatever it is aint good enough",
  "id" : 602632214677889024,
  "in_reply_to_status_id" : 602595599196688384,
  "created_at" : "2015-05-25 00:28:11 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602197326023692288",
  "text" : "blobs \nand zippies\nblob blobs \nand zippy zippies",
  "id" : 602197326023692288,
  "created_at" : "2015-05-23 19:40:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601991677457248256",
  "text" : "ATTACK OF THE BUTT GACTERIA",
  "id" : 601991677457248256,
  "created_at" : "2015-05-23 06:02:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AntiDisplacementCoup",
      "screen_name" : "AsterZephyrIsis",
      "indices" : [ 3, 19 ],
      "id_str" : "413492760",
      "id" : 413492760
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SF",
      "indices" : [ 47, 50 ]
    }, {
      "text" : "HP",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/ostVgAu2Au",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=eRnHxffe8fg",
      "display_url" : "youtube.com\/watch?v=eRnHxf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601932060664537088",
  "text" : "RT @AsterZephyrIsis: Remember the rappers from #SF #HP who got patted-down in the middle of their demo shoot? Check their finished video: h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SF",
        "indices" : [ 26, 29 ]
      }, {
        "text" : "HP",
        "indices" : [ 30, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ostVgAu2Au",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=eRnHxffe8fg",
        "display_url" : "youtube.com\/watch?v=eRnHxf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600024089978228737",
    "text" : "Remember the rappers from #SF #HP who got patted-down in the middle of their demo shoot? Check their finished video: https:\/\/t.co\/ostVgAu2Au",
    "id" : 600024089978228737,
    "created_at" : "2015-05-17 19:44:25 +0000",
    "user" : {
      "name" : "AntiDisplacementCoup",
      "screen_name" : "AsterZephyrIsis",
      "protected" : false,
      "id_str" : "413492760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000087946067\/4f0db6b2619fba8511a2648de2692bb8_normal.jpeg",
      "id" : 413492760,
      "verified" : false
    }
  },
  "id" : 601932060664537088,
  "created_at" : "2015-05-23 02:06:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601837920920555520",
  "text" : "I have stopped writing docs",
  "id" : 601837920920555520,
  "created_at" : "2015-05-22 19:51:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601834027075686401",
  "geo" : { },
  "id_str" : "601837021171089409",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack webcamo",
  "id" : 601837021171089409,
  "in_reply_to_status_id" : 601834027075686401,
  "created_at" : "2015-05-22 19:48:22 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601805788357660672",
  "text" : "who clouds are these?",
  "id" : 601805788357660672,
  "created_at" : "2015-05-22 17:44:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601795275762438144",
  "text" : "this weather is depressing me.",
  "id" : 601795275762438144,
  "created_at" : "2015-05-22 17:02:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/9EHQrXp5PA",
      "expanded_url" : "https:\/\/soundcloud.com\/linearlabs\/sets\/linear-labs-los-angeles-1",
      "display_url" : "soundcloud.com\/linearlabs\/set\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601597068688261121",
  "text" : "listening https:\/\/t.co\/9EHQrXp5PA",
  "id" : 601597068688261121,
  "created_at" : "2015-05-22 03:54:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601595043862818816",
  "text" : "ima make it\ni have to make it first to make it so\nima make it",
  "id" : 601595043862818816,
  "created_at" : "2015-05-22 03:46:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601185616064307200",
  "text" : "Has nothing changed since East Berlin?",
  "id" : 601185616064307200,
  "created_at" : "2015-05-21 00:39:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601102560519262208",
  "geo" : { },
  "id_str" : "601106789136867328",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso hello!",
  "id" : 601106789136867328,
  "in_reply_to_status_id" : 601102560519262208,
  "created_at" : "2015-05-20 19:26:41 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601096880127225857",
  "geo" : { },
  "id_str" : "601105650760814592",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack also when the money \/ property you traded your life-time for loses it's worth",
  "id" : 601105650760814592,
  "in_reply_to_status_id" : 601096880127225857,
  "created_at" : "2015-05-20 19:22:09 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601093293703757824",
  "geo" : { },
  "id_str" : "601095524939223040",
  "in_reply_to_user_id" : 46961216,
  "text" : "cultural colonialism right here",
  "id" : 601095524939223040,
  "in_reply_to_status_id" : 601093293703757824,
  "created_at" : "2015-05-20 18:41:55 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/62L7hLHkHW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=YqeW9_5kURI",
      "display_url" : "youtube.com\/watch?v=YqeW9_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601093293703757824",
  "text" : "why did they let her ruin all that fine choreography? she dances like a small dog trying to hump a large one.  https:\/\/t.co\/62L7hLHkHW",
  "id" : 601093293703757824,
  "created_at" : "2015-05-20 18:33:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "folkstack",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/MwbUed6dVt",
      "expanded_url" : "https:\/\/instant.io\/#99d4475b40b8595962a64126bffa5382f416f82d",
      "display_url" : "instant.io\/#99d4475b40b85\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600767651284029440",
  "text" : "I am seeding this new #folkstack groove on p2p radio.  For science.  It's a selectable cut.  Streeeeam with me now!\nhttps:\/\/t.co\/MwbUed6dVt",
  "id" : 600767651284029440,
  "created_at" : "2015-05-19 20:59:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/F6OG7ZA1gd",
      "expanded_url" : "https:\/\/twitter.com\/marinakukso\/status\/600744582708469760",
      "display_url" : "twitter.com\/marinakukso\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600758007270543360",
  "text" : "with my new Chopin y Sampleaux web synth software you will be able to create dazzlingly endless music. https:\/\/t.co\/F6OG7ZA1gd",
  "id" : 600758007270543360,
  "created_at" : "2015-05-19 20:20:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600757137220874241",
  "text" : "i only need one lyric for a song",
  "id" : 600757137220874241,
  "created_at" : "2015-05-19 20:17:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kickstarterzak",
      "indices" : [ 64, 79 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600744582708469760",
  "geo" : { },
  "id_str" : "600757034913378306",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  it was on the list for stupid hackathon projects  #kickstarterzak",
  "id" : 600757034913378306,
  "in_reply_to_status_id" : 600744582708469760,
  "created_at" : "2015-05-19 20:16:53 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600756821649858560",
  "text" : "song lyric:  recognize each other's strengths",
  "id" : 600756821649858560,
  "created_at" : "2015-05-19 20:16:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600740950256685056",
  "text" : "there is a campaign for an app that guides you in stretching your horse",
  "id" : 600740950256685056,
  "created_at" : "2015-05-19 19:12:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600738642487685120",
  "geo" : { },
  "id_str" : "600739120361541632",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  until you are completely swollen on your folk consumer heroism",
  "id" : 600739120361541632,
  "in_reply_to_status_id" : 600738642487685120,
  "created_at" : "2015-05-19 19:05:42 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600738443669278721",
  "text" : "every kickstarter video has the same bland goodsy-woodsy music like a volkswagon commercial for world hunger w\/ licensed canadian indie rock",
  "id" : 600738443669278721,
  "created_at" : "2015-05-19 19:03:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600734297759199232",
  "geo" : { },
  "id_str" : "600736217898975232",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  technology it is",
  "id" : 600736217898975232,
  "in_reply_to_status_id" : 600734297759199232,
  "created_at" : "2015-05-19 18:54:10 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600734297759199232",
  "text" : "should I put my music software in the technology or music section of the crowdfund platform?",
  "id" : 600734297759199232,
  "created_at" : "2015-05-19 18:46:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 0, 9 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yGVrQ18kjm",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=RThnq3-d6PY",
      "display_url" : "youtube.com\/watch?v=RThnq3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "600443822414241792",
  "geo" : { },
  "id_str" : "600449499811610625",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jfhbrook \"the art of simple food\", \"the new laurel's kitchen\"... I live on this (20 second) french omelette https:\/\/t.co\/yGVrQ18kjm",
  "id" : 600449499811610625,
  "in_reply_to_status_id" : 600443822414241792,
  "created_at" : "2015-05-18 23:54:51 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600353925775036417",
  "text" : "they call me johnny heisenberg, johnny high as a bird,\nthat cherub slingin zeno's arrows, wings uncertain curves",
  "id" : 600353925775036417,
  "created_at" : "2015-05-18 17:35:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/gQ71ks0wBt",
      "expanded_url" : "https:\/\/twitter.com\/FakeElectronica\/status\/600334135593279489",
      "display_url" : "twitter.com\/FakeElectronic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600347805912141824",
  "text" : "they call me johnny polymath, johnny polygraph, \njohnny quiz the cosmic knowledge, that's the only fact. https:\/\/t.co\/gQ71ks0wBt",
  "id" : 600347805912141824,
  "created_at" : "2015-05-18 17:10:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600147039150735360",
  "text" : "I jus thought maybe I will create an EDMIFYING AUTOSYNTHESIZER, license it to clubs, and send a bunch of shitty DJs and producers home.",
  "id" : 600147039150735360,
  "created_at" : "2015-05-18 03:52:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600121793173528578",
  "text" : "Dionne Warwick &amp; Co sound perfectly oriental backwards.",
  "id" : 600121793173528578,
  "created_at" : "2015-05-18 02:12:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Gk6a1H0cZX",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=g0I5WL019UU",
      "display_url" : "youtube.com\/watch?v=g0I5WL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600094229973467137",
  "text" : "this the funkiest punk music evr\nThe Stick Men - Mystery Party \nhttps:\/\/t.co\/Gk6a1H0cZX",
  "id" : 600094229973467137,
  "created_at" : "2015-05-18 00:23:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600093331633213440",
  "text" : "\"A Quick Guide to Inanechatter-core\"",
  "id" : 600093331633213440,
  "created_at" : "2015-05-18 00:19:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600086443256455169",
  "geo" : { },
  "id_str" : "600086560902549505",
  "in_reply_to_user_id" : 46961216,
  "text" : "but an old macbook will only get you so many apples.",
  "id" : 600086560902549505,
  "in_reply_to_status_id" : 600086443256455169,
  "created_at" : "2015-05-17 23:52:39 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600086443256455169",
  "text" : "If ur gonna trade yr labor for cash, consumerism is probably your best hedge against the inevitable implosion of the dollar.",
  "id" : 600086443256455169,
  "created_at" : "2015-05-17 23:52:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600085763657609216",
  "text" : "I am always amazed that people will exchange fine beer and produce for this worthless dollar currency.",
  "id" : 600085763657609216,
  "created_at" : "2015-05-17 23:49:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600084820937482240",
  "text" : "choose to be poor now, and avoid the rush.",
  "id" : 600084820937482240,
  "created_at" : "2015-05-17 23:45:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600046882895728640",
  "text" : "RT @TheHatGhost: @johnnyscript this looks like much rad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "600022764662038528",
    "geo" : { },
    "id_str" : "600037402552508416",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript this looks like much rad",
    "id" : 600037402552508416,
    "in_reply_to_status_id" : 600022764662038528,
    "created_at" : "2015-05-17 20:37:19 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606927351168036864\/lzGOA4HX_normal.jpg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 600046882895728640,
  "created_at" : "2015-05-17 21:14:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/600022764662038528\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/Cr2ppFALh0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFO1hmPUMAAKr-u.png",
      "id_str" : "600022764175503360",
      "id" : 600022764175503360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFO1hmPUMAAKr-u.png",
      "sizes" : [ {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 946,
        "resize" : "fit",
        "w" : 1903
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Cr2ppFALh0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600022764662038528",
  "text" : ";^) http:\/\/t.co\/Cr2ppFALh0",
  "id" : 600022764662038528,
  "created_at" : "2015-05-17 19:39:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600001267880984576",
  "text" : "setting self to godspeed",
  "id" : 600001267880984576,
  "created_at" : "2015-05-17 18:13:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599764398110965760",
  "text" : "I want to have my pie, and throw it in your face, too.",
  "id" : 599764398110965760,
  "created_at" : "2015-05-17 02:32:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599324807247728640",
  "text" : "choose wisely  which side of the equilibrium you change the time",
  "id" : 599324807247728640,
  "created_at" : "2015-05-15 21:25:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zerohedge",
      "screen_name" : "zerohedge",
      "indices" : [ 0, 10 ],
      "id_str" : "18856867",
      "id" : 18856867
    }, {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 11, 22 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599276080789348352",
  "geo" : { },
  "id_str" : "599284226219839488",
  "in_reply_to_user_id" : 18856867,
  "text" : "@zerohedge @Satoshi_N_  or transfer your money's value to a currency they don't control",
  "id" : 599284226219839488,
  "in_reply_to_status_id" : 599276080789348352,
  "created_at" : "2015-05-15 18:44:28 +0000",
  "in_reply_to_screen_name" : "zerohedge",
  "in_reply_to_user_id_str" : "18856867",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flac",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599276848451690496",
  "text" : "when will browsers support the free lossless audio codec?  it's fucking free and fucking lossless, just do it.  #flac",
  "id" : 599276848451690496,
  "created_at" : "2015-05-15 18:15:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599257314957205504",
  "text" : "i'm having a bitch of a time trying to change speed without changing position",
  "id" : 599257314957205504,
  "created_at" : "2015-05-15 16:57:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/57eteI2qve",
      "expanded_url" : "https:\/\/twitter.com\/DaMFunK\/status\/598691789235757056",
      "display_url" : "twitter.com\/DaMFunK\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598904821442187264",
  "text" : "super fine https:\/\/t.co\/57eteI2qve",
  "id" : 598904821442187264,
  "created_at" : "2015-05-14 17:36:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 26, 39 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598667424913694720",
  "geo" : { },
  "id_str" : "598668099907244032",
  "in_reply_to_user_id" : 46961216,
  "text" : "manual data entry for you @johnnyscript",
  "id" : 598668099907244032,
  "in_reply_to_status_id" : 598667424913694720,
  "created_at" : "2015-05-14 01:56:12 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598667424913694720",
  "text" : "I can't get \n\ninput[type=range]::-webkit-slider-thumb::after\u007B\n  content: attr(name) \" \";\n\u007D\n\nto work, and I don't know who talk to about it.",
  "id" : 598667424913694720,
  "created_at" : "2015-05-14 01:53:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 0, 14 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/73q3TauIhP",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=c23b29f6a9f2482e2c81",
      "display_url" : "requirebin.com\/?gist=c23b29f6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598632396460720128",
  "in_reply_to_user_id" : 379919160,
  "text" : "@MikolaLysenko works!  it has a warm dampening effect, almost like an old record http:\/\/t.co\/73q3TauIhP",
  "id" : 598632396460720128,
  "created_at" : "2015-05-13 23:34:20 +0000",
  "in_reply_to_screen_name" : "MikolaLysenko",
  "in_reply_to_user_id_str" : "379919160",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/598627811679539200\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/cKnj8WKbyW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE7A0qCUUAAncZ1.png",
      "id_str" : "598627811356594176",
      "id" : 598627811356594176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE7A0qCUUAAncZ1.png",
      "sizes" : [ {
        "h" : 489,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cKnj8WKbyW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598627811679539200",
  "text" : "I don't have time to make bespoke glyphs for my bespoke synths. http:\/\/t.co\/cKnj8WKbyW",
  "id" : 598627811679539200,
  "created_at" : "2015-05-13 23:16:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598604529425231872",
  "text" : "friends needs friends",
  "id" : 598604529425231872,
  "created_at" : "2015-05-13 21:43:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 0, 14 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/73q3TauIhP",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=c23b29f6a9f2482e2c81",
      "display_url" : "requirebin.com\/?gist=c23b29f6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598602368465313792",
  "in_reply_to_user_id" : 379919160,
  "text" : "@MikolaLysenko http:\/\/t.co\/73q3TauIhP  drag and drop an audio file, open console for ndarray related error.  fix for gaussian audio!",
  "id" : 598602368465313792,
  "created_at" : "2015-05-13 21:35:00 +0000",
  "in_reply_to_screen_name" : "MikolaLysenko",
  "in_reply_to_user_id_str" : "379919160",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598590881977868288",
  "geo" : { },
  "id_str" : "598593270940241920",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee CANT STOP WONT STOP",
  "id" : 598593270940241920,
  "in_reply_to_status_id" : 598590881977868288,
  "created_at" : "2015-05-13 20:58:51 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598593063213080576",
  "text" : "I don't think of it as making money.  when I get money, I make sure it loses it value.",
  "id" : 598593063213080576,
  "created_at" : "2015-05-13 20:58:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598592817909211136",
  "text" : "srsly open source has scaled enough, and it is time to monetize.",
  "id" : 598592817909211136,
  "created_at" : "2015-05-13 20:57:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598580486475108354",
  "text" : "the last configuration of christ",
  "id" : 598580486475108354,
  "created_at" : "2015-05-13 20:08:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EINS78",
      "screen_name" : "EINS78",
      "indices" : [ 0, 7 ],
      "id_str" : "14301616",
      "id" : 14301616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598559633784045569",
  "geo" : { },
  "id_str" : "598561578410094592",
  "in_reply_to_user_id" : 14301616,
  "text" : "@EINS78  composed entirely from a 4 second loop cut from an old-school internet meme",
  "id" : 598561578410094592,
  "in_reply_to_status_id" : 598559633784045569,
  "created_at" : "2015-05-13 18:52:55 +0000",
  "in_reply_to_screen_name" : "EINS78",
  "in_reply_to_user_id_str" : "14301616",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598561169188651008",
  "text" : "if I build a social (re\/mix\/able), p2p, music CMS slash streaming, I might as well monetize the service level (blob store, etc)  who's w\/me?",
  "id" : 598561169188651008,
  "created_at" : "2015-05-13 18:51:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598560112010080257",
  "text" : "we are only using soundcloud until I finish a way better social CMS for music heads.  inquire within.",
  "id" : 598560112010080257,
  "created_at" : "2015-05-13 18:47:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598559526179119104",
  "text" : "granted most tracks i upload have high or low audio, and often an awkward intro",
  "id" : 598559526179119104,
  "created_at" : "2015-05-13 18:44:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/8N41YpKzA0",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/loopography",
      "display_url" : "soundcloud.com\/folkstack\/loop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598559015694565376",
  "text" : "uploade laste night, a loop sample of a loop sample  https:\/\/t.co\/8N41YpKzA0\n\nfolkstack sample synth testing well",
  "id" : 598559015694565376,
  "created_at" : "2015-05-13 18:42:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EINS78",
      "screen_name" : "EINS78",
      "indices" : [ 0, 7 ],
      "id_str" : "14301616",
      "id" : 14301616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598557579028070400",
  "geo" : { },
  "id_str" : "598558830281117696",
  "in_reply_to_user_id" : 14301616,
  "text" : "@EINS78  thanks!  which ones?",
  "id" : 598558830281117696,
  "in_reply_to_status_id" : 598557579028070400,
  "created_at" : "2015-05-13 18:42:00 +0000",
  "in_reply_to_screen_name" : "EINS78",
  "in_reply_to_user_id_str" : "14301616",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/jXEnvk1COF",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/donde-el-antidoto",
      "display_url" : "soundcloud.com\/folkstack\/dond\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598556930466938880",
  "text" : "i guess I am the only one listens to this track, yall missing out.   https:\/\/t.co\/jXEnvk1COF\n\nidk why I bother uploading rare grooves.",
  "id" : 598556930466938880,
  "created_at" : "2015-05-13 18:34:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/coPNmiMQRS",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/martian-desert-night-waltz",
      "display_url" : "soundcloud.com\/folkstack\/mart\u2026"
    }, {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/jXEnvk1COF",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/donde-el-antidoto",
      "display_url" : "soundcloud.com\/folkstack\/dond\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598555179714117632",
  "text" : "new track https:\/\/t.co\/coPNmiMQRS\n\nthis recording followed directly after this session https:\/\/t.co\/jXEnvk1COF",
  "id" : 598555179714117632,
  "created_at" : "2015-05-13 18:27:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598541729617334272",
  "geo" : { },
  "id_str" : "598542068932214784",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts  BUT IT PLAYS THE FRIENDS JINGLE ONSTART",
  "id" : 598542068932214784,
  "in_reply_to_status_id" : 598541729617334272,
  "created_at" : "2015-05-13 17:35:24 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598541494912491520",
  "geo" : { },
  "id_str" : "598541633324326913",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts I CANNOT!",
  "id" : 598541633324326913,
  "in_reply_to_status_id" : 598541494912491520,
  "created_at" : "2015-05-13 17:33:40 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598540989662298112",
  "text" : "is freenode sploding?",
  "id" : 598540989662298112,
  "created_at" : "2015-05-13 17:31:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/598216214398144512\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/R6e4SVvYnh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE1KehmVAAAVKFK.png",
      "id_str" : "598216213785804800",
      "id" : 598216213785804800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE1KehmVAAAVKFK.png",
      "sizes" : [ {
        "h" : 121,
        "resize" : "crop",
        "w" : 121
      }, {
        "h" : 121,
        "resize" : "fit",
        "w" : 168
      }, {
        "h" : 121,
        "resize" : "fit",
        "w" : 168
      }, {
        "h" : 121,
        "resize" : "fit",
        "w" : 168
      }, {
        "h" : 121,
        "resize" : "fit",
        "w" : 168
      } ],
      "display_url" : "pic.twitter.com\/R6e4SVvYnh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598216214398144512",
  "text" : "metacode http:\/\/t.co\/R6e4SVvYnh",
  "id" : 598216214398144512,
  "created_at" : "2015-05-12 20:00:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 0, 9 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/597935323889340416\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/rxCATGxY3O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CExLAj7VAAAg1HB.png",
      "id_str" : "597935323549597696",
      "id" : 597935323549597696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CExLAj7VAAAg1HB.png",
      "sizes" : [ {
        "h" : 123,
        "resize" : "fit",
        "w" : 243
      }, {
        "h" : 123,
        "resize" : "fit",
        "w" : 243
      }, {
        "h" : 123,
        "resize" : "fit",
        "w" : 243
      }, {
        "h" : 123,
        "resize" : "fit",
        "w" : 243
      }, {
        "h" : 123,
        "resize" : "crop",
        "w" : 123
      } ],
      "display_url" : "pic.twitter.com\/rxCATGxY3O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597916715788275712",
  "geo" : { },
  "id_str" : "597935323889340416",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jfhbrook well then http:\/\/t.co\/rxCATGxY3O",
  "id" : 597935323889340416,
  "in_reply_to_status_id" : 597916715788275712,
  "created_at" : "2015-05-12 01:24:24 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Batuhan Bozkurt",
      "screen_name" : "earslap",
      "indices" : [ 0, 8 ],
      "id_str" : "27159398",
      "id" : 27159398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/UopjGveF7L",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/gym",
      "display_url" : "soundcloud.com\/folkstack\/gym"
    } ]
  },
  "in_reply_to_status_id_str" : "597872329885163520",
  "geo" : { },
  "id_str" : "597928271683063809",
  "in_reply_to_user_id" : 27159398,
  "text" : "@earslap a truly wonderful synth, and an innovative music playing experience!  I practiced this tiny piece for hours https:\/\/t.co\/UopjGveF7L",
  "id" : 597928271683063809,
  "in_reply_to_status_id" : 597872329885163520,
  "created_at" : "2015-05-12 00:56:23 +0000",
  "in_reply_to_screen_name" : "earslap",
  "in_reply_to_user_id_str" : "27159398",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/HCcXDkmnQg",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/597920386320240640",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597923655134253056",
  "text" : "jamin https:\/\/t.co\/HCcXDkmnQg",
  "id" : 597923655134253056,
  "created_at" : "2015-05-12 00:38:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jfhbrook",
      "indices" : [ 0, 9 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597903381110239233",
  "geo" : { },
  "id_str" : "597913002155778048",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jfhbrook  who did you appoint to shoot you in case you should ever want to try such a thing?",
  "id" : 597913002155778048,
  "in_reply_to_status_id" : 597903381110239233,
  "created_at" : "2015-05-11 23:55:43 +0000",
  "in_reply_to_screen_name" : "jfhbrook",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597851399825698816",
  "text" : "browser should use jack for web audio routing.",
  "id" : 597851399825698816,
  "created_at" : "2015-05-11 19:50:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/20uNGXgNLW",
      "expanded_url" : "https:\/\/github.com\/unclechu\/node-jack-connector",
      "display_url" : "github.com\/unclechu\/node-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597846997396107266",
  "text" : "this changes everything https:\/\/t.co\/20uNGXgNLW",
  "id" : 597846997396107266,
  "created_at" : "2015-05-11 19:33:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597627538454654977",
  "text" : "I am experiencing bad httpses",
  "id" : 597627538454654977,
  "created_at" : "2015-05-11 05:01:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/cP1zxGziOy",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=f0afec9d11fb34b21d59",
      "display_url" : "requirebin.com\/?gist=f0afec9d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597626761313058816",
  "text" : "throwback sunday http:\/\/t.co\/cP1zxGziOy",
  "id" : 597626761313058816,
  "created_at" : "2015-05-11 04:58:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/ph5J7Eg9V2",
      "expanded_url" : "https:\/\/twitter.com\/hughskennedy\/status\/597570174980526080",
      "display_url" : "twitter.com\/hughskennedy\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597592496361713664",
  "text" : "this is just great https:\/\/t.co\/ph5J7Eg9V2",
  "id" : 597592496361713664,
  "created_at" : "2015-05-11 02:42:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597501013822570496",
  "geo" : { },
  "id_str" : "597512422367211521",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  he'll never become president with that hair",
  "id" : 597512422367211521,
  "in_reply_to_status_id" : 597501013822570496,
  "created_at" : "2015-05-10 21:23:57 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/vuo6Z4VeOG",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/596908096015863808",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596919525305552896",
  "text" : "SCREAMING https:\/\/t.co\/vuo6Z4VeOG",
  "id" : 596919525305552896,
  "created_at" : "2015-05-09 06:07:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/kcx84uQTbS",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/wheres-my-money",
      "display_url" : "soundcloud.com\/folkstack\/wher\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596912591571652608",
  "text" : "first loops created using folkstack's own bespolk chopped, screwed, vaped and skewed sampler innurface\nhttps:\/\/t.co\/kcx84uQTbS",
  "id" : 596912591571652608,
  "created_at" : "2015-05-09 05:40:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596806058816868352",
  "text" : "What did the dog say while boasting about progress made?\n\n\"I'm sniffin' ass AND taking names.\"",
  "id" : 596806058816868352,
  "created_at" : "2015-05-08 22:37:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/4xVT1qxtiA",
      "expanded_url" : "http:\/\/geelen.github.io\/x-gif\/#\/http:\/\/i.imgur.com\/iKXH4E2.gif",
      "display_url" : "geelen.github.io\/x-gif\/#\/http:\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "596584917036867584",
  "geo" : { },
  "id_str" : "596706504993968128",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts  x-gif is the only good one http:\/\/t.co\/4xVT1qxtiA",
  "id" : 596706504993968128,
  "in_reply_to_status_id" : 596584917036867584,
  "created_at" : "2015-05-08 16:01:31 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596586615117459456",
  "geo" : { },
  "id_str" : "596701848595083264",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  \"Kickstarterzak\"",
  "id" : 596701848595083264,
  "in_reply_to_status_id" : 596586615117459456,
  "created_at" : "2015-05-08 15:43:01 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/9ULQE1ksQD",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=biDlCLXrWJU",
      "display_url" : "youtube.com\/watch?v=biDlCL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596532242383376384",
  "text" : "I love this song and I love Nidia Gongora https:\/\/t.co\/9ULQE1ksQD",
  "id" : 596532242383376384,
  "created_at" : "2015-05-08 04:29:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596526671299088384",
  "text" : "s\/context\/master",
  "id" : 596526671299088384,
  "created_at" : "2015-05-08 04:06:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596523227909783552",
  "text" : "yo quiero plata",
  "id" : 596523227909783552,
  "created_at" : "2015-05-08 03:53:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Rb458S3oVx",
      "expanded_url" : "https:\/\/twitter.com\/yoshuawuyts\/status\/596219085781921792",
      "display_url" : "twitter.com\/yoshuawuyts\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596368762934140929",
  "text" : "I AM ENTITLED TO RAMBLE ON ABOUT THINGS EVERYBODY ALREADY KNOWS https:\/\/t.co\/Rb458S3oVx",
  "id" : 596368762934140929,
  "created_at" : "2015-05-07 17:39:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596259066512453632",
  "text" : "P2P2 NO SEQUEL",
  "id" : 596259066512453632,
  "created_at" : "2015-05-07 10:23:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596129600062750724",
  "geo" : { },
  "id_str" : "596139473148125184",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts  MAKE IT SO",
  "id" : 596139473148125184,
  "in_reply_to_status_id" : 596129600062750724,
  "created_at" : "2015-05-07 02:28:20 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    }, {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 17, 24 ],
      "id_str" : "291901937",
      "id" : 291901937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596066154252083200",
  "geo" : { },
  "id_str" : "596075120013119488",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha cc\/ @LB2045",
  "id" : 596075120013119488,
  "in_reply_to_status_id" : 596066154252083200,
  "created_at" : "2015-05-06 22:12:37 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595677831679627264",
  "text" : "Where does feel and think meet?",
  "id" : 595677831679627264,
  "created_at" : "2015-05-05 19:53:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595677771516538882",
  "text" : "Dualities are a necessary human ab\/dis\/traction.  That is usually conclusion, but not always.  Depends on my mood.",
  "id" : 595677771516538882,
  "created_at" : "2015-05-05 19:53:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/UopjGveF7L",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/gym",
      "display_url" : "soundcloud.com\/folkstack\/gym"
    } ]
  },
  "geo" : { },
  "id_str" : "595496538429751296",
  "text" : "Gymnopedie Rapido https:\/\/t.co\/UopjGveF7L",
  "id" : 595496538429751296,
  "created_at" : "2015-05-05 07:53:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/4EIZK7EUPp",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/fruity-loop",
      "display_url" : "soundcloud.com\/folkstack\/frui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595349899111112705",
  "text" : "my current project is a long time comin' loop sample web synth interface.  here's a silly manually cut loop: https:\/\/t.co\/4EIZK7EUPp",
  "id" : 595349899111112705,
  "created_at" : "2015-05-04 22:10:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 3, 14 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595113184786128896",
  "text" : "RT @Satoshi_N_: Peer to peer money is unstoppable.  Trust me.  If they could have stopped peer to peer music and movies, they would have.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595044114934210560",
    "text" : "Peer to peer money is unstoppable.  Trust me.  If they could have stopped peer to peer music and movies, they would have.",
    "id" : 595044114934210560,
    "created_at" : "2015-05-04 01:55:47 +0000",
    "user" : {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "protected" : false,
      "id_str" : "2375721396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727448034024525825\/nxaF8tNf_normal.jpg",
      "id" : 2375721396,
      "verified" : false
    }
  },
  "id" : 595113184786128896,
  "created_at" : "2015-05-04 06:30:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594962694173696000",
  "text" : "PEACE BE WITH YOU",
  "id" : 594962694173696000,
  "created_at" : "2015-05-03 20:32:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Sidner",
      "screen_name" : "sarasidnerCNN",
      "indices" : [ 0, 14 ],
      "id_str" : "45544324",
      "id" : 45544324
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 15, 21 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594882295682703360",
  "geo" : { },
  "id_str" : "594960675622887424",
  "in_reply_to_user_id" : 45544324,
  "text" : "@sarasidnerCNN @deray EVERYBODY CAN SEE THE VIDEO LADY WE DON'T YOUR OPINION ON DEFINITIONS OF POLICE BRUTALITY",
  "id" : 594960675622887424,
  "in_reply_to_status_id" : 594882295682703360,
  "created_at" : "2015-05-03 20:24:13 +0000",
  "in_reply_to_screen_name" : "sarasidnerCNN",
  "in_reply_to_user_id_str" : "45544324",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594955273262866434",
  "text" : "back to irregularly scheduled hacking",
  "id" : 594955273262866434,
  "created_at" : "2015-05-03 20:02:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594941533243092992",
  "text" : "i'm always go for broke.",
  "id" : 594941533243092992,
  "created_at" : "2015-05-03 19:08:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594928229514809345",
  "text" : "the police would be a lot more fucked if they weren't allowed to carry cruel and deadly weapons.",
  "id" : 594928229514809345,
  "created_at" : "2015-05-03 18:15:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594923114259030016",
  "text" : "how are curfews legally justifiable in the first place?  is it simply because they are not legally challenged at last?",
  "id" : 594923114259030016,
  "created_at" : "2015-05-03 17:54:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594918903916007424",
  "geo" : { },
  "id_str" : "594920201830801409",
  "in_reply_to_user_id" : 46961216,
  "text" : "people sell they subjugation for consumer comforts, become complacent.  fear of a worse personal fate suppresses the desire for commonwealth",
  "id" : 594920201830801409,
  "in_reply_to_status_id" : 594918903916007424,
  "created_at" : "2015-05-03 17:43:23 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594918903916007424",
  "text" : "One of the biggest challenges today is that so many people have come to desire &amp; justify their own oppression \/ subjugation. That's fascism!",
  "id" : 594918903916007424,
  "created_at" : "2015-05-03 17:38:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AYA",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594914160036614145",
  "geo" : { },
  "id_str" : "594914445161172992",
  "in_reply_to_user_id" : 46961216,
  "text" : "ASK YOURSELF ANYTHING #AYA",
  "id" : 594914445161172992,
  "in_reply_to_status_id" : 594914160036614145,
  "created_at" : "2015-05-03 17:20:31 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594914160036614145",
  "text" : "Q. Do police discriminate?\nA.  Statistically.\nQ.  What would be the reality if they were no less violent, but completely indiscriminate?",
  "id" : 594914160036614145,
  "created_at" : "2015-05-03 17:19:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594912836087717888",
  "text" : "nobody would be for arming the police if the brutality and murder were indiscriminate. not taking action against them is pro-discrimination.",
  "id" : 594912836087717888,
  "created_at" : "2015-05-03 17:14:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/HwYy9yNDZK",
      "expanded_url" : "https:\/\/twitter.com\/AmichaiStein1\/status\/594897525166841856",
      "display_url" : "twitter.com\/AmichaiStein1\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594912294888280064",
  "text" : "looks like they are using vehicles to protest.... good tactic https:\/\/t.co\/HwYy9yNDZK",
  "id" : 594912294888280064,
  "created_at" : "2015-05-03 17:11:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594911437908148224",
  "text" : "Don't fight the armor, fight THE MAN behind the armor.  Police are shielding city councils and mayors, who could disarm them with laws.",
  "id" : 594911437908148224,
  "created_at" : "2015-05-03 17:08:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594909006713495552",
  "geo" : { },
  "id_str" : "594909385257660417",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray yo man, where is the protest strategy for disarming police so that being violent is less of an option for them?  local politics...",
  "id" : 594909385257660417,
  "in_reply_to_status_id" : 594909006713495552,
  "created_at" : "2015-05-03 17:00:24 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BaltimoreUprising",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594908809975332864",
  "text" : "the police can't be brutal if they don't have weapons.  stand off with your city council, not the brute squad.  disarm.  #BaltimoreUprising",
  "id" : 594908809975332864,
  "created_at" : "2015-05-03 16:58:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594907812578267136",
  "text" : "whatever threat perceived by local police that they should need deadly weapons is pure paranoia.",
  "id" : 594907812578267136,
  "created_at" : "2015-05-03 16:54:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BaltimoreUprising",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594906691348467713",
  "text" : "no reason for police to carry deadly weapons.  none.  absolutely zero.  they are the armed thugs of your city council.  #BaltimoreUprising",
  "id" : 594906691348467713,
  "created_at" : "2015-05-03 16:49:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594906147036876800",
  "text" : "we need to see the police for what they are.  they protect the local political order.  go to the root of police authority and disarm them.",
  "id" : 594906147036876800,
  "created_at" : "2015-05-03 16:47:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594905782002429952",
  "text" : "guns: deadly, intimidating\ntasers:  cruel, often deadly\ntear gas:  unknown chemical agent \n\nthis is local politics, disarm your city council",
  "id" : 594905782002429952,
  "created_at" : "2015-05-03 16:46:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/JhP0X1t15P",
      "expanded_url" : "https:\/\/twitter.com\/deray\/status\/594895836598800384",
      "display_url" : "twitter.com\/deray\/status\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594902709976698880",
  "text" : "police like hyenas the way they separate the prey from the pack https:\/\/t.co\/JhP0X1t15P",
  "id" : 594902709976698880,
  "created_at" : "2015-05-03 16:33:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesper Andersen",
      "screen_name" : "jandersen",
      "indices" : [ 3, 13 ],
      "id_str" : "6154922",
      "id" : 6154922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594885110459015169",
  "text" : "RT @jandersen: Suddenly the Bay Area erupts with contempt for a few guys getting millions and not delivering anything of value.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594731872791367680",
    "text" : "Suddenly the Bay Area erupts with contempt for a few guys getting millions and not delivering anything of value.",
    "id" : 594731872791367680,
    "created_at" : "2015-05-03 05:15:02 +0000",
    "user" : {
      "name" : "Jesper Andersen",
      "screen_name" : "jandersen",
      "protected" : false,
      "id_str" : "6154922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2381768123\/image_normal.jpg",
      "id" : 6154922,
      "verified" : false
    }
  },
  "id" : 594885110459015169,
  "created_at" : "2015-05-03 15:23:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594885074224422912",
  "text" : "will an over-hyped sissy fight save the sport of boxing???",
  "id" : 594885074224422912,
  "created_at" : "2015-05-03 15:23:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 0, 6 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594610313955307520",
  "geo" : { },
  "id_str" : "594611885137235970",
  "in_reply_to_user_id" : 29417304,
  "text" : "@deray  There's a stairway to heaven, and a highway to hell.",
  "id" : 594611885137235970,
  "in_reply_to_status_id" : 594610313955307520,
  "created_at" : "2015-05-02 21:18:15 +0000",
  "in_reply_to_screen_name" : "deray",
  "in_reply_to_user_id_str" : "29417304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Atwood",
      "screen_name" : "gretchenatwood",
      "indices" : [ 3, 18 ],
      "id_str" : "16993251",
      "id" : 16993251
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 20, 26 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594608886071431168",
  "text" : "RT @gretchenatwood: @deray Old white dude w\/ drippy \"support the  police\" sign right abt 1 thing: When u support the police, black bleeds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 0, 6 ],
        "id_str" : "29417304",
        "id" : 29417304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "594603085437210624",
    "geo" : { },
    "id_str" : "594606438883856386",
    "in_reply_to_user_id" : 29417304,
    "text" : "@deray Old white dude w\/ drippy \"support the  police\" sign right abt 1 thing: When u support the police, black bleeds",
    "id" : 594606438883856386,
    "in_reply_to_status_id" : 594603085437210624,
    "created_at" : "2015-05-02 20:56:36 +0000",
    "in_reply_to_screen_name" : "deray",
    "in_reply_to_user_id_str" : "29417304",
    "user" : {
      "name" : "Gretchen Atwood",
      "screen_name" : "gretchenatwood",
      "protected" : false,
      "id_str" : "16993251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602342747329024000\/kfqgqphG_normal.jpg",
      "id" : 16993251,
      "verified" : false
    }
  },
  "id" : 594608886071431168,
  "created_at" : "2015-05-02 21:06:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594572794500780032",
  "text" : "god I hope that this movement turns the flow of money away from bombs and jails and toward public education.  but this is mere hope.",
  "id" : 594572794500780032,
  "created_at" : "2015-05-02 18:42:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "april glaser",
      "screen_name" : "aprilaser",
      "indices" : [ 0, 10 ],
      "id_str" : "210056653",
      "id" : 210056653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594538704615510016",
  "geo" : { },
  "id_str" : "594543896400539651",
  "in_reply_to_user_id" : 210056653,
  "text" : "@aprilaser  I could make that outrageous salary programming, but I can't make rent teaching it.  Public Ed. is the bane of my life.",
  "id" : 594543896400539651,
  "in_reply_to_status_id" : 594538704615510016,
  "created_at" : "2015-05-02 16:48:05 +0000",
  "in_reply_to_screen_name" : "aprilaser",
  "in_reply_to_user_id_str" : "210056653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Political Fail Blog",
      "screen_name" : "PFailBlog",
      "indices" : [ 3, 13 ],
      "id_str" : "235636773",
      "id" : 235636773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oakland",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "MayDay",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "Baltimore",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594378508794601472",
  "text" : "RT @PFailBlog: OPD now threatening to use \"chemical agents\" on the citizens of #Oakland.  #MayDay solidarity w\/ #Baltimore",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oakland",
        "indices" : [ 64, 72 ]
      }, {
        "text" : "MayDay",
        "indices" : [ 75, 82 ]
      }, {
        "text" : "Baltimore",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594371536322039809",
    "text" : "OPD now threatening to use \"chemical agents\" on the citizens of #Oakland.  #MayDay solidarity w\/ #Baltimore",
    "id" : 594371536322039809,
    "created_at" : "2015-05-02 05:23:11 +0000",
    "user" : {
      "name" : "Political Fail Blog",
      "screen_name" : "PFailBlog",
      "protected" : false,
      "id_str" : "235636773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2891729995\/16a0bb13e20dfb2c4c4d9f4356be8fad_normal.png",
      "id" : 235636773,
      "verified" : false
    }
  },
  "id" : 594378508794601472,
  "created_at" : "2015-05-02 05:50:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Perry Barlow",
      "screen_name" : "JPBarlow",
      "indices" : [ 3, 12 ],
      "id_str" : "14274132",
      "id" : 14274132
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JPBarlow\/status\/594367274498174976\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/OevoCSZqCm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD-d4xAUEAEoUKR.jpg",
      "id_str" : "594367274389082113",
      "id" : 594367274389082113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD-d4xAUEAEoUKR.jpg",
      "sizes" : [ {
        "h" : 516,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 1569
      } ],
      "display_url" : "pic.twitter.com\/OevoCSZqCm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594376309175783424",
  "text" : "RT @JPBarlow: http:\/\/t.co\/OevoCSZqCm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JPBarlow\/status\/594367274498174976\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/OevoCSZqCm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD-d4xAUEAEoUKR.jpg",
        "id_str" : "594367274389082113",
        "id" : 594367274389082113,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD-d4xAUEAEoUKR.jpg",
        "sizes" : [ {
          "h" : 516,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 171,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 791,
          "resize" : "fit",
          "w" : 1569
        } ],
        "display_url" : "pic.twitter.com\/OevoCSZqCm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594367274498174976",
    "text" : "http:\/\/t.co\/OevoCSZqCm",
    "id" : 594367274498174976,
    "created_at" : "2015-05-02 05:06:15 +0000",
    "user" : {
      "name" : "John Perry Barlow",
      "screen_name" : "JPBarlow",
      "protected" : false,
      "id_str" : "14274132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593246930014064640\/zvByG4sa_normal.jpg",
      "id" : 14274132,
      "verified" : false
    }
  },
  "id" : 594376309175783424,
  "created_at" : "2015-05-02 05:42:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594372410276581377",
  "text" : "i'm so poor i'm literally dogfooding my dog's food iykwim",
  "id" : 594372410276581377,
  "created_at" : "2015-05-02 05:26:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594361737308078081",
  "geo" : { },
  "id_str" : "594363255843229697",
  "in_reply_to_user_id" : 46961216,
  "text" : "Devil:  Ah, back when it all started.\nJan: Hey!\nDevil:  Or are we when it ends?  These things confuse me sometimes.",
  "id" : 594363255843229697,
  "in_reply_to_status_id" : 594361737308078081,
  "created_at" : "2015-05-02 04:50:17 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594361737308078081",
  "text" : "Reading over stories I wrote in a past life.  Never finished a script titled \"The Devil and Schrodinger's Cat\".",
  "id" : 594361737308078081,
  "created_at" : "2015-05-02 04:44:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cian \u00D3 Maid\u00EDn",
      "screen_name" : "Cianomaidin",
      "indices" : [ 0, 12 ],
      "id_str" : "23092438",
      "id" : 23092438
    }, {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 13, 17 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "talkpay",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594297813732872194",
  "geo" : { },
  "id_str" : "594305701117177856",
  "in_reply_to_user_id" : 23092438,
  "text" : "@Cianomaidin @izs  I think #talkpay refutes you on that point.",
  "id" : 594305701117177856,
  "in_reply_to_status_id" : 594297813732872194,
  "created_at" : "2015-05-02 01:01:35 +0000",
  "in_reply_to_screen_name" : "Cianomaidin",
  "in_reply_to_user_id_str" : "23092438",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594303791274467329",
  "text" : "\"This advertisement will close in 30 seconds.\"\n\n*closes tab*",
  "id" : 594303791274467329,
  "created_at" : "2015-05-02 00:54:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hotep Hannibal\u2122",
      "screen_name" : "VibeHi",
      "indices" : [ 0, 7 ],
      "id_str" : "21822997",
      "id" : 21822997
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 8, 14 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594296240306814978",
  "geo" : { },
  "id_str" : "594298364918767617",
  "in_reply_to_user_id" : 21822997,
  "text" : "@VibeHi @deray Straight giving $$ to the enemy. The uprising woulda started a decade ago had black folk traded cable for an internet connect",
  "id" : 594298364918767617,
  "in_reply_to_status_id" : 594296240306814978,
  "created_at" : "2015-05-02 00:32:26 +0000",
  "in_reply_to_screen_name" : "VibeHi",
  "in_reply_to_user_id_str" : "21822997",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hotep Hannibal\u2122",
      "screen_name" : "VibeHi",
      "indices" : [ 3, 10 ],
      "id_str" : "21822997",
      "id" : 21822997
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 59, 72 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 81, 87 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594297847937273856",
  "text" : "RT @VibeHi: I get called an EXTREMIST when I say this. RT: @johnnyscript: VibeHi @deray cable television",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 47, 60 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 69, 75 ],
        "id_str" : "29417304",
        "id" : 29417304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "594296024086097921",
    "geo" : { },
    "id_str" : "594296240306814978",
    "in_reply_to_user_id" : 46961216,
    "text" : "I get called an EXTREMIST when I say this. RT: @johnnyscript: VibeHi @deray cable television",
    "id" : 594296240306814978,
    "in_reply_to_status_id" : 594296024086097921,
    "created_at" : "2015-05-02 00:23:59 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Hotep Hannibal\u2122",
      "screen_name" : "VibeHi",
      "protected" : false,
      "id_str" : "21822997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684265954180775936\/v7Jnja7N_normal.jpg",
      "id" : 21822997,
      "verified" : false
    }
  },
  "id" : 594297847937273856,
  "created_at" : "2015-05-02 00:30:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hotep Hannibal\u2122",
      "screen_name" : "VibeHi",
      "indices" : [ 0, 7 ],
      "id_str" : "21822997",
      "id" : 21822997
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 8, 14 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594284459408674816",
  "geo" : { },
  "id_str" : "594296024086097921",
  "in_reply_to_user_id" : 21822997,
  "text" : "@VibeHi @deray cable television",
  "id" : 594296024086097921,
  "in_reply_to_status_id" : 594284459408674816,
  "created_at" : "2015-05-02 00:23:08 +0000",
  "in_reply_to_screen_name" : "VibeHi",
  "in_reply_to_user_id_str" : "21822997",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BaltimoreUprising",
      "indices" : [ 108, 126 ]
    }, {
      "text" : "policeReform",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594250030699061248",
  "text" : "Police Patrols shouldn't be armed with deadly weapons.  Armed police should be like firefighters: on call.  #BaltimoreUprising #policeReform",
  "id" : 594250030699061248,
  "created_at" : "2015-05-01 21:20:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Situation Room",
      "screen_name" : "CNNSitRoom",
      "indices" : [ 0, 11 ],
      "id_str" : "34310801",
      "id" : 34310801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreddieGray",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594232047209689088",
  "geo" : { },
  "id_str" : "594232914398679040",
  "in_reply_to_user_id" : 34310801,
  "text" : "@CNNSitRoom  On this side of the charge, you mean.  #FreddieGray",
  "id" : 594232914398679040,
  "in_reply_to_status_id" : 594232047209689088,
  "created_at" : "2015-05-01 20:12:21 +0000",
  "in_reply_to_screen_name" : "CNNSitRoom",
  "in_reply_to_user_id_str" : "34310801",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 125, 138 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Anonymous",
      "indices" : [ 3, 13 ]
    }, {
      "text" : "FreddieGray",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9PXzHOYdoO",
      "expanded_url" : "http:\/\/photographyisnotacrime.com\/2015\/05\/man-who-recorded-freddie-gray-video-arrested-after-voicing-fears-that-police-were-trying-to-intimidate-him\/",
      "display_url" : "photographyisnotacrime.com\/2015\/05\/man-wh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594231536574074880",
  "text" : "yo #Anonymous the police have one of yours in custody, man who filmed the arrest of #FreddieGray http:\/\/t.co\/9PXzHOYdoO \n\ncc\/@YourAnonNews",
  "id" : 594231536574074880,
  "created_at" : "2015-05-01 20:06:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/sxJhdfcPUG",
      "expanded_url" : "https:\/\/twitter.com\/DaMFunK\/status\/594226360513634304",
      "display_url" : "twitter.com\/DaMFunK\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594228121173299201",
  "text" : "DAM RIGHT https:\/\/t.co\/sxJhdfcPUG",
  "id" : 594228121173299201,
  "created_at" : "2015-05-01 19:53:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Coe",
      "screen_name" : "BenjaminCoe",
      "indices" : [ 0, 12 ],
      "id_str" : "24659495",
      "id" : 24659495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594208069594152960",
  "geo" : { },
  "id_str" : "594211133612892160",
  "in_reply_to_user_id" : 24659495,
  "text" : "@BenjaminCoe ah ya",
  "id" : 594211133612892160,
  "in_reply_to_status_id" : 594208069594152960,
  "created_at" : "2015-05-01 18:45:48 +0000",
  "in_reply_to_screen_name" : "BenjaminCoe",
  "in_reply_to_user_id_str" : "24659495",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Coe",
      "screen_name" : "BenjaminCoe",
      "indices" : [ 0, 12 ],
      "id_str" : "24659495",
      "id" : 24659495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594202484995821568",
  "in_reply_to_user_id" : 24659495,
  "text" : "@BenjaminCoe  come to the OMNI tonight for a benefit party, check out the spot.",
  "id" : 594202484995821568,
  "created_at" : "2015-05-01 18:11:26 +0000",
  "in_reply_to_screen_name" : "BenjaminCoe",
  "in_reply_to_user_id_str" : "24659495",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 3, 18 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    }, {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 54, 63 ],
      "id_str" : "411733308",
      "id" : 411733308
    }, {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 92, 107 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594201725751275520",
  "text" : "yo @oaklanddancejs party tonight at the OMNI, home of @sudoroom, Cyber Wizard, and possibly @oaklanddancejs \ncome thru!\n4799 Shattuck Avenue",
  "id" : 594201725751275520,
  "created_at" : "2015-05-01 18:08:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 17, 25 ]
    }, {
      "text" : "LaborAgainstPoliceTerror",
      "indices" : [ 60, 85 ]
    }, {
      "text" : "MayDay",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/Z6cGJDFlIl",
      "expanded_url" : "https:\/\/oaklandwiki.org\/May_Day_Stop_Police_Terror_Port_Shutdown",
      "display_url" : "oaklandwiki.org\/May_Day_Stop_P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594183371913236482",
  "text" : "RT @marinakukso: #oakland: document what's happening at the #LaborAgainstPoliceTerror #MayDay port shutdown. Add pics &amp; info here: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oakland",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "LaborAgainstPoliceTerror",
        "indices" : [ 43, 68 ]
      }, {
        "text" : "MayDay",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/Z6cGJDFlIl",
        "expanded_url" : "https:\/\/oaklandwiki.org\/May_Day_Stop_Police_Terror_Port_Shutdown",
        "display_url" : "oaklandwiki.org\/May_Day_Stop_P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594182380954333186",
    "text" : "#oakland: document what's happening at the #LaborAgainstPoliceTerror #MayDay port shutdown. Add pics &amp; info here: https:\/\/t.co\/Z6cGJDFlIl",
    "id" : 594182380954333186,
    "created_at" : "2015-05-01 16:51:33 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 594183371913236482,
  "created_at" : "2015-05-01 16:55:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "talkpay",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "mayday",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594182058143928320",
  "text" : "#talkpay\n$20K is a good year.\nhealth insurance never.\nno savings, family or inheritance.\ncurrent income 160\/mo teaching javascript.\n#mayday",
  "id" : 594182058143928320,
  "created_at" : "2015-05-01 16:50:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]