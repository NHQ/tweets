Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682740578136670209",
  "text" : "food",
  "id" : 682740578136670209,
  "created_at" : "2016-01-01 01:50:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682733772232470529",
  "text" : "the cutting edge of technology is the edge that cuts humans",
  "id" : 682733772232470529,
  "created_at" : "2016-01-01 01:23:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682103348548390917",
  "text" : "when cinema is your only reprieve",
  "id" : 682103348548390917,
  "created_at" : "2015-12-30 07:38:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682101215245647872",
  "text" : "ye aint that good with yr bye tbh",
  "id" : 682101215245647872,
  "created_at" : "2015-12-30 07:29:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682101022303469568",
  "text" : "aint never gonna be be whom I gonna be",
  "id" : 682101022303469568,
  "created_at" : "2015-12-30 07:28:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682100913654243328",
  "text" : "who I am",
  "id" : 682100913654243328,
  "created_at" : "2015-12-30 07:28:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shruti Ravindran",
      "screen_name" : "s_ravindran",
      "indices" : [ 0, 12 ],
      "id_str" : "924046771",
      "id" : 924046771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/7ZMOWegMpj",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/RollerCoaster_Tycoon",
      "display_url" : "en.wikipedia.org\/wiki\/RollerCoa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "682082853631471616",
  "geo" : { },
  "id_str" : "682093778274914305",
  "in_reply_to_user_id" : 924046771,
  "text" : "@s_ravindran  https:\/\/t.co\/7ZMOWegMpj",
  "id" : 682093778274914305,
  "in_reply_to_status_id" : 682082853631471616,
  "created_at" : "2015-12-30 07:00:04 +0000",
  "in_reply_to_screen_name" : "s_ravindran",
  "in_reply_to_user_id_str" : "924046771",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bMSxGvNuL0",
      "expanded_url" : "https:\/\/archive.org\/details\/folkstack_Warp_session",
      "display_url" : "archive.org\/details\/folkst\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682080483279159297",
  "text" : "give the internet archive some satoshi for hosting algorithmically induced psych-outs and then chillax a few tracks\n\nhttps:\/\/t.co\/bMSxGvNuL0",
  "id" : 682080483279159297,
  "created_at" : "2015-12-30 06:07:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/srz0TTgYfK",
      "expanded_url" : "https:\/\/twitter.com\/substack\/status\/682069985750024194",
      "display_url" : "twitter.com\/substack\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682076185610682368",
  "text" : "yay https:\/\/t.co\/srz0TTgYfK",
  "id" : 682076185610682368,
  "created_at" : "2015-12-30 05:50:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682066414795010049",
  "text" : "life, adulterated",
  "id" : 682066414795010049,
  "created_at" : "2015-12-30 05:11:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682060116837806080",
  "text" : "johnny is currently feeling lonely",
  "id" : 682060116837806080,
  "created_at" : "2015-12-30 04:46:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680156447506706432",
  "text" : "What do these three saints have in common?\n\nSanta Maria, Santa Monica, Santa Claus  \n\nhow do they differ from San Antonio, San Louis Obispo?",
  "id" : 680156447506706432,
  "created_at" : "2015-12-24 22:41:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680135385897250816",
  "text" : "The truth will set your ass free.\n\nReligion is totes fucking retarding.\n\nSanta Claus is obviously spo to be gendered a Saintly god*mother*",
  "id" : 680135385897250816,
  "created_at" : "2015-12-24 21:18:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680133600453341185",
  "text" : "I ask the congregation, did you reject indoctrinated religion out of your heart yet?  Be honest w thy selfie.  Fear not inner truth voice.",
  "id" : 680133600453341185,
  "created_at" : "2015-12-24 21:11:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2605 Deeky Stardust \u2605",
      "screen_name" : "MrDeeky",
      "indices" : [ 3, 11 ],
      "id_str" : "243861655",
      "id" : 243861655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/wgoez5vOkE",
      "expanded_url" : "http:\/\/www.rawstory.com\/2015\/12\/these-14-large-police-departments-only-killed-black-people-this-year\/#.Vnq80HAguVI.twitter",
      "display_url" : "rawstory.com\/2015\/12\/these-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679744569848680448",
  "text" : "RT @MrDeeky: These 14 large police departments only killed black people this year https:\/\/t.co\/wgoez5vOkE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/wgoez5vOkE",
        "expanded_url" : "http:\/\/www.rawstory.com\/2015\/12\/these-14-large-police-departments-only-killed-black-people-this-year\/#.Vnq80HAguVI.twitter",
        "display_url" : "rawstory.com\/2015\/12\/these-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679684172600967168",
    "text" : "These 14 large police departments only killed black people this year https:\/\/t.co\/wgoez5vOkE",
    "id" : 679684172600967168,
    "created_at" : "2015-12-23 15:25:09 +0000",
    "user" : {
      "name" : "\u2605 Deeky Stardust \u2605",
      "screen_name" : "MrDeeky",
      "protected" : false,
      "id_str" : "243861655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623665396160286720\/sUlhdKMP_normal.jpg",
      "id" : 243861655,
      "verified" : false
    }
  },
  "id" : 679744569848680448,
  "created_at" : "2015-12-23 19:25:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandraBland",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679202418874146816",
  "text" : "Pulled over for turn signal by cop on a tirade, on camera.\nDies mysteriously in jail two days later.\nWhat's there to indict?\n#SandraBland",
  "id" : 679202418874146816,
  "created_at" : "2015-12-22 07:30:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avocado",
      "screen_name" : "RealAvocadoFact",
      "indices" : [ 3, 19 ],
      "id_str" : "1510981123",
      "id" : 1510981123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679120366573363200",
  "text" : "RT @RealAvocadoFact: things avocados didn't do this week:\n\u2022 anything really\n\u2022 avocado is a fruit\n\u2022 a new Manhattan Project to strengthen a \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678569101875388416",
    "text" : "things avocados didn't do this week:\n\u2022 anything really\n\u2022 avocado is a fruit\n\u2022 a new Manhattan Project to strengthen a police state are you f",
    "id" : 678569101875388416,
    "created_at" : "2015-12-20 13:34:15 +0000",
    "user" : {
      "name" : "Avocado",
      "screen_name" : "RealAvocadoFact",
      "protected" : false,
      "id_str" : "1510981123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261569405885\/600319ed2d9c3ed74e94342e8ae75826_normal.jpeg",
      "id" : 1510981123,
      "verified" : false
    }
  },
  "id" : 679120366573363200,
  "created_at" : "2015-12-22 02:04:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Sinyangwe",
      "screen_name" : "samswey",
      "indices" : [ 3, 11 ],
      "id_str" : "791077327",
      "id" : 791077327
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/samswey\/status\/677365526021013505\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/rExjBWEw52",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWZ8Wx7U4AAgT-P.jpg",
      "id_str" : "677365524766973952",
      "id" : 677365524766973952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWZ8Wx7U4AAgT-P.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 676
      } ],
      "display_url" : "pic.twitter.com\/rExjBWEw52"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679044675429203969",
  "text" : "RT @samswey: This. https:\/\/t.co\/rExjBWEw52",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/samswey\/status\/677365526021013505\/photo\/1",
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/rExjBWEw52",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWZ8Wx7U4AAgT-P.jpg",
        "id_str" : "677365524766973952",
        "id" : 677365524766973952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWZ8Wx7U4AAgT-P.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 676
        } ],
        "display_url" : "pic.twitter.com\/rExjBWEw52"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677365526021013505",
    "text" : "This. https:\/\/t.co\/rExjBWEw52",
    "id" : 677365526021013505,
    "created_at" : "2015-12-17 05:51:40 +0000",
    "user" : {
      "name" : "Samuel Sinyangwe",
      "screen_name" : "samswey",
      "protected" : false,
      "id_str" : "791077327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622937073574514688\/mugS1Bdm_normal.jpg",
      "id" : 791077327,
      "verified" : false
    }
  },
  "id" : 679044675429203969,
  "created_at" : "2015-12-21 21:04:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678679945162285056",
  "text" : "I support a wikipedia tax for California homeowners and their dependents.",
  "id" : 678679945162285056,
  "created_at" : "2015-12-20 20:54:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678679702630850560",
  "text" : "Please force your government to give wikipedia more money than it ever dreamed.",
  "id" : 678679702630850560,
  "created_at" : "2015-12-20 20:53:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678611087466500096",
  "geo" : { },
  "id_str" : "678654563054829568",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  omg unlimited hot beverages and pastries",
  "id" : 678654563054829568,
  "in_reply_to_status_id" : 678611087466500096,
  "created_at" : "2015-12-20 19:13:51 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678294927386632192",
  "text" : "RT @postcrunk: ideology is an invisible dictator",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678290860505722880",
    "text" : "ideology is an invisible dictator",
    "id" : 678290860505722880,
    "created_at" : "2015-12-19 19:08:37 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 678294927386632192,
  "created_at" : "2015-12-19 19:24:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "indices" : [ 3, 12 ],
      "id_str" : "14607140",
      "id" : 14607140
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hackaday\/status\/677843356274302977\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/ZRENCJ0JER",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWgu8OhWEAEIIlE.jpg",
      "id_str" : "677843356144242689",
      "id" : 677843356144242689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWgu8OhWEAEIIlE.jpg",
      "sizes" : [ {
        "h" : 112,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ZRENCJ0JER"
    } ],
    "hashtags" : [ {
      "text" : "RaspberryPi",
      "indices" : [ 37, 49 ]
    }, {
      "text" : "Python",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/uxKy02MhGG",
      "expanded_url" : "http:\/\/bit.ly\/1mmS1MV",
      "display_url" : "bit.ly\/1mmS1MV"
    } ]
  },
  "geo" : { },
  "id_str" : "677975708652580864",
  "text" : "RT @hackaday: Polarimetric camera w\/ #RaspberryPi &amp; #Python scripts can see landmines, cancerous tissue: https:\/\/t.co\/uxKy02MhGG https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/hackaday\/status\/677843356274302977\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/ZRENCJ0JER",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWgu8OhWEAEIIlE.jpg",
        "id_str" : "677843356144242689",
        "id" : 677843356144242689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWgu8OhWEAEIIlE.jpg",
        "sizes" : [ {
          "h" : 112,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/ZRENCJ0JER"
      } ],
      "hashtags" : [ {
        "text" : "RaspberryPi",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "Python",
        "indices" : [ 42, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/uxKy02MhGG",
        "expanded_url" : "http:\/\/bit.ly\/1mmS1MV",
        "display_url" : "bit.ly\/1mmS1MV"
      } ]
    },
    "geo" : { },
    "id_str" : "677843356274302977",
    "text" : "Polarimetric camera w\/ #RaspberryPi &amp; #Python scripts can see landmines, cancerous tissue: https:\/\/t.co\/uxKy02MhGG https:\/\/t.co\/ZRENCJ0JER",
    "id" : 677843356274302977,
    "created_at" : "2015-12-18 13:30:24 +0000",
    "user" : {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "protected" : false,
      "id_str" : "14607140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699222440702926848\/8Pm7yZFb_normal.png",
      "id" : 14607140,
      "verified" : false
    }
  },
  "id" : 677975708652580864,
  "created_at" : "2015-12-18 22:16:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Intercept FLM",
      "screen_name" : "the_intercept",
      "indices" : [ 3, 17 ],
      "id_str" : "719972682322853888",
      "id" : 719972682322853888
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/the_intercept\/status\/677540224113745920\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/ltCQrqPhuT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWcbMLnW4AAD4w1.png",
      "id_str" : "677540165032796160",
      "id" : 677540165032796160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWcbMLnW4AAD4w1.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ltCQrqPhuT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/RHuPpxxL6N",
      "expanded_url" : "http:\/\/interc.pt\/1QPwmby",
      "display_url" : "interc.pt\/1QPwmby"
    } ]
  },
  "geo" : { },
  "id_str" : "677556602694569984",
  "text" : "RT @the_intercept: Exclusive: A secret catalogue of government gear for spying on your cellphone https:\/\/t.co\/RHuPpxxL6N https:\/\/t.co\/ltCQr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/the_intercept\/status\/677540224113745920\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/ltCQrqPhuT",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWcbMLnW4AAD4w1.png",
        "id_str" : "677540165032796160",
        "id" : 677540165032796160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWcbMLnW4AAD4w1.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ltCQrqPhuT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/RHuPpxxL6N",
        "expanded_url" : "http:\/\/interc.pt\/1QPwmby",
        "display_url" : "interc.pt\/1QPwmby"
      } ]
    },
    "geo" : { },
    "id_str" : "677540224113745920",
    "text" : "Exclusive: A secret catalogue of government gear for spying on your cellphone https:\/\/t.co\/RHuPpxxL6N https:\/\/t.co\/ltCQrqPhuT",
    "id" : 677540224113745920,
    "created_at" : "2015-12-17 17:25:52 +0000",
    "user" : {
      "name" : "The Intercept",
      "screen_name" : "theintercept",
      "protected" : false,
      "id_str" : "2329066872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621138310585409536\/mSJHNbO6_normal.png",
      "id" : 2329066872,
      "verified" : true
    }
  },
  "id" : 677556602694569984,
  "created_at" : "2015-12-17 18:30:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 13, 21 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676191238949851140",
  "text" : "HAPPY BUBDAY @Gyselie",
  "id" : 676191238949851140,
  "created_at" : "2015-12-14 00:05:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675876298892451840",
  "text" : "A government p2p, p4p, and opp!",
  "id" : 675876298892451840,
  "created_at" : "2015-12-13 03:14:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/2qpTW7HlrV",
      "expanded_url" : "http:\/\/www.theonion.com\/article\/woman-launches-into-4-minute-self-deprecating-prea-37532",
      "display_url" : "theonion.com\/article\/woman-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675797985670897664",
  "text" : "RT @marinakukso: \"Woman Launches Into 4-Minute Self-Deprecating Preamble Before Speaking Mind\" https:\/\/t.co\/2qpTW7HlrV consequences of perv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/2qpTW7HlrV",
        "expanded_url" : "http:\/\/www.theonion.com\/article\/woman-launches-into-4-minute-self-deprecating-prea-37532",
        "display_url" : "theonion.com\/article\/woman-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675764706162806784",
    "text" : "\"Woman Launches Into 4-Minute Self-Deprecating Preamble Before Speaking Mind\" https:\/\/t.co\/2qpTW7HlrV consequences of pervasive gaslighting",
    "id" : 675764706162806784,
    "created_at" : "2015-12-12 19:50:35 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 675797985670897664,
  "created_at" : "2015-12-12 22:02:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/eSsCYm2Wn9",
      "expanded_url" : "http:\/\/www.theonion.com\/article\/woman-quickly-cycles-through-non-threatening-voice-50917",
      "display_url" : "theonion.com\/article\/woman-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675797974958530560",
  "text" : "RT @marinakukso: \"Woman Quickly Cycles Through Non-Threatening Voice Inflections Before Expressing Concern\" https:\/\/t.co\/eSsCYm2Wn9 consequ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/eSsCYm2Wn9",
        "expanded_url" : "http:\/\/www.theonion.com\/article\/woman-quickly-cycles-through-non-threatening-voice-50917",
        "display_url" : "theonion.com\/article\/woman-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675768992384966656",
    "text" : "\"Woman Quickly Cycles Through Non-Threatening Voice Inflections Before Expressing Concern\" https:\/\/t.co\/eSsCYm2Wn9 consequenc of gaslighting",
    "id" : 675768992384966656,
    "created_at" : "2015-12-12 20:07:37 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 675797974958530560,
  "created_at" : "2015-12-12 22:02:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/6UAExX9zFw",
      "expanded_url" : "http:\/\/everydayfeminism.com\/2015\/05\/financial-problems-not-your-fault\/",
      "display_url" : "everydayfeminism.com\/2015\/05\/financ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675797904603406336",
  "text" : "RT @marinakukso: \"professionalism was designed to keep certain people out of \u201Cprofessional\u201D environments &amp; away from systemic power.\" https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/6UAExX9zFw",
        "expanded_url" : "http:\/\/everydayfeminism.com\/2015\/05\/financial-problems-not-your-fault\/",
        "display_url" : "everydayfeminism.com\/2015\/05\/financ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675773102534451201",
    "text" : "\"professionalism was designed to keep certain people out of \u201Cprofessional\u201D environments &amp; away from systemic power.\" https:\/\/t.co\/6UAExX9zFw",
    "id" : 675773102534451201,
    "created_at" : "2015-12-12 20:23:57 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 675797904603406336,
  "created_at" : "2015-12-12 22:02:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rhodey orbits",
      "screen_name" : "NotRhodey",
      "indices" : [ 0, 10 ],
      "id_str" : "1131293652",
      "id" : 1131293652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675080341980381184",
  "geo" : { },
  "id_str" : "675088090214604800",
  "in_reply_to_user_id" : 1131293652,
  "text" : "@NotRhodey  Cryptony Tony",
  "id" : 675088090214604800,
  "in_reply_to_status_id" : 675080341980381184,
  "created_at" : "2015-12-10 23:01:57 +0000",
  "in_reply_to_screen_name" : "NotRhodey",
  "in_reply_to_user_id_str" : "1131293652",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rhodey orbits",
      "screen_name" : "NotRhodey",
      "indices" : [ 0, 10 ],
      "id_str" : "1131293652",
      "id" : 1131293652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675078553755656192",
  "geo" : { },
  "id_str" : "675079449650556929",
  "in_reply_to_user_id" : 1131293652,
  "text" : "@NotRhodey Nichelodey Plutoney",
  "id" : 675079449650556929,
  "in_reply_to_status_id" : 675078553755656192,
  "created_at" : "2015-12-10 22:27:37 +0000",
  "in_reply_to_screen_name" : "NotRhodey",
  "in_reply_to_user_id_str" : "1131293652",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "indices" : [ 3, 19 ],
      "id_str" : "87320284",
      "id" : 87320284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/HjPHYBmDyp",
      "expanded_url" : "https:\/\/youtu.be\/sDH3tpAtx58",
      "display_url" : "youtu.be\/sDH3tpAtx58"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/bReeDZfKAK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=u-lVYVfa8E0",
      "display_url" : "youtube.com\/watch?v=u-lVYV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675047408703815684",
  "text" : "RT @veeveeveeveevee: NEW BEAUTIFUL KOOL A.D. MUSIC VIDEO \"MAESTRO\" https:\/\/t.co\/HjPHYBmDyp ALSO WATCH THIS 1 AGAIN 2 WHILE UR AT IT Y NOT h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/HjPHYBmDyp",
        "expanded_url" : "https:\/\/youtu.be\/sDH3tpAtx58",
        "display_url" : "youtu.be\/sDH3tpAtx58"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/bReeDZfKAK",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=u-lVYVfa8E0",
        "display_url" : "youtube.com\/watch?v=u-lVYV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675030549451415553",
    "text" : "NEW BEAUTIFUL KOOL A.D. MUSIC VIDEO \"MAESTRO\" https:\/\/t.co\/HjPHYBmDyp ALSO WATCH THIS 1 AGAIN 2 WHILE UR AT IT Y NOT https:\/\/t.co\/bReeDZfKAK",
    "id" : 675030549451415553,
    "created_at" : "2015-12-10 19:13:19 +0000",
    "user" : {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "protected" : false,
      "id_str" : "87320284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3290278496\/63e6e6ef113610b95961f0a5436adf5d_normal.jpeg",
      "id" : 87320284,
      "verified" : true
    }
  },
  "id" : 675047408703815684,
  "created_at" : "2015-12-10 20:20:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "indices" : [ 3, 19 ],
      "id_str" : "87320284",
      "id" : 87320284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/JfWs4z2UjI",
      "expanded_url" : "https:\/\/koolad.bandcamp.com\/album\/o-k",
      "display_url" : "koolad.bandcamp.com\/album\/o-k"
    } ]
  },
  "geo" : { },
  "id_str" : "675047375057133569",
  "text" : "RT @veeveeveeveevee: PAY WHAT U WANT FOR THIS 100 SONG ALBUM I MADE (RECOMMENDED PRICE $100) https:\/\/t.co\/JfWs4z2UjI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/JfWs4z2UjI",
        "expanded_url" : "https:\/\/koolad.bandcamp.com\/album\/o-k",
        "display_url" : "koolad.bandcamp.com\/album\/o-k"
      } ]
    },
    "geo" : { },
    "id_str" : "675035963316412418",
    "text" : "PAY WHAT U WANT FOR THIS 100 SONG ALBUM I MADE (RECOMMENDED PRICE $100) https:\/\/t.co\/JfWs4z2UjI",
    "id" : 675035963316412418,
    "created_at" : "2015-12-10 19:34:49 +0000",
    "user" : {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "protected" : false,
      "id_str" : "87320284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3290278496\/63e6e6ef113610b95961f0a5436adf5d_normal.jpeg",
      "id" : 87320284,
      "verified" : true
    }
  },
  "id" : 675047375057133569,
  "created_at" : "2015-12-10 20:20:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675046236790091777",
  "text" : "realness isn't an ism",
  "id" : 675046236790091777,
  "created_at" : "2015-12-10 20:15:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/FpsrQpiXWL",
      "expanded_url" : "http:\/\/www.dailymotion.com\/video\/x2hdcji",
      "display_url" : "dailymotion.com\/video\/x2hdcji"
    } ]
  },
  "in_reply_to_status_id_str" : "675001445624754176",
  "geo" : { },
  "id_str" : "675001818473209856",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript and link goes to https:\/\/t.co\/FpsrQpiXWL",
  "id" : 675001818473209856,
  "in_reply_to_status_id" : 675001445624754176,
  "created_at" : "2015-12-10 17:19:09 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675001445624754176",
  "text" : "oh shit there's a new adam curtis documentary about US and Saudi Arabia",
  "id" : 675001445624754176,
  "created_at" : "2015-12-10 17:17:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674453970711003136",
  "text" : "GET ME A BACKDOOR INTO BITCOIN NAKAMOTO",
  "id" : 674453970711003136,
  "created_at" : "2015-12-09 05:02:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/apZhfVS2G8",
      "expanded_url" : "https:\/\/twitter.com\/cfarivar\/status\/674314174361550848",
      "display_url" : "twitter.com\/cfarivar\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674337555769262080",
  "text" : "RT @marinakukso: this article puts \"curtailing police shootings &amp; eliminating racial profiling\" in \"better commty relations\" category https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/apZhfVS2G8",
        "expanded_url" : "https:\/\/twitter.com\/cfarivar\/status\/674314174361550848",
        "display_url" : "twitter.com\/cfarivar\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674317405686857730",
    "text" : "this article puts \"curtailing police shootings &amp; eliminating racial profiling\" in \"better commty relations\" category https:\/\/t.co\/apZhfVS2G8",
    "id" : 674317405686857730,
    "created_at" : "2015-12-08 19:59:32 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 674337555769262080,
  "created_at" : "2015-12-08 21:19:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lady Alex",
      "screen_name" : "Sounjaneer",
      "indices" : [ 0, 11 ],
      "id_str" : "2588867390",
      "id" : 2588867390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674330151640047616",
  "geo" : { },
  "id_str" : "674337246166704128",
  "in_reply_to_user_id" : 2588867390,
  "text" : "@Sounjaneer  click report pls",
  "id" : 674337246166704128,
  "in_reply_to_status_id" : 674330151640047616,
  "created_at" : "2015-12-08 21:18:22 +0000",
  "in_reply_to_screen_name" : "Sounjaneer",
  "in_reply_to_user_id_str" : "2588867390",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "East Bay Express",
      "screen_name" : "EastBayExpress",
      "indices" : [ 3, 18 ],
      "id_str" : "19315665",
      "id" : 19315665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/QNONKCW9E7",
      "expanded_url" : "http:\/\/buff.ly\/1XQKruO",
      "display_url" : "buff.ly\/1XQKruO"
    } ]
  },
  "geo" : { },
  "id_str" : "674289358128594944",
  "text" : "RT @EastBayExpress: The number of Ellis Act evictions in Oakland has more than doubled in the past six months. https:\/\/t.co\/QNONKCW9E7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/QNONKCW9E7",
        "expanded_url" : "http:\/\/buff.ly\/1XQKruO",
        "display_url" : "buff.ly\/1XQKruO"
      } ]
    },
    "geo" : { },
    "id_str" : "674277991413886981",
    "text" : "The number of Ellis Act evictions in Oakland has more than doubled in the past six months. https:\/\/t.co\/QNONKCW9E7",
    "id" : 674277991413886981,
    "created_at" : "2015-12-08 17:22:55 +0000",
    "user" : {
      "name" : "East Bay Express",
      "screen_name" : "EastBayExpress",
      "protected" : false,
      "id_str" : "19315665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727664063103148032\/mF_dtiRx_normal.jpg",
      "id" : 19315665,
      "verified" : false
    }
  },
  "id" : 674289358128594944,
  "created_at" : "2015-12-08 18:08:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674009688707502080",
  "text" : "the media on a war tour",
  "id" : 674009688707502080,
  "created_at" : "2015-12-07 23:36:46 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673998486942027776",
  "text" : "If you gun owners were really into defending life and liberty, you would be out there protecting those who protest your shit-fucked systems.",
  "id" : 673998486942027776,
  "created_at" : "2015-12-07 22:52:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/673417146244927488\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/bEZir24XIg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVh1U1OVEAEmk_b.png",
      "id_str" : "673417145036902401",
      "id" : 673417145036902401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVh1U1OVEAEmk_b.png",
      "sizes" : [ {
        "h" : 547,
        "resize" : "fit",
        "w" : 547
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 547
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 547
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/bEZir24XIg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/hVen24yfGM",
      "expanded_url" : "https:\/\/soundcloud.com\/atakak\/ata-kak-momayendo-rm",
      "display_url" : "soundcloud.com\/atakak\/ata-kak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673417146244927488",
  "text" : "https:\/\/t.co\/hVen24yfGM https:\/\/t.co\/bEZir24XIg",
  "id" : 673417146244927488,
  "created_at" : "2015-12-06 08:22:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 3, 11 ],
      "id_str" : "19417999",
      "id" : 19417999
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DaMFunK\/status\/673412145988501505\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Abq1gjjC7y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVhwxrIUAAA63sN.jpg",
      "id_str" : "673412142985379840",
      "id" : 673412142985379840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVhwxrIUAAA63sN.jpg",
      "sizes" : [ {
        "h" : 323,
        "resize" : "fit",
        "w" : 323
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 323
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 323
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 323
      } ],
      "display_url" : "pic.twitter.com\/Abq1gjjC7y"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/DaMFunK\/status\/673412145988501505\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Abq1gjjC7y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVhwxrGUAAAi1uH.jpg",
      "id_str" : "673412142976991232",
      "id" : 673412142976991232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVhwxrGUAAAi1uH.jpg",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 306
      } ],
      "display_url" : "pic.twitter.com\/Abq1gjjC7y"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/DaMFunK\/status\/673412145988501505\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Abq1gjjC7y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVhwxrFU4AAQeb0.jpg",
      "id_str" : "673412142972854272",
      "id" : 673412142972854272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVhwxrFU4AAQeb0.jpg",
      "sizes" : [ {
        "h" : 401,
        "resize" : "fit",
        "w" : 401
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 401
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 401
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Abq1gjjC7y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/QoswA8CmCJ",
      "expanded_url" : "http:\/\/youtu.be\/gML0PukI5rI",
      "display_url" : "youtu.be\/gML0PukI5rI"
    } ]
  },
  "geo" : { },
  "id_str" : "673412749255442432",
  "text" : "RT @DaMFunK: \u270C\uD83C\uDFFF\uFE0F Software - Island-Sunrise\nInnovative Communication \/ 1988\nhttps:\/\/t.co\/QoswA8CmCJ | DF https:\/\/t.co\/Abq1gjjC7y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DaMFunK\/status\/673412145988501505\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/Abq1gjjC7y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVhwxrIUAAA63sN.jpg",
        "id_str" : "673412142985379840",
        "id" : 673412142985379840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVhwxrIUAAA63sN.jpg",
        "sizes" : [ {
          "h" : 323,
          "resize" : "fit",
          "w" : 323
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 323
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 323
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 323
        } ],
        "display_url" : "pic.twitter.com\/Abq1gjjC7y"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/DaMFunK\/status\/673412145988501505\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/Abq1gjjC7y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVhwxrGUAAAi1uH.jpg",
        "id_str" : "673412142976991232",
        "id" : 673412142976991232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVhwxrGUAAAi1uH.jpg",
        "sizes" : [ {
          "h" : 306,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 306
        } ],
        "display_url" : "pic.twitter.com\/Abq1gjjC7y"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/DaMFunK\/status\/673412145988501505\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/Abq1gjjC7y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVhwxrFU4AAQeb0.jpg",
        "id_str" : "673412142972854272",
        "id" : 673412142972854272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVhwxrFU4AAQeb0.jpg",
        "sizes" : [ {
          "h" : 401,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Abq1gjjC7y"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/QoswA8CmCJ",
        "expanded_url" : "http:\/\/youtu.be\/gML0PukI5rI",
        "display_url" : "youtu.be\/gML0PukI5rI"
      } ]
    },
    "geo" : { },
    "id_str" : "673412145988501505",
    "text" : "\u270C\uD83C\uDFFF\uFE0F Software - Island-Sunrise\nInnovative Communication \/ 1988\nhttps:\/\/t.co\/QoswA8CmCJ | DF https:\/\/t.co\/Abq1gjjC7y",
    "id" : 673412145988501505,
    "created_at" : "2015-12-06 08:02:21 +0000",
    "user" : {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "protected" : false,
      "id_str" : "19417999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727729991186825216\/fKFPEbre_normal.jpg",
      "id" : 19417999,
      "verified" : true
    }
  },
  "id" : 673412749255442432,
  "created_at" : "2015-12-06 08:04:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673264727334621184",
  "text" : "ya'll busy being fools\nmy fool phase OVER \nnow im jus fool n\nshut up and look pretty \/ sad",
  "id" : 673264727334621184,
  "created_at" : "2015-12-05 22:16:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673263872908767232",
  "text" : "you should want to get with me and what I'm doing, and if you don't I ain't got shit for you.  not even shit.  my shit's too good.",
  "id" : 673263872908767232,
  "created_at" : "2015-12-05 22:13:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "indices" : [ 3, 16 ],
      "id_str" : "481655487",
      "id" : 481655487
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarioWoods",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672983918606352384",
  "text" : "RT @juliacarriew: At #MarioWoods SFPD town hall: Suhr says 1 officer fired in defense of self, 4 officers fired in defense of first officer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarioWoods",
        "indices" : [ 3, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672966957541429248",
    "text" : "At #MarioWoods SFPD town hall: Suhr says 1 officer fired in defense of self, 4 officers fired in defense of first officer",
    "id" : 672966957541429248,
    "created_at" : "2015-12-05 02:33:20 +0000",
    "user" : {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "protected" : false,
      "id_str" : "481655487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621392347536818176\/dkI_Q4kL_normal.jpg",
      "id" : 481655487,
      "verified" : false
    }
  },
  "id" : 672983918606352384,
  "created_at" : "2015-12-05 03:40:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "indices" : [ 3, 16 ],
      "id_str" : "481655487",
      "id" : 481655487
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/juliacarriew\/status\/672976141360074753\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/T54MO7WCWR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVbkO0GUkAAA5qs.jpg",
      "id_str" : "672976137492926464",
      "id" : 672976137492926464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVbkO0GUkAAA5qs.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T54MO7WCWR"
    } ],
    "hashtags" : [ {
      "text" : "MarioWoods",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672983768110514176",
  "text" : "RT @juliacarriew: Woman raises litany of problems with Suhr's tenure, including racist text messages #MarioWoods https:\/\/t.co\/T54MO7WCWR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/juliacarriew\/status\/672976141360074753\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/T54MO7WCWR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVbkO0GUkAAA5qs.jpg",
        "id_str" : "672976137492926464",
        "id" : 672976137492926464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVbkO0GUkAAA5qs.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/T54MO7WCWR"
      } ],
      "hashtags" : [ {
        "text" : "MarioWoods",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "672975807329910786",
    "geo" : { },
    "id_str" : "672976141360074753",
    "in_reply_to_user_id" : 481655487,
    "text" : "Woman raises litany of problems with Suhr's tenure, including racist text messages #MarioWoods https:\/\/t.co\/T54MO7WCWR",
    "id" : 672976141360074753,
    "in_reply_to_status_id" : 672975807329910786,
    "created_at" : "2015-12-05 03:09:50 +0000",
    "in_reply_to_screen_name" : "juliacarriew",
    "in_reply_to_user_id_str" : "481655487",
    "user" : {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "protected" : false,
      "id_str" : "481655487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621392347536818176\/dkI_Q4kL_normal.jpg",
      "id" : 481655487,
      "verified" : false
    }
  },
  "id" : 672983768110514176,
  "created_at" : "2015-12-05 03:40:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "indices" : [ 3, 16 ],
      "id_str" : "481655487",
      "id" : 481655487
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarioWoods",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672983714553397248",
  "text" : "RT @juliacarriew: Representative of Alex Nieto's family to Chief Suhr: \"Are you here to resign? Huge cheers from crowd. #MarioWoods",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarioWoods",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672975807329910786",
    "text" : "Representative of Alex Nieto's family to Chief Suhr: \"Are you here to resign? Huge cheers from crowd. #MarioWoods",
    "id" : 672975807329910786,
    "created_at" : "2015-12-05 03:08:30 +0000",
    "user" : {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "protected" : false,
      "id_str" : "481655487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621392347536818176\/dkI_Q4kL_normal.jpg",
      "id" : 481655487,
      "verified" : false
    }
  },
  "id" : 672983714553397248,
  "created_at" : "2015-12-05 03:39:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "indices" : [ 3, 16 ],
      "id_str" : "481655487",
      "id" : 481655487
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarioWoods",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672983693577728000",
  "text" : "RT @juliacarriew: \"I have a question. If it were your father or your son or your family that had a knife would you have shot him down like \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarioWoods",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672973866021482497",
    "text" : "\"I have a question. If it were your father or your son or your family that had a knife would you have shot him down like a pig?\" #MarioWoods",
    "id" : 672973866021482497,
    "created_at" : "2015-12-05 03:00:47 +0000",
    "user" : {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "protected" : false,
      "id_str" : "481655487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621392347536818176\/dkI_Q4kL_normal.jpg",
      "id" : 481655487,
      "verified" : false
    }
  },
  "id" : 672983693577728000,
  "created_at" : "2015-12-05 03:39:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/672921718239924224\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/JRmKmxiZJt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVayvIMXAAYqQ5H.jpg",
      "id_str" : "672921717061386246",
      "id" : 672921717061386246,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVayvIMXAAYqQ5H.jpg",
      "sizes" : [ {
        "h" : 956,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 956,
        "resize" : "fit",
        "w" : 970
      } ],
      "display_url" : "pic.twitter.com\/JRmKmxiZJt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/FWn1tYeN9G",
      "expanded_url" : "http:\/\/www.nydailynews.com\/news\/national\/king-mario-woods-life-brutally-cops-article-1.2455457?cid=bitly",
      "display_url" : "nydailynews.com\/news\/national\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672921718239924224",
  "text" : "this is some death squad shit san franscisco  https:\/\/t.co\/FWn1tYeN9G https:\/\/t.co\/JRmKmxiZJt",
  "id" : 672921718239924224,
  "created_at" : "2015-12-04 23:33:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BlackOUT Collective",
      "screen_name" : "blackoutcollect",
      "indices" : [ 3, 19 ],
      "id_str" : "2912990047",
      "id" : 2912990047
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/blackoutcollect\/status\/672479011809857536\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/TNzfYbcEC1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVUgGQjUkAA5kIj.jpg",
      "id_str" : "672479011256176640",
      "id" : 672479011256176640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVUgGQjUkAA5kIj.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/TNzfYbcEC1"
    } ],
    "hashtags" : [ {
      "text" : "Justice4Mario",
      "indices" : [ 61, 75 ]
    }, {
      "text" : "BayviewShooting",
      "indices" : [ 76, 92 ]
    }, {
      "text" : "Bayview",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "BlackLivesMatter",
      "indices" : [ 103, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672502408585461760",
  "text" : "RT @blackoutcollect: His name is Mario Woods, 26 years old.  #Justice4Mario #BayviewShooting  #Bayview #BlackLivesMatter https:\/\/t.co\/TNzfY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/blackoutcollect\/status\/672479011809857536\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/TNzfYbcEC1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVUgGQjUkAA5kIj.jpg",
        "id_str" : "672479011256176640",
        "id" : 672479011256176640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVUgGQjUkAA5kIj.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/TNzfYbcEC1"
      } ],
      "hashtags" : [ {
        "text" : "Justice4Mario",
        "indices" : [ 40, 54 ]
      }, {
        "text" : "BayviewShooting",
        "indices" : [ 55, 71 ]
      }, {
        "text" : "Bayview",
        "indices" : [ 73, 81 ]
      }, {
        "text" : "BlackLivesMatter",
        "indices" : [ 82, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672479776158826496",
    "text" : "His name is Mario Woods, 26 years old.  #Justice4Mario #BayviewShooting  #Bayview #BlackLivesMatter https:\/\/t.co\/TNzfYbcEC1",
    "id" : 672479776158826496,
    "created_at" : "2015-12-03 18:17:27 +0000",
    "user" : {
      "name" : "BlackOUT Collective",
      "screen_name" : "blackoutcollect",
      "protected" : false,
      "id_str" : "2912990047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684272036072439808\/tm_NYSHQ_normal.jpg",
      "id" : 2912990047,
      "verified" : false
    }
  },
  "id" : 672502408585461760,
  "created_at" : "2015-12-03 19:47:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AAAARG.ORG",
      "screen_name" : "aaaarg",
      "indices" : [ 3, 10 ],
      "id_str" : "26307941",
      "id" : 26307941
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/aaaarg\/status\/672323295748956160\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/m1KGe3Y3YM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVSSeajXIAAAiJB.jpg",
      "id_str" : "672323295606415360",
      "id" : 672323295606415360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVSSeajXIAAAiJB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 740,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 740,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 740,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/m1KGe3Y3YM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672480955211321344",
  "text" : "RT @aaaarg: via Crunchy Continental Memes https:\/\/t.co\/m1KGe3Y3YM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/aaaarg\/status\/672323295748956160\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/m1KGe3Y3YM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVSSeajXIAAAiJB.jpg",
        "id_str" : "672323295606415360",
        "id" : 672323295606415360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVSSeajXIAAAiJB.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/m1KGe3Y3YM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672323295748956160",
    "text" : "via Crunchy Continental Memes https:\/\/t.co\/m1KGe3Y3YM",
    "id" : 672323295748956160,
    "created_at" : "2015-12-03 07:55:39 +0000",
    "user" : {
      "name" : "AAAARG.ORG",
      "screen_name" : "aaaarg",
      "protected" : false,
      "id_str" : "26307941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460785029392515072\/20oeyJsG_normal.jpeg",
      "id" : 26307941,
      "verified" : false
    }
  },
  "id" : 672480955211321344,
  "created_at" : "2015-12-03 18:22:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Conniff",
      "screen_name" : "FrankConniff",
      "indices" : [ 3, 16 ],
      "id_str" : "34556109",
      "id" : 34556109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672201451830030336",
  "text" : "RT @FrankConniff: Everybody please show some respect and don't comment on today's mass shooting until tomorrow's mass shooting.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672193941748514816",
    "text" : "Everybody please show some respect and don't comment on today's mass shooting until tomorrow's mass shooting.",
    "id" : 672193941748514816,
    "created_at" : "2015-12-02 23:21:39 +0000",
    "user" : {
      "name" : "Frank Conniff",
      "screen_name" : "FrankConniff",
      "protected" : false,
      "id_str" : "34556109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661920537459990528\/qoOh7YAz_normal.jpg",
      "id" : 34556109,
      "verified" : false
    }
  },
  "id" : 672201451830030336,
  "created_at" : "2015-12-02 23:51:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]