Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taco Bell",
      "screen_name" : "tacobell",
      "indices" : [ 93, 102 ],
      "id_str" : "7831092",
      "id" : 7831092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "google",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/rALB9llb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=cdgQpa1pUUE",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185486653287174146",
  "text" : "Let it be known foreverforward that AUTOMATIC Vehicle Drive Destination No. 000000000001 was @TacoBell #google http:\/\/t.co\/rALB9llb",
  "id" : 185486653287174146,
  "created_at" : "2012-03-29 22:00:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 4, 20 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/ovmQMadW",
      "expanded_url" : "http:\/\/www.openculture.com\/2012\/03\/female_noir_director_ida_lupinos_ithe_hitch-hikeri_free_online.html",
      "display_url" : "openculture.com\/2012\/03\/female\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184818769514856448",
  "text" : "TV? @angelinegragzin http:\/\/t.co\/ovmQMadW",
  "id" : 184818769514856448,
  "created_at" : "2012-03-28 01:46:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIMESCANNER",
      "screen_name" : "timescanner",
      "indices" : [ 3, 15 ],
      "id_str" : "32769498",
      "id" : 32769498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184814977566261248",
  "text" : "RT @timescanner: DOUBLE ENTENDRE IS A VERBAL SCHROEDINGER'S CAT. IS MY STATEMENT SUGGESTIVE OR INNOCENT? YOUR RESPONSE DECIDES.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "184812871786565632",
    "text" : "DOUBLE ENTENDRE IS A VERBAL SCHROEDINGER'S CAT. IS MY STATEMENT SUGGESTIVE OR INNOCENT? YOUR RESPONSE DECIDES.",
    "id" : 184812871786565632,
    "created_at" : "2012-03-28 01:23:16 +0000",
    "user" : {
      "name" : "TIMESCANNER",
      "screen_name" : "timescanner",
      "protected" : false,
      "id_str" : "32769498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000791283829\/cab80ae84c0d5f60d2f8eb4148bc382f_normal.png",
      "id" : 32769498,
      "verified" : false
    }
  },
  "id" : 184814977566261248,
  "created_at" : "2012-03-28 01:31:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "html",
      "indices" : [ 52, 57 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184774359930507264",
  "text" : "to me, events are a nouns, and views are are verbs. #html #nodejs",
  "id" : 184774359930507264,
  "created_at" : "2012-03-27 22:50:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John D. Cook",
      "screen_name" : "JohnDCook",
      "indices" : [ 103, 113 ],
      "id_str" : "17522755",
      "id" : 17522755
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184737969943482368",
  "text" : "correction: I'm going to follow most of the these computer \/ science \/ math tip accounts on twitter by @johnDCook",
  "id" : 184737969943482368,
  "created_at" : "2012-03-27 20:25:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184736756896235521",
  "text" : "Couldn't type 'k' for a minute. Sent me back to the early days when I had to keep an apostrophe on the clipboard.",
  "id" : 184736756896235521,
  "created_at" : "2012-03-27 20:20:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 3, 16 ],
      "id_str" : "814304",
      "id" : 814304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184182683239333888",
  "text" : "RT @arielwaldman: Science is gross:\"[a neutron star's] density is ~equivalent 2 the mass of the entire human population compressed 2 the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "184181295000203264",
    "text" : "Science is gross:\"[a neutron star's] density is ~equivalent 2 the mass of the entire human population compressed 2 the size of a sugar cube\"",
    "id" : 184181295000203264,
    "created_at" : "2012-03-26 07:33:37 +0000",
    "user" : {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "protected" : false,
      "id_str" : "814304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2530407461\/xujyyx9bdf3wi65o5a60_normal.jpeg",
      "id" : 814304,
      "verified" : false
    }
  },
  "id" : 184182683239333888,
  "created_at" : "2012-03-26 07:39:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EARL",
      "screen_name" : "earlxsweat",
      "indices" : [ 3, 14 ],
      "id_str" : "486955518",
      "id" : 486955518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184180490440425473",
  "text" : "RT @earlxsweat: Having a good girlfriend is tight as fuck.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "184171258022342657",
    "text" : "Having a good girlfriend is tight as fuck.",
    "id" : 184171258022342657,
    "created_at" : "2012-03-26 06:53:44 +0000",
    "user" : {
      "name" : "EARL",
      "screen_name" : "earlxsweat",
      "protected" : false,
      "id_str" : "486955518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576208223880888320\/yPthJ9d6_normal.jpeg",
      "id" : 486955518,
      "verified" : true
    }
  },
  "id" : 184180490440425473,
  "created_at" : "2012-03-26 07:30:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "javascript",
      "indices" : [ 115, 126 ]
    }, {
      "text" : "jquery",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183986511203676162",
  "text" : "Hey guy your function \/ widget \/ module won't take null for an argument value. Come on. I'm not THAT lazy. #nodejs #javascript #jquery",
  "id" : 183986511203676162,
  "created_at" : "2012-03-25 18:39:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PaidContent",
      "screen_name" : "PaidContent",
      "indices" : [ 18, 30 ],
      "id_str" : "2191049840",
      "id" : 2191049840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/OB1QUQ6y",
      "expanded_url" : "http:\/\/cnt.to\/q3g",
      "display_url" : "cnt.to\/q3g"
    } ]
  },
  "geo" : { },
  "id_str" : "182514356179836928",
  "text" : "@simpleavchicago \u201C@paidContent: Back To The Future: YouTube Launches Live Comedy Talk Show http:\/\/t.co\/OB1QUQ6y\u201D",
  "id" : 182514356179836928,
  "created_at" : "2012-03-21 17:09:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "indices" : [ 3, 10 ],
      "id_str" : "11388132",
      "id" : 11388132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/aAc0sHd7",
      "expanded_url" : "http:\/\/www.followthemoney.org\/press\/ReportView.phtml?r=484",
      "display_url" : "followthemoney.org\/press\/ReportVi\u2026"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/IjzgVm5X",
      "expanded_url" : "http:\/\/rootstrikers.org",
      "display_url" : "rootstrikers.org"
    } ]
  },
  "geo" : { },
  "id_str" : "182512759638982656",
  "text" : "RT @lessig: How $$ killed Community Broadband in NC: http:\/\/t.co\/aAc0sHd7 We're organizing on this. Join us: http:\/\/t.co\/IjzgVm5X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/aAc0sHd7",
        "expanded_url" : "http:\/\/www.followthemoney.org\/press\/ReportView.phtml?r=484",
        "display_url" : "followthemoney.org\/press\/ReportVi\u2026"
      }, {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/IjzgVm5X",
        "expanded_url" : "http:\/\/rootstrikers.org",
        "display_url" : "rootstrikers.org"
      } ]
    },
    "geo" : { },
    "id_str" : "182478759725760513",
    "text" : "How $$ killed Community Broadband in NC: http:\/\/t.co\/aAc0sHd7 We're organizing on this. Join us: http:\/\/t.co\/IjzgVm5X",
    "id" : 182478759725760513,
    "created_at" : "2012-03-21 14:48:21 +0000",
    "user" : {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "protected" : false,
      "id_str" : "11388132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689571338332327949\/N_fQy389_normal.jpg",
      "id" : 11388132,
      "verified" : true
    }
  },
  "id" : 182512759638982656,
  "created_at" : "2012-03-21 17:03:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181483202928586752",
  "text" : "RT @hotdogsladies: \"Questions have been raised\u2026\" declares the NY Times.\n\nBecause, hey, why let crooked politicians monopolize the beige  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/birdhouseapp.com\" rel=\"nofollow\"\u003EBirdhouse\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181478452334039041",
    "text" : "\"Questions have been raised\u2026\" declares the NY Times.\n\nBecause, hey, why let crooked politicians monopolize the beige passive construction?",
    "id" : 181478452334039041,
    "created_at" : "2012-03-18 20:33:29 +0000",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548615975268921345\/15phrwGy_normal.jpeg",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 181483202928586752,
  "created_at" : "2012-03-18 20:52:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/GfEgo1Ea",
      "expanded_url" : "http:\/\/i.imgur.com\/xPBkH.png",
      "display_url" : "i.imgur.com\/xPBkH.png"
    } ]
  },
  "geo" : { },
  "id_str" : "180032227650965504",
  "text" : "I'm building browser tests for fonts. \n# Dynamic templates # legibility\nhttp:\/\/t.co\/GfEgo1Ea",
  "id" : 180032227650965504,
  "created_at" : "2012-03-14 20:46:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equalAccess",
      "indices" : [ 92, 104 ]
    }, {
      "text" : "freeIntermet",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179643392106569729",
  "text" : "Fuck you AT&amp;T your Los Angeles skid row area internet does not deliver my http packets. #equalAccess #freeIntermet",
  "id" : 179643392106569729,
  "created_at" : "2012-03-13 19:01:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/stdWGaps",
      "expanded_url" : "http:\/\/i.imgur.com\/u7V9L.png",
      "display_url" : "i.imgur.com\/u7V9L.png"
    } ]
  },
  "geo" : { },
  "id_str" : "178284580086886400",
  "text" : "if u know what this looks like then we could be friends http:\/\/t.co\/stdWGaps",
  "id" : 178284580086886400,
  "created_at" : "2012-03-10 01:02:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177187698644234240",
  "text" : "I accidentally read a Huff Paste article, author writes \"a common component in homemade bombs\". Who knew stupidity makes propaganda?",
  "id" : 177187698644234240,
  "created_at" : "2012-03-07 00:23:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSS",
      "indices" : [ 55, 59 ]
    }, {
      "text" : "DNS",
      "indices" : [ 78, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177184972237570048",
  "text" : "It is agreed, then, get rid of the fuckering prefixes. #CSS Also, nix the TLD #DNS",
  "id" : 177184972237570048,
  "created_at" : "2012-03-07 00:12:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jsmag",
      "screen_name" : "jsmag",
      "indices" : [ 17, 23 ],
      "id_str" : "18047173",
      "id" : 18047173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "html",
      "indices" : [ 119, 124 ]
    }, {
      "text" : "javascript",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177140907290787841",
  "text" : "do you not blush @jsmag to publish a javascript magazine as .pfd instead of the true universal doc format called HTML? #html #javascript",
  "id" : 177140907290787841,
  "created_at" : "2012-03-06 21:17:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peteris Krumins",
      "screen_name" : "pkrumins",
      "indices" : [ 33, 42 ],
      "id_str" : "2134501",
      "id" : 2134501
    }, {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 102, 113 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/JRkYD28Y",
      "expanded_url" : "http:\/\/vimeo.com\/36579366",
      "display_url" : "vimeo.com\/36579366"
    } ]
  },
  "geo" : { },
  "id_str" : "176085091175505920",
  "text" : "all kinds of inspiration here RT @pkrumins: This talk is amazing - http:\/\/t.co\/JRkYD28Y. Bret Victor (@worrydream): Inventing on Principle.",
  "id" : 176085091175505920,
  "created_at" : "2012-03-03 23:22:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yipyip",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "random",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175456646473064448",
  "text" : "Chaos is Oneness #yipyip #random",
  "id" : 175456646473064448,
  "created_at" : "2012-03-02 05:44:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]