Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ordinance",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197012476263546880",
  "text" : "In the equation 1. do __some thing__ ,\n2. ??? ,\n3. PROFIT ; the variable ??? == 'Raise an Army' #ordinance",
  "id" : 197012476263546880,
  "created_at" : "2012-04-30 17:20:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/iWqz2Ov4",
      "expanded_url" : "http:\/\/www.pixartouchbook.com\/blog\/2011\/5\/15\/pixar-story-rules-one-version.html",
      "display_url" : "pixartouchbook.com\/blog\/2011\/5\/15\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "196742799402602496",
  "in_reply_to_user_id" : 58809542,
  "text" : "@angelinegragzin story helpers http:\/\/t.co\/iWqz2Ov4",
  "id" : 196742799402602496,
  "created_at" : "2012-04-29 23:28:33 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195595883620999168",
  "text" : "proxy 4 profit || bust",
  "id" : 195595883620999168,
  "created_at" : "2012-04-26 19:31:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 19, 26 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/49Bhr3NO",
      "expanded_url" : "http:\/\/nationalheadquarters.org",
      "display_url" : "nationalheadquarters.org"
    } ]
  },
  "in_reply_to_status_id_str" : "195584137690750976",
  "geo" : { },
  "id_str" : "195585177479692288",
  "in_reply_to_user_id" : 14690653,
  "text" : "for your pleasure, @regisl, one of a variation of our network national headquarters dot org logo http:\/\/t.co\/49Bhr3NO",
  "id" : 195585177479692288,
  "in_reply_to_status_id" : 195584137690750976,
  "created_at" : "2012-04-26 18:48:34 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195584098427871233",
  "text" : "Listen long, and prosper.",
  "id" : 195584098427871233,
  "created_at" : "2012-04-26 18:44:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195311899594858499",
  "text" : "This line sums up American Journalism & Critical Writing: \"In fact, of course, Unicorns, and here's why (I'm telling you).\"",
  "id" : 195311899594858499,
  "created_at" : "2012-04-26 00:42:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 67, 75 ],
      "id_str" : "807095",
      "id" : 807095
    }, {
      "name" : "David Brooks",
      "screen_name" : "DavidBrooksNYT",
      "indices" : [ 76, 91 ],
      "id_str" : "342672909",
      "id" : 342672909
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "catPuke",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "rhetoric",
      "indices" : [ 101, 110 ]
    }, {
      "text" : "lazy",
      "indices" : [ 111, 116 ]
    }, {
      "text" : "righteousEpidemic",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195310835898400768",
  "text" : "\"In fact, he argues, [a thing not a fact]\" ROTF Rolling my eyes at @nytimes @davidbrooksnyt #catPuke #rhetoric #lazy #righteousEpidemic",
  "id" : 195310835898400768,
  "created_at" : "2012-04-26 00:38:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "duh",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195306288589185024",
  "text" : "A: Because the crop and the weedkiller are 2 sources of renewable revenue. #duh A common case of 'not the cure, the treatment' economics.",
  "id" : 195306288589185024,
  "created_at" : "2012-04-26 00:20:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195305414617874433",
  "text" : "Q: Why don't DOW & Monsanto genetically modify the weeds to be weaker, instead of modifying the crop to withstand the harsh weed killers?",
  "id" : 195305414617874433,
  "created_at" : "2012-04-26 00:16:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195304435793145856",
  "text" : "You are not a farmer if you need Agent Orange Lite to protect your robocrops from weeds. You are a parasite on humanity. #fail",
  "id" : 195304435793145856,
  "created_at" : "2012-04-26 00:13:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 3, 12 ],
      "id_str" : "141834186",
      "id" : 141834186
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DowChemical",
      "indices" : [ 35, 47 ]
    }, {
      "text" : "GMO",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/qzeOn1sl",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/04\/26\/business\/energy-environment\/dow-weed-killer-runs-into-opposition.html",
      "display_url" : "nytimes.com\/2012\/04\/26\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195303167620161536",
  "text" : "RT @FearDept: We intend to approve #DowChemical's application to market a derivative of Agent Orange for use on corn crops:  http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DowChemical",
        "indices" : [ 21, 33 ]
      }, {
        "text" : "GMO",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/qzeOn1sl",
        "expanded_url" : "http:\/\/www.nytimes.com\/2012\/04\/26\/business\/energy-environment\/dow-weed-killer-runs-into-opposition.html",
        "display_url" : "nytimes.com\/2012\/04\/26\/bus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "195292066874523648",
    "text" : "We intend to approve #DowChemical's application to market a derivative of Agent Orange for use on corn crops:  http:\/\/t.co\/qzeOn1sl #GMO",
    "id" : 195292066874523648,
    "created_at" : "2012-04-25 23:23:51 +0000",
    "user" : {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "protected" : false,
      "id_str" : "141834186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453113104939761664\/9ZqHHvvA_normal.png",
      "id" : 141834186,
      "verified" : false
    }
  },
  "id" : 195303167620161536,
  "created_at" : "2012-04-26 00:07:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "indices" : [ 0, 6 ],
      "id_str" : "202571491",
      "id" : 202571491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195038316209516544",
  "geo" : { },
  "id_str" : "195041670952255488",
  "in_reply_to_user_id" : 202571491,
  "text" : "@idiot what about stylus, sass, or less?",
  "id" : 195041670952255488,
  "in_reply_to_status_id" : 195038316209516544,
  "created_at" : "2012-04-25 06:48:52 +0000",
  "in_reply_to_screen_name" : "idiot",
  "in_reply_to_user_id_str" : "202571491",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 48, 64 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195037286260412416",
  "text" : "you don't want the Johnny talks taint in public @angelinegragzin but he coming anyways look out",
  "id" : 195037286260412416,
  "created_at" : "2012-04-25 06:31:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "indices" : [ 0, 6 ],
      "id_str" : "202571491",
      "id" : 202571491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195034918957490176",
  "geo" : { },
  "id_str" : "195036846043049984",
  "in_reply_to_user_id" : 202571491,
  "text" : "@idiot eg. Gaming frameworks, next gen CMSs, consumer level cloud systems.",
  "id" : 195036846043049984,
  "in_reply_to_status_id" : 195034918957490176,
  "created_at" : "2012-04-25 06:29:42 +0000",
  "in_reply_to_screen_name" : "idiot",
  "in_reply_to_user_id_str" : "202571491",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "indices" : [ 117, 123 ],
      "id_str" : "202571491",
      "id" : 202571491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195034918957490176",
  "geo" : { },
  "id_str" : "195036264297271297",
  "in_reply_to_user_id" : 202571491,
  "text" : "my take is that the next level of open software will have heavy front facing component. bootstrap is a meta example. @idiot",
  "id" : 195036264297271297,
  "in_reply_to_status_id" : 195034918957490176,
  "created_at" : "2012-04-25 06:27:23 +0000",
  "in_reply_to_screen_name" : "idiot",
  "in_reply_to_user_id_str" : "202571491",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195034424818139136",
  "text" : "and has been for 2 years *fuggface*",
  "id" : 195034424818139136,
  "created_at" : "2012-04-25 06:20:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195033789917970432",
  "text" : "basically twitter is my poor lousy no good blunted muffhuckin stand-in publisher till my shit is ready.",
  "id" : 195033789917970432,
  "created_at" : "2012-04-25 06:17:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195033393191337984",
  "text" : "CAN'T DELETE TWEET MUST BURN TWEESPHERE",
  "id" : 195033393191337984,
  "created_at" : "2012-04-25 06:15:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195033066366959616",
  "text" : "twitter makes me feel uncool like it was 1992-1999",
  "id" : 195033066366959616,
  "created_at" : "2012-04-25 06:14:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Park",
      "screen_name" : "donpark",
      "indices" : [ 3, 11 ],
      "id_str" : "892821",
      "id" : 892821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193888643604164609",
  "text" : "RT @donpark: Parents needs to teach their kids that it's very rude to point smartphones at strangers unless there is a crime in progress.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "193868929008021504",
    "text" : "Parents needs to teach their kids that it's very rude to point smartphones at strangers unless there is a crime in progress.",
    "id" : 193868929008021504,
    "created_at" : "2012-04-22 01:08:49 +0000",
    "user" : {
      "name" : "Don Park",
      "screen_name" : "donpark",
      "protected" : false,
      "id_str" : "892821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514554580210679809\/D4j5vRJC_normal.jpeg",
      "id" : 892821,
      "verified" : false
    }
  },
  "id" : 193888643604164609,
  "created_at" : "2012-04-22 02:27:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "indices" : [ 4, 10 ],
      "id_str" : "202571491",
      "id" : 202571491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193785600443293697",
  "geo" : { },
  "id_str" : "193785916182106112",
  "in_reply_to_user_id" : 202571491,
  "text" : "But @idiot, if the word is unnecessary to begin with, why do you care that they shorten it?",
  "id" : 193785916182106112,
  "in_reply_to_status_id" : 193785600443293697,
  "created_at" : "2012-04-21 19:38:57 +0000",
  "in_reply_to_screen_name" : "idiot",
  "in_reply_to_user_id_str" : "202571491",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenn R",
      "screen_name" : "heyitskenn",
      "indices" : [ 44, 55 ],
      "id_str" : "310502222",
      "id" : 310502222
    }, {
      "name" : "Austin Cross",
      "screen_name" : "AustinCross",
      "indices" : [ 56, 68 ],
      "id_str" : "280153685",
      "id" : 280153685
    }, {
      "name" : "Kirsten B.",
      "screen_name" : "sojournalista",
      "indices" : [ 69, 83 ],
      "id_str" : "26404914",
      "id" : 26404914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193774605125693441",
  "geo" : { },
  "id_str" : "193784896328712192",
  "in_reply_to_user_id" : 634703,
  "text" : "blind people need eye protection, too ^ . ^ @heyitskenn @austincross @sojournalista",
  "id" : 193784896328712192,
  "in_reply_to_status_id" : 193774605125693441,
  "created_at" : "2012-04-21 19:34:54 +0000",
  "in_reply_to_screen_name" : "k3nnr",
  "in_reply_to_user_id_str" : "634703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 14, 26 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193474339960668160",
  "text" : "RT @substack: @astromanies and it completely eliminates tactical voting while very occasionally electing Vermin Supreme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 0, 12 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "193235310270889984",
    "geo" : { },
    "id_str" : "193257723633209344",
    "in_reply_to_user_id" : 46961216,
    "text" : "@astromanies and it completely eliminates tactical voting while very occasionally electing Vermin Supreme",
    "id" : 193257723633209344,
    "in_reply_to_status_id" : 193235310270889984,
    "created_at" : "2012-04-20 08:40:06 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 193474339960668160,
  "created_at" : "2012-04-20 23:00:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 119, 128 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193210870468313088",
  "geo" : { },
  "id_str" : "193235310270889984",
  "in_reply_to_user_id" : 125027291,
  "text" : "I love it! Imagine the effects it would have on who runs, on campaigning, and the on way voters coalesce into parties. @substack",
  "id" : 193235310270889984,
  "in_reply_to_status_id" : 193210870468313088,
  "created_at" : "2012-04-20 07:11:02 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DHS",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/6yIBXB5y",
      "expanded_url" : "http:\/\/www.dhs.gov\/files\/programs\/gc_1218480185439.shtm#6",
      "display_url" : "dhs.gov\/files\/programs\u2026"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/OoTjU19R",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2012\/04\/homeland-securitys-pre-crime-screening-will-never-work\/255971\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193132190895325184",
  "text" : "#DHS's \"Pre-Crime Detection\" filed under \"Human Factors\/Behavioral Sciences Projects\" http:\/\/t.co\/6yIBXB5y see also: http:\/\/t.co\/OoTjU19R",
  "id" : 193132190895325184,
  "created_at" : "2012-04-20 00:21:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "justWorked",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/vq7fqwKY",
      "expanded_url" : "http:\/\/sveinbjorn.org\/platypus",
      "display_url" : "sveinbjorn.org\/platypus"
    } ]
  },
  "geo" : { },
  "id_str" : "193127722564857856",
  "text" : "Searched all day how to make apps for Macs so I could distribute #nodejs scripts. Found the platypus: http:\/\/t.co\/vq7fqwKY #justWorked",
  "id" : 193127722564857856,
  "created_at" : "2012-04-20 00:03:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newt Gingrich",
      "screen_name" : "Newt_Gingrich",
      "indices" : [ 40, 54 ],
      "id_str" : "17463211",
      "id" : 17463211
    }, {
      "name" : "do u even drone Bro",
      "screen_name" : "korch",
      "indices" : [ 76, 82 ],
      "id_str" : "18758312",
      "id" : 18758312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouroboros",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193101284298067968",
  "text" : "It's enough to make somebody want to do @Newt_Gingrich harm! #ouroboros cc\/ @korch",
  "id" : 193101284298067968,
  "created_at" : "2012-04-19 22:18:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193100382451408896",
  "text" : "Gonna disrupt the pupuseria market now.",
  "id" : 193100382451408896,
  "created_at" : "2012-04-19 22:14:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blingbling",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193097178141569024",
  "text" : "Been an entrepreneur since my early days. Then I learned to code. Now I'm an entrepreneur who can code. #blingbling",
  "id" : 193097178141569024,
  "created_at" : "2012-04-19 22:02:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/J34flyxn",
      "expanded_url" : "http:\/\/blogoscoped.com\/archive\/2005-08-24-n14.html",
      "display_url" : "blogoscoped.com\/archive\/2005-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192416723771719680",
  "text" : "I am certainly a lazy programmer, and I will try to be dumber. Should be easy. http:\/\/t.co\/J34flyxn",
  "id" : 192416723771719680,
  "created_at" : "2012-04-18 00:58:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192403682179039234",
  "text" : "Some people used to be called computers. The were the first humans computers replaced.",
  "id" : 192403682179039234,
  "created_at" : "2012-04-18 00:06:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DRAKE THOUGHTS",
      "screen_name" : "DRAKE_THOUGHTS",
      "indices" : [ 77, 92 ],
      "id_str" : "478342262",
      "id" : 478342262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191433482990391297",
  "geo" : { },
  "id_str" : "192006212424966144",
  "in_reply_to_user_id" : 478342262,
  "text" : "May I suggest these replacements: '[the] Random'; or perhaps '[Utter] Unity' @DRAKE_THOUGHTS",
  "id" : 192006212424966144,
  "in_reply_to_status_id" : 191433482990391297,
  "created_at" : "2012-04-16 21:47:03 +0000",
  "in_reply_to_screen_name" : "DRAKE_THOUGHTS",
  "in_reply_to_user_id_str" : "478342262",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "indices" : [ 41, 47 ],
      "id_str" : "202571491",
      "id" : 202571491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191996813170057219",
  "geo" : { },
  "id_str" : "192000176125259777",
  "in_reply_to_user_id" : 202571491,
  "text" : "document.querySelectorAll('.className'), @idiot",
  "id" : 192000176125259777,
  "in_reply_to_status_id" : 191996813170057219,
  "created_at" : "2012-04-16 21:23:03 +0000",
  "in_reply_to_screen_name" : "idiot",
  "in_reply_to_user_id_str" : "202571491",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190641280173350912",
  "text" : "I'm looking for statistics. Are 'bugs' more often in the code or the design?",
  "id" : 190641280173350912,
  "created_at" : "2012-04-13 03:23:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190637012427091968",
  "text" : "Twitter is the last great MSM company.",
  "id" : 190637012427091968,
  "created_at" : "2012-04-13 03:06:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/yFFNptCY",
      "expanded_url" : "http:\/\/thelistserve.com\/",
      "display_url" : "thelistserve.com"
    } ]
  },
  "geo" : { },
  "id_str" : "190161833099919360",
  "text" : "hey @`you sign up for this PR lottery http:\/\/t.co\/yFFNptCY",
  "id" : 190161833099919360,
  "created_at" : "2012-04-11 19:38:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189776146383122432",
  "text" : "sittin around gettin some sun, thinkin about mutual funds",
  "id" : 189776146383122432,
  "created_at" : "2012-04-10 18:05:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pomax",
      "screen_name" : "TheRealPomax",
      "indices" : [ 40, 53 ],
      "id_str" : "96111570",
      "id" : 96111570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189149644985606144",
  "geo" : { },
  "id_str" : "189154572709801985",
  "in_reply_to_user_id" : 96111570,
  "text" : "my thought is this is a very good idea. @TheRealPomax",
  "id" : 189154572709801985,
  "in_reply_to_status_id" : 189149644985606144,
  "created_at" : "2012-04-09 00:55:39 +0000",
  "in_reply_to_screen_name" : "TheRealPomax",
  "in_reply_to_user_id_str" : "96111570",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spring",
      "indices" : [ 40, 47 ]
    }, {
      "text" : "sprung",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "bizbuzz",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188666344089190401",
  "text" : "hundred bees sexing up two olive trees. #spring #sprung #bizbuzz",
  "id" : 188666344089190401,
  "created_at" : "2012-04-07 16:35:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE REPUBLICAN DALEK",
      "screen_name" : "RepublicanDalek",
      "indices" : [ 3, 19 ],
      "id_str" : "308900763",
      "id" : 308900763
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DALEKSWIN",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xSVzfQ9w",
      "expanded_url" : "http:\/\/www.republicreport.org\/2012\/lobbying-bpa-chemical\/",
      "display_url" : "republicreport.org\/2012\/lobbying-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "188379443427938304",
  "text" : "RT @RepublicanDalek: WE GET TO KEEP PUTTING BPA IN FOOD PACKAGING! YOUR SPECIES IS ONE STEP CLOSER TO STERILITY. #DALEKSWIN http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DALEKSWIN",
        "indices" : [ 92, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/xSVzfQ9w",
        "expanded_url" : "http:\/\/www.republicreport.org\/2012\/lobbying-bpa-chemical\/",
        "display_url" : "republicreport.org\/2012\/lobbying-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "188378302493360129",
    "text" : "WE GET TO KEEP PUTTING BPA IN FOOD PACKAGING! YOUR SPECIES IS ONE STEP CLOSER TO STERILITY. #DALEKSWIN http:\/\/t.co\/xSVzfQ9w",
    "id" : 188378302493360129,
    "created_at" : "2012-04-06 21:31:01 +0000",
    "user" : {
      "name" : "THE REPUBLICAN DALEK",
      "screen_name" : "RepublicanDalek",
      "protected" : false,
      "id_str" : "308900763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511173133517090816\/19ZoONOP_normal.png",
      "id" : 308900763,
      "verified" : false
    }
  },
  "id" : 188379443427938304,
  "created_at" : "2012-04-06 21:35:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188065528768770051",
  "text" : "feeds gone wild",
  "id" : 188065528768770051,
  "created_at" : "2012-04-06 00:48:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "suckserver",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188038805524197377",
  "text" : "User, why did you delete that tweet which was a response to my own question? Thanks, twitter, for the disappearing reference. #suckserver",
  "id" : 188038805524197377,
  "created_at" : "2012-04-05 23:01:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188036695650877440",
  "text" : "BOWDOWN(with this)\u007B like so ! \u007D",
  "id" : 188036695650877440,
  "created_at" : "2012-04-05 22:53:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]