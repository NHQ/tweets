Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/VIs02K7j",
      "expanded_url" : "http:\/\/redd.it\/kw3fx",
      "display_url" : "redd.it\/kw3fx"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/qaW04vGh",
      "expanded_url" : "http:\/\/redd.it\/ksknp",
      "display_url" : "redd.it\/ksknp"
    } ]
  },
  "geo" : { },
  "id_str" : "119863791298158592",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin have yr many NYC friends send clean clothes to protesters occupying wall street http:\/\/t.co\/VIs02K7j http:\/\/t.co\/qaW04vGh",
  "id" : 119863791298158592,
  "created_at" : "2011-09-30 19:58:49 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/mFnL1ssa",
      "expanded_url" : "http:\/\/imgur.com\/4miTZ",
      "display_url" : "imgur.com\/4miTZ"
    } ]
  },
  "geo" : { },
  "id_str" : "119862370607710209",
  "text" : "Frank Zappa : rockin and rolling || fighting against the man http:\/\/t.co\/mFnL1ssa",
  "id" : 119862370607710209,
  "created_at" : "2011-09-30 19:53:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OccupyWallStreet",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Vp80ohxI",
      "expanded_url" : "http:\/\/redd.it\/kw3fx",
      "display_url" : "redd.it\/kw3fx"
    } ]
  },
  "geo" : { },
  "id_str" : "119860694299582464",
  "text" : "RT @wilw: Hey, #OccupyWallStreet, I am 100% behind you, and I *really* want you to read this, because it's *great* advice: http:\/\/t.co\/V ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OccupyWallStreet",
        "indices" : [ 5, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/Vp80ohxI",
        "expanded_url" : "http:\/\/redd.it\/kw3fx",
        "display_url" : "redd.it\/kw3fx"
      } ]
    },
    "geo" : { },
    "id_str" : "119694121584701440",
    "text" : "Hey, #OccupyWallStreet, I am 100% behind you, and I *really* want you to read this, because it's *great* advice: http:\/\/t.co\/Vp80ohxI",
    "id" : 119694121584701440,
    "created_at" : "2011-09-30 08:44:37 +0000",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660891140418236416\/7zeCwT9K_normal.png",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 119860694299582464,
  "created_at" : "2011-09-30 19:46:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea Verou",
      "screen_name" : "LeaVerou",
      "indices" : [ 3, 12 ],
      "id_str" : "22199970",
      "id" : 22199970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119860559205244928",
  "text" : "RT @LeaVerou: Oh man, I love being a woman in tech!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.5211064167, 13.40651418 ]
    },
    "id_str" : "119848421187264512",
    "text" : "Oh man, I love being a woman in tech!!",
    "id" : 119848421187264512,
    "created_at" : "2011-09-30 18:57:44 +0000",
    "user" : {
      "name" : "Lea Verou",
      "screen_name" : "LeaVerou",
      "protected" : false,
      "id_str" : "22199970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584963092120899586\/TxkxQ7Y5_normal.png",
      "id" : 22199970,
      "verified" : false
    }
  },
  "id" : 119860559205244928,
  "created_at" : "2011-09-30 19:45:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/TWeJlrnv",
      "expanded_url" : "http:\/\/angusj.com\/delphi\/clipper.php",
      "display_url" : "angusj.com\/delphi\/clipper\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "119127524621037569",
  "text" : "? is there a #nodejs binding for http:\/\/t.co\/TWeJlrnv",
  "id" : 119127524621037569,
  "created_at" : "2011-09-28 19:13:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 3, 14 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118858720565407744",
  "text" : "RT @uptownherd: ALL MATTER IS EXPRESSIONS OF WAVEFORMS IS THAT SO HARD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117378535789826049",
    "text" : "ALL MATTER IS EXPRESSIONS OF WAVEFORMS IS THAT SO HARD",
    "id" : 117378535789826049,
    "created_at" : "2011-09-23 23:23:18 +0000",
    "user" : {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "protected" : false,
      "id_str" : "122112121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518645860863709184\/iHz-222r_normal.jpeg",
      "id" : 122112121,
      "verified" : false
    }
  },
  "id" : 118858720565407744,
  "created_at" : "2011-09-28 01:25:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 0, 7 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118539757239271424",
  "in_reply_to_user_id" : 20536157,
  "text" : "@google do we really not know the difference between \"by\" and \"about\"?",
  "id" : 118539757239271424,
  "created_at" : "2011-09-27 04:17:35 +0000",
  "in_reply_to_screen_name" : "google",
  "in_reply_to_user_id_str" : "20536157",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Revolution TV",
      "screen_name" : "GlobalRevLive",
      "indices" : [ 3, 17 ],
      "id_str" : "377837520",
      "id" : 377837520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OccupyWallStreet",
      "indices" : [ 31, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118507101504012289",
  "text" : "RT @GlobalRevLive: For 10 days #OccupyWallStreet streamed 1 mil. videos to 250,000 people\/14.4 mil. viewer minutes. What media blackout? :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OccupyWallStreet",
        "indices" : [ 12, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118500633534939136",
    "text" : "For 10 days #OccupyWallStreet streamed 1 mil. videos to 250,000 people\/14.4 mil. viewer minutes. What media blackout? :-)",
    "id" : 118500633534939136,
    "created_at" : "2011-09-27 01:42:07 +0000",
    "user" : {
      "name" : "Global Revolution TV",
      "screen_name" : "GlobalRevLive",
      "protected" : false,
      "id_str" : "377837520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1777375214\/299131_204937729571301_204900636241677_543343_381562625_n_normal.jpg",
      "id" : 377837520,
      "verified" : false
    }
  },
  "id" : 118507101504012289,
  "created_at" : "2011-09-27 02:07:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phoebe Gillim",
      "screen_name" : "usdayofrage",
      "indices" : [ 3, 15 ],
      "id_str" : "4377025355",
      "id" : 4377025355
    }, {
      "name" : "Exceedingly Unseelie",
      "screen_name" : "der_bluthund",
      "indices" : [ 139, 140 ],
      "id_str" : "137480382",
      "id" : 137480382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupywallstreet",
      "indices" : [ 53, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MleFfdKq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Sdak0ojF_go&feature=channel_video_title",
      "display_url" : "youtube.com\/watch?v=Sdak0o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "118507049389797377",
  "text" : "RT @USDayofRage: AlJazeera coverage of USDayofRage & #occupywallstreet Where's mainstream media?[corporate censorship] http:\/\/t.co\/MleFf ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Exceedingly Unseelie",
        "screen_name" : "der_bluthund",
        "indices" : [ 127, 140 ],
        "id_str" : "137480382",
        "id" : 137480382
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupywallstreet",
        "indices" : [ 36, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/MleFfdKq",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Sdak0ojF_go&feature=channel_video_title",
        "display_url" : "youtube.com\/watch?v=Sdak0o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "118502863830913024",
    "text" : "AlJazeera coverage of USDayofRage & #occupywallstreet Where's mainstream media?[corporate censorship] http:\/\/t.co\/MleFfdKq via @der_bluthund",
    "id" : 118502863830913024,
    "created_at" : "2011-09-27 01:50:59 +0000",
    "user" : {
      "name" : "The Great Unwashed",
      "screen_name" : "_GreatUnwashed",
      "protected" : false,
      "id_str" : "263466153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677200566724853760\/sMleis2S_normal.jpg",
      "id" : 263466153,
      "verified" : false
    }
  },
  "id" : 118507049389797377,
  "created_at" : "2011-09-27 02:07:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twi\u0334\u031B\u031Bg \u0322\u031B\u0335Har\u0319\u0320\u0353per",
      "screen_name" : "twigharper",
      "indices" : [ 3, 14 ],
      "id_str" : "176528202",
      "id" : 176528202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OCCUPYREALITY",
      "indices" : [ 16, 30 ]
    }, {
      "text" : "OCULARPIE",
      "indices" : [ 31, 41 ]
    }, {
      "text" : "OCTIPI",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506869273804800",
  "text" : "RT @twigharper: #OCCUPYREALITY #OCULARPIE #OCTIPI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OCCUPYREALITY",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "OCULARPIE",
        "indices" : [ 15, 25 ]
      }, {
        "text" : "OCTIPI",
        "indices" : [ 26, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118488699536281600",
    "text" : "#OCCUPYREALITY #OCULARPIE #OCTIPI",
    "id" : 118488699536281600,
    "created_at" : "2011-09-27 00:54:42 +0000",
    "user" : {
      "name" : "Twi\u0334\u031B\u031Bg \u0322\u031B\u0335Har\u0319\u0320\u0353per",
      "screen_name" : "twigharper",
      "protected" : false,
      "id_str" : "176528202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565169973467688960\/YRxf2Ecs_normal.jpeg",
      "id" : 176528202,
      "verified" : false
    }
  },
  "id" : 118506869273804800,
  "created_at" : "2011-09-27 02:06:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "indices" : [ 3, 19 ],
      "id_str" : "12585462",
      "id" : 12585462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506858242772992",
  "text" : "RT @StefanoBlackest: @hymnhummer don't be dramatic. You're living in a fantasy if you think the end of mass big-media reliance is nigh.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118053178515271681",
    "geo" : { },
    "id_str" : "118085359606312960",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer don't be dramatic. You're living in a fantasy if you think the end of mass big-media reliance is nigh. Like it or not.",
    "id" : 118085359606312960,
    "in_reply_to_status_id" : 118053178515271681,
    "created_at" : "2011-09-25 22:11:58 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "protected" : false,
      "id_str" : "12585462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686700608104099841\/FU5sZEYI_normal.jpg",
      "id" : 12585462,
      "verified" : false
    }
  },
  "id" : 118506858242772992,
  "created_at" : "2011-09-27 02:06:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "indices" : [ 3, 19 ],
      "id_str" : "12585462",
      "id" : 12585462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506858251161600",
  "text" : "RT @StefanoBlackest: @hymnhummer dude, you sound like a fucking idiot. Flowery bullshit like that is why no one takes real radical polit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118490925449228290",
    "geo" : { },
    "id_str" : "118501132413833216",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer dude, you sound like a fucking idiot. Flowery bullshit like that is why no one takes real radical politics seriously.",
    "id" : 118501132413833216,
    "in_reply_to_status_id" : 118490925449228290,
    "created_at" : "2011-09-27 01:44:06 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "protected" : false,
      "id_str" : "12585462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686700608104099841\/FU5sZEYI_normal.jpg",
      "id" : 12585462,
      "verified" : false
    }
  },
  "id" : 118506858251161600,
  "created_at" : "2011-09-27 02:06:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "indices" : [ 3, 19 ],
      "id_str" : "12585462",
      "id" : 12585462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506858255368193",
  "text" : "RT @StefanoBlackest: @hymnhummer You're talking to someone who was on radical politics back before the internet made it easy. Know yr li ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118490925449228290",
    "geo" : { },
    "id_str" : "118501623524896768",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer You're talking to someone who was on radical politics back before the internet made it easy. Know yr listener before you speak.",
    "id" : 118501623524896768,
    "in_reply_to_status_id" : 118490925449228290,
    "created_at" : "2011-09-27 01:46:03 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "protected" : false,
      "id_str" : "12585462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686700608104099841\/FU5sZEYI_normal.jpg",
      "id" : 12585462,
      "verified" : false
    }
  },
  "id" : 118506858255368193,
  "created_at" : "2011-09-27 02:06:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506860016963584",
  "text" : "RT @JoeTheMailman: @hymnhummer LMAO...........you are funny!...he - he - he - he... I knew you get a real kick out of Bob Hope!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118063374213988352",
    "geo" : { },
    "id_str" : "118065672847765504",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer LMAO...........you are funny!...he - he - he - he... I knew you get a real kick out of Bob Hope!",
    "id" : 118065672847765504,
    "in_reply_to_status_id" : 118063374213988352,
    "created_at" : "2011-09-25 20:53:44 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506860016963584,
  "created_at" : "2011-09-27 02:06:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506860121821185",
  "text" : "RT @JoeTheMailman: @hymnhummer Bob Hope is so funny. However, there is a whole lot of truth in what he is suggesting!.....LMAO.....he -  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118063374213988352",
    "geo" : { },
    "id_str" : "118066065073901569",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer Bob Hope is so funny. However, there is a whole lot of truth in what he is suggesting!.....LMAO.....he - he - he",
    "id" : 118066065073901569,
    "in_reply_to_status_id" : 118063374213988352,
    "created_at" : "2011-09-25 20:55:18 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506860121821185,
  "created_at" : "2011-09-27 02:06:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/P87ghgiD",
      "expanded_url" : "http:\/\/bit.ly\/q9TTVW",
      "display_url" : "bit.ly\/q9TTVW"
    } ]
  },
  "geo" : { },
  "id_str" : "118506628701102080",
  "text" : "RT @JoeTheMailman: @hymnhummer Our \"PRESIDENT\" accuses Black Americans as LAZY WHINERS~wearing bedroom slippers~ Is OBAMA Right?~ http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/P87ghgiD",
        "expanded_url" : "http:\/\/bit.ly\/q9TTVW",
        "display_url" : "bit.ly\/q9TTVW"
      } ]
    },
    "geo" : { },
    "id_str" : "118058853484068864",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer Our \"PRESIDENT\" accuses Black Americans as LAZY WHINERS~wearing bedroom slippers~ Is OBAMA Right?~ http:\/\/t.co\/P87ghgiD",
    "id" : 118058853484068864,
    "created_at" : "2011-09-25 20:26:38 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506628701102080,
  "created_at" : "2011-09-27 02:05:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/oRe7MOz7",
      "expanded_url" : "http:\/\/bit.ly\/pJzp",
      "display_url" : "bit.ly\/pJzp"
    } ]
  },
  "geo" : { },
  "id_str" : "118506629388963842",
  "text" : "RT @JoeTheMailman: @hymnhummer Watch this Video~&gt; Some are \"ZOMBIES\" & some are Independent Thinkers (which one are you?)~&gt; http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/oRe7MOz7",
        "expanded_url" : "http:\/\/bit.ly\/pJzp",
        "display_url" : "bit.ly\/pJzp"
      } ]
    },
    "in_reply_to_status_id_str" : "118060820042223617",
    "geo" : { },
    "id_str" : "118061697041825792",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer Watch this Video~&gt; Some are \"ZOMBIES\" & some are Independent Thinkers (which one are you?)~&gt; http:\/\/t.co\/oRe7MOz7",
    "id" : 118061697041825792,
    "in_reply_to_status_id" : 118060820042223617,
    "created_at" : "2011-09-25 20:37:56 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506629388963842,
  "created_at" : "2011-09-27 02:05:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506593519280129",
  "text" : "RT @JoeTheMailman: @hymnhummer If you do NOT know the difference between good & bad, then you have a serious problem.... Filter...filter ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118056772484337664",
    "geo" : { },
    "id_str" : "118058565427671041",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer If you do NOT know the difference between good & bad, then you have a serious problem.... Filter...filter...filter",
    "id" : 118058565427671041,
    "in_reply_to_status_id" : 118056772484337664,
    "created_at" : "2011-09-25 20:25:30 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506593519280129,
  "created_at" : "2011-09-27 02:05:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    }, {
      "name" : "arlenearmy",
      "screen_name" : "arlenearmy",
      "indices" : [ 31, 42 ],
      "id_str" : "17569219",
      "id" : 17569219
    }, {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 43, 49 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506582815424512",
  "text" : "RT @JoeTheMailman: @hymnhummer @arlenearmy @z56po let me rephrase... \"INDEPENDENT Thinker\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "arlenearmy",
        "screen_name" : "arlenearmy",
        "indices" : [ 12, 23 ],
        "id_str" : "17569219",
        "id" : 17569219
      }, {
        "name" : "Conservatarian",
        "screen_name" : "z56po",
        "indices" : [ 24, 30 ],
        "id_str" : "63188134",
        "id" : 63188134
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118056772484337664",
    "geo" : { },
    "id_str" : "118057450703302656",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer @arlenearmy @z56po let me rephrase... \"INDEPENDENT Thinker\"",
    "id" : 118057450703302656,
    "in_reply_to_status_id" : 118056772484337664,
    "created_at" : "2011-09-25 20:21:04 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506582815424512,
  "created_at" : "2011-09-27 02:05:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506567824965633",
  "text" : "RT @JoeTheMailman: @hymnhummer are you so gullible to believe \"EVERYTHING you hear??... You want to buy some swamp land????",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118056772484337664",
    "geo" : { },
    "id_str" : "118057168309198849",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer are you so gullible to believe \"EVERYTHING you hear??... You want to buy some swamp land????",
    "id" : 118057168309198849,
    "in_reply_to_status_id" : 118056772484337664,
    "created_at" : "2011-09-25 20:19:56 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506567824965633,
  "created_at" : "2011-09-27 02:05:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    }, {
      "name" : "arlenearmy",
      "screen_name" : "arlenearmy",
      "indices" : [ 31, 42 ],
      "id_str" : "17569219",
      "id" : 17569219
    }, {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 43, 49 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506556051570688",
  "text" : "RT @JoeTheMailman: @hymnhummer @arlenearmy @z56po Only an idiot will believe \"EVERYTHING\" they hear....... dont you know how to filter t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "arlenearmy",
        "screen_name" : "arlenearmy",
        "indices" : [ 12, 23 ],
        "id_str" : "17569219",
        "id" : 17569219
      }, {
        "name" : "Conservatarian",
        "screen_name" : "z56po",
        "indices" : [ 24, 30 ],
        "id_str" : "63188134",
        "id" : 63188134
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118055763347386368",
    "geo" : { },
    "id_str" : "118056531836141570",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer @arlenearmy @z56po Only an idiot will believe \"EVERYTHING\" they hear....... dont you know how to filter the bad from the good???",
    "id" : 118056531836141570,
    "in_reply_to_status_id" : 118055763347386368,
    "created_at" : "2011-09-25 20:17:25 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506556051570688,
  "created_at" : "2011-09-27 02:05:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 3, 17 ],
      "id_str" : "21598656",
      "id" : 21598656
    }, {
      "name" : "arlenearmy",
      "screen_name" : "arlenearmy",
      "indices" : [ 31, 42 ],
      "id_str" : "17569219",
      "id" : 17569219
    }, {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 43, 49 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118506546148818944",
  "text" : "RT @JoeTheMailman: @hymnhummer @arlenearmy @z56po The question should be \"Should you be swayed by the media?\"... are you a independent t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "arlenearmy",
        "screen_name" : "arlenearmy",
        "indices" : [ 12, 23 ],
        "id_str" : "17569219",
        "id" : 17569219
      }, {
        "name" : "Conservatarian",
        "screen_name" : "z56po",
        "indices" : [ 24, 30 ],
        "id_str" : "63188134",
        "id" : 63188134
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "118051344899780608",
    "geo" : { },
    "id_str" : "118052198084132865",
    "in_reply_to_user_id" : 46961216,
    "text" : "@hymnhummer @arlenearmy @z56po The question should be \"Should you be swayed by the media?\"... are you a independent thinker?",
    "id" : 118052198084132865,
    "in_reply_to_status_id" : 118051344899780608,
    "created_at" : "2011-09-25 20:00:11 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "protected" : false,
      "id_str" : "21598656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642130282854748160\/6UolZa3A_normal.jpg",
      "id" : 21598656,
      "verified" : false
    }
  },
  "id" : 118506546148818944,
  "created_at" : "2011-09-27 02:05:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "indices" : [ 0, 16 ],
      "id_str" : "12585462",
      "id" : 12585462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118501132413833216",
  "geo" : { },
  "id_str" : "118505229221232640",
  "in_reply_to_user_id" : 12585462,
  "text" : "@StefanoBlackest says the guy with tigerbeat head shots all over his 'nets.",
  "id" : 118505229221232640,
  "in_reply_to_status_id" : 118501132413833216,
  "created_at" : "2011-09-27 02:00:23 +0000",
  "in_reply_to_screen_name" : "StefanoBlackest",
  "in_reply_to_user_id_str" : "12585462",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The TN Conservative",
      "screen_name" : "TennConserv",
      "indices" : [ 0, 12 ],
      "id_str" : "28708693",
      "id" : 28708693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118468598829297664",
  "geo" : { },
  "id_str" : "118493788187525120",
  "in_reply_to_user_id" : 28708693,
  "text" : "@TennConserv that does not set a fine example for others, whom you should like to respect the same office at other times.",
  "id" : 118493788187525120,
  "in_reply_to_status_id" : 118468598829297664,
  "created_at" : "2011-09-27 01:14:55 +0000",
  "in_reply_to_screen_name" : "TennConserv",
  "in_reply_to_user_id_str" : "28708693",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118492498615214080",
  "text" : "RT @postcrunk: jokingly wanting something",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "118471544992309249",
    "text" : "jokingly wanting something",
    "id" : 118471544992309249,
    "created_at" : "2011-09-26 23:46:32 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 118492498615214080,
  "created_at" : "2011-09-27 01:09:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "indices" : [ 0, 16 ],
      "id_str" : "12585462",
      "id" : 12585462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118085359606312960",
  "geo" : { },
  "id_str" : "118490925449228290",
  "in_reply_to_user_id" : 12585462,
  "text" : "@StefanoBlackest have you seen the Internet do it's thing yet? We're post MSM. They will not condescend. Wolf Blitzer will not save you.",
  "id" : 118490925449228290,
  "in_reply_to_status_id" : 118085359606312960,
  "created_at" : "2011-09-27 01:03:32 +0000",
  "in_reply_to_screen_name" : "StefanoBlackest",
  "in_reply_to_user_id_str" : "12585462",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 0, 14 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118061697041825792",
  "geo" : { },
  "id_str" : "118063374213988352",
  "in_reply_to_user_id" : 21598656,
  "text" : "@JoeTheMailman I have never met any of what they describe as zombies, but you are starting to come off like an automaton yourself.",
  "id" : 118063374213988352,
  "in_reply_to_status_id" : 118061697041825792,
  "created_at" : "2011-09-25 20:44:36 +0000",
  "in_reply_to_screen_name" : "JoeTheMailman",
  "in_reply_to_user_id_str" : "21598656",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 0, 14 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118058853484068864",
  "geo" : { },
  "id_str" : "118061298088026112",
  "in_reply_to_user_id" : 21598656,
  "text" : "@JoeTheMailman good and bad deserve quotation marks, not president. the office is real, the good and the bad are subjective, esp in politics",
  "id" : 118061298088026112,
  "in_reply_to_status_id" : 118058853484068864,
  "created_at" : "2011-09-25 20:36:21 +0000",
  "in_reply_to_screen_name" : "JoeTheMailman",
  "in_reply_to_user_id_str" : "21598656",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 0, 14 ],
      "id_str" : "21598656",
      "id" : 21598656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118058565427671041",
  "geo" : { },
  "id_str" : "118060820042223617",
  "in_reply_to_user_id" : 21598656,
  "text" : "@JoeTheMailman your filters are your biases. what assures you that you of all people only allow the \"good\" and filter the \"bad\"?",
  "id" : 118060820042223617,
  "in_reply_to_status_id" : 118058565427671041,
  "created_at" : "2011-09-25 20:34:27 +0000",
  "in_reply_to_screen_name" : "JoeTheMailman",
  "in_reply_to_user_id_str" : "21598656",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 0, 14 ],
      "id_str" : "21598656",
      "id" : 21598656
    }, {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 15, 21 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118057450703302656",
  "geo" : { },
  "id_str" : "118059605313064960",
  "in_reply_to_user_id" : 21598656,
  "text" : "@JoeTheMailman @z56po independent of what exactly? do u believe yourself independent of all bias? meaning, you have none?",
  "id" : 118059605313064960,
  "in_reply_to_status_id" : 118057450703302656,
  "created_at" : "2011-09-25 20:29:38 +0000",
  "in_reply_to_screen_name" : "JoeTheMailman",
  "in_reply_to_user_id_str" : "21598656",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 0, 14 ],
      "id_str" : "21598656",
      "id" : 21598656
    }, {
      "name" : "arlenearmy",
      "screen_name" : "arlenearmy",
      "indices" : [ 15, 26 ],
      "id_str" : "17569219",
      "id" : 17569219
    }, {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 27, 33 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118052198084132865",
  "geo" : { },
  "id_str" : "118056772484337664",
  "in_reply_to_user_id" : 21598656,
  "text" : "@JoeTheMailman @arlenearmy @z56po let me rephrase... deep contradiction ...",
  "id" : 118056772484337664,
  "in_reply_to_status_id" : 118052198084132865,
  "created_at" : "2011-09-25 20:18:22 +0000",
  "in_reply_to_screen_name" : "JoeTheMailman",
  "in_reply_to_user_id_str" : "21598656",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 0, 14 ],
      "id_str" : "21598656",
      "id" : 21598656
    }, {
      "name" : "arlenearmy",
      "screen_name" : "arlenearmy",
      "indices" : [ 15, 26 ],
      "id_str" : "17569219",
      "id" : 17569219
    }, {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 27, 33 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118052198084132865",
  "geo" : { },
  "id_str" : "118056041517826048",
  "in_reply_to_user_id" : 21598656,
  "text" : "@JoeTheMailman @arlenearmy @z56po Also, Deep irony quoting Rush about not being swayed by media.",
  "id" : 118056041517826048,
  "in_reply_to_status_id" : 118052198084132865,
  "created_at" : "2011-09-25 20:15:28 +0000",
  "in_reply_to_screen_name" : "JoeTheMailman",
  "in_reply_to_user_id_str" : "21598656",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 0, 14 ],
      "id_str" : "21598656",
      "id" : 21598656
    }, {
      "name" : "arlenearmy",
      "screen_name" : "arlenearmy",
      "indices" : [ 15, 26 ],
      "id_str" : "17569219",
      "id" : 17569219
    }, {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 27, 33 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118052198084132865",
  "geo" : { },
  "id_str" : "118055763347386368",
  "in_reply_to_user_id" : 21598656,
  "text" : "@JoeTheMailman @arlenearmy @z56po U get yr info from the media, do you not? I'm saying you better your faith in any of them.",
  "id" : 118055763347386368,
  "in_reply_to_status_id" : 118052198084132865,
  "created_at" : "2011-09-25 20:14:22 +0000",
  "in_reply_to_screen_name" : "JoeTheMailman",
  "in_reply_to_user_id_str" : "21598656",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLLOW ME 4 SADNESS\u2592",
      "screen_name" : "StefanoBlackest",
      "indices" : [ 0, 16 ],
      "id_str" : "12585462",
      "id" : 12585462
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 17, 33 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118049978907234304",
  "geo" : { },
  "id_str" : "118053178515271681",
  "in_reply_to_user_id" : 12585462,
  "text" : "@StefanoBlackest @AngelineGragzin leave CNN out of it. Do not rely on them and their ilk. let them pass, let them all pass for good",
  "id" : 118053178515271681,
  "in_reply_to_status_id" : 118049978907234304,
  "created_at" : "2011-09-25 20:04:05 +0000",
  "in_reply_to_screen_name" : "StefanoBlackest",
  "in_reply_to_user_id_str" : "12585462",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose",
      "screen_name" : "JoeTheMailman",
      "indices" : [ 0, 14 ],
      "id_str" : "21598656",
      "id" : 21598656
    }, {
      "name" : "arlenearmy",
      "screen_name" : "arlenearmy",
      "indices" : [ 15, 26 ],
      "id_str" : "17569219",
      "id" : 17569219
    }, {
      "name" : "Conservatarian",
      "screen_name" : "z56po",
      "indices" : [ 27, 33 ],
      "id_str" : "63188134",
      "id" : 63188134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dangling",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "118048587820187649",
  "geo" : { },
  "id_str" : "118051344899780608",
  "in_reply_to_user_id" : 21598656,
  "text" : "@JoeTheMailman @arlenearmy @z56po re: people pick the prez, not the media... who picks the media in that equation? #dangling",
  "id" : 118051344899780608,
  "in_reply_to_status_id" : 118048587820187649,
  "created_at" : "2011-09-25 19:56:48 +0000",
  "in_reply_to_screen_name" : "JoeTheMailman",
  "in_reply_to_user_id_str" : "21598656",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AS-ISN'T CO.",
      "screen_name" : "asisntco",
      "indices" : [ 1, 10 ],
      "id_str" : "42496785",
      "id" : 42496785
    }, {
      "name" : "Mike Rundle",
      "screen_name" : "flyosity",
      "indices" : [ 15, 24 ],
      "id_str" : "10545",
      "id" : 10545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117731408167968769",
  "text" : "\u201C@asisntco: RT @flyosity: We don't allow faster than light neutrinos in here\" said the bartender. A neutrino walks into a bar\u201D",
  "id" : 117731408167968769,
  "created_at" : "2011-09-24 22:45:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tmyk",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117098088895746048",
  "text" : "time and lightspeed are not correlated. #tmyk",
  "id" : 117098088895746048,
  "created_at" : "2011-09-23 04:48:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Smith",
      "screen_name" : "brad",
      "indices" : [ 0, 5 ],
      "id_str" : "5871202",
      "id" : 5871202
    }, {
      "name" : "\u0410\u043B\u044F\u0431\u0438\u043D \u0410\u043D\u0430\u0442\u043E\u043B\u0438\u0439",
      "screen_name" : "fchimero",
      "indices" : [ 6, 15 ],
      "id_str" : "2833375983",
      "id" : 2833375983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "duh",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "116991930545610752",
  "geo" : { },
  "id_str" : "117096260904824832",
  "in_reply_to_user_id" : 5871202,
  "text" : "@brad @fchimero light from a star 1 \"lightyear\" away travelled twice lightspeed, it would still arrive .5 light years after it left #duh",
  "id" : 117096260904824832,
  "in_reply_to_status_id" : 116991930545610752,
  "created_at" : "2011-09-23 04:41:38 +0000",
  "in_reply_to_screen_name" : "brad",
  "in_reply_to_user_id_str" : "5871202",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116672489953837056",
  "text" : "console.log(\"I feel you\")",
  "id" : 116672489953837056,
  "created_at" : "2011-09-22 00:37:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/0EnRTp38",
      "expanded_url" : "http:\/\/reut.rs\/mZxdGI",
      "display_url" : "reut.rs\/mZxdGI"
    } ]
  },
  "geo" : { },
  "id_str" : "114496912358506496",
  "text" : "know yr bitches : Fifteen lawmakers ask Obama to OK AT&T merger http:\/\/t.co\/0EnRTp38",
  "id" : 114496912358506496,
  "created_at" : "2011-09-16 00:32:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 3, 15 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/LnwAiD3",
      "expanded_url" : "http:\/\/OFA.BO\/JAU1dM",
      "display_url" : "OFA.BO\/JAU1dM"
    } ]
  },
  "geo" : { },
  "id_str" : "111924838427402240",
  "text" : "RT @BarackObama: Today\u2019s grassroots fundraising tip\u2014make a hard ask. Be clear about what you want and when you need it. http:\/\/t.co\/LnwAiD3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 122 ],
        "url" : "http:\/\/t.co\/LnwAiD3",
        "expanded_url" : "http:\/\/OFA.BO\/JAU1dM",
        "display_url" : "OFA.BO\/JAU1dM"
      } ]
    },
    "geo" : { },
    "id_str" : "111884655875207168",
    "text" : "Today\u2019s grassroots fundraising tip\u2014make a hard ask. Be clear about what you want and when you need it. http:\/\/t.co\/LnwAiD3",
    "id" : 111884655875207168,
    "created_at" : "2011-09-08 19:32:35 +0000",
    "user" : {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "protected" : false,
      "id_str" : "813286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451007105391022080\/iu1f7brY_normal.png",
      "id" : 813286,
      "verified" : true
    }
  },
  "id" : 111924838427402240,
  "created_at" : "2011-09-08 22:12:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]