Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218862422390353920",
  "text" : "And you don't include the module, so here I go installing what I hope is the correct version. HOPE THIS HURTS",
  "id" : 218862422390353920,
  "created_at" : "2012-06-30 00:24:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218861503904886785",
  "text" : "FEEL ME??",
  "id" : 218861503904886785,
  "created_at" : "2012-06-30 00:20:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218861325835706369",
  "text" : "Here I am trying to write spartan server code, and then your API Wrapper dumps fat dependencies into my stack just to route a path.",
  "id" : 218861325835706369,
  "created_at" : "2012-06-30 00:19:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218197900042313728",
  "text" : "The dream is to live off the fat of my head.",
  "id" : 218197900042313728,
  "created_at" : "2012-06-28 04:23:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 25, 41 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/Mvr2B2W3",
      "expanded_url" : "http:\/\/sourcefilmmaker.com\/",
      "display_url" : "sourcefilmmaker.com"
    } ]
  },
  "geo" : { },
  "id_str" : "218128648312602625",
  "text" : "Filmmaking of the future @angelinegragzin the video is poignent  http:\/\/t.co\/Mvr2B2W3",
  "id" : 218128648312602625,
  "created_at" : "2012-06-27 23:48:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/XnpXtRVy",
      "expanded_url" : "http:\/\/appjs.org\/",
      "display_url" : "appjs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "217749967954116608",
  "text" : "Node.js developers be scratching all my itches. http:\/\/t.co\/XnpXtRVy is looking very nice. HTML GUI BFFTW",
  "id" : 217749967954116608,
  "created_at" : "2012-06-26 22:43:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217718905500729344",
  "text" : "THE RENT IS TOO DAMN HOT",
  "id" : 217718905500729344,
  "created_at" : "2012-06-26 20:40:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 99 ],
      "url" : "https:\/\/t.co\/tAs0IJCz",
      "expanded_url" : "https:\/\/developer.mozilla.org\/en-US\/demos",
      "display_url" : "developer.mozilla.org\/en-US\/demos"
    } ]
  },
  "geo" : { },
  "id_str" : "217698890927964160",
  "text" : "HA! Recent Mozilla Developer Demos. CSS Hulk, CSS Spiderman, CSS Superman.... https:\/\/t.co\/tAs0IJCz",
  "id" : 217698890927964160,
  "created_at" : "2012-06-26 19:20:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216665994406535168",
  "text" : "&gt; * &gt; *",
  "id" : 216665994406535168,
  "created_at" : "2012-06-23 22:56:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216380894137683969",
  "text" : "I CLEANED HOUSE BITCH COCO CLEANED THE BONE OF YET ANOTHER VICTIM OF OUR HAMBURGER SOCIETY",
  "id" : 216380894137683969,
  "created_at" : "2012-06-23 04:03:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216370490393116672",
  "text" : "ITS FRIDAY NIGHT LETS CLEAN THE MONASTERY",
  "id" : 216370490393116672,
  "created_at" : "2012-06-23 03:21:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216283096314675200",
  "text" : "I'm very proud to watch my bitch Coco wolfing food too hot to chew. And on a hot day harissa. Get out!",
  "id" : 216283096314675200,
  "created_at" : "2012-06-22 21:34:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Rush",
      "screen_name" : "kylerush",
      "indices" : [ 4, 13 ],
      "id_str" : "15141153",
      "id" : 15141153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216257046658564096",
  "geo" : { },
  "id_str" : "216259924894826496",
  "in_reply_to_user_id" : 15141153,
  "text" : "Sir @kylerush Advanced Javascript, HTML, CSS, APIs, Node.js, hacker, at your service.",
  "id" : 216259924894826496,
  "in_reply_to_status_id" : 216257046658564096,
  "created_at" : "2012-06-22 20:02:38 +0000",
  "in_reply_to_screen_name" : "kylerush",
  "in_reply_to_user_id_str" : "15141153",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216008086857592832",
  "text" : "RT @IAM_SHAKESPEARE: BOURBON. Shame, and eternal shame, nothing but shame!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216007607863877635",
    "text" : "BOURBON. Shame, and eternal shame, nothing but shame!",
    "id" : 216007607863877635,
    "created_at" : "2012-06-22 03:20:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 216008086857592832,
  "created_at" : "2012-06-22 03:21:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 39, 46 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216005713191899137",
  "geo" : { },
  "id_str" : "216006367343939584",
  "in_reply_to_user_id" : 14690653,
  "text" : "Have you changed his diet recently???? @regisl",
  "id" : 216006367343939584,
  "in_reply_to_status_id" : 216005713191899137,
  "created_at" : "2012-06-22 03:15:05 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NBA",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216004314727071744",
  "text" : "when your referees have to discuss WHO committed the inevitable foul, your sport is not a game. #NBA",
  "id" : 216004314727071744,
  "created_at" : "2012-06-22 03:06:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215218721491394561",
  "text" : "RT @hotdogsladies: Bourbon is my spirit animal spirit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213886211599769600",
    "text" : "Bourbon is my spirit animal spirit.",
    "id" : 213886211599769600,
    "created_at" : "2012-06-16 06:50:21 +0000",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548615975268921345\/15phrwGy_normal.jpeg",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 215218721491394561,
  "created_at" : "2012-06-19 23:05:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214918183688224768",
  "text" : ".profile &gt; div:not(.selected):hover &gt; * \u007B visibility : visible \u007D",
  "id" : 214918183688224768,
  "created_at" : "2012-06-19 03:11:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EXO-M \uC384\uC528 \uD3F4\uB77C\uB85C\uC774\uB4DC \uC2A4\uD2F0\uCEE4",
      "screen_name" : "EXOM7",
      "indices" : [ 61, 67 ],
      "id_str" : "1130470483",
      "id" : 1130470483
    }, {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 68, 75 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214839836773855232",
  "text" : "which you will want to wear if you're dragging iron knuckles @ExoM7 @regisl",
  "id" : 214839836773855232,
  "created_at" : "2012-06-18 21:59:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 0, 7 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214836344420179969",
  "geo" : { },
  "id_str" : "214837174431006720",
  "in_reply_to_user_id" : 14690653,
  "text" : "@regisl cook chicken under them, like the Italians do",
  "id" : 214837174431006720,
  "in_reply_to_status_id" : 214836344420179969,
  "created_at" : "2012-06-18 21:49:08 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSS",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "carpentry",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214836477341859840",
  "text" : "figuring out how to modify transform-origin when scaling or translating is like trying to cut compound angles #CSS #carpentry",
  "id" : 214836477341859840,
  "created_at" : "2012-06-18 21:46:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corinthiano Sofredor",
      "screen_name" : "corinthino",
      "indices" : [ 0, 11 ],
      "id_str" : "2231991757",
      "id" : 2231991757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214831502163329024",
  "text" : "@corinthino customer reviews is a consumer revolution",
  "id" : 214831502163329024,
  "created_at" : "2012-06-18 21:26:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Windows",
      "screen_name" : "Windows",
      "indices" : [ 41, 49 ],
      "id_str" : "15670515",
      "id" : 15670515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214124520695545856",
  "text" : "I would make apps for windows phone 8 if @windows paid me, and if my apps were node.js powered with html5 UI",
  "id" : 214124520695545856,
  "created_at" : "2012-06-16 22:37:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aheckmann",
      "screen_name" : "aaronheckmann",
      "indices" : [ 3, 17 ],
      "id_str" : "13818902",
      "id" : 13818902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/JDgtHR0n",
      "expanded_url" : "http:\/\/blog.hooktheory.com\/2012\/06\/06\/i-analyzed-the-chords-of-1300-popular-songs-for-patterns-this-is-what-i-found\/#.T9wy6fUrEuw.twitter",
      "display_url" : "blog.hooktheory.com\/2012\/06\/06\/i-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213910064459825153",
  "text" : "RT @aaronheckmann: Analysis of 1300 pop songs: http:\/\/t.co\/JDgtHR0n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/JDgtHR0n",
        "expanded_url" : "http:\/\/blog.hooktheory.com\/2012\/06\/06\/i-analyzed-the-chords-of-1300-popular-songs-for-patterns-this-is-what-i-found\/#.T9wy6fUrEuw.twitter",
        "display_url" : "blog.hooktheory.com\/2012\/06\/06\/i-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "213893113746432000",
    "text" : "Analysis of 1300 pop songs: http:\/\/t.co\/JDgtHR0n",
    "id" : 213893113746432000,
    "created_at" : "2012-06-16 07:17:46 +0000",
    "user" : {
      "name" : "aheckmann",
      "screen_name" : "aaronheckmann",
      "protected" : false,
      "id_str" : "13818902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550709414077145088\/PldPS-Hh_normal.jpeg",
      "id" : 13818902,
      "verified" : false
    }
  },
  "id" : 213910064459825153,
  "created_at" : "2012-06-16 08:25:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 54, 67 ],
      "id_str" : "814304",
      "id" : 814304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213167274272632832",
  "geo" : { },
  "id_str" : "213168317177929728",
  "in_reply_to_user_id" : 814304,
  "text" : "You have to suspend your disbelief in the first place @arielwaldman to believe in the hypothetic substance",
  "id" : 213168317177929728,
  "in_reply_to_status_id" : 213167274272632832,
  "created_at" : "2012-06-14 07:17:41 +0000",
  "in_reply_to_screen_name" : "arielwaldman",
  "in_reply_to_user_id_str" : "814304",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213167289862856704",
  "text" : "Can 'despite' be a logical operator?",
  "id" : 213167289862856704,
  "created_at" : "2012-06-14 07:13:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213053159160029185",
  "text" : "Will I regret not being able to burn these digital files???",
  "id" : 213053159160029185,
  "created_at" : "2012-06-13 23:40:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea Verou",
      "screen_name" : "LeaVerou",
      "indices" : [ 14, 23 ],
      "id_str" : "22199970",
      "id" : 22199970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/QkZDa2Od",
      "expanded_url" : "http:\/\/leaverou.github.com\/regexplained\/",
      "display_url" : "leaverou.github.com\/regexplained\/"
    } ]
  },
  "geo" : { },
  "id_str" : "213025628402880512",
  "text" : "I just cloned @LeaVerou's Prefixfree, then browsed her repos further and glimpsed this new development http:\/\/t.co\/QkZDa2Od",
  "id" : 213025628402880512,
  "created_at" : "2012-06-13 21:50:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212970796652568576",
  "text" : "I updated my profile for this particular network. \n\nStay clean.",
  "id" : 212970796652568576,
  "created_at" : "2012-06-13 18:12:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212664918120480769",
  "text" : "homemade PB&amp;J  crepedilla",
  "id" : 212664918120480769,
  "created_at" : "2012-06-12 21:57:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212625389628047360",
  "text" : "Yes I am having a Kentucky Libre for lunch.",
  "id" : 212625389628047360,
  "created_at" : "2012-06-12 19:20:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 32, 39 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212621031540662272",
  "geo" : { },
  "id_str" : "212622738504949762",
  "in_reply_to_user_id" : 14690653,
  "text" : "Pyramid can't stand on its head @regisl its structure is predetermined by its purpose. It's good exercise to walk up one and spit in its eye",
  "id" : 212622738504949762,
  "in_reply_to_status_id" : 212621031540662272,
  "created_at" : "2012-06-12 19:09:45 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212621385816743936",
  "text" : "ITS NATURAL TO REPEAT. ITS NATURAL TO REPEAT",
  "id" : 212621385816743936,
  "created_at" : "2012-06-12 19:04:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212606424658886656",
  "text" : "Los Angeles sure knows how to ruin a walk",
  "id" : 212606424658886656,
  "created_at" : "2012-06-12 18:04:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211742624837664768",
  "text" : "drink, and proxy, drink drink and proxy proxy",
  "id" : 211742624837664768,
  "created_at" : "2012-06-10 08:52:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211740252128296960",
  "geo" : { },
  "id_str" : "211741330722914306",
  "in_reply_to_user_id" : 78194111,
  "text" : "What's a woman like you doing on a MSM Network like twitter at this hour? @ChelseaVPeretti You selling something?",
  "id" : 211741330722914306,
  "in_reply_to_status_id" : 211740252128296960,
  "created_at" : "2012-06-10 08:47:21 +0000",
  "in_reply_to_screen_name" : "chelseaperetti",
  "in_reply_to_user_id_str" : "78194111",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EARL",
      "screen_name" : "earlxsweat",
      "indices" : [ 12, 23 ],
      "id_str" : "486955518",
      "id" : 486955518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211738965601038339",
  "geo" : { },
  "id_str" : "211740545033310208",
  "in_reply_to_user_id" : 486955518,
  "text" : "yeah me too @earlxsweat but it made me wanna build a website for text rap duels",
  "id" : 211740545033310208,
  "in_reply_to_status_id" : 211738965601038339,
  "created_at" : "2012-06-10 08:44:14 +0000",
  "in_reply_to_screen_name" : "earlxsweat",
  "in_reply_to_user_id_str" : "486955518",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EARL",
      "screen_name" : "earlxsweat",
      "indices" : [ 22, 33 ],
      "id_str" : "486955518",
      "id" : 486955518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211733040374878208",
  "geo" : { },
  "id_str" : "211733353676804097",
  "in_reply_to_user_id" : 486955518,
  "text" : "golly over some acne? @earlxsweat",
  "id" : 211733353676804097,
  "in_reply_to_status_id" : 211733040374878208,
  "created_at" : "2012-06-10 08:15:39 +0000",
  "in_reply_to_screen_name" : "earlxsweat",
  "in_reply_to_user_id_str" : "486955518",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "javascript",
      "indices" : [ 78, 89 ]
    }, {
      "text" : "browserify",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 77 ],
      "url" : "https:\/\/t.co\/uSlkGiIT",
      "expanded_url" : "https:\/\/github.com\/dominictarr\/youtube-player",
      "display_url" : "github.com\/dominictarr\/yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211509087089852416",
  "text" : "RT @dominictarr: youtube player api now mostly harmless https:\/\/t.co\/uSlkGiIT #javascript #browserify",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "javascript",
        "indices" : [ 61, 72 ]
      }, {
        "text" : "browserify",
        "indices" : [ 73, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 60 ],
        "url" : "https:\/\/t.co\/uSlkGiIT",
        "expanded_url" : "https:\/\/github.com\/dominictarr\/youtube-player",
        "display_url" : "github.com\/dominictarr\/yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "211506268903444480",
    "text" : "youtube player api now mostly harmless https:\/\/t.co\/uSlkGiIT #javascript #browserify",
    "id" : 211506268903444480,
    "created_at" : "2012-06-09 17:13:18 +0000",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712569197126160384\/nvnXBzt-_normal.jpg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 211509087089852416,
  "created_at" : "2012-06-09 17:24:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211506512043053056",
  "text" : "Internet Service Providers - We Are the Man in the Middle",
  "id" : 211506512043053056,
  "created_at" : "2012-06-09 17:14:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211505821077618688",
  "text" : "every website should be https to keep the ISPs from snooping",
  "id" : 211505821077618688,
  "created_at" : "2012-06-09 17:11:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Z. Schlueter",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211500840194801664",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs sorry, bad question.",
  "id" : 211500840194801664,
  "created_at" : "2012-06-09 16:51:44 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211484886190657536",
  "text" : "I've got dangling symlinks",
  "id" : 211484886190657536,
  "created_at" : "2012-06-09 15:48:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211479148399575040",
  "text" : "RT @IAM_SHAKESPEARE: [Sheathes his sword]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211477758725992448",
    "text" : "[Sheathes his sword]",
    "id" : 211477758725992448,
    "created_at" : "2012-06-09 15:20:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 211479148399575040,
  "created_at" : "2012-06-09 15:25:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 21, 37 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211271214243647490",
  "text" : "what api is that? RT @IAM_SHAKESPEARE rest, that is the rendezvous of it.",
  "id" : 211271214243647490,
  "created_at" : "2012-06-09 01:39:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 0, 7 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211174871907045376",
  "geo" : { },
  "id_str" : "211175291689771008",
  "in_reply_to_user_id" : 14690653,
  "text" : "@regisl Navy Baby Seals",
  "id" : 211175291689771008,
  "in_reply_to_status_id" : 211174871907045376,
  "created_at" : "2012-06-08 19:18:07 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal Rogers",
      "screen_name" : "mikeal",
      "indices" : [ 38, 45 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 77 ],
      "url" : "https:\/\/t.co\/CVTArWXK",
      "expanded_url" : "https:\/\/github.com\/NHQ\/three-legged-bitch",
      "display_url" : "github.com\/NHQ\/three-legg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211171996774567937",
  "text" : "here's my localhost https proxy using @mikeal's request https:\/\/t.co\/CVTArWXK Used to get around wireless tethering blockade",
  "id" : 211171996774567937,
  "created_at" : "2012-06-08 19:05:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211159672017784832",
  "text" : "YEAH BOOYY my 3 legged localhost https proxy has bypassed the wireless data plan tethering blockade!",
  "id" : 211159672017784832,
  "created_at" : "2012-06-08 18:16:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210969163257221120",
  "text" : "drink and proxy",
  "id" : 210969163257221120,
  "created_at" : "2012-06-08 05:39:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210966398623694848",
  "text" : "uri = require('irl') \/\/ literal typo #nodejs",
  "id" : 210966398623694848,
  "created_at" : "2012-06-08 05:28:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209845412629192704",
  "text" : "RT @IAM_SHAKESPEARE: DRAMATIS PERSONAE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209834432570466304",
    "text" : "DRAMATIS PERSONAE",
    "id" : 209834432570466304,
    "created_at" : "2012-06-05 02:30:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 209845412629192704,
  "created_at" : "2012-06-05 03:13:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E2\u30CF\u30E8\u30CA\u30AA",
      "screen_name" : "mohayonao",
      "indices" : [ 68, 78 ],
      "id_str" : "27622871",
      "id" : 27622871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 63 ],
      "url" : "https:\/\/t.co\/pRa65KZc",
      "expanded_url" : "https:\/\/github.com\/mohayonao\/timbre",
      "display_url" : "github.com\/mohayonao\/timb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209844477848850432",
  "text" : "Timbre.js is awesome and getting awesomer https:\/\/t.co\/pRa65KZc and @mohayonao must be some kind of wizard",
  "id" : 209844477848850432,
  "created_at" : "2012-06-05 03:09:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singly10k",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209078496784420864",
  "text" : "APIs are the deli meat of the open source software sandwich #singly10k",
  "id" : 209078496784420864,
  "created_at" : "2012-06-03 00:26:12 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 52, 61 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singly10k",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209047543965945858",
  "text" : "Are silicon valley peeps just being polite by using @linkedin or why else? #singly10k",
  "id" : 209047543965945858,
  "created_at" : "2012-06-02 22:23:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208965817407246338",
  "text" : "I am in Oakland yall",
  "id" : 208965817407246338,
  "created_at" : "2012-06-02 16:58:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]