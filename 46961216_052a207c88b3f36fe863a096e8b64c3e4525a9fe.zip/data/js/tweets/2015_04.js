Grailbird.data.tweets_2015_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593955118493536257",
  "geo" : { },
  "id_str" : "593956004519223298",
  "in_reply_to_user_id" : 46961216,
  "text" : "this is end times level absurd.  but in the article the author is like, \"this stifles black expression.\" and \"we need more studies\".",
  "id" : 593956004519223298,
  "in_reply_to_status_id" : 593955118493536257,
  "created_at" : "2015-05-01 01:52:01 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ylugxHyDgP",
      "expanded_url" : "http:\/\/www.eastbayexpress.com\/oakland\/raps-poetic-license-revoked\/Content?oid=4260991",
      "display_url" : "eastbayexpress.com\/oakland\/raps-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593955118493536257",
  "text" : "wow, I did not know this was happening, this is totally fucked. rap songs and videos used as evidence against authors http:\/\/t.co\/ylugxHyDgP",
  "id" : 593955118493536257,
  "created_at" : "2015-05-01 01:48:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ry\u03B1\u03B7j",
      "screen_name" : "ryanj",
      "indices" : [ 0, 6 ],
      "id_str" : "14945367",
      "id" : 14945367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593893212974112768",
  "geo" : { },
  "id_str" : "593938354980290560",
  "in_reply_to_user_id" : 14945367,
  "text" : "@ryanj yes yes",
  "id" : 593938354980290560,
  "in_reply_to_status_id" : 593893212974112768,
  "created_at" : "2015-05-01 00:41:53 +0000",
  "in_reply_to_screen_name" : "ryanj",
  "in_reply_to_user_id_str" : "14945367",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/FaWNOvy5qY",
      "expanded_url" : "https:\/\/twitter.com\/deray\/status\/593597588076634112",
      "display_url" : "twitter.com\/deray\/status\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593599189533110272",
  "text" : "CAMERA ROLL, CUE LIGHTS, AND ACTION https:\/\/t.co\/FaWNOvy5qY",
  "id" : 593599189533110272,
  "created_at" : "2015-04-30 02:14:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593566599027658752",
  "text" : "I can't wait to get the protest bandaleros together again.  Last protest season, kids on mic singing \"hands up don't shoot\".",
  "id" : 593566599027658752,
  "created_at" : "2015-04-30 00:04:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593558924248231936",
  "text" : "spring a sprung",
  "id" : 593558924248231936,
  "created_at" : "2015-04-29 23:34:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593555648421335040",
  "text" : "Our governments are totes tallitarian.",
  "id" : 593555648421335040,
  "created_at" : "2015-04-29 23:21:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BaltimoreUprising",
      "indices" : [ 64, 82 ]
    }, {
      "text" : "BlackLivesMatter",
      "indices" : [ 83, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593554305048662016",
  "text" : "Disarm your local police immediately.  People don't feel safe.  #BaltimoreUprising #BlackLivesMatter",
  "id" : 593554305048662016,
  "created_at" : "2015-04-29 23:15:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593553887300177920",
  "text" : "If police killings were indiscriminate, nobody would be safe.  The safety of your person and business is costing others they peace and life.",
  "id" : 593553887300177920,
  "created_at" : "2015-04-29 23:14:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BaltimoreUprising",
      "indices" : [ 58, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593551847748542464",
  "text" : "I love what the people of baltimore are doing right now.  #BaltimoreUprising",
  "id" : 593551847748542464,
  "created_at" : "2015-04-29 23:06:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 0, 8 ],
      "id_str" : "19417999",
      "id" : 19417999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593549838899351552",
  "geo" : { },
  "id_str" : "593551073954004992",
  "in_reply_to_user_id" : 19417999,
  "text" : "@DaMFunK hits the spot!",
  "id" : 593551073954004992,
  "in_reply_to_status_id" : 593549838899351552,
  "created_at" : "2015-04-29 23:02:58 +0000",
  "in_reply_to_screen_name" : "DaMFunK",
  "in_reply_to_user_id_str" : "19417999",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 3, 11 ],
      "id_str" : "19417999",
      "id" : 19417999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7vVUnRsbxm",
      "expanded_url" : "http:\/\/youtu.be\/NEscJWErZ0I",
      "display_url" : "youtu.be\/NEscJWErZ0I"
    } ]
  },
  "geo" : { },
  "id_str" : "593550810790793219",
  "text" : "RT @DaMFunK: Behold 1 of the most incredible lead synth-lines in all of music history, at approximately the 46 sec. mark of this.\n\nhttp:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/7vVUnRsbxm",
        "expanded_url" : "http:\/\/youtu.be\/NEscJWErZ0I",
        "display_url" : "youtu.be\/NEscJWErZ0I"
      } ]
    },
    "geo" : { },
    "id_str" : "593549838899351552",
    "text" : "Behold 1 of the most incredible lead synth-lines in all of music history, at approximately the 46 sec. mark of this.\n\nhttp:\/\/t.co\/7vVUnRsbxm",
    "id" : 593549838899351552,
    "created_at" : "2015-04-29 22:58:03 +0000",
    "user" : {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "protected" : false,
      "id_str" : "19417999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727729991186825216\/fKFPEbre_normal.jpg",
      "id" : 19417999,
      "verified" : true
    }
  },
  "id" : 593550810790793219,
  "created_at" : "2015-04-29 23:01:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593161133839687680",
  "text" : "I need cymbals and hi hats, any shimmering metals really.  A gong.  I accept donations of musical  instruments.",
  "id" : 593161133839687680,
  "created_at" : "2015-04-28 21:13:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/rl6p0VU4GJ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=8QLL2j8ZtxE",
      "display_url" : "youtube.com\/watch?v=8QLL2j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593149771679813632",
  "text" : "https:\/\/t.co\/rl6p0VU4GJ",
  "id" : 593149771679813632,
  "created_at" : "2015-04-28 20:28:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593105205635325953",
  "text" : "police violence is so much cowardice.",
  "id" : 593105205635325953,
  "created_at" : "2015-04-28 17:31:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 0, 8 ],
      "id_str" : "19417999",
      "id" : 19417999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592940573725622272",
  "geo" : { },
  "id_str" : "592946550315298817",
  "in_reply_to_user_id" : 19417999,
  "text" : "@DaMFunK  that's an expression of freedom we don't  even know we've lost.  it takes a riot to shut down the streets just to feel that free.",
  "id" : 592946550315298817,
  "in_reply_to_status_id" : 592940573725622272,
  "created_at" : "2015-04-28 07:00:48 +0000",
  "in_reply_to_screen_name" : "DaMFunK",
  "in_reply_to_user_id_str" : "19417999",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592931306050314240",
  "text" : "dancing in the streets feels good, like it should.",
  "id" : 592931306050314240,
  "created_at" : "2015-04-28 06:00:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592874964644167680",
  "geo" : { },
  "id_str" : "592875686202843137",
  "in_reply_to_user_id" : 46961216,
  "text" : "this is jus a lil exercise work n the buffers.  it was made with one short audio sample.",
  "id" : 592875686202843137,
  "in_reply_to_status_id" : 592874964644167680,
  "created_at" : "2015-04-28 02:19:13 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Qa8nRmRvnb",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/clear-your-meme-cache-alternate-version",
      "display_url" : "soundcloud.com\/folkstack\/clea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592874964644167680",
  "text" : "clear your meme cache, alternate version\n\nhttps:\/\/t.co\/Qa8nRmRvnb",
  "id" : 592874964644167680,
  "created_at" : "2015-04-28 02:16:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/HhrhgaSZKh",
      "expanded_url" : "http:\/\/tiffzhang.com\/startup\/index.html?s=284251996915",
      "display_url" : "tiffzhang.com\/startup\/index.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592804686769561600",
  "text" : "meet injurvy \nhttp:\/\/t.co\/HhrhgaSZKh",
  "id" : 592804686769561600,
  "created_at" : "2015-04-27 21:37:05 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/eFo4h7zMJp",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/clear-your-meme-cache",
      "display_url" : "soundcloud.com\/folkstack\/clea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592735710911803392",
  "text" : "clear your meme cache https:\/\/t.co\/eFo4h7zMJp",
  "id" : 592735710911803392,
  "created_at" : "2015-04-27 17:03:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592734225364844544",
  "text" : "RT @postcrunk: the pentagon can lose track of billions of dollars but we can't escape our student loans",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "592732941807128577",
    "text" : "the pentagon can lose track of billions of dollars but we can't escape our student loans",
    "id" : 592732941807128577,
    "created_at" : "2015-04-27 16:52:00 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 592734225364844544,
  "created_at" : "2015-04-27 16:57:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 3, 11 ],
      "id_str" : "19417999",
      "id" : 19417999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592514226339602434",
  "text" : "RT @DaMFunK: I'm so not interested in goin' big. \nRather, I'm interested in creating dope music. | DF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "592511361898393601",
    "text" : "I'm so not interested in goin' big. \nRather, I'm interested in creating dope music. | DF",
    "id" : 592511361898393601,
    "created_at" : "2015-04-27 02:11:31 +0000",
    "user" : {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "protected" : false,
      "id_str" : "19417999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727729991186825216\/fKFPEbre_normal.jpg",
      "id" : 19417999,
      "verified" : true
    }
  },
  "id" : 592514226339602434,
  "created_at" : "2015-04-27 02:22:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592387851867721728",
  "geo" : { },
  "id_str" : "592393377926119424",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts if you get 10 viewers I will make a cameo",
  "id" : 592393377926119424,
  "in_reply_to_status_id" : 592387851867721728,
  "created_at" : "2015-04-26 18:22:42 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u221E The Brown Noise \u221E",
      "screen_name" : "brownnoiseblog",
      "indices" : [ 0, 15 ],
      "id_str" : "283708113",
      "id" : 283708113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592102772578906112",
  "geo" : { },
  "id_str" : "592121764307603457",
  "in_reply_to_user_id" : 283708113,
  "text" : "@brownnoiseblog  lyrics and singing have ruined more songs than they have improved",
  "id" : 592121764307603457,
  "in_reply_to_status_id" : 592102772578906112,
  "created_at" : "2015-04-26 00:23:24 +0000",
  "in_reply_to_screen_name" : "brownnoiseblog",
  "in_reply_to_user_id_str" : "283708113",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592104714503720961",
  "text" : "How to train your Google Botch",
  "id" : 592104714503720961,
  "created_at" : "2015-04-25 23:15:39 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/xGigmnQeOM",
      "expanded_url" : "https:\/\/2cadff4c48a72df44c7eb1d1a4fc1b5f3981a54a.htmlb.in",
      "display_url" : "\u20262df44c7eb1d1a4fc1b5f3981a54a.htmlb.in"
    } ]
  },
  "geo" : { },
  "id_str" : "592089647884308481",
  "text" : "spamming htmlb.in with loopy web sounds.  can you guess the sample?\n\nhttps:\/\/t.co\/xGigmnQeOM",
  "id" : 592089647884308481,
  "created_at" : "2015-04-25 22:15:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webaudio",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "algowave",
      "indices" : [ 40, 49 ]
    }, {
      "text" : "JavaScript",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/uX5v7yyvKi",
      "expanded_url" : "https:\/\/d05795d5323f21c370fdac7426dfd921d335786a.htmlb.in",
      "display_url" : "\u202621c370fdac7426dfd921d335786a.htmlb.in"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/2YyiB4vrh7",
      "expanded_url" : "https:\/\/a1aa51372869c7a6910518316fda2f3823a29644.htmlb.in",
      "display_url" : "\u2026c7a6910518316fda2f3823a29644.htmlb.in"
    } ]
  },
  "geo" : { },
  "id_str" : "592018854475268096",
  "text" : "variations on an audio sample #webaudio #algowave #JavaScript \n\nmas groovy\nhttps:\/\/t.co\/uX5v7yyvKi\n\nmas funky\nhttps:\/\/t.co\/2YyiB4vrh7",
  "id" : 592018854475268096,
  "created_at" : "2015-04-25 17:34:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dalai lama",
      "screen_name" : "daIaiIama",
      "indices" : [ 3, 13 ],
      "id_str" : "477932439",
      "id" : 477932439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591663147187994624",
  "text" : "RT @daIaiIama: This tea is bullshit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "578016756314198016",
    "text" : "This tea is bullshit.",
    "id" : 578016756314198016,
    "created_at" : "2015-03-18 02:15:08 +0000",
    "user" : {
      "name" : "dalai lama",
      "screen_name" : "daIaiIama",
      "protected" : false,
      "id_str" : "477932439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1790212244\/hhdl-twitter_normal.png",
      "id" : 477932439,
      "verified" : false
    }
  },
  "id" : 591663147187994624,
  "created_at" : "2015-04-24 18:01:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591550096904298500",
  "text" : "What does the Rubik's Cube have to say about data compression?",
  "id" : 591550096904298500,
  "created_at" : "2015-04-24 10:31:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/D4vQ3qZtHN",
      "expanded_url" : "https:\/\/www.npmjs.com\/package\/nvelope",
      "display_url" : "npmjs.com\/package\/nvelope"
    } ]
  },
  "in_reply_to_status_id_str" : "591461093446299650",
  "geo" : { },
  "id_str" : "591510685902774272",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  Requesting one of these for drawing bezier curves and getting cb(points)  which can then be used with this https:\/\/t.co\/D4vQ3qZtHN.",
  "id" : 591510685902774272,
  "in_reply_to_status_id" : 591461093446299650,
  "created_at" : "2015-04-24 07:55:11 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591490759200616449",
  "geo" : { },
  "id_str" : "591498480855621633",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross  Nah leave it for somebody who needs the job offers.",
  "id" : 591498480855621633,
  "in_reply_to_status_id" : 591490759200616449,
  "created_at" : "2015-04-24 07:06:42 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/FZJFrRjEng",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=2NiLFS2VlU4",
      "display_url" : "youtube.com\/watch?v=2NiLFS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591127279658381312",
  "text" : "https:\/\/t.co\/FZJFrRjEng",
  "id" : 591127279658381312,
  "created_at" : "2015-04-23 06:31:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591126471453777920",
  "text" : "give up the chick habit, give it up daddio, you'll never get another fix",
  "id" : 591126471453777920,
  "created_at" : "2015-04-23 06:28:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/591016539563790336\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Nhdowad1Jn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDO2aT2UIAAGeeX.png",
      "id_str" : "591016539236605952",
      "id" : 591016539236605952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDO2aT2UIAAGeeX.png",
      "sizes" : [ {
        "h" : 149,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 149,
        "resize" : "crop",
        "w" : 149
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 342
      } ],
      "display_url" : "pic.twitter.com\/Nhdowad1Jn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591016539563790336",
  "text" : "http:\/\/t.co\/Nhdowad1Jn",
  "id" : 591016539563790336,
  "created_at" : "2015-04-22 23:11:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 13, 21 ],
      "id_str" : "33519541",
      "id" : 33519541
    }, {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 22, 33 ],
      "id_str" : "15734539",
      "id" : 15734539
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/591015854357098496\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/psVUvzPYup",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDO1ybFVIAAAX6w.jpg",
      "id_str" : "591015853983866880",
      "id" : 591015853983866880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDO1ybFVIAAAX6w.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/psVUvzPYup"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591013759038009345",
  "geo" : { },
  "id_str" : "591015854357098496",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @pfrazee @FrozenFire  \n\n*hangs poster on the wall* http:\/\/t.co\/psVUvzPYup",
  "id" : 591015854357098496,
  "in_reply_to_status_id" : 591013759038009345,
  "created_at" : "2015-04-22 23:08:54 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    }, {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 9, 20 ],
      "id_str" : "15734539",
      "id" : 15734539
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 21, 33 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591011056895430659",
  "geo" : { },
  "id_str" : "591012846504267776",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee @FrozenFire @dominictarr  \nGUYS \n*scans for pronoun reproach*  \nIt's got 12 Down River Gold Plated IPAs in it.",
  "id" : 591012846504267776,
  "in_reply_to_status_id" : 591011056895430659,
  "created_at" : "2015-04-22 22:56:57 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "-\u212F^(\u03C0\u2148)x engiqueer",
      "screen_name" : "FrozenFire",
      "indices" : [ 13, 24 ],
      "id_str" : "15734539",
      "id" : 15734539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591004587802251265",
  "geo" : { },
  "id_str" : "591007065042092033",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @FrozenFire who put their desk exactly where I was about to put the mini fridge?",
  "id" : 591007065042092033,
  "in_reply_to_status_id" : 591004587802251265,
  "created_at" : "2015-04-22 22:33:59 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590941950418690048",
  "text" : "my documentations is down to the extreme minimal.",
  "id" : 590941950418690048,
  "created_at" : "2015-04-22 18:15:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chicago",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590937878890295296",
  "text" : "#chicago friends, go to the Vic tonight if you can.  you will not be disappoint",
  "id" : 590937878890295296,
  "created_at" : "2015-04-22 17:59:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590689840015998976",
  "geo" : { },
  "id_str" : "590691872231784448",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  thanks.  but it's been a long time. I'm thinkin I should feed the melancholia and let it grow.",
  "id" : 590691872231784448,
  "in_reply_to_status_id" : 590689840015998976,
  "created_at" : "2015-04-22 01:41:31 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/iWrm3Pi4ZR",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=97rLRloBWwE",
      "display_url" : "youtube.com\/watch?v=97rLRl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590689538026168320",
  "text" : "I used to loop this for days!  oh no, I hope I'm not going melancholy again.  (too late)  https:\/\/t.co\/iWrm3Pi4ZR",
  "id" : 590689538026168320,
  "created_at" : "2015-04-22 01:32:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/y9KHspub0G",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=w03_LCgIn5U",
      "display_url" : "youtube.com\/watch?v=w03_LC\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590683275275984896",
  "geo" : { },
  "id_str" : "590687764582105089",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso https:\/\/t.co\/y9KHspub0G\n\n(and now, blasto de pasto, imma be on a pinback kick for while.)",
  "id" : 590687764582105089,
  "in_reply_to_status_id" : 590683275275984896,
  "created_at" : "2015-04-22 01:25:12 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 0, 15 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    }, {
      "name" : "oakland javascript",
      "screen_name" : "oaklandjs",
      "indices" : [ 35, 45 ],
      "id_str" : "2561997186",
      "id" : 2561997186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590568541931319296",
  "in_reply_to_user_id" : 2797358358,
  "text" : "@oaklanddancejs meeting tonight at @oaklandjs",
  "id" : 590568541931319296,
  "created_at" : "2015-04-21 17:31:27 +0000",
  "in_reply_to_screen_name" : "oaklanddancejs",
  "in_reply_to_user_id_str" : "2797358358",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590544177080991747",
  "geo" : { },
  "id_str" : "590561108399939585",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts fool",
  "id" : 590561108399939585,
  "in_reply_to_status_id" : 590544177080991747,
  "created_at" : "2015-04-21 17:01:54 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steph davidson",
      "screen_name" : "stephcd",
      "indices" : [ 3, 11 ],
      "id_str" : "14573958",
      "id" : 14573958
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stephcd\/status\/522240407414243329\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/u8skzZMaC1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz9e4gWCMAMAt2s.jpg",
      "id_str" : "522240406646304771",
      "id" : 522240406646304771,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz9e4gWCMAMAt2s.jpg",
      "sizes" : [ {
        "h" : 477,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 701,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 701,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 701,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/u8skzZMaC1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590247413115269120",
  "text" : "RT @stephcd: dress for job you want http:\/\/t.co\/u8skzZMaC1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/stephcd\/status\/522240407414243329\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/u8skzZMaC1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz9e4gWCMAMAt2s.jpg",
        "id_str" : "522240406646304771",
        "id" : 522240406646304771,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz9e4gWCMAMAt2s.jpg",
        "sizes" : [ {
          "h" : 477,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 701,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 701,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 701,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/u8skzZMaC1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "522240407414243329",
    "text" : "dress for job you want http:\/\/t.co\/u8skzZMaC1",
    "id" : 522240407414243329,
    "created_at" : "2014-10-15 04:19:50 +0000",
    "user" : {
      "name" : "steph davidson",
      "screen_name" : "stephcd",
      "protected" : false,
      "id_str" : "14573958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527140641944252417\/aYYqPXHB_normal.jpeg",
      "id" : 14573958,
      "verified" : false
    }
  },
  "id" : 590247413115269120,
  "created_at" : "2015-04-20 20:15:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "indices" : [ 3, 14 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Satoshi_N_\/status\/590210770945859585\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/QA6O29a9lD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDZkXiUgAAtz9m.jpg",
      "id_str" : "590210770002018304",
      "id" : 590210770002018304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDZkXiUgAAtz9m.jpg",
      "sizes" : [ {
        "h" : 244,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/QA6O29a9lD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590247348208439296",
  "text" : "RT @Satoshi_N_: http:\/\/t.co\/QA6O29a9lD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Satoshi_N_\/status\/590210770945859585\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/QA6O29a9lD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDZkXiUgAAtz9m.jpg",
        "id_str" : "590210770002018304",
        "id" : 590210770002018304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDZkXiUgAAtz9m.jpg",
        "sizes" : [ {
          "h" : 244,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/QA6O29a9lD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590210770945859585",
    "text" : "http:\/\/t.co\/QA6O29a9lD",
    "id" : 590210770945859585,
    "created_at" : "2015-04-20 17:49:48 +0000",
    "user" : {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "Satoshi_N_",
      "protected" : false,
      "id_str" : "2375721396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727448034024525825\/nxaF8tNf_normal.jpg",
      "id" : 2375721396,
      "verified" : false
    }
  },
  "id" : 590247348208439296,
  "created_at" : "2015-04-20 20:15:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiora Aeterna \u2604",
      "screen_name" : "FioraAeterna",
      "indices" : [ 3, 16 ],
      "id_str" : "2468699718",
      "id" : 2468699718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/o4niEPD4W2",
      "expanded_url" : "http:\/\/weputachipinit.tumblr.com",
      "display_url" : "weputachipinit.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "590205886884282368",
  "text" : "RT @FioraAeterna: \"We put a chip in it\": a website for all those Internet-enabled 'smart devices' that nobody really needed: http:\/\/t.co\/o4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/o4niEPD4W2",
        "expanded_url" : "http:\/\/weputachipinit.tumblr.com",
        "display_url" : "weputachipinit.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "590168053003866112",
    "text" : "\"We put a chip in it\": a website for all those Internet-enabled 'smart devices' that nobody really needed: http:\/\/t.co\/o4niEPD4W2",
    "id" : 590168053003866112,
    "created_at" : "2015-04-20 15:00:03 +0000",
    "user" : {
      "name" : "Fiora Aeterna \u2604",
      "screen_name" : "FioraAeterna",
      "protected" : false,
      "id_str" : "2468699718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666568245516746752\/17dinxNI_normal.jpg",
      "id" : 2468699718,
      "verified" : false
    }
  },
  "id" : 590205886884282368,
  "created_at" : "2015-04-20 17:30:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590200925853093888",
  "text" : "I was gonna work today, but",
  "id" : 590200925853093888,
  "created_at" : "2015-04-20 17:10:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589990259993149440",
  "text" : "I accept width and hidth.",
  "id" : 589990259993149440,
  "created_at" : "2015-04-20 03:13:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589975318670270464",
  "geo" : { },
  "id_str" : "589976570208526336",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar I was decoding yr dragging of points, which interested me",
  "id" : 589976570208526336,
  "in_reply_to_status_id" : 589975318670270464,
  "created_at" : "2015-04-20 02:19:10 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589968351511851009",
  "geo" : { },
  "id_str" : "589975175103254528",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  noting only fellow module imps",
  "id" : 589975175103254528,
  "in_reply_to_status_id" : 589968351511851009,
  "created_at" : "2015-04-20 02:13:37 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/JhTuHCoEnX",
      "expanded_url" : "https:\/\/www.npmjs.com\/package\/closeness",
      "display_url" : "npmjs.com\/package\/closen\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "589948626685669376",
  "geo" : { },
  "id_str" : "589954354515283968",
  "in_reply_to_user_id" : 46961216,
  "text" : "@tmpvar https:\/\/t.co\/JhTuHCoEnX  ;^p",
  "id" : 589954354515283968,
  "in_reply_to_status_id" : 589948626685669376,
  "created_at" : "2015-04-20 00:50:53 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Focused\u26A1\uFE0FD\u0101M-F\u0426\u041FK",
      "screen_name" : "DaMFunK",
      "indices" : [ 47, 55 ],
      "id_str" : "19417999",
      "id" : 19417999
    }, {
      "name" : "Todd Rundgren",
      "screen_name" : "toddrundgren",
      "indices" : [ 76, 89 ],
      "id_str" : "18772361",
      "id" : 18772361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BZ3wzm7R3i",
      "expanded_url" : "http:\/\/www.todd-rundgren.com\/tr-tour.html",
      "display_url" : "todd-rundgren.com\/tr-tour.html"
    } ]
  },
  "geo" : { },
  "id_str" : "589952462439583744",
  "text" : "I almost feel like this was meant jus for me.  @DaMFunK touring the US with @toddrundgren this show must be amazing.  http:\/\/t.co\/BZ3wzm7R3i",
  "id" : 589952462439583744,
  "created_at" : "2015-04-20 00:43:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "temporary variable",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/0RIxKSOOBb",
      "expanded_url" : "https:\/\/www.npmjs.com\/package\/offsetter",
      "display_url" : "npmjs.com\/package\/offset\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "589918115204567040",
  "geo" : { },
  "id_str" : "589948626685669376",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar https:\/\/t.co\/0RIxKSOOBb  ;^p",
  "id" : 589948626685669376,
  "in_reply_to_status_id" : 589918115204567040,
  "created_at" : "2015-04-20 00:28:07 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589886617697046529",
  "text" : "OH you can OH me on that",
  "id" : 589886617697046529,
  "created_at" : "2015-04-19 20:21:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589885166585131009",
  "text" : "am I sitting next to a USB powered toothbrush?",
  "id" : 589885166585131009,
  "created_at" : "2015-04-19 20:15:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589849523603709953",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr's ideas always give me the fever",
  "id" : 589849523603709953,
  "created_at" : "2015-04-19 17:54:19 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 10, 22 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589705133329551360",
  "geo" : { },
  "id_str" : "589847634208165891",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack @dominictarr ya but that middle ground is the computer executable natural language!",
  "id" : 589847634208165891,
  "in_reply_to_status_id" : 589705133329551360,
  "created_at" : "2015-04-19 17:46:49 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/589633020384022528\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/rbl7oiYs7S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC7MG2RUMAEz5hJ.png",
      "id_str" : "589633019251535873",
      "id" : 589633019251535873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC7MG2RUMAEz5hJ.png",
      "sizes" : [ {
        "h" : 120,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 457
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 457
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 457
      } ],
      "display_url" : "pic.twitter.com\/rbl7oiYs7S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589633020384022528",
  "text" : "I am a contributor to the great open source project NPM. http:\/\/t.co\/rbl7oiYs7S",
  "id" : 589633020384022528,
  "created_at" : "2015-04-19 03:34:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589622417099595776",
  "text" : "RT @marinakukso: please recommend a good scifi movie that i haven't seen before.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "589617974442463232",
    "text" : "please recommend a good scifi movie that i haven't seen before.",
    "id" : 589617974442463232,
    "created_at" : "2015-04-19 02:34:14 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619358210831466496\/ozk67ntW_normal.jpg",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 589622417099595776,
  "created_at" : "2015-04-19 02:51:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589617031235809280",
  "text" : "bum ba cheeba bum\nbum ba cheeba bum\nbum ba cheeba bum\nbum ba cheeba bum\nbum ba cheeba bum",
  "id" : 589617031235809280,
  "created_at" : "2015-04-19 02:30:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589188268320628736",
  "text" : "hillary 2016, let's do it for the make history one more time",
  "id" : 589188268320628736,
  "created_at" : "2015-04-17 22:06:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "april glaser",
      "screen_name" : "aprilaser",
      "indices" : [ 3, 13 ],
      "id_str" : "210056653",
      "id" : 210056653
    }, {
      "name" : "Streetsblog SF",
      "screen_name" : "StreetsblogSF",
      "indices" : [ 122, 136 ],
      "id_str" : "30318395",
      "id" : 30318395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Z0kMSCSlBw",
      "expanded_url" : "http:\/\/cal.streetsblog.org\/2015\/04\/14\/ca-bill-to-prohibit-tolls-for-bikes-peds-on-state-owned-bridges-passes-committee\/#.VS8wM9HxV0M.twitter",
      "display_url" : "cal.streetsblog.org\/2015\/04\/14\/ca-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589152701658714112",
  "text" : "RT @aprilaser: CA Bill to Prohibit Golden Gate Bridge Bike Tolls Expanded to All State Bridges http:\/\/t.co\/Z0kMSCSlBw via @StreetsblogSF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Streetsblog SF",
        "screen_name" : "StreetsblogSF",
        "indices" : [ 107, 121 ],
        "id_str" : "30318395",
        "id" : 30318395
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/Z0kMSCSlBw",
        "expanded_url" : "http:\/\/cal.streetsblog.org\/2015\/04\/14\/ca-bill-to-prohibit-tolls-for-bikes-peds-on-state-owned-bridges-passes-committee\/#.VS8wM9HxV0M.twitter",
        "display_url" : "cal.streetsblog.org\/2015\/04\/14\/ca-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "589145981830041600",
    "text" : "CA Bill to Prohibit Golden Gate Bridge Bike Tolls Expanded to All State Bridges http:\/\/t.co\/Z0kMSCSlBw via @StreetsblogSF",
    "id" : 589145981830041600,
    "created_at" : "2015-04-17 19:18:42 +0000",
    "user" : {
      "name" : "april glaser",
      "screen_name" : "aprilaser",
      "protected" : false,
      "id_str" : "210056653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712477337531449344\/H6j-FPul_normal.jpg",
      "id" : 210056653,
      "verified" : false
    }
  },
  "id" : 589152701658714112,
  "created_at" : "2015-04-17 19:45:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589143528225181696",
  "text" : "I AM TRIP N ON THE YES VIBES",
  "id" : 589143528225181696,
  "created_at" : "2015-04-17 19:08:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589142308727066625",
  "text" : "IOT, with app brands hogging homonyms, every single-word concept is like hot TLD virtual real estate.  Counter by meaning the root form.",
  "id" : 589142308727066625,
  "created_at" : "2015-04-17 19:04:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/588888440910909441\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/222qgsoGuE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCwm6owUsAEZj4c.png",
      "id_str" : "588888440093061121",
      "id" : 588888440093061121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCwm6owUsAEZj4c.png",
      "sizes" : [ {
        "h" : 647,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 910,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/222qgsoGuE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588886929078226944",
  "geo" : { },
  "id_str" : "588888440910909441",
  "in_reply_to_user_id" : 46961216,
  "text" : "http:\/\/t.co\/222qgsoGuE",
  "id" : 588888440910909441,
  "in_reply_to_status_id" : 588886929078226944,
  "created_at" : "2015-04-17 02:15:19 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oona R\u00E4is\u00E4nen",
      "screen_name" : "windyoona",
      "indices" : [ 3, 13 ],
      "id_str" : "427696547",
      "id" : 427696547
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/windyoona\/status\/588822005975162880\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/KKNLRbYDD6",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CCvqbteUsAAUwVi.png",
      "id_str" : "588821938086129664",
      "id" : 588821938086129664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CCvqbteUsAAUwVi.png",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KKNLRbYDD6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588887311309352960",
  "text" : "RT @windyoona: sine &amp; cosine of an angle: http:\/\/t.co\/KKNLRbYDD6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/windyoona\/status\/588822005975162880\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/KKNLRbYDD6",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CCvqbteUsAAUwVi.png",
        "id_str" : "588821938086129664",
        "id" : 588821938086129664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CCvqbteUsAAUwVi.png",
        "sizes" : [ {
          "h" : 270,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KKNLRbYDD6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588822005975162880",
    "text" : "sine &amp; cosine of an angle: http:\/\/t.co\/KKNLRbYDD6",
    "id" : 588822005975162880,
    "created_at" : "2015-04-16 21:51:20 +0000",
    "user" : {
      "name" : "Oona R\u00E4is\u00E4nen",
      "screen_name" : "windyoona",
      "protected" : false,
      "id_str" : "427696547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695939423800791041\/iej9RPGH_normal.jpg",
      "id" : 427696547,
      "verified" : false
    }
  },
  "id" : 588887311309352960,
  "created_at" : "2015-04-17 02:10:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588885803884883968",
  "geo" : { },
  "id_str" : "588886929078226944",
  "in_reply_to_user_id" : 46961216,
  "text" : "subdue the competition, flush the competition, jettison the competition!",
  "id" : 588886929078226944,
  "in_reply_to_status_id" : 588885803884883968,
  "created_at" : "2015-04-17 02:09:19 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 25, 39 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/wvfFvlzvRF",
      "expanded_url" : "https:\/\/github.com\/NHQ\/mostmodernist",
      "display_url" : "github.com\/NHQ\/mostmodern\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588885803884883968",
  "text" : "apropos coming soon from @modulhaus3000 I have published to the internet my first distributed paper https:\/\/t.co\/wvfFvlzvRF",
  "id" : 588885803884883968,
  "created_at" : "2015-04-17 02:04:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588844150939779073",
  "text" : "catch me on stage singing all the pet names I have for big baby bubba.  \n\nimmediately after typing that, little bear big puked at my heel.",
  "id" : 588844150939779073,
  "created_at" : "2015-04-16 23:19:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @denormalize",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "3529967232",
      "id" : 3529967232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588754788998778880",
  "geo" : { },
  "id_str" : "588755788115542016",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden  my one dream law is ISPs must provide a public ipv6 address for all connected devices",
  "id" : 588755788115542016,
  "in_reply_to_status_id" : 588754788998778880,
  "created_at" : "2015-04-16 17:28:13 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588593239852130304",
  "geo" : { },
  "id_str" : "588594303338840065",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords  yo man I got yr back, if u need a hug",
  "id" : 588594303338840065,
  "in_reply_to_status_id" : 588593239852130304,
  "created_at" : "2015-04-16 06:46:32 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588591755102068737",
  "text" : "I am very approachable IRL but not on the internet.  I will straight up rob you on the internet.",
  "id" : 588591755102068737,
  "created_at" : "2015-04-16 06:36:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Graham \u2744\uFE0F",
      "screen_name" : "ErrataRob",
      "indices" : [ 0, 10 ],
      "id_str" : "15300995",
      "id" : 15300995
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 11, 20 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588552078924054529",
  "geo" : { },
  "id_str" : "588591105333047296",
  "in_reply_to_user_id" : 15300995,
  "text" : "@ErrataRob @substack   very considerate leaving hidden directories alone.  *git reset*",
  "id" : 588591105333047296,
  "in_reply_to_status_id" : 588552078924054529,
  "created_at" : "2015-04-16 06:33:49 +0000",
  "in_reply_to_screen_name" : "ErrataRob",
  "in_reply_to_user_id_str" : "15300995",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "n1k0",
      "screen_name" : "n1k0",
      "indices" : [ 3, 8 ],
      "id_str" : "6619162",
      "id" : 6619162
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/n1k0\/status\/572668629860405248\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/qQdk60c7k0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_KHFVrXEAAzuzc.jpg",
      "id_str" : "572668628417581056",
      "id" : 572668628417581056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_KHFVrXEAAzuzc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qQdk60c7k0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588588285468876800",
  "text" : "RT @n1k0: BRING ME SCHR\u00D6DINGER'S HEAD http:\/\/t.co\/qQdk60c7k0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/n1k0\/status\/572668629860405248\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/qQdk60c7k0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_KHFVrXEAAzuzc.jpg",
        "id_str" : "572668628417581056",
        "id" : 572668628417581056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_KHFVrXEAAzuzc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 604
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 604
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/qQdk60c7k0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572668629860405248",
    "text" : "BRING ME SCHR\u00D6DINGER'S HEAD http:\/\/t.co\/qQdk60c7k0",
    "id" : 572668629860405248,
    "created_at" : "2015-03-03 08:03:35 +0000",
    "user" : {
      "name" : "n1k0",
      "screen_name" : "n1k0",
      "protected" : false,
      "id_str" : "6619162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692386032084480001\/JuLlbeF3_normal.jpg",
      "id" : 6619162,
      "verified" : false
    }
  },
  "id" : 588588285468876800,
  "created_at" : "2015-04-16 06:22:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oakland javascript",
      "screen_name" : "oaklandjs",
      "indices" : [ 14, 24 ],
      "id_str" : "2561997186",
      "id" : 2561997186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588511473585954820",
  "text" : "it's time for @oaklandjs to move to a less bourgy establishment",
  "id" : 588511473585954820,
  "created_at" : "2015-04-16 01:17:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588498049309093888",
  "text" : "puttin' on a pantz",
  "id" : 588498049309093888,
  "created_at" : "2015-04-16 00:24:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oakland javascript",
      "screen_name" : "oaklandjs",
      "indices" : [ 19, 29 ],
      "id_str" : "2561997186",
      "id" : 2561997186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588488423473840128",
  "text" : "imma touch down at @oaklandjs later",
  "id" : 588488423473840128,
  "created_at" : "2015-04-15 23:45:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588412949452062721",
  "text" : "where my venture anarcho-capitalists at?",
  "id" : 588412949452062721,
  "created_at" : "2015-04-15 18:45:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588405072503017473",
  "text" : "When the prelude to doing a thing creates conflict in your mind, process emit error, debug out.",
  "id" : 588405072503017473,
  "created_at" : "2015-04-15 18:14:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/oNsiSQZbRy",
      "expanded_url" : "https:\/\/medium.com\/human-parts\/a-gentlemens-guide-to-rape-culture-7fc86c50dc4c",
      "display_url" : "medium.com\/human-parts\/a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588373829258358785",
  "text" : "The gentleman's guide.  \"Some of the things you inherit from society are cool and some of them are rape culture.\"  https:\/\/t.co\/oNsiSQZbRy",
  "id" : 588373829258358785,
  "created_at" : "2015-04-15 16:10:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KSNrDmsAzH",
      "expanded_url" : "http:\/\/www.bloomberg.com\/news\/articles\/2015-04-08\/the-u-s-government-s-800-billion-gamble-on-student-loans",
      "display_url" : "bloomberg.com\/news\/articles\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588373654011977728",
  "text" : "that gov't makes money off students loans is pure lechery, and stupid economics.  also, don't pay back your loans!  http:\/\/t.co\/KSNrDmsAzH",
  "id" : 588373654011977728,
  "created_at" : "2015-04-15 16:09:45 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Gruber",
      "screen_name" : "juliangruber",
      "indices" : [ 3, 16 ],
      "id_str" : "324544130",
      "id" : 324544130
    }, {
      "name" : "Running Death",
      "screen_name" : "RunningDeath1",
      "indices" : [ 49, 63 ],
      "id_str" : "1915033699",
      "id" : 1915033699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/SpURihbIkv",
      "expanded_url" : "https:\/\/github.com\/juliangruber\/running-death-overdrive",
      "display_url" : "github.com\/juliangruber\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588361684579790848",
  "text" : "RT @juliangruber: Music as a node module! Stream @RunningDeath1's album by `npm install -g running-death-overdrive`: https:\/\/t.co\/SpURihbIkv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Running Death",
        "screen_name" : "RunningDeath1",
        "indices" : [ 31, 45 ],
        "id_str" : "1915033699",
        "id" : 1915033699
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/SpURihbIkv",
        "expanded_url" : "https:\/\/github.com\/juliangruber\/running-death-overdrive",
        "display_url" : "github.com\/juliangruber\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588300333950099456",
    "text" : "Music as a node module! Stream @RunningDeath1's album by `npm install -g running-death-overdrive`: https:\/\/t.co\/SpURihbIkv",
    "id" : 588300333950099456,
    "created_at" : "2015-04-15 11:18:24 +0000",
    "user" : {
      "name" : "Julian Gruber",
      "screen_name" : "juliangruber",
      "protected" : false,
      "id_str" : "324544130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716770462114701313\/9HlkRMJp_normal.jpg",
      "id" : 324544130,
      "verified" : false
    }
  },
  "id" : 588361684579790848,
  "created_at" : "2015-04-15 15:22:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/jXEnvkjedf",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/donde-el-antidoto",
      "display_url" : "soundcloud.com\/folkstack\/dond\u2026"
    }, {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/nNzEIanJV1",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/surfin-george",
      "display_url" : "soundcloud.com\/folkstack\/surf\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "588211468174286848",
  "geo" : { },
  "id_str" : "588212176340525056",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \nwhich see\nhttps:\/\/t.co\/jXEnvkjedf\nhttps:\/\/t.co\/nNzEIanJV1",
  "id" : 588212176340525056,
  "in_reply_to_status_id" : 588211468174286848,
  "created_at" : "2015-04-15 05:28:05 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/wGWRTdBevd",
      "expanded_url" : "https:\/\/soundcloud.com\/daniel-pollman",
      "display_url" : "soundcloud.com\/daniel-pollman"
    } ]
  },
  "geo" : { },
  "id_str" : "588211468174286848",
  "text" : "Me and this Daniel play together.  He is amazing.   https:\/\/t.co\/wGWRTdBevd",
  "id" : 588211468174286848,
  "created_at" : "2015-04-15 05:25:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588208434572558336",
  "text" : "eat shit breathe shit feel shit",
  "id" : 588208434572558336,
  "created_at" : "2015-04-15 05:13:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588207901174530048",
  "text" : "your feel for art is your grok of science is your body asana.",
  "id" : 588207901174530048,
  "created_at" : "2015-04-15 05:11:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588206235972984832",
  "text" : "i bet most of yall can't ear my music cuz you are too used to that scaled and compressed shit they feed you thru iplumes and you tubes",
  "id" : 588206235972984832,
  "created_at" : "2015-04-15 05:04:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588203718128046080",
  "text" : "I'm no hater of getting paid.  When I gots money I throw that shit away!",
  "id" : 588203718128046080,
  "created_at" : "2015-04-15 04:54:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588202430569062400",
  "text" : "life is better when you don't need very many thousands of dollars per year to do what you are inspired to do",
  "id" : 588202430569062400,
  "created_at" : "2015-04-15 04:49:22 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588199500667314177",
  "text" : "RT @tinysubversions: The collective noun for \"thing\" is \"internet\" -- a gaggle of geese, a school of fish, an internet of things.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587610842541113344",
    "text" : "The collective noun for \"thing\" is \"internet\" -- a gaggle of geese, a school of fish, an internet of things.",
    "id" : 587610842541113344,
    "created_at" : "2015-04-13 13:38:36 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 588199500667314177,
  "created_at" : "2015-04-15 04:37:43 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yaya",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588197925404172288",
  "text" : "you always yay always #yaya",
  "id" : 588197925404172288,
  "created_at" : "2015-04-15 04:31:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/QgVkhjCHKk",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/untitled-recording-42",
      "display_url" : "soundcloud.com\/johnnyscript\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588197313627168768",
  "text" : "i made a song cut of music track https:\/\/t.co\/QgVkhjCHKk",
  "id" : 588197313627168768,
  "created_at" : "2015-04-15 04:29:02 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588174811832127489",
  "text" : "boners to murgatroyd",
  "id" : 588174811832127489,
  "created_at" : "2015-04-15 02:59:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588172575232106497",
  "text" : "hollywood is as abuse to your senses.  Hollywood is annoying tricks on your perception.",
  "id" : 588172575232106497,
  "created_at" : "2015-04-15 02:50:44 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588172119432962048",
  "text" : "popcorn time is too hollywood YALL ARE TOO HOLLYWOOD",
  "id" : 588172119432962048,
  "created_at" : "2015-04-15 02:48:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588171143678427136",
  "text" : "After much scrolling down the popular film marquees of popcorn time, I watched Black Swan.  It was basically Fight Club.",
  "id" : 588171143678427136,
  "created_at" : "2015-04-15 02:45:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588162802243792898",
  "geo" : { },
  "id_str" : "588165023203209216",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso n I am surprised and shocked, that Vice would blur CG nipples",
  "id" : 588165023203209216,
  "in_reply_to_status_id" : 588162802243792898,
  "created_at" : "2015-04-15 02:20:43 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 13, 25 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JpWDjF8wQC",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/drum-machine-hot-take",
      "display_url" : "soundcloud.com\/johnnyscript\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588061774970257410",
  "text" : "last night:  @ednapiranha upped a drum machine web synth and I immediately shaton it with my bird machine web synth\n\nhttps:\/\/t.co\/JpWDjF8wQC",
  "id" : 588061774970257410,
  "created_at" : "2015-04-14 19:30:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588053936944324609",
  "text" : "I have never been able to bear wearing ear\/head\/phones.  If I must, they need to be \"open back\" cans.  Currently I have none.",
  "id" : 588053936944324609,
  "created_at" : "2015-04-14 18:59:18 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 0, 11 ],
      "id_str" : "407296703",
      "id" : 407296703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588053349569802243",
  "in_reply_to_user_id" : 407296703,
  "text" : "@obensource  a pretty modest setup for a stack artist, i'd say. one hard synth. two cheap monitors. gb's of code. the rest is butt amperage.",
  "id" : 588053349569802243,
  "created_at" : "2015-04-14 18:56:58 +0000",
  "in_reply_to_screen_name" : "obensource",
  "in_reply_to_user_id_str" : "407296703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/osnq0A4wxv",
      "expanded_url" : "https:\/\/github.com\/NHQ\/los-manos",
      "display_url" : "github.com\/NHQ\/los-manos"
    } ]
  },
  "in_reply_to_status_id_str" : "588049218813698048",
  "geo" : { },
  "id_str" : "588050654691745793",
  "in_reply_to_user_id" : 46961216,
  "text" : "not a line of code has changed since last years node knockout....\ngit clone https:\/\/t.co\/osnq0A4wxv\ncd los-manos\nnpm install\nnpm start",
  "id" : 588050654691745793,
  "in_reply_to_status_id" : 588049218813698048,
  "created_at" : "2015-04-14 18:46:16 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 0, 11 ],
      "id_str" : "407296703",
      "id" : 407296703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588049238937874432",
  "geo" : { },
  "id_str" : "588050192726884353",
  "in_reply_to_user_id" : 407296703,
  "text" : "@obensource  I wouldn't call any of it pro.  the bass barrel is a beast of its own nature.  the KRKs bassy and clear enuf for c-list prices.",
  "id" : 588050192726884353,
  "in_reply_to_status_id" : 588049238937874432,
  "created_at" : "2015-04-14 18:44:26 +0000",
  "in_reply_to_screen_name" : "obensource",
  "in_reply_to_user_id_str" : "407296703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 84, 92 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/osnq0A4wxv",
      "expanded_url" : "https:\/\/github.com\/NHQ\/los-manos",
      "display_url" : "github.com\/NHQ\/los-manos"
    } ]
  },
  "geo" : { },
  "id_str" : "588049218813698048",
  "text" : "im going to make a gif of my code n music studio using this gif creator I made with @soldair last node knockout  https:\/\/t.co\/osnq0A4wxv",
  "id" : 588049218813698048,
  "created_at" : "2015-04-14 18:40:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 0, 11 ],
      "id_str" : "407296703",
      "id" : 407296703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588048727778136065",
  "in_reply_to_user_id" : 407296703,
  "text" : "@obensource ok, it gets better after the drop, the keyboard solo is sweet.  the rest is just as you said: contemporary jazz!",
  "id" : 588048727778136065,
  "created_at" : "2015-04-14 18:38:36 +0000",
  "in_reply_to_screen_name" : "obensource",
  "in_reply_to_user_id_str" : "407296703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 0, 11 ],
      "id_str" : "407296703",
      "id" : 407296703
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/588047832764022784\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/JNoXixiDea",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CCkqYx5UgAAI3A6.png",
      "id_str" : "588047831547543552",
      "id" : 588047831547543552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CCkqYx5UgAAI3A6.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/JNoXixiDea"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588046028651245568",
  "geo" : { },
  "id_str" : "588047832764022784",
  "in_reply_to_user_id" : 407296703,
  "text" : "@obensource  oh yeah you and what army? http:\/\/t.co\/JNoXixiDea",
  "id" : 588047832764022784,
  "in_reply_to_status_id" : 588046028651245568,
  "created_at" : "2015-04-14 18:35:03 +0000",
  "in_reply_to_screen_name" : "obensource",
  "in_reply_to_user_id_str" : "407296703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 0, 11 ],
      "id_str" : "407296703",
      "id" : 407296703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588044341848879104",
  "geo" : { },
  "id_str" : "588045582247337985",
  "in_reply_to_user_id" : 407296703,
  "text" : "@obensource  true, I should play it thru the sound system.  then... then I can judge.",
  "id" : 588045582247337985,
  "in_reply_to_status_id" : 588044341848879104,
  "created_at" : "2015-04-14 18:26:06 +0000",
  "in_reply_to_screen_name" : "obensource",
  "in_reply_to_user_id_str" : "407296703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 0, 11 ],
      "id_str" : "407296703",
      "id" : 407296703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588008940392345600",
  "geo" : { },
  "id_str" : "588041798855090179",
  "in_reply_to_user_id" : 407296703,
  "text" : "@obensource  rly tho?  I can't judge.  I had to leave Safeway before the track was over.",
  "id" : 588041798855090179,
  "in_reply_to_status_id" : 588008940392345600,
  "created_at" : "2015-04-14 18:11:04 +0000",
  "in_reply_to_screen_name" : "obensource",
  "in_reply_to_user_id_str" : "407296703",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ry\u03B1\u03B7j",
      "screen_name" : "ryanj",
      "indices" : [ 0, 6 ],
      "id_str" : "14945367",
      "id" : 14945367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588016696029552640",
  "geo" : { },
  "id_str" : "588040943158296576",
  "in_reply_to_user_id" : 14945367,
  "text" : "@ryanj did he steal the bike, or roll up on it?",
  "id" : 588040943158296576,
  "in_reply_to_status_id" : 588016696029552640,
  "created_at" : "2015-04-14 18:07:40 +0000",
  "in_reply_to_screen_name" : "ryanj",
  "in_reply_to_user_id_str" : "14945367",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587843901202927616",
  "text" : "comcast doing some fucked up MITM shit as a service",
  "id" : 587843901202927616,
  "created_at" : "2015-04-14 05:04:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/JpWDjFq7Ia",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/drum-machine-hot-take",
      "display_url" : "soundcloud.com\/johnnyscript\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "587805296690470912",
  "geo" : { },
  "id_str" : "587812547169927169",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha  coldest hot take on the westcoast.  \n\nhttps:\/\/t.co\/JpWDjFq7Ia",
  "id" : 587812547169927169,
  "in_reply_to_status_id" : 587805296690470912,
  "created_at" : "2015-04-14 03:00:06 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587805378764607488",
  "text" : "Good (well done) normal music (produced song arrangements) always sound better after listening to alotta my weird shit.",
  "id" : 587805378764607488,
  "created_at" : "2015-04-14 02:31:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/csCIvLAp6B",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rDsmR1S6DPQ&list=PL1C8EACC58B956923&index=3",
      "display_url" : "youtube.com\/watch?v=rDsmR1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587800170122711040",
  "text" : "This will probably groove well with you.  Icey Demons https:\/\/t.co\/csCIvLAp6B",
  "id" : 587800170122711040,
  "created_at" : "2015-04-14 02:10:56 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/587799794891894784\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/PH2h99DrN2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CChIzH5UkAAsMdV.png",
      "id_str" : "587799794501849088",
      "id" : 587799794501849088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CChIzH5UkAAsMdV.png",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 1053
      } ],
      "display_url" : "pic.twitter.com\/PH2h99DrN2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587799794891894784",
  "text" : "eww http:\/\/t.co\/PH2h99DrN2",
  "id" : 587799794891894784,
  "created_at" : "2015-04-14 02:09:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene - Our Oakland",
      "screen_name" : "DIYGene",
      "indices" : [ 0, 8 ],
      "id_str" : "90479930",
      "id" : 90479930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587768091473391617",
  "geo" : { },
  "id_str" : "587768576301342720",
  "in_reply_to_user_id" : 90479930,
  "text" : "@DIYGene  yeah its been there for weeks",
  "id" : 587768576301342720,
  "in_reply_to_status_id" : 587768091473391617,
  "created_at" : "2015-04-14 00:05:23 +0000",
  "in_reply_to_screen_name" : "DIYGene",
  "in_reply_to_user_id_str" : "90479930",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/587767544972386305\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/dvSO488fMb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCgrdsIUIAARDkH.jpg",
      "id_str" : "587767540434083840",
      "id" : 587767540434083840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCgrdsIUIAARDkH.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dvSO488fMb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587767544972386305",
  "text" : "Visit Oakland http:\/\/t.co\/dvSO488fMb",
  "id" : 587767544972386305,
  "created_at" : "2015-04-14 00:01:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587749559452860417",
  "geo" : { },
  "id_str" : "587752293627330560",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  most sessions are experimental bogeys, but there remains several dozen algo jams from the past year ready for the light",
  "id" : 587752293627330560,
  "in_reply_to_status_id" : 587749559452860417,
  "created_at" : "2015-04-13 23:00:41 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "spacer.swf",
      "screen_name" : "brianloveswords",
      "indices" : [ 0, 16 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587742342167146496",
  "geo" : { },
  "id_str" : "587747878350667776",
  "in_reply_to_user_id" : 17177251,
  "text" : "@brianloveswords  I call that positional timekeeping.  Music be mostly frequential.  Hours, days, months... notches on the old king's rule!",
  "id" : 587747878350667776,
  "in_reply_to_status_id" : 587742342167146496,
  "created_at" : "2015-04-13 22:43:08 +0000",
  "in_reply_to_screen_name" : "brianloveswords",
  "in_reply_to_user_id_str" : "17177251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587710748928815104",
  "text" : "not sorry if any of my algos or recordings chew up your laptop tweeters",
  "id" : 587710748928815104,
  "created_at" : "2015-04-13 20:15:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587709568035098626",
  "text" : "i'm the best investment your mom ever made.",
  "id" : 587709568035098626,
  "created_at" : "2015-04-13 20:10:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587707747631632384",
  "text" : "im sexy, and willing to accept business proposals from people who want to become financially involved",
  "id" : 587707747631632384,
  "created_at" : "2015-04-13 20:03:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 128, 150 ],
      "url" : "http:\/\/t.co\/6Kyw8SOwJg",
      "expanded_url" : "http:\/\/linkis.com\/grist.org\/business-t\/E2j68",
      "display_url" : "linkis.com\/grist.org\/busi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587698378475081729",
  "text" : "All wealth in the world derives from nature's endowment, which belongs to all life.  But the 1% own &amp; hoard it.  &gt;_&lt;  http:\/\/t.co\/6Kyw8SOwJg",
  "id" : 587698378475081729,
  "created_at" : "2015-04-13 19:26:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 0, 12 ],
      "id_str" : "39952227",
      "id" : 39952227
    }, {
      "name" : "Hugh Kennedy",
      "screen_name" : "hughskennedy",
      "indices" : [ 17, 30 ],
      "id_str" : "338334935",
      "id" : 338334935
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/587660349618262016\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/6hP8aGXFSX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCfJ-VNUwAAm-7N.png",
      "id_str" : "587660349077241856",
      "id" : 587660349077241856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCfJ-VNUwAAm-7N.png",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6hP8aGXFSX"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/587660349618262016\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/6hP8aGXFSX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCfJ-TkUwAAj5Y_.png",
      "id_str" : "587660348636839936",
      "id" : 587660348636839936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCfJ-TkUwAAj5Y_.png",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/6hP8aGXFSX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587660349618262016",
  "in_reply_to_user_id" : 39952227,
  "text" : "@yoshuawuyts and @hughskennedy in the haus. http:\/\/t.co\/6hP8aGXFSX",
  "id" : 587660349618262016,
  "created_at" : "2015-04-13 16:55:20 +0000",
  "in_reply_to_screen_name" : "yoshuawuyts",
  "in_reply_to_user_id_str" : "39952227",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob C Lowe",
      "screen_name" : "jcblw",
      "indices" : [ 0, 6 ],
      "id_str" : "25859082",
      "id" : 25859082
    }, {
      "name" : "City of Santa Monica",
      "screen_name" : "santamonicacity",
      "indices" : [ 7, 23 ],
      "id_str" : "67424923",
      "id" : 67424923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587636930159849472",
  "geo" : { },
  "id_str" : "587657953961844736",
  "in_reply_to_user_id" : 25859082,
  "text" : "@jcblw @santamonicacity  fascists!",
  "id" : 587657953961844736,
  "in_reply_to_status_id" : 587636930159849472,
  "created_at" : "2015-04-13 16:45:49 +0000",
  "in_reply_to_screen_name" : "jcblw",
  "in_reply_to_user_id_str" : "25859082",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587352306347282432",
  "text" : "this one session had a 7 minute prelude of silence, like john cage on javascript.  I was probably in the kitchen, having myself a snack.",
  "id" : 587352306347282432,
  "created_at" : "2015-04-12 20:31:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587350185602379778",
  "text" : "I'm editing live edits.",
  "id" : 587350185602379778,
  "created_at" : "2015-04-12 20:22:51 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587349924439793664",
  "text" : "the bugged version is almost always the better with algorithmic music",
  "id" : 587349924439793664,
  "created_at" : "2015-04-12 20:21:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/laNRz8A8xo",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=c27f05c0287ed2e594f3",
      "display_url" : "requirebin.com\/?gist=c27f05c0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587346598155386882",
  "text" : "I fixed the bug. now it's almost like I'm in yr room live coding exactly as I did 245.6418044 days ago for 48 hours.  http:\/\/t.co\/laNRz8A8xo",
  "id" : 587346598155386882,
  "created_at" : "2015-04-12 20:08:36 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/N36R7QjPS6",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=2baf1a3a04afff102ed1",
      "display_url" : "requirebin.com\/?gist=2baf1a3a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587344380517863424",
  "text" : "I'm writing program to turn my live-coded diffs into auto timed synths. This funky cut is from a bug in that program. http:\/\/t.co\/N36R7QjPS6",
  "id" : 587344380517863424,
  "created_at" : "2015-04-12 19:59:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587340732454809600",
  "text" : "Last night:  I invented a new immutable data type.  It's called futile.",
  "id" : 587340732454809600,
  "created_at" : "2015-04-12 19:45:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Daughter's Army",
      "screen_name" : "MyDaughtersArmy",
      "indices" : [ 3, 19 ],
      "id_str" : "2196201139",
      "id" : 2196201139
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mydaughtersarmy\/status\/586972585105035264\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/pBki5BWf6T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCVYc0hWMAAogmM.jpg",
      "id_str" : "586972578599809024",
      "id" : 586972578599809024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCVYc0hWMAAogmM.jpg",
      "sizes" : [ {
        "h" : 654,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 654,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pBki5BWf6T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587289579851382784",
  "text" : "RT @mydaughtersarmy: What war on women? http:\/\/t.co\/pBki5BWf6T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mydaughtersarmy\/status\/586972585105035264\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/pBki5BWf6T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCVYc0hWMAAogmM.jpg",
        "id_str" : "586972578599809024",
        "id" : 586972578599809024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCVYc0hWMAAogmM.jpg",
        "sizes" : [ {
          "h" : 654,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 654,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pBki5BWf6T"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586972585105035264",
    "text" : "What war on women? http:\/\/t.co\/pBki5BWf6T",
    "id" : 586972585105035264,
    "created_at" : "2015-04-11 19:22:24 +0000",
    "user" : {
      "name" : "My Daughter's Army",
      "screen_name" : "MyDaughtersArmy",
      "protected" : false,
      "id_str" : "2196201139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562051396070289411\/Ivgy9n2R_normal.jpeg",
      "id" : 2196201139,
      "verified" : false
    }
  },
  "id" : 587289579851382784,
  "created_at" : "2015-04-12 16:22:01 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "algorave",
      "indices" : [ 88, 97 ]
    }, {
      "text" : "folk",
      "indices" : [ 98, 103 ]
    }, {
      "text" : "algaewave",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/MVHLjQ4XRd",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/space-wizard",
      "display_url" : "soundcloud.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587088721721237505",
  "text" : "I left a 1:40 prelude on to bounce limp clicks.  also unedited.  this is hecka trippy.  #algorave #folk #algaewave\n\nhttps:\/\/t.co\/MVHLjQ4XRd",
  "id" : 587088721721237505,
  "created_at" : "2015-04-12 03:03:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/MVHLjQ4XRd",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/space-wizard",
      "display_url" : "soundcloud.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586936919356866560",
  "text" : "but let's talk about when your frequency moduation game is so low you make funky drops out of anti-patterns  https:\/\/t.co\/MVHLjQ4XRd",
  "id" : 586936919356866560,
  "created_at" : "2015-04-11 17:00:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586934442830143488",
  "text" : "taylor swift has 50 million followerbots.  But tween slash housewife culture is a shrinking slice of the web &amp; future, so we can ignore it.",
  "id" : 586934442830143488,
  "created_at" : "2015-04-11 16:50:50 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586933603474345986",
  "text" : "The flip side of male boner culture is the likes of taylor swift echoing faded norms as edgy modern mass culture, mostly for girls.",
  "id" : 586933603474345986,
  "created_at" : "2015-04-11 16:47:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586924077056716800",
  "geo" : { },
  "id_str" : "586932118992752640",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt  they coulda used an actual poster or life size cardboard james dean for all that guy represents in the video... and the song.",
  "id" : 586932118992752640,
  "in_reply_to_status_id" : 586924077056716800,
  "created_at" : "2015-04-11 16:41:36 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586930034994053120",
  "text" : "my number one feature request for a social network is to be able wake up any of my mutual friends at any time.",
  "id" : 586930034994053120,
  "created_at" : "2015-04-11 16:33:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586927997283729408",
  "text" : "i know i jus dropped a space detonated F-bomb'n H-bomb, u better play it quick n gimme love, cuz soon I will replaze it with a bass beatdown",
  "id" : 586927997283729408,
  "created_at" : "2015-04-11 16:25:13 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/MVHLjQ4XRd",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/space-wizard",
      "display_url" : "soundcloud.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586925787732807681",
  "text" : "they call me johnny rhythms, johnny sits &amp; spins,\njohnny off in his weird world, space wizard shit\n\nhttps:\/\/t.co\/MVHLjQ4XRd",
  "id" : 586925787732807681,
  "created_at" : "2015-04-11 16:16:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586923893094387712",
  "text" : "RT @TheHatGhost: @johnnyscript I have been with you in some of those vehicles",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "586351677642448897",
    "geo" : { },
    "id_str" : "586923226481102848",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript I have been with you in some of those vehicles",
    "id" : 586923226481102848,
    "in_reply_to_status_id" : 586351677642448897,
    "created_at" : "2015-04-11 16:06:16 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606927351168036864\/lzGOA4HX_normal.jpg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 586923893094387712,
  "created_at" : "2015-04-11 16:08:55 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586917948213760000",
  "text" : "I wrote some cosmic freqy devil ish algo yesterday.  I justly had to name the recording Space Wizard.",
  "id" : 586917948213760000,
  "created_at" : "2015-04-11 15:45:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586915923514167296",
  "text" : "idgafu its hot",
  "id" : 586915923514167296,
  "created_at" : "2015-04-11 15:37:15 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586351677642448897",
  "text" : "they call me johnny lincoln, johnny sing hymns, \njohnny took off with muh automobile, seize him",
  "id" : 586351677642448897,
  "created_at" : "2015-04-10 02:15:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584963768746016769",
  "geo" : { },
  "id_str" : "586243532081467393",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack\n      o   ^__^\n       o  (oo)\\_______\n           (__)\\           )\\\/\\\n                |  |-----w |\n                |  |       |  |",
  "id" : 586243532081467393,
  "in_reply_to_status_id" : 584963768746016769,
  "created_at" : "2015-04-09 19:05:24 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586234342223011843",
  "text" : "meme call these early stage VC induced businesses \"strapons\" from now on.",
  "id" : 586234342223011843,
  "created_at" : "2015-04-09 18:28:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586226263141982209",
  "text" : "good morning glorious!\nthe pitbull is howling to the cluck of chickens.\nsinging choruses to lil orpheus.",
  "id" : 586226263141982209,
  "created_at" : "2015-04-09 17:56:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586220557185585152",
  "text" : "they call me johnny scriptus.  johnny honestly.  johnny say some things that make the audience contemplate.",
  "id" : 586220557185585152,
  "created_at" : "2015-04-09 17:34:06 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585948273099145216",
  "text" : "Altho I love \"kung fu\", GONG FOO I like more, cuz gong means time, and gong also means that thing you hit when ur keeping it cosmic.",
  "id" : 585948273099145216,
  "created_at" : "2015-04-08 23:32:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585947540647849984",
  "text" : "FROM NOW ON ITS GONG FOO WIZARDS",
  "id" : 585947540647849984,
  "created_at" : "2015-04-08 23:29:14 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/fN5zeLojBn",
      "expanded_url" : "https:\/\/twitter.com\/stonesthrow\/status\/585857629081231360",
      "display_url" : "twitter.com\/stonesthrow\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "585867397996748800",
  "text" : "love it! https:\/\/t.co\/fN5zeLojBn",
  "id" : 585867397996748800,
  "created_at" : "2015-04-08 18:10:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WalterScott",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585607057467924481",
  "text" : "Discord between communities and their police is a really low level division, which really helps the upper system keep us down.  #WalterScott",
  "id" : 585607057467924481,
  "created_at" : "2015-04-08 00:56:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WalterScott",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585605834639564800",
  "text" : "Use laws to take guns away from police, immediately.  If they wuss out as a result, true peace keepers will fill their ranks.  #WalterScott",
  "id" : 585605834639564800,
  "created_at" : "2015-04-08 00:51:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585604756162355200",
  "text" : "Tasers are cruel.",
  "id" : 585604756162355200,
  "created_at" : "2015-04-08 00:47:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WalterScott",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585604675115868161",
  "text" : "Until laws are reigned in, which will probably never be, domestic security and protection officers can't have deadly weapons.  #WalterScott",
  "id" : 585604675115868161,
  "created_at" : "2015-04-08 00:46:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WalterScott",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585603079166373889",
  "text" : "It started because a police man stopped a person under the legal pretense of A BROKEN TAIL LIGHT\n\n#WalterScott",
  "id" : 585603079166373889,
  "created_at" : "2015-04-08 00:40:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/E5bcWYplFw",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/cease-speaking-evil",
      "display_url" : "soundcloud.com\/folkstack\/ceas\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "585586614434471936",
  "geo" : { },
  "id_str" : "585586966160416768",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  aaaand my bass and drums rerecording of same https:\/\/t.co\/E5bcWYplFw",
  "id" : 585586966160416768,
  "in_reply_to_status_id" : 585586614434471936,
  "created_at" : "2015-04-07 23:36:27 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/USZmLwOgmY",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=mtaqWGySmZY",
      "display_url" : "youtube.com\/watch?v=mtaqWG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "585586614434471936",
  "text" : "stop speaking bad  https:\/\/t.co\/USZmLwOgmY",
  "id" : 585586614434471936,
  "created_at" : "2015-04-07 23:35:03 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 3, 14 ],
      "id_str" : "14236976",
      "id" : 14236976
    }, {
      "name" : "Alan Wolke W2AEW",
      "screen_name" : "AlanAtTek",
      "indices" : [ 139, 140 ],
      "id_str" : "57210865",
      "id" : 57210865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585585716308115456",
  "text" : "RT @ToddBailey: I had hand surgery today; am basically useless for a hot minute. Pls recommend long engineering documentaries lest I watch \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alan Wolke W2AEW",
        "screen_name" : "AlanAtTek",
        "indices" : [ 123, 133 ],
        "id_str" : "57210865",
        "id" : 57210865
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585573111116001282",
    "text" : "I had hand surgery today; am basically useless for a hot minute. Pls recommend long engineering documentaries lest I watch @AlanAtTek reruns",
    "id" : 585573111116001282,
    "created_at" : "2015-04-07 22:41:23 +0000",
    "user" : {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "protected" : false,
      "id_str" : "14236976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502885261\/TB_Cropped_5_normal.jpg",
      "id" : 14236976,
      "verified" : false
    }
  },
  "id" : 585585716308115456,
  "created_at" : "2015-04-07 23:31:29 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 0, 10 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585548060857671681",
  "geo" : { },
  "id_str" : "585561951155179523",
  "in_reply_to_user_id" : 14529356,
  "text" : "@postcrunk  *deep movie preview voice*  The True Culture War is about to begin...",
  "id" : 585561951155179523,
  "in_reply_to_status_id" : 585548060857671681,
  "created_at" : "2015-04-07 21:57:03 +0000",
  "in_reply_to_screen_name" : "postcrunk",
  "in_reply_to_user_id_str" : "14529356",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 6, 19 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585548319595896833",
  "text" : "Bored @johnnyscript inverting the mousetrap mechanism to fling the rodent thru a nearby open window",
  "id" : 585548319595896833,
  "created_at" : "2015-04-07 21:02:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/modulhaus3000\/status\/585526481926905859\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/4Ky6ss1EXp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCA1O3cWAAApU31.png",
      "id_str" : "585526481075437568",
      "id" : 585526481075437568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCA1O3cWAAApU31.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 135,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 1501
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4Ky6ss1EXp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585528589174603777",
  "text" : "RT @modulhaus3000: http:\/\/t.co\/4Ky6ss1EXp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/modulhaus3000\/status\/585526481926905859\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/4Ky6ss1EXp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCA1O3cWAAApU31.png",
        "id_str" : "585526481075437568",
        "id" : 585526481075437568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCA1O3cWAAApU31.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 135,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 597,
          "resize" : "fit",
          "w" : 1501
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4Ky6ss1EXp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585526481926905859",
    "text" : "http:\/\/t.co\/4Ky6ss1EXp",
    "id" : 585526481926905859,
    "created_at" : "2015-04-07 19:36:06 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 585528589174603777,
  "created_at" : "2015-04-07 19:44:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/modulhaus3000\/status\/585524082277486592\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/kuMWp7AY9I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCAzDLHWEAA3TVR.png",
      "id_str" : "585524081174384640",
      "id" : 585524081174384640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCAzDLHWEAA3TVR.png",
      "sizes" : [ {
        "h" : 797,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kuMWp7AY9I"
    } ],
    "hashtags" : [ {
      "text" : "LEBRON",
      "indices" : [ 23, 30 ]
    }, {
      "text" : "leveldb",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "browserify",
      "indices" : [ 57, 68 ]
    }, {
      "text" : "npm",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585528571873120256",
  "text" : "RT @modulhaus3000: The #LEBRON technology stack #leveldb #browserify #npm always wins http:\/\/t.co\/kuMWp7AY9I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/modulhaus3000\/status\/585524082277486592\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/kuMWp7AY9I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCAzDLHWEAA3TVR.png",
        "id_str" : "585524081174384640",
        "id" : 585524081174384640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCAzDLHWEAA3TVR.png",
        "sizes" : [ {
          "h" : 797,
          "resize" : "fit",
          "w" : 1201
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kuMWp7AY9I"
      } ],
      "hashtags" : [ {
        "text" : "LEBRON",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "leveldb",
        "indices" : [ 29, 37 ]
      }, {
        "text" : "browserify",
        "indices" : [ 38, 49 ]
      }, {
        "text" : "npm",
        "indices" : [ 50, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585524082277486592",
    "text" : "The #LEBRON technology stack #leveldb #browserify #npm always wins http:\/\/t.co\/kuMWp7AY9I",
    "id" : 585524082277486592,
    "created_at" : "2015-04-07 19:26:34 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 585528571873120256,
  "created_at" : "2015-04-07 19:44:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585488402876911617",
  "text" : "training others in wizardry puts my own skills in relief and makes me feel powerful.",
  "id" : 585488402876911617,
  "created_at" : "2015-04-07 17:04:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585488153814949890",
  "text" : "I train people in martial and mental arts.",
  "id" : 585488153814949890,
  "created_at" : "2015-04-07 17:03:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585247813958819840",
  "geo" : { },
  "id_str" : "585257557960175616",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  negative.  did you see my email?",
  "id" : 585257557960175616,
  "in_reply_to_status_id" : 585247813958819840,
  "created_at" : "2015-04-07 01:47:30 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585217744204869634",
  "geo" : { },
  "id_str" : "585218112489947136",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  I had to remind the old guy we were legal while he rolled it.  He siad, That's right I gotta remove these chains.",
  "id" : 585218112489947136,
  "in_reply_to_status_id" : 585217744204869634,
  "created_at" : "2015-04-06 23:10:45 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585217744204869634",
  "text" : "The war on drugs didn't let you give a 60 y.o. black man some humboldt flower while ya sat and talked on the bench in front of the bakery.",
  "id" : 585217744204869634,
  "created_at" : "2015-04-06 23:09:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "indices" : [ 3, 11 ],
      "id_str" : "885173964",
      "id" : 885173964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Snowden",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/VGgjKwVEKy",
      "expanded_url" : "https:\/\/vine.co\/v\/eBBvedaHtBz\/",
      "display_url" : "vine.co\/v\/eBBvedaHtBz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "585204470713286659",
  "text" : "RT @jerquee: NYC Parks Dept. literally stepping on the head of Bald Eagle to cover up Ed #Snowden statue https:\/\/t.co\/VGgjKwVEKy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Snowden",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/VGgjKwVEKy",
        "expanded_url" : "https:\/\/vine.co\/v\/eBBvedaHtBz\/",
        "display_url" : "vine.co\/v\/eBBvedaHtBz\/"
      } ]
    },
    "geo" : { },
    "id_str" : "585189096584253441",
    "text" : "NYC Parks Dept. literally stepping on the head of Bald Eagle to cover up Ed #Snowden statue https:\/\/t.co\/VGgjKwVEKy",
    "id" : 585189096584253441,
    "created_at" : "2015-04-06 21:15:27 +0000",
    "user" : {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "protected" : false,
      "id_str" : "885173964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2879740670\/3705297a3d36fce362afdd93a090a3ea_normal.jpeg",
      "id" : 885173964,
      "verified" : false
    }
  },
  "id" : 585204470713286659,
  "created_at" : "2015-04-06 22:16:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585202952505270272",
  "text" : "RT @dominictarr: @johnnyscript TEACH OR BE TAUGHT!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "585154254735826944",
    "geo" : { },
    "id_str" : "585183729238155265",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript TEACH OR BE TAUGHT!",
    "id" : 585183729238155265,
    "in_reply_to_status_id" : 585154254735826944,
    "created_at" : "2015-04-06 20:54:07 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712569197126160384\/nvnXBzt-_normal.jpg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 585202952505270272,
  "created_at" : "2015-04-06 22:10:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wizard",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585157320356847616",
  "text" : "RT @nexxylove: I am a #wizard.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wizard",
        "indices" : [ 7, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585155327181455360",
    "text" : "I am a #wizard.",
    "id" : 585155327181455360,
    "created_at" : "2015-04-06 19:01:16 +0000",
    "user" : {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719047162793828353\/ilHIszOy_normal.jpg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 585157320356847616,
  "created_at" : "2015-04-06 19:09:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585154254735826944",
  "text" : "Those who can't teach, get told what to do.",
  "id" : 585154254735826944,
  "created_at" : "2015-04-06 18:57:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nodeconf",
      "screen_name" : "nodeconf",
      "indices" : [ 0, 9 ],
      "id_str" : "186697923",
      "id" : 186697923
    }, {
      "name" : "Ben Michel",
      "screen_name" : "obensource",
      "indices" : [ 10, 21 ],
      "id_str" : "407296703",
      "id" : 407296703
    }, {
      "name" : "Omni Commons",
      "screen_name" : "omnicommons",
      "indices" : [ 86, 98 ],
      "id_str" : "2476635312",
      "id" : 2476635312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585109591001665536",
  "geo" : { },
  "id_str" : "585112001137008640",
  "in_reply_to_user_id" : 186697923,
  "text" : "@nodeconf @obensource  WAIT you could move it the glorious, cheap, community ballroom @omnicommons",
  "id" : 585112001137008640,
  "in_reply_to_status_id" : 585109591001665536,
  "created_at" : "2015-04-06 16:09:06 +0000",
  "in_reply_to_screen_name" : "nodeconf",
  "in_reply_to_user_id_str" : "186697923",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585102608764956672",
  "text" : "are there any browser based img\/canvas-to-video rendering modules?",
  "id" : 585102608764956672,
  "created_at" : "2015-04-06 15:31:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584920605788475392",
  "text" : "a wizard, a true dogmonkey goatcrab, middlename lizard.",
  "id" : 584920605788475392,
  "created_at" : "2015-04-06 03:28:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/kWcib5rEjQ",
      "expanded_url" : "http:\/\/www.parisdjs.com\/index.php\/post\/Greenwood-Rhythm-Coalition-Sol-Vibrations",
      "display_url" : "parisdjs.com\/index.php\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584791531078299648",
  "text" : "i love this mix  http:\/\/t.co\/kWcib5rEjQ  [direct audio link toward bottom]",
  "id" : 584791531078299648,
  "created_at" : "2015-04-05 18:55:40 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584789476834017280",
  "text" : "last week I recorded the diffs for my 666th live coded music session",
  "id" : 584789476834017280,
  "created_at" : "2015-04-05 18:47:30 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584788344766345217",
  "geo" : { },
  "id_str" : "584788856064475136",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  it's brighter out west bruh see you space cowboy",
  "id" : 584788856064475136,
  "in_reply_to_status_id" : 584788344766345217,
  "created_at" : "2015-04-05 18:45:02 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584787882289815552",
  "geo" : { },
  "id_str" : "584788100968120320",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  HAS DISCOVERED TIME TRAVEL ASK HIM FOR ALL HIS WEIRD SECRETS",
  "id" : 584788100968120320,
  "in_reply_to_status_id" : 584787882289815552,
  "created_at" : "2015-04-05 18:42:02 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "folkstack",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584787438368923648",
  "geo" : { },
  "id_str" : "584787824408264704",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  can I use 1:11 for my next #folkstack track art?",
  "id" : 584787824408264704,
  "in_reply_to_status_id" : 584787438368923648,
  "created_at" : "2015-04-05 18:40:56 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584786954723713024",
  "geo" : { },
  "id_str" : "584787302087462913",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  i'm in the first zone",
  "id" : 584787302087462913,
  "in_reply_to_status_id" : 584786954723713024,
  "created_at" : "2015-04-05 18:38:52 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 3, 14 ],
      "id_str" : "17092251",
      "id" : 17092251
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 16, 29 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whichlight\/status\/584785496976535552\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/McmMg9yD8m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB2TT22UsAAS05E.png",
      "id_str" : "584785495978192896",
      "id" : 584785495978192896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB2TT22UsAAS05E.png",
      "sizes" : [ {
        "h" : 478,
        "resize" : "fit",
        "w" : 668
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 668
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/McmMg9yD8m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584786621418971138",
  "text" : "RT @whichlight: @johnnyscript http:\/\/t.co\/McmMg9yD8m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/whichlight\/status\/584785496976535552\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/McmMg9yD8m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB2TT22UsAAS05E.png",
        "id_str" : "584785495978192896",
        "id" : 584785495978192896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB2TT22UsAAS05E.png",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 668
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 668
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/McmMg9yD8m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "584784838382587904",
    "geo" : { },
    "id_str" : "584785496976535552",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript http:\/\/t.co\/McmMg9yD8m",
    "id" : 584785496976535552,
    "in_reply_to_status_id" : 584784838382587904,
    "created_at" : "2015-04-05 18:31:41 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "protected" : false,
      "id_str" : "17092251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582894470452133888\/uBlV4V8-_normal.jpg",
      "id" : 17092251,
      "verified" : false
    }
  },
  "id" : 584786621418971138,
  "created_at" : "2015-04-05 18:36:10 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584784458060062720",
  "geo" : { },
  "id_str" : "584786424781672449",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  \nwe can discuss the time when all that remains of us is a diminishing signal.  \n\n*looks into your eyes*  \n\nLETS MAKE SOME NOISE",
  "id" : 584786424781672449,
  "in_reply_to_status_id" : 584784458060062720,
  "created_at" : "2015-04-05 18:35:23 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584784251029217280",
  "geo" : { },
  "id_str" : "584784838382587904",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  it's just you and me here!",
  "id" : 584784838382587904,
  "in_reply_to_status_id" : 584784251029217280,
  "created_at" : "2015-04-05 18:29:04 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584784251029217280",
  "geo" : { },
  "id_str" : "584784555921387520",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  ok LETS DO THIS.  What do you want to talk about?  WHAT IS BURNING?",
  "id" : 584784555921387520,
  "in_reply_to_status_id" : 584784251029217280,
  "created_at" : "2015-04-05 18:27:57 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584780866754375680",
  "geo" : { },
  "id_str" : "584783758508761089",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  a color clock means I actually have to look at a clock tho",
  "id" : 584783758508761089,
  "in_reply_to_status_id" : 584780866754375680,
  "created_at" : "2015-04-05 18:24:47 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 13, 24 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584783529055092736",
  "text" : "Anybody know @whichlight it is?  Can you give that to me in milliseconds since the dawn of the 70s?",
  "id" : 584783529055092736,
  "created_at" : "2015-04-05 18:23:52 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BRAINFEEDER",
      "screen_name" : "BRAINFEEDER",
      "indices" : [ 0, 12 ],
      "id_str" : "31620747",
      "id" : 31620747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584780121531256832",
  "in_reply_to_user_id" : 31620747,
  "text" : "@BRAINFEEDER yr site is still down.  perhaps I can help.",
  "id" : 584780121531256832,
  "created_at" : "2015-04-05 18:10:20 +0000",
  "in_reply_to_screen_name" : "BRAINFEEDER",
  "in_reply_to_user_id_str" : "31620747",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584773030036934656",
  "text" : "RT @postcrunk: there is no moral high ground between eating factory farm meat and fruits and vegetables harvested by slave labor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584769973869912064",
    "text" : "there is no moral high ground between eating factory farm meat and fruits and vegetables harvested by slave labor",
    "id" : 584769973869912064,
    "created_at" : "2015-04-05 17:30:00 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 584773030036934656,
  "created_at" : "2015-04-05 17:42:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 3, 10 ],
      "id_str" : "291901937",
      "id" : 291901937
    }, {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 12, 19 ],
      "id_str" : "291901937",
      "id" : 291901937
    }, {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 39, 52 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "folkstack",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584577568990339072",
  "text" : "RT @LB2045: @LB2045 I'd love to hear a @johnnyscript #folkstack mangling of this",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lesley Bell",
        "screen_name" : "LB2045",
        "indices" : [ 0, 7 ],
        "id_str" : "291901937",
        "id" : 291901937
      }, {
        "name" : "johnny tha bodt",
        "screen_name" : "johnnyscript",
        "indices" : [ 27, 40 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "folkstack",
        "indices" : [ 41, 51 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "584564025272377345",
    "geo" : { },
    "id_str" : "584566399382597632",
    "in_reply_to_user_id" : 291901937,
    "text" : "@LB2045 I'd love to hear a @johnnyscript #folkstack mangling of this",
    "id" : 584566399382597632,
    "in_reply_to_status_id" : 584564025272377345,
    "created_at" : "2015-04-05 04:01:04 +0000",
    "in_reply_to_screen_name" : "LB2045",
    "in_reply_to_user_id_str" : "291901937",
    "user" : {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "protected" : false,
      "id_str" : "291901937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524991844514418688\/hPkExiIp_normal.jpeg",
      "id" : 291901937,
      "verified" : false
    }
  },
  "id" : 584577568990339072,
  "created_at" : "2015-04-05 04:45:28 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chorizo",
      "screen_name" : "tupactopus",
      "indices" : [ 3, 14 ],
      "id_str" : "1317798079",
      "id" : 1317798079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584572095192965121",
  "text" : "RT @tupactopus: hi im jesus *resurrects* n ur watching disney channel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klinkerapps.com\" rel=\"nofollow\"\u003ETalon (Classic)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584533430991355904",
    "text" : "hi im jesus *resurrects* n ur watching disney channel",
    "id" : 584533430991355904,
    "created_at" : "2015-04-05 01:50:04 +0000",
    "user" : {
      "name" : "Chorizo",
      "screen_name" : "tupactopus",
      "protected" : false,
      "id_str" : "1317798079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3454956179\/fee6436c1a4f2ea222512553370a270b_normal.jpeg",
      "id" : 1317798079,
      "verified" : false
    }
  },
  "id" : 584572095192965121,
  "created_at" : "2015-04-05 04:23:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584570100197363712",
  "text" : "whoa ho ho, in chrome dev tools &gt; network you can right-click copy a request as curl command.",
  "id" : 584570100197363712,
  "created_at" : "2015-04-05 04:15:47 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/PvVXQ1SDLn",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=tPVJ8sXcljU",
      "display_url" : "youtube.com\/watch?v=tPVJ8s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584509836064350209",
  "geo" : { },
  "id_str" : "584512972157915136",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey  im ready like https:\/\/t.co\/PvVXQ1SDLn",
  "id" : 584512972157915136,
  "in_reply_to_status_id" : 584509836064350209,
  "created_at" : "2015-04-05 00:28:46 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 0, 11 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584499795399553024",
  "geo" : { },
  "id_str" : "584504843198271489",
  "in_reply_to_user_id" : 14236976,
  "text" : "@ToddBailey  this is exceptional",
  "id" : 584504843198271489,
  "in_reply_to_status_id" : 584499795399553024,
  "created_at" : "2015-04-04 23:56:28 +0000",
  "in_reply_to_screen_name" : "ToddBailey",
  "in_reply_to_user_id_str" : "14236976",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 3, 14 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ToddBailey\/status\/584499795399553024\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dILtAKzv6P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CByPdkoVIAAph8y.jpg",
      "id_str" : "584499789863133184",
      "id" : 584499789863133184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CByPdkoVIAAph8y.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dILtAKzv6P"
    } ],
    "hashtags" : [ {
      "text" : "DontWantNoneDontStartNone",
      "indices" : [ 104, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584503344678342656",
  "text" : "RT @ToddBailey: Peoples' Vector Game finally free of capitalist chains and external computer hardware.  #DontWantNoneDontStartNone http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ToddBailey\/status\/584499795399553024\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/dILtAKzv6P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CByPdkoVIAAph8y.jpg",
        "id_str" : "584499789863133184",
        "id" : 584499789863133184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CByPdkoVIAAph8y.jpg",
        "sizes" : [ {
          "h" : 1032,
          "resize" : "fit",
          "w" : 774
        }, {
          "h" : 1032,
          "resize" : "fit",
          "w" : 774
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dILtAKzv6P"
      } ],
      "hashtags" : [ {
        "text" : "DontWantNoneDontStartNone",
        "indices" : [ 88, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584499795399553024",
    "text" : "Peoples' Vector Game finally free of capitalist chains and external computer hardware.  #DontWantNoneDontStartNone http:\/\/t.co\/dILtAKzv6P",
    "id" : 584499795399553024,
    "created_at" : "2015-04-04 23:36:25 +0000",
    "user" : {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "protected" : false,
      "id_str" : "14236976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502885261\/TB_Cropped_5_normal.jpg",
      "id" : 14236976,
      "verified" : false
    }
  },
  "id" : 584503344678342656,
  "created_at" : "2015-04-04 23:50:31 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584370773755834368",
  "geo" : { },
  "id_str" : "584408184623738880",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt  WHAT ARE YOU TRYING TO COMMUNICATE",
  "id" : 584408184623738880,
  "in_reply_to_status_id" : 584370773755834368,
  "created_at" : "2015-04-04 17:32:23 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/584264816715366401\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/FcsypQAcyY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBu5wM6VIAI22k_.jpg",
      "id_str" : "584264814425350146",
      "id" : 584264814425350146,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBu5wM6VIAI22k_.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FcsypQAcyY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584264816715366401",
  "text" : "Big baby bubba http:\/\/t.co\/FcsypQAcyY",
  "id" : 584264816715366401,
  "created_at" : "2015-04-04 08:02:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/584262163130220546\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/lV8PmC6tU2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBu3V2yVIAEHniw.png",
      "id_str" : "584262162786361345",
      "id" : 584262162786361345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBu3V2yVIAEHniw.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 959
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 959
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lV8PmC6tU2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584262163130220546",
  "text" : "sine of the devil? http:\/\/t.co\/lV8PmC6tU2",
  "id" : 584262163130220546,
  "created_at" : "2015-04-04 07:52:09 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584262100739993601",
  "text" : "damnit those were clean",
  "id" : 584262100739993601,
  "created_at" : "2015-04-04 07:51:54 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/584253817065050113\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/ujbwhxRtaS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBuvvyGVEAAvyhl.jpg",
      "id_str" : "584253812111642624",
      "id" : 584253812111642624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBuvvyGVEAAvyhl.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ujbwhxRtaS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584253817065050113",
  "text" : "We've all been here http:\/\/t.co\/ujbwhxRtaS",
  "id" : 584253817065050113,
  "created_at" : "2015-04-04 07:18:59 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BRAINFEEDER",
      "screen_name" : "BRAINFEEDER",
      "indices" : [ 0, 12 ],
      "id_str" : "31620747",
      "id" : 31620747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584210204033617921",
  "in_reply_to_user_id" : 31620747,
  "text" : "@BRAINFEEDER yr site is down",
  "id" : 584210204033617921,
  "created_at" : "2015-04-04 04:25:41 +0000",
  "in_reply_to_screen_name" : "BRAINFEEDER",
  "in_reply_to_user_id_str" : "31620747",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold River",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584129078451658752",
  "geo" : { },
  "id_str" : "584132064804384769",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt  he survived the titanic but not you kid",
  "id" : 584132064804384769,
  "in_reply_to_status_id" : 584129078451658752,
  "created_at" : "2015-04-03 23:15:11 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584131833417175040",
  "text" : "my computer's been crashing, and every time I recover browser tabs, more and more live algorithms at once kick into musical action.",
  "id" : 584131833417175040,
  "created_at" : "2015-04-03 23:14:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584103707479945216",
  "geo" : { },
  "id_str" : "584105771719266304",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  and in every one of muh tweets LIKE A BOSS.  \n\njk i don't anything LIKE A BOSS cuz that analogy is antithetical &amp; im sensitive",
  "id" : 584105771719266304,
  "in_reply_to_status_id" : 584103707479945216,
  "created_at" : "2015-04-03 21:30:42 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584097547804811264",
  "geo" : { },
  "id_str" : "584102548899889152",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  I asserted my burly profile into the feedback",
  "id" : 584102548899889152,
  "in_reply_to_status_id" : 584097547804811264,
  "created_at" : "2015-04-03 21:17:54 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584100617838178304",
  "geo" : { },
  "id_str" : "584101641390919680",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr you go ahead and drop the mic on that one",
  "id" : 584101641390919680,
  "in_reply_to_status_id" : 584100617838178304,
  "created_at" : "2015-04-03 21:14:18 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/584092590380752896\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/onEwMuoSwi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBsdHKPUEAEk3nF.jpg",
      "id_str" : "584092585519484929",
      "id" : 584092585519484929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBsdHKPUEAEk3nF.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/onEwMuoSwi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584092590380752896",
  "text" : "It's sansculottes season.  Unless u chill in a climate controlled office all day. http:\/\/t.co\/onEwMuoSwi",
  "id" : 584092590380752896,
  "created_at" : "2015-04-03 20:38:20 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584091785292460033",
  "text" : "I don't always choose a visual medium, but when I do, I usually choose my selfie.",
  "id" : 584091785292460033,
  "created_at" : "2015-04-03 20:35:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/584089459882266624\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Z5k53NG1pv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBsaPjaUsAAuOT8.jpg",
      "id_str" : "584089431180619776",
      "id" : 584089431180619776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBsaPjaUsAAuOT8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Z5k53NG1pv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584089459882266624",
  "text" : "The day way more better &amp; productive when I begin with martial arts, proceed to a pure form, and then do the mental. http:\/\/t.co\/Z5k53NG1pv",
  "id" : 584089459882266624,
  "created_at" : "2015-04-03 20:25:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584083423645474816",
  "geo" : { },
  "id_str" : "584083843218448386",
  "in_reply_to_user_id" : 46961216,
  "text" : "@nexxylove cuz they will never get it right",
  "id" : 584083843218448386,
  "in_reply_to_status_id" : 584083423645474816,
  "created_at" : "2015-04-03 20:03:34 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584081758011822080",
  "geo" : { },
  "id_str" : "584083423645474816",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove this made me think we should design open UX antiharass protocols for these social cloisternet inc. boycott em to implement as UI.",
  "id" : 584083423645474816,
  "in_reply_to_status_id" : 584081758011822080,
  "created_at" : "2015-04-03 20:01:54 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584081470018363392",
  "text" : "ICYMI your pet creatures behold you as divinely magnificent and beautiful.",
  "id" : 584081470018363392,
  "created_at" : "2015-04-03 19:54:08 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/584078529064599552\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/L9nTnvEYw1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBsQUlAUsAAb12Z.jpg",
      "id_str" : "584078522391506944",
      "id" : 584078522391506944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBsQUlAUsAAb12Z.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/L9nTnvEYw1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584078529064599552",
  "text" : "Say hello to my little bear http:\/\/t.co\/L9nTnvEYw1",
  "id" : 584078529064599552,
  "created_at" : "2015-04-03 19:42:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584072767328231424",
  "text" : "RT @modulhaus3000: Are you OSS dev with an idea or project that might make a good crowdfund, but don't wanna do it solo?  Perhaps we can he\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584065595110367232",
    "text" : "Are you OSS dev with an idea or project that might make a good crowdfund, but don't wanna do it solo?  Perhaps we can help!",
    "id" : 584065595110367232,
    "created_at" : "2015-04-03 18:51:03 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 584072767328231424,
  "created_at" : "2015-04-03 19:19:33 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/584071781591322624\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/epKY4z3HcQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBsKMDSVEAAir7p.jpg",
      "id_str" : "584071778831503360",
      "id" : 584071778831503360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBsKMDSVEAAir7p.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/epKY4z3HcQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584071781591322624",
  "text" : "This long range hi frequency megamicrophone appeared on my doorstep last night! http:\/\/t.co\/epKY4z3HcQ",
  "id" : 584071781591322624,
  "created_at" : "2015-04-03 19:15:38 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/LeFemO8R2l",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/lotr-the-missing-poop-break-montages",
      "display_url" : "soundcloud.com\/folkstack\/lotr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584068376336564225",
  "text" : "Ah a babbling creek a burbling brook &amp; other things of that nature, &amp; other natures derived from a greater nature  https:\/\/t.co\/LeFemO8R2l",
  "id" : 584068376336564225,
  "created_at" : "2015-04-03 19:02:07 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "april glaser",
      "screen_name" : "aprilaser",
      "indices" : [ 0, 10 ],
      "id_str" : "210056653",
      "id" : 210056653
    }, {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "indices" : [ 11, 19 ],
      "id_str" : "885173964",
      "id" : 885173964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584066337036566529",
  "geo" : { },
  "id_str" : "584066980262490112",
  "in_reply_to_user_id" : 210056653,
  "text" : "@aprilaser @jerquee ha good one!",
  "id" : 584066980262490112,
  "in_reply_to_status_id" : 584066337036566529,
  "created_at" : "2015-04-03 18:56:34 +0000",
  "in_reply_to_screen_name" : "aprilaser",
  "in_reply_to_user_id_str" : "210056653",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584053859623903232",
  "text" : "all unwanted advertising and promotion is psychic violence",
  "id" : 584053859623903232,
  "created_at" : "2015-04-03 18:04:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "indices" : [ 3, 13 ],
      "id_str" : "14529356",
      "id" : 14529356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584053141122875392",
  "text" : "RT @postcrunk: everything we think we know about reality is just a thorough public relations campaign",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584052746363469825",
    "text" : "everything we think we know about reality is just a thorough public relations campaign",
    "id" : 584052746363469825,
    "created_at" : "2015-04-03 18:00:00 +0000",
    "user" : {
      "name" : "lord crunkington III",
      "screen_name" : "postcrunk",
      "protected" : false,
      "id_str" : "14529356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2509015830\/1z069osgm8dqx8b63x5i_normal.png",
      "id" : 14529356,
      "verified" : false
    }
  },
  "id" : 584053141122875392,
  "created_at" : "2015-04-03 18:01:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584052348932132864",
  "text" : "auto play of audio and video ads is violence",
  "id" : 584052348932132864,
  "created_at" : "2015-04-03 17:58:25 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "algowave",
      "indices" : [ 116, 125 ]
    }, {
      "text" : "algowave",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Y7A4h9EULJ",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/johnny-modulator",
      "display_url" : "soundcloud.com\/folkstack\/john\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584040523754639360",
  "text" : "are levels too low on this?  they sounds lower than when I published it yesterday. bubba.  https:\/\/t.co\/Y7A4h9EULJ  #algowave #algowave",
  "id" : 584040523754639360,
  "created_at" : "2015-04-03 17:11:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/Y7A4h9EULJ",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/johnny-modulator",
      "display_url" : "soundcloud.com\/folkstack\/john\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584039881216626689",
  "text" : "the new hit right here https:\/\/t.co\/Y7A4h9EULJ",
  "id" : 584039881216626689,
  "created_at" : "2015-04-03 17:08:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584039015533281280",
  "text" : "algorithms make an excellent 3rd bandmate",
  "id" : 584039015533281280,
  "created_at" : "2015-04-03 17:05:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584020600521297920",
  "text" : "I had to watch a commercial on youtube to watch a commercial on youtube",
  "id" : 584020600521297920,
  "created_at" : "2015-04-03 15:52:16 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/T59VKqJeZO",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Wgm5GUo8o7I",
      "display_url" : "youtube.com\/watch?v=Wgm5GU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584020125310853121",
  "text" : "riddley scott's cyberpunk coca cola commercial\n\nhttps:\/\/t.co\/T59VKqJeZO",
  "id" : 584020125310853121,
  "created_at" : "2015-04-03 15:50:23 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psychedelic",
      "indices" : [ 71, 83 ]
    }, {
      "text" : "psyche",
      "indices" : [ 84, 91 ]
    }, {
      "text" : "psyfi",
      "indices" : [ 92, 98 ]
    }, {
      "text" : "bass",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "guitar",
      "indices" : [ 105, 112 ]
    }, {
      "text" : "algorithms",
      "indices" : [ 113, 124 ]
    }, {
      "text" : "algorave",
      "indices" : [ 125, 134 ]
    }, {
      "text" : "you",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/nNzEIanJV1",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/surfin-george",
      "display_url" : "soundcloud.com\/folkstack\/surf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583843290862243840",
  "text" : "drums, guitar on homecoded effect synth what\n\nhttps:\/\/t.co\/nNzEIanJV1\n\n#psychedelic #psyche #psyfi #bass #guitar #algorithms #algorave #you",
  "id" : 583843290862243840,
  "created_at" : "2015-04-03 04:07:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583815818565328896",
  "text" : "I miss my Guitarai",
  "id" : 583815818565328896,
  "created_at" : "2015-04-03 02:18:32 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583815683835883520",
  "text" : "that was a fun warm up",
  "id" : 583815683835883520,
  "created_at" : "2015-04-03 02:18:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "algorave",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "algowave",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "freak",
      "indices" : [ 45, 51 ]
    }, {
      "text" : "fmsynth",
      "indices" : [ 52, 60 ]
    }, {
      "text" : "livecode",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "folkstack",
      "indices" : [ 71, 81 ]
    }, {
      "text" : "audio",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "javascript",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Y7A4h9njUb",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/johnny-modulator",
      "display_url" : "soundcloud.com\/folkstack\/john\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583815353744109568",
  "text" : "https:\/\/t.co\/Y7A4h9njUb\n\n#algorave #algowave #freak #fmsynth #livecode #folkstack #audio  #javascript (yup)",
  "id" : 583815353744109568,
  "created_at" : "2015-04-03 02:16:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "algorave",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Y7A4h9njUb",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/johnny-modulator",
      "display_url" : "soundcloud.com\/folkstack\/john\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583814021041758208",
  "text" : "Liner notes:  Pick a middle point if you are impatient, cuz real time buildup... Actually sane levels!\n\nhttps:\/\/t.co\/Y7A4h9njUb\n\n#algorave",
  "id" : 583814021041758208,
  "created_at" : "2015-04-03 02:11:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583811013318995969",
  "text" : "I got muh micros workin",
  "id" : 583811013318995969,
  "created_at" : "2015-04-03 01:59:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583810764055666688",
  "text" : "I just cut loose hammering drums over a neat algorithm, unedited upload coming upload coming upload coming upload coming upload coming uplo",
  "id" : 583810764055666688,
  "created_at" : "2015-04-03 01:58:27 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583790185839665152",
  "text" : "[What you are going to do tomorrow, do today,\nWhat you are going to do today, do now]\n.unshift(What you are going to someday, do tomorrow)",
  "id" : 583790185839665152,
  "created_at" : "2015-04-03 00:36:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583789230817583104",
  "geo" : { },
  "id_str" : "583789442671849472",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  pretty soon you will have to build the auto diff playback synth",
  "id" : 583789442671849472,
  "in_reply_to_status_id" : 583789230817583104,
  "created_at" : "2015-04-03 00:33:44 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583789230817583104",
  "geo" : { },
  "id_str" : "583789347192713216",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  besides storing the diffs",
  "id" : 583789347192713216,
  "in_reply_to_status_id" : 583789230817583104,
  "created_at" : "2015-04-03 00:33:21 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583789230817583104",
  "text" : "i should be recording this",
  "id" : 583789230817583104,
  "created_at" : "2015-04-03 00:32:53 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/ZB1GgquVUf",
      "expanded_url" : "http:\/\/node.module.club",
      "display_url" : "node.module.club"
    }, {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ZMNBbfgwre",
      "expanded_url" : "https:\/\/github.com\/NHQ\/jsynth-script-node\/tree\/allone",
      "display_url" : "github.com\/NHQ\/jsynth-scr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583782454902726656",
  "text" : "the code for http:\/\/t.co\/ZB1GgquVUf is here: https:\/\/t.co\/ZMNBbfgwre  \n\ncheckout allone",
  "id" : 583782454902726656,
  "created_at" : "2015-04-03 00:05:58 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/OclrAC55jR",
      "expanded_url" : "http:\/\/requirebin.com",
      "display_url" : "requirebin.com"
    }, {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/ZB1GgquVUf",
      "expanded_url" : "http:\/\/node.module.club",
      "display_url" : "node.module.club"
    } ]
  },
  "geo" : { },
  "id_str" : "583782063599259649",
  "text" : "Did you know all http:\/\/t.co\/OclrAC55jR code works in http:\/\/t.co\/ZB1GgquVUf?  Diffs are:  shift-enter to compile changes, and no html body.",
  "id" : 583782063599259649,
  "created_at" : "2015-04-03 00:04:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583776375636561920",
  "text" : "I'm the bastard son of digital synthesis and natural beauty.",
  "id" : 583776375636561920,
  "created_at" : "2015-04-02 23:41:48 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583774628792799233",
  "geo" : { },
  "id_str" : "583775010298310656",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  sweet drop at 00:39 tho",
  "id" : 583775010298310656,
  "in_reply_to_status_id" : 583774628792799233,
  "created_at" : "2015-04-02 23:36:23 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583774307660075008",
  "geo" : { },
  "id_str" : "583774628792799233",
  "in_reply_to_user_id" : 46961216,
  "text" : "unfortunately the bombing was distorted by the laptop mic rec, which was all that was available at the time",
  "id" : 583774628792799233,
  "in_reply_to_status_id" : 583774307660075008,
  "created_at" : "2015-04-02 23:34:52 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ry\u03B1\u03B7j",
      "screen_name" : "ryanj",
      "indices" : [ 36, 42 ],
      "id_str" : "14945367",
      "id" : 14945367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/mqhyWf7CBx",
      "expanded_url" : "https:\/\/soundcloud.com\/folkstack\/a-mic-on-the-wall",
      "display_url" : "soundcloud.com\/folkstack\/a-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583774307660075008",
  "text" : "here's a clip of a sesh with me and @ryanj \n\nlive coded carrier wave FM synth + 4 korgies on the floor\n\nhttps:\/\/t.co\/mqhyWf7CBx",
  "id" : 583774307660075008,
  "created_at" : "2015-04-02 23:33:35 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583772249179561985",
  "text" : "TIL that the autism spectrum goes from people don't believe in it, to people believe the fetus should be aborted.  Fuck shit!",
  "id" : 583772249179561985,
  "created_at" : "2015-04-02 23:25:24 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583757622882406401",
  "text" : "oops",
  "id" : 583757622882406401,
  "created_at" : "2015-04-02 22:27:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "johnny tha bodt",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/p0NnxqrDh9",
      "expanded_url" : "http:\/\/iamautistic.tumblr.com\/post\/104850984273\/trying-to-act-calm-in-an-anxiety-attack-like",
      "display_url" : "iamautistic.tumblr.com\/post\/104850984\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "583756614584246273",
  "geo" : { },
  "id_str" : "583756647593455618",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \nhttp:\/\/t.co\/p0NnxqrDh9",
  "id" : 583756647593455618,
  "in_reply_to_status_id" : 583756614584246273,
  "created_at" : "2015-04-02 22:23:25 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583756614584246273",
  "text" : "it's so true, I reinvented chill",
  "id" : 583756614584246273,
  "created_at" : "2015-04-02 22:23:17 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/W09G8yxZxv",
      "expanded_url" : "http:\/\/iamautistic.tumblr.com\/post\/108729464231\/finding-not-ableistic-people",
      "display_url" : "iamautistic.tumblr.com\/post\/108729464\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583753883471581185",
  "text" : "this is therapeutically hilarious http:\/\/t.co\/W09G8yxZxv",
  "id" : 583753883471581185,
  "created_at" : "2015-04-02 22:12:26 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Sb8p4t75W9",
      "expanded_url" : "http:\/\/iamautistic.tumblr.com\/post\/113139988266\/when-someone-asks-if-i-know-anything-about-what",
      "display_url" : "iamautistic.tumblr.com\/post\/113139988\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583752690938679296",
  "text" : "\"when someone asks if i know anything about what happens to be my obsession\u2026\"\n\nhttp:\/\/t.co\/Sb8p4t75W9",
  "id" : 583752690938679296,
  "created_at" : "2015-04-02 22:07:41 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/2arnKAZRld",
      "expanded_url" : "http:\/\/iamautistic.tumblr.com\/post\/113845813741\/seeing-something-soft-and-fluffy",
      "display_url" : "iamautistic.tumblr.com\/post\/113845813\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583752409366732801",
  "text" : "http:\/\/t.co\/2arnKAZRld",
  "id" : 583752409366732801,
  "created_at" : "2015-04-02 22:06:34 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583529816755867648",
  "text" : "I could have elaborated.  And I will not.",
  "id" : 583529816755867648,
  "created_at" : "2015-04-02 07:22:04 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583528873129742336",
  "text" : "I want everybody to know that soon my feed will be nothing but promos and hashtags dumps, and not a pretend hangout where I talk to myself.",
  "id" : 583528873129742336,
  "created_at" : "2015-04-02 07:18:19 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 0, 8 ],
      "id_str" : "185744472",
      "id" : 185744472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/GkokDDth1o",
      "expanded_url" : "http:\/\/requirebin.com\/?gist=316e9eceb140e8596550",
      "display_url" : "requirebin.com\/?gist=316e9ece\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "583451446177243136",
  "geo" : { },
  "id_str" : "583471965177909249",
  "in_reply_to_user_id" : 185744472,
  "text" : "@Cabbibo concurrent composition http:\/\/t.co\/GkokDDth1o",
  "id" : 583471965177909249,
  "in_reply_to_status_id" : 583451446177243136,
  "created_at" : "2015-04-02 03:32:11 +0000",
  "in_reply_to_screen_name" : "Cabbibo",
  "in_reply_to_user_id_str" : "185744472",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583434323665162241",
  "text" : "People sure put a lot of importance on sexual identity for how little sex they have.",
  "id" : 583434323665162241,
  "created_at" : "2015-04-02 01:02:37 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keegan Stephan",
      "screen_name" : "KeeganNYC",
      "indices" : [ 3, 13 ],
      "id_str" : "93879982",
      "id" : 93879982
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/KeeganNYC\/status\/583343096450183168\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZhNrrl1Wom",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBhzcs4VAAAfUXD.jpg",
      "id_str" : "583343088665427968",
      "id" : 583343088665427968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBhzcs4VAAAfUXD.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZhNrrl1Wom"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/t8ov71B7Ag",
      "expanded_url" : "http:\/\/m.dailykos.com\/story\/2015\/04\/01\/1374908\/-American-police-killed-more-people-in-March-111-than-in-the-entire-United-Kingdom-since-1900",
      "display_url" : "m.dailykos.com\/story\/2015\/04\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583421289014009856",
  "text" : "RT @KeeganNYC: U.S. police have killed more people since March 1st than U.K. police have killed since 1900: http:\/\/t.co\/t8ov71B7Ag http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/KeeganNYC\/status\/583343096450183168\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ZhNrrl1Wom",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBhzcs4VAAAfUXD.jpg",
        "id_str" : "583343088665427968",
        "id" : 583343088665427968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBhzcs4VAAAfUXD.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZhNrrl1Wom"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/t8ov71B7Ag",
        "expanded_url" : "http:\/\/m.dailykos.com\/story\/2015\/04\/01\/1374908\/-American-police-killed-more-people-in-March-111-than-in-the-entire-United-Kingdom-since-1900",
        "display_url" : "m.dailykos.com\/story\/2015\/04\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "583343096450183168",
    "text" : "U.S. police have killed more people since March 1st than U.K. police have killed since 1900: http:\/\/t.co\/t8ov71B7Ag http:\/\/t.co\/ZhNrrl1Wom",
    "id" : 583343096450183168,
    "created_at" : "2015-04-01 19:00:06 +0000",
    "user" : {
      "name" : "Keegan Stephan",
      "screen_name" : "KeeganNYC",
      "protected" : false,
      "id_str" : "93879982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696764273687715843\/7DcwCFz3_normal.png",
      "id" : 93879982,
      "verified" : false
    }
  },
  "id" : 583421289014009856,
  "created_at" : "2015-04-02 00:10:49 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583398984913297409",
  "text" : "siesta la vista",
  "id" : 583398984913297409,
  "created_at" : "2015-04-01 22:42:11 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 0, 12 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/583376385974005761\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/PRxkbeGYGi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBiRu1TUcAEZBNc.png",
      "id_str" : "583376385512599553",
      "id" : 583376385512599553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBiRu1TUcAEZBNc.png",
      "sizes" : [ {
        "h" : 359,
        "resize" : "fit",
        "w" : 1015
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 1015
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PRxkbeGYGi"
    } ],
    "hashtags" : [ {
      "text" : "YesAllWomen",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583372498303000576",
  "geo" : { },
  "id_str" : "583376385974005761",
  "in_reply_to_user_id" : 1484011428,
  "text" : "@marinakukso  jeezus #YesAllWomen is crawling with troll rejects and this guy's ads http:\/\/t.co\/PRxkbeGYGi",
  "id" : 583376385974005761,
  "in_reply_to_status_id" : 583372498303000576,
  "created_at" : "2015-04-01 21:12:23 +0000",
  "in_reply_to_screen_name" : "marinakukso",
  "in_reply_to_user_id_str" : "1484011428",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myles Borins",
      "screen_name" : "thealphanerd",
      "indices" : [ 0, 13 ],
      "id_str" : "150664007",
      "id" : 150664007
    }, {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "yoshuawuyts",
      "indices" : [ 14, 26 ],
      "id_str" : "39952227",
      "id" : 39952227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583360847348514816",
  "geo" : { },
  "id_str" : "583366696267694080",
  "in_reply_to_user_id" : 150664007,
  "text" : "@thealphanerd @yoshuawuyts  he meant \"Dangerous Palace\".  The danger is that you will never want to leave.",
  "id" : 583366696267694080,
  "in_reply_to_status_id" : 583360847348514816,
  "created_at" : "2015-04-01 20:33:53 +0000",
  "in_reply_to_screen_name" : "thealphanerd",
  "in_reply_to_user_id_str" : "150664007",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabbibo",
      "screen_name" : "Cabbibo",
      "indices" : [ 0, 8 ],
      "id_str" : "185744472",
      "id" : 185744472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583362606565445632",
  "geo" : { },
  "id_str" : "583365996020301824",
  "in_reply_to_user_id" : 185744472,
  "text" : "@Cabbibo  this is delicious",
  "id" : 583365996020301824,
  "in_reply_to_status_id" : 583362606565445632,
  "created_at" : "2015-04-01 20:31:06 +0000",
  "in_reply_to_screen_name" : "Cabbibo",
  "in_reply_to_user_id_str" : "185744472",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mx emily a rose",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    }, {
      "name" : "Spark is Particle",
      "screen_name" : "spark_io",
      "indices" : [ 11, 20 ],
      "id_str" : "3187046084",
      "id" : 3187046084
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 21, 33 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583363575395160064",
  "geo" : { },
  "id_str" : "583365896242003968",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove @spark_io @kickstarter  somebody please buy me one, i spend 70% of my income on rent.  Reward:  awkward friendship.",
  "id" : 583365896242003968,
  "in_reply_to_status_id" : 583363575395160064,
  "created_at" : "2015-04-01 20:30:42 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583353816461918208",
  "text" : "I have a couple deep groove(n) live code sessions jus chillin in my browser on pause.",
  "id" : 583353816461918208,
  "created_at" : "2015-04-01 19:42:42 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/kZjiCyS7R8",
      "expanded_url" : "https:\/\/github.com\/NHQ?tab=repositories",
      "display_url" : "github.com\/NHQ?tab=reposi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583327301653266432",
  "text" : "I like my GH pic cuz it makes me appear large, perhaps burly, when in fact I am petite.  It's like a joke.  https:\/\/t.co\/kZjiCyS7R8",
  "id" : 583327301653266432,
  "created_at" : "2015-04-01 17:57:21 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583320410118168576",
  "text" : "Music is the lowest level art.  It is radical in nature.  It is the entry point for major, popular shifts in technology.  qv. napster, BT...",
  "id" : 583320410118168576,
  "created_at" : "2015-04-01 17:29:57 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "indices" : [ 3, 17 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583313120912781313",
  "text" : "RT @modulhaus3000: HOWBOUT instead of a rich corporate label all star backed music streaming service, a distributed hack star lead open sou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583312688463233024",
    "text" : "HOWBOUT instead of a rich corporate label all star backed music streaming service, a distributed hack star lead open source p2p system?",
    "id" : 583312688463233024,
    "created_at" : "2015-04-01 16:59:17 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "modulhaus3000",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578767377573150721\/0jKA7W6H_normal.png",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 583313120912781313,
  "created_at" : "2015-04-01 17:01:00 +0000",
  "user" : {
    "name" : "johnny tha bodt",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725152025583853568\/So5ySFzo_normal.jpg",
    "id" : 46961216,
    "verified" : false
  }
} ]