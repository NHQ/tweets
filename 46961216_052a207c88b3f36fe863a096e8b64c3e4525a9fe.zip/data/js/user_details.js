var user_details =  {
  "screen_name" : "johnnyscript",
  "location" : "Oakland, CA",
  "full_name" : "johnny tha bodt",
  "bio" : "folk stack artist",
  "id" : "46961216",
  "created_at" : "2009-06-13 20:52:01 +0000"
}