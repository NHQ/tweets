var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2016_05.js",
  "year" : 2016,
  "var_name" : "tweets_2016_05",
  "tweet_count" : 52,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2016_04.js",
  "year" : 2016,
  "var_name" : "tweets_2016_04",
  "tweet_count" : 98,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2016_03.js",
  "year" : 2016,
  "var_name" : "tweets_2016_03",
  "tweet_count" : 67,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2016_02.js",
  "year" : 2016,
  "var_name" : "tweets_2016_02",
  "tweet_count" : 111,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2016_01.js",
  "year" : 2016,
  "var_name" : "tweets_2016_01",
  "tweet_count" : 98,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2015_12.js",
  "year" : 2015,
  "var_name" : "tweets_2015_12",
  "tweet_count" : 54,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2015_11.js",
  "year" : 2015,
  "var_name" : "tweets_2015_11",
  "tweet_count" : 66,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2015_10.js",
  "year" : 2015,
  "var_name" : "tweets_2015_10",
  "tweet_count" : 73,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2015_09.js",
  "year" : 2015,
  "var_name" : "tweets_2015_09",
  "tweet_count" : 79,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2015_08.js",
  "year" : 2015,
  "var_name" : "tweets_2015_08",
  "tweet_count" : 87,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2015_07.js",
  "year" : 2015,
  "var_name" : "tweets_2015_07",
  "tweet_count" : 75,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2015_06.js",
  "year" : 2015,
  "var_name" : "tweets_2015_06",
  "tweet_count" : 114,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2015_05.js",
  "year" : 2015,
  "var_name" : "tweets_2015_05",
  "tweet_count" : 165,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2015_04.js",
  "year" : 2015,
  "var_name" : "tweets_2015_04",
  "tweet_count" : 263,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2015_03.js",
  "year" : 2015,
  "var_name" : "tweets_2015_03",
  "tweet_count" : 242,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2015_02.js",
  "year" : 2015,
  "var_name" : "tweets_2015_02",
  "tweet_count" : 266,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2015_01.js",
  "year" : 2015,
  "var_name" : "tweets_2015_01",
  "tweet_count" : 110,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2014_12.js",
  "year" : 2014,
  "var_name" : "tweets_2014_12",
  "tweet_count" : 793,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2014_11.js",
  "year" : 2014,
  "var_name" : "tweets_2014_11",
  "tweet_count" : 518,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2014_10.js",
  "year" : 2014,
  "var_name" : "tweets_2014_10",
  "tweet_count" : 119,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2014_09.js",
  "year" : 2014,
  "var_name" : "tweets_2014_09",
  "tweet_count" : 342,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2014_08.js",
  "year" : 2014,
  "var_name" : "tweets_2014_08",
  "tweet_count" : 324,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2014_07.js",
  "year" : 2014,
  "var_name" : "tweets_2014_07",
  "tweet_count" : 51,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2014_06.js",
  "year" : 2014,
  "var_name" : "tweets_2014_06",
  "tweet_count" : 105,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2014_05.js",
  "year" : 2014,
  "var_name" : "tweets_2014_05",
  "tweet_count" : 207,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2014_04.js",
  "year" : 2014,
  "var_name" : "tweets_2014_04",
  "tweet_count" : 200,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2014_03.js",
  "year" : 2014,
  "var_name" : "tweets_2014_03",
  "tweet_count" : 143,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2014_02.js",
  "year" : 2014,
  "var_name" : "tweets_2014_02",
  "tweet_count" : 80,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2014_01.js",
  "year" : 2014,
  "var_name" : "tweets_2014_01",
  "tweet_count" : 92,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2013_12.js",
  "year" : 2013,
  "var_name" : "tweets_2013_12",
  "tweet_count" : 71,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2013_11.js",
  "year" : 2013,
  "var_name" : "tweets_2013_11",
  "tweet_count" : 164,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2013_10.js",
  "year" : 2013,
  "var_name" : "tweets_2013_10",
  "tweet_count" : 126,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2013_09.js",
  "year" : 2013,
  "var_name" : "tweets_2013_09",
  "tweet_count" : 107,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2013_08.js",
  "year" : 2013,
  "var_name" : "tweets_2013_08",
  "tweet_count" : 767,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2013_07.js",
  "year" : 2013,
  "var_name" : "tweets_2013_07",
  "tweet_count" : 178,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2013_06.js",
  "year" : 2013,
  "var_name" : "tweets_2013_06",
  "tweet_count" : 43,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2013_05.js",
  "year" : 2013,
  "var_name" : "tweets_2013_05",
  "tweet_count" : 83,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2013_04.js",
  "year" : 2013,
  "var_name" : "tweets_2013_04",
  "tweet_count" : 31,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2013_03.js",
  "year" : 2013,
  "var_name" : "tweets_2013_03",
  "tweet_count" : 62,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2013_02.js",
  "year" : 2013,
  "var_name" : "tweets_2013_02",
  "tweet_count" : 51,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2013_01.js",
  "year" : 2013,
  "var_name" : "tweets_2013_01",
  "tweet_count" : 52,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2012_12.js",
  "year" : 2012,
  "var_name" : "tweets_2012_12",
  "tweet_count" : 36,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2012_11.js",
  "year" : 2012,
  "var_name" : "tweets_2012_11",
  "tweet_count" : 32,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2012_10.js",
  "year" : 2012,
  "var_name" : "tweets_2012_10",
  "tweet_count" : 126,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2012_09.js",
  "year" : 2012,
  "var_name" : "tweets_2012_09",
  "tweet_count" : 99,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2012_08.js",
  "year" : 2012,
  "var_name" : "tweets_2012_08",
  "tweet_count" : 136,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2012_07.js",
  "year" : 2012,
  "var_name" : "tweets_2012_07",
  "tweet_count" : 84,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2012_06.js",
  "year" : 2012,
  "var_name" : "tweets_2012_06",
  "tweet_count" : 55,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2012_05.js",
  "year" : 2012,
  "var_name" : "tweets_2012_05",
  "tweet_count" : 51,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2012_04.js",
  "year" : 2012,
  "var_name" : "tweets_2012_04",
  "tweet_count" : 43,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2012_03.js",
  "year" : 2012,
  "var_name" : "tweets_2012_03",
  "tweet_count" : 20,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2012_02.js",
  "year" : 2012,
  "var_name" : "tweets_2012_02",
  "tweet_count" : 79,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2012_01.js",
  "year" : 2012,
  "var_name" : "tweets_2012_01",
  "tweet_count" : 82,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2011_12.js",
  "year" : 2011,
  "var_name" : "tweets_2011_12",
  "tweet_count" : 49,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2011_11.js",
  "year" : 2011,
  "var_name" : "tweets_2011_11",
  "tweet_count" : 27,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2011_10.js",
  "year" : 2011,
  "var_name" : "tweets_2011_10",
  "tweet_count" : 32,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2011_09.js",
  "year" : 2011,
  "var_name" : "tweets_2011_09",
  "tweet_count" : 41,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2011_08.js",
  "year" : 2011,
  "var_name" : "tweets_2011_08",
  "tweet_count" : 48,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2011_07.js",
  "year" : 2011,
  "var_name" : "tweets_2011_07",
  "tweet_count" : 43,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2011_06.js",
  "year" : 2011,
  "var_name" : "tweets_2011_06",
  "tweet_count" : 35,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2011_05.js",
  "year" : 2011,
  "var_name" : "tweets_2011_05",
  "tweet_count" : 39,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2011_04.js",
  "year" : 2011,
  "var_name" : "tweets_2011_04",
  "tweet_count" : 31,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2011_03.js",
  "year" : 2011,
  "var_name" : "tweets_2011_03",
  "tweet_count" : 28,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2011_02.js",
  "year" : 2011,
  "var_name" : "tweets_2011_02",
  "tweet_count" : 23,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2011_01.js",
  "year" : 2011,
  "var_name" : "tweets_2011_01",
  "tweet_count" : 18,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2010_12.js",
  "year" : 2010,
  "var_name" : "tweets_2010_12",
  "tweet_count" : 181,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2010_11.js",
  "year" : 2010,
  "var_name" : "tweets_2010_11",
  "tweet_count" : 99,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2010_10.js",
  "year" : 2010,
  "var_name" : "tweets_2010_10",
  "tweet_count" : 73,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2010_09.js",
  "year" : 2010,
  "var_name" : "tweets_2010_09",
  "tweet_count" : 28,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2010_08.js",
  "year" : 2010,
  "var_name" : "tweets_2010_08",
  "tweet_count" : 106,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2010_07.js",
  "year" : 2010,
  "var_name" : "tweets_2010_07",
  "tweet_count" : 13,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2010_06.js",
  "year" : 2010,
  "var_name" : "tweets_2010_06",
  "tweet_count" : 15,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2010_05.js",
  "year" : 2010,
  "var_name" : "tweets_2010_05",
  "tweet_count" : 172,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2010_04.js",
  "year" : 2010,
  "var_name" : "tweets_2010_04",
  "tweet_count" : 38,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2010_03.js",
  "year" : 2010,
  "var_name" : "tweets_2010_03",
  "tweet_count" : 52,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2010_02.js",
  "year" : 2010,
  "var_name" : "tweets_2010_02",
  "tweet_count" : 36,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2010_01.js",
  "year" : 2010,
  "var_name" : "tweets_2010_01",
  "tweet_count" : 172,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2009_12.js",
  "year" : 2009,
  "var_name" : "tweets_2009_12",
  "tweet_count" : 149,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2009_11.js",
  "year" : 2009,
  "var_name" : "tweets_2009_11",
  "tweet_count" : 145,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2009_10.js",
  "year" : 2009,
  "var_name" : "tweets_2009_10",
  "tweet_count" : 107,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2009_09.js",
  "year" : 2009,
  "var_name" : "tweets_2009_09",
  "tweet_count" : 58,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2009_08.js",
  "year" : 2009,
  "var_name" : "tweets_2009_08",
  "tweet_count" : 181,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2009_07.js",
  "year" : 2009,
  "var_name" : "tweets_2009_07",
  "tweet_count" : 57,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2009_06.js",
  "year" : 2009,
  "var_name" : "tweets_2009_06",
  "tweet_count" : 10,
  "month" : 6
} ]